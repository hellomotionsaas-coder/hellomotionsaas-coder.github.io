/*
 * MotionSaaS — the depth engine behind OS Kit → Depth reveal, run from the panel (Node), never from After
 * Effects: After Effects only says which file to process (MS.os("depthSource")) and imports the finished
 * map (MS.os("depthImport")), so it never waits on — or freezes for — the engine.
 *
 * Install (once, on request, with progress in the panel — no console windows):
 *   1. Python runtime: a standalone CPython .tar.gz, downloaded and unpacked here (gzip + a small tar reader).
 *   2. AI packages: pip, run with pythonw.exe on Windows (no window) / bin/python3 on macOS.
 *   3. Depth model: Depth Anything v2 small (ONNX).
 *   Everything lives in <user data>/MotionSaaS/depth; the runner is copied from extension/depth/.
 * Make a map: depth_runner.py in the background, its "Progress: frame i / n" lines drive the progress bar.
 *
 * Published as MSUI.depthEngine; the pure helpers (tar reader, log-line parsers) also as module.exports for
 * scripts/check.js. Chromium 61 / Node 8 safe: ES5, callbacks + Promises, no recursive mkdir.
 */
(function (root) {
  "use strict";

  /* ------------------------------------------------------------- pure helpers */

  function cstr(buf, off, len) {
    var end = off, max = off + len;
    while (end < max && buf[end] !== 0) end++;
    return buf.toString("utf8", off, end);
  }
  function octal(buf, off, len) { var s = cstr(buf, off, len).replace(/[^0-7]/g, ""); return s ? parseInt(s, 8) : 0; }

  // The entries of an (uncompressed) tar archive: { name, type: "file"|"dir"|"symlink"|"link", mode, offset,
  // size, link }. Understands ustar prefixes, GNU long names (L / K) and pax headers (x).
  function tarEntries(buf) {
    var out = [], off = 0, longName = null, longLink = null, pax = null, h, size, type, name, link, prefix, data, e;
    while (off + 512 <= buf.length) {
      h = off;
      if (buf[h] === 0 && cstr(buf, h, 100) === "") break;   // end-of-archive block
      size = octal(buf, h + 124, 12);
      type = String.fromCharCode(buf[h + 156] || 48);
      data = h + 512;
      if (type === "L" || type === "K") {
        if (type === "L") longName = cstr(buf, data, size); else longLink = cstr(buf, data, size);
      } else if (type === "x") {
        pax = parsePax(buf.toString("utf8", data, data + size));
      } else if (type === "g") {
        // global pax header: nothing we need
      } else {
        name = cstr(buf, h, 100);
        prefix = buf.toString("ascii", h + 257, h + 262) === "ustar" ? cstr(buf, h + 345, 155) : "";
        if (prefix) name = prefix + "/" + name;
        link = cstr(buf, h + 157, 100);
        if (pax && pax.path) name = pax.path;
        if (pax && pax.linkpath) link = pax.linkpath;
        if (pax && pax.size) size = +pax.size;
        if (longName !== null) name = longName;
        if (longLink !== null) link = longLink;
        e = { name: name, mode: octal(buf, h + 100, 8), offset: data, size: size, link: link,
          type: type === "5" ? "dir" : type === "2" ? "symlink" : type === "1" ? "link" : (type === "0" || type === "\0" || type === "7") ? "file" : "other" };
        if (e.type === "file" && /\/$/.test(e.name)) e.type = "dir";
        out.push(e);
        longName = longLink = pax = null;
      }
      off = data + Math.ceil(size / 512) * 512;
    }
    return out;
  }
  function parsePax(s) {
    var o = {}, i = 0, sp, len, rec, eq;
    while (i < s.length) {
      sp = s.indexOf(" ", i);
      if (sp < 0) break;
      len = parseInt(s.slice(i, sp), 10);
      if (!(len > 0)) break;
      rec = s.slice(sp + 1, i + len - 1);
      eq = rec.indexOf("=");
      if (eq > 0) o[rec.slice(0, eq)] = rec.slice(eq + 1);
      i += len;
    }
    return o;
  }
  // An archive path made safe to join under the install folder, or null (absolute paths, "..").
  function safeRel(name) {
    var norm = String(name).replace(/\\/g, "/"), parts = norm.split("/"), out = [], i;
    if (/^\//.test(norm) || /^[A-Za-z]:/.test(norm)) return null;
    for (i = 0; i < parts.length; i++) {
      if (parts[i] === "" || parts[i] === ".") continue;
      if (parts[i] === "..") return null;
      out.push(parts[i]);
    }
    return out.length ? out.join("/") : null;
  }
  // depth_runner.py output → { frame, total } / { device } / null
  function runnerLine(line) {
    var m = /^Progress: frame (\d+)(?: \/ (\d+))?/.exec(line);
    if (m) return { frame: +m[1], total: m[2] ? +m[2] : 0 };
    m = /^Compute device: (\S+)/.exec(line);
    if (m) return { device: m[1].replace(/ExecutionProvider$/, "") };
    return null;
  }
  // pip output → { collect } / { download, size } / { installing } / { done } / null
  function pipLine(line) {
    var m = /^\s*Collecting (\S+)/.exec(line);
    if (m) return { collect: m[1].replace(/[<>=!~;].*$/, "") };
    m = /^\s*Downloading (\S+?)(?:-\d[^\s]*)? \(([^)]+)\)/.exec(line);
    if (m) return { download: m[1], size: m[2] };
    if (/^\s*Installing collected packages/.test(line)) return { installing: true };
    if (/^\s*Successfully installed/.test(line) || /^\s*Requirement already satisfied/.test(line)) return { done: true };
    return null;
  }
  function mb(n) { return (n / 1048576).toFixed(n < 10485760 ? 1 : 0) + " MB"; }

  var pure = { tarEntries: tarEntries, safeRel: safeRel, runnerLine: runnerLine, pipLine: pipLine, mb: mb };
  if (typeof module !== "undefined" && module.exports) { module.exports = pure; }
  var MSUI = root && root.MSUI;
  if (!MSUI) return;

  /* ---------------------------------------------------------------- the engine */

  var URLS = {
    pyWin: "https://github.com/astral-sh/python-build-standalone/releases/download/20240814/cpython-3.11.9+20240814-x86_64-pc-windows-msvc-install_only.tar.gz",
    pyMacArm: "https://github.com/astral-sh/python-build-standalone/releases/download/20240814/cpython-3.11.9+20240814-aarch64-apple-darwin-install_only.tar.gz",
    pyMacX64: "https://github.com/astral-sh/python-build-standalone/releases/download/20240814/cpython-3.11.9+20240814-x86_64-apple-darwin-install_only.tar.gz",
    // Our own copy (public MotionSaas repo, pre-release "depth-model-v1" so it never counts as an app update).
    model: "https://github.com/hellomotionsaas-coder/MotionSaas/releases/download/depth-model-v1/depth_anything_v2_vits.onnx"
  };
  var MODEL_MIN = 60000000;
  // Depth Anything V2 Small (Apache-2.0), as published in that release: checked after every download.
  var MODEL_SHA256 = "afb6a5c28f3b6bf1618c6e43f02073ef9dfdc70e937502d51603e57b0a1df10c";
  var STEPS = [{ id: "python", label: "Python runtime" }, { id: "packages", label: "AI packages" }, { id: "model", label: "Depth model" }];

  function req(name) { try { return MSUI.node && MSUI.node.require ? MSUI.node.require(name) : null; } catch (e) { return null; } }
  var fs = MSUI.node && MSUI.node.fs, path = MSUI.node && MSUI.node.path;
  var proc = (root.cep_node && root.cep_node.process) || (typeof process !== "undefined" ? process : null);
  var isWin = proc ? proc.platform === "win32" : /Win/.test(navigator.platform);
  var current = null;   // the running job: { cancel() }

  function available() { return !!(proc && fs && path && req("https") && req("child_process") && req("zlib") && req("crypto") && MSUI.systemDir && MSUI.systemDir("userData")); }
  function paths() {
    var r = path.join(MSUI.systemDir("userData"), "MotionSaaS", "depth");
    return { root: r, py: path.join(r, "python", isWin ? "python.exe" : "bin/python3"), pyRun: path.join(r, "python", isWin ? "pythonw.exe" : "bin/python3"),
      model: path.join(r, "depth_anything_v2_vits.onnx"), runner: path.join(r, "depth_runner.py"), marker: path.join(r, "engine.json") };
  }
  function exists(p) { try { fs.statSync(p); return true; } catch (e) { return false; } }
  function size(p) { try { return fs.statSync(p).size; } catch (e) { return 0; } }
  function mkdirp(dir) {
    if (exists(dir)) return;
    mkdirp(path.dirname(dir));
    try { fs.mkdirSync(dir); } catch (e) { if (!exists(dir)) throw e; }
  }
  function rm(p) { try { fs.unlinkSync(p); } catch (e) {} }
  function packagesThere(P) {
    if (exists(P.marker)) return true;
    if (exists(path.join(P.root, "packages.partial"))) return false;   // a pip run that was stopped halfway
    // installs made before the marker existed: the packages' folders
    var sp = isWin ? [path.join(P.root, "python", "Lib", "site-packages")] : [];
    try { if (!isWin) fs.readdirSync(path.join(P.root, "python", "lib")).forEach(function (d) { if (/^python3/.test(d)) sp.push(path.join(P.root, "python", "lib", d, "site-packages")); }); } catch (e) {}
    return sp.some(function (d) { return exists(path.join(d, "onnxruntime")) && exists(path.join(d, "cv2")); });
  }
  // { installed, partial, folder, available }
  function status() {
    if (!available()) return { available: false, installed: false, partial: false };
    var P = paths(), py = exists(P.py) && exists(P.pyRun), model = size(P.model) > MODEL_MIN, pk = py && packagesThere(P);
    return { available: true, installed: py && model && pk, partial: py || model, folder: P.root };
  }

  // Download url → file, following redirects; onProgress(received, total, bytesPerSecond).
  function download(url, file, onProgress, job) {
    var https = req("https");
    return new Promise(function (resolve, reject) {
      var hops = 0;
      function get(u) {
        var r = https.get(u, { headers: { "User-Agent": "MotionSaaS" } }, function (res) {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && hops++ < 8) {
            res.resume();
            get(resolveUrl(u, res.headers.location));
            return;
          }
          if (res.statusCode !== 200) { res.resume(); reject(new Error("Download failed (HTTP " + res.statusCode + ")")); return; }
          var total = +res.headers["content-length"] || 0, got = 0, t0 = Date.now(), last = 0, out = fs.createWriteStream(file);
          res.on("data", function (chunk) {
            got += chunk.length;
            var now = Date.now();
            if (now - last > 200) { last = now; onProgress(got, total, got / Math.max(0.2, (now - t0) / 1000)); }
          });
          res.on("error", function (e) { out.destroy(); reject(e); });
          out.on("error", function (e) { r.abort(); reject(e); });
          out.on("finish", function () {
            if (job.cancelled) { reject(new Error("cancelled")); return; }
            if (total && got < total) { reject(new Error("The download was cut off — check your connection and try again")); return; }
            onProgress(got, total || got, 0);
            resolve(got);
          });
          res.pipe(out);
        });
        r.on("error", function (e) { reject(job.cancelled ? new Error("cancelled") : new Error("Couldn't download (" + e.message + ") — check your internet connection")); });
        r.setTimeout(45000, function () { r.abort(); });
        job.abort = function () { try { r.abort(); } catch (e) {} };
      }
      get(url);
    });
  }
  // SHA-256 of a file, streamed (the model is ~100 MB).
  function sha256(file) {
    var crypto = req("crypto");
    return new Promise(function (resolve, reject) {
      var h = crypto.createHash("sha256"), s = fs.createReadStream(file);
      s.on("data", function (d) { h.update(d); });
      s.on("error", reject);
      s.on("end", function () { resolve(h.digest("hex")); });
    });
  }
  function resolveUrl(base, loc) {
    try { return new URL(loc, base).href; } catch (e) { var u = req("url"); return u && u.resolve ? u.resolve(base, loc) : loc; }
  }

  // Unpack a .tar.gz into dir, a few hundred files per tick so the panel stays responsive.
  function untgz(file, dir, onProgress, job) {
    var zlib = req("zlib");
    return new Promise(function (resolve, reject) {
      fs.readFile(file, function (err, gz) {
        if (err) { reject(err); return; }
        zlib.gunzip(gz, function (err2, tar) {
          if (err2) { reject(new Error("The Python download is damaged — try again")); return; }
          var list = tarEntries(tar), i = 0, links = [];
          function step() {
            if (job.cancelled) { reject(new Error("cancelled")); return; }
            var end = Math.min(list.length, i + 250), e, rel, p;
            try {
              for (; i < end; i++) {
                e = list[i];
                rel = safeRel(e.name);
                if (!rel) continue;
                p = path.join(dir, rel);
                if (e.type === "dir") { mkdirp(p); continue; }
                if (e.type === "symlink" || e.type === "link") { links.push({ e: e, p: p }); continue; }
                if (e.type !== "file") continue;
                mkdirp(path.dirname(p));
                fs.writeFileSync(p, tar.slice(e.offset, e.offset + e.size));
                if (!isWin && e.mode) { try { fs.chmodSync(p, e.mode & 511); } catch (eM) {} }
              }
            } catch (eW) { reject(eW); return; }
            onProgress(i, list.length);
            if (i < list.length) { setTimeout(step, 0); return; }
            // links last, once their targets exist
            links.forEach(function (l) {
              try {
                rm(l.p);
                mkdirp(path.dirname(l.p));
                if (l.e.type === "symlink") fs.symlinkSync(l.e.link, l.p);
                else { var src = safeRel(l.e.link); if (src) fs.writeFileSync(l.p, fs.readFileSync(path.join(dir, src))); }
              } catch (eL) {}
            });
            resolve(list.length);
          }
          step();
        });
      });
    });
  }

  // Run a program with no window; onLine(text) per output line. Resolves with the exit code.
  function run(cmd, args, cwd, onLine, job) {
    var cp = req("child_process");
    return new Promise(function (resolve, reject) {
      var env = {}, k;
      for (k in proc.env) { if (proc.env.hasOwnProperty(k)) env[k] = proc.env[k]; }
      env.PYTHONUNBUFFERED = "1"; env.PYTHONNOUSERSITE = "1"; env.PIP_NO_INPUT = "1"; env.PYTHONIOENCODING = "utf-8";
      var ch;
      try { ch = cp.spawn(cmd, args, { cwd: cwd, env: env, windowsHide: true, stdio: ["ignore", "pipe", "pipe"] }); } catch (e) { reject(e); return; }
      var buf = "", tail = [];
      function feed(d) {
        buf += String(d);
        var parts = buf.split(/\r?\n|\r/);
        buf = parts.pop();
        parts.forEach(function (l) { if (!l) return; tail.push(l); if (tail.length > 12) tail.shift(); onLine(l); });
      }
      ch.stdout.on("data", feed);
      ch.stderr.on("data", feed);
      ch.on("error", reject);
      ch.on("close", function (code) { if (buf) feed(buf + "\n"); resolve({ code: code, tail: tail.join("\n") }); });
      job.abort = function () { try { ch.kill(); } catch (e) {} };
    });
  }

  function copyRunner(P) {
    var src = path.join(MSUI.systemDir("extension"), "depth", "depth_runner.py");
    fs.writeFileSync(P.runner, fs.readFileSync(src));
  }

  // Install whatever is missing. onUpdate({ steps: [{ id, label, state, pct, detail }] }) — state: "wait" |
  // "active" | "done" | "error"; pct 0..1 or null (busy, size unknown). Resolves when ready.
  function install(onUpdate) {
    if (current) return Promise.reject(new Error("The depth engine is busy"));
    if (!available()) return Promise.reject(new Error("The depth engine needs MotionSaaS inside After Effects"));
    var P = paths(), job = { cancelled: false, abort: null }, steps = STEPS.map(function (s) { return { id: s.id, label: s.label, state: "wait", pct: null, detail: "" }; });
    current = { kind: "install", cancel: function () { job.cancelled = true; if (job.abort) job.abort(); } };
    function set(i, o) { var k; for (k in o) { if (o.hasOwnProperty(k)) steps[i][k] = o[k]; } onUpdate({ steps: steps }); }
    function rate(got, total, bps) { return mb(got) + (total ? " of " + mb(total) : "") + (bps ? " · " + mb(bps) + "/s" : ""); }

    var pyUrl = isWin ? URLS.pyWin : (proc.arch === "arm64" ? URLS.pyMacArm : URLS.pyMacX64), tgz = path.join(P.root, "python.tar.gz");
    var chain = Promise.resolve().then(function () { mkdirp(P.root); copyRunner(P); });
    function stopIfCancelled() { if (job.cancelled) throw new Error("cancelled"); }
    // 1. Python
    chain = chain.then(function () {
      stopIfCancelled();
      if (exists(P.py) && exists(P.pyRun)) { set(0, { state: "done", pct: 1, detail: "Already installed" }); return; }
      set(0, { state: "active", pct: 0, detail: "Connecting…" });
      return download(pyUrl, tgz, function (got, total, bps) { set(0, { pct: total ? got / total * 0.7 : null, detail: "Downloading · " + rate(got, total, bps) }); }, job)
        .then(function () {
          set(0, { pct: 0.7, detail: "Unpacking…" });
          return untgz(tgz, P.root, function (n, all) { set(0, { pct: 0.7 + 0.3 * n / Math.max(1, all), detail: "Unpacking · " + n + " of " + all + " files" }); }, job);
        })
        .then(function () {
          rm(tgz);
          if (!exists(P.py)) throw new Error("Python didn't unpack correctly — try again");
          set(0, { state: "done", pct: 1, detail: "Python 3.11" });
        });
    });
    // 2. packages: done when the finished-install marker is there, or when Python can actually import them
    chain = chain.then(function () {
      stopIfCancelled();
      if (exists(P.marker)) { set(1, { state: "done", pct: 1, detail: "Already installed" }); return; }
      set(1, { state: "active", pct: null, detail: "Checking…" });
      return run(P.pyRun, ["-c", "import onnxruntime, cv2, numpy, imageio"], P.root, function () {}, job).then(function (r) {
        stopIfCancelled();
        if (r.code === 0 && !exists(path.join(P.root, "packages.partial"))) { set(1, { state: "done", pct: 1, detail: "Already installed" }); return; }
        return pipInstall();
      });
    });
    function pipInstall() {
      var seen = 0, EXPECT = 14, partial = path.join(P.root, "packages.partial");
      fs.writeFileSync(partial, "pip install started " + new Date().toISOString());
      set(1, { state: "active", pct: 0.02, detail: "Starting…" });
      return run(P.pyRun, ["-m", "pip", "install", "--disable-pip-version-check", "--no-warn-script-location", "--progress-bar", "off",
        isWin ? "onnxruntime-directml" : "onnxruntime", "opencv-python-headless", "numpy", "imageio", "imageio-ffmpeg"], P.root, function (l) {
        var p = pipLine(l);
        if (!p) return;
        if (p.collect) { seen++; set(1, { pct: Math.min(0.6, seen / EXPECT * 0.6), detail: "Getting " + p.collect }); }
        else if (p.download) set(1, { detail: "Downloading " + p.download + " (" + p.size + ")" });
        else if (p.installing) set(1, { pct: 0.75, detail: "Installing…" });
      }, job).then(function (r) {
        if (job.cancelled) throw new Error("cancelled");
        if (r.code !== 0) throw new Error("Installing the AI packages failed:\n" + r.tail);
        rm(partial);
        set(1, { state: "done", pct: 1, detail: "onnxruntime, OpenCV, NumPy, imageio" });
      });
    }
    // 3. model
    chain = chain.then(function () {
      stopIfCancelled();
      if (size(P.model) > MODEL_MIN) { set(2, { state: "done", pct: 1, detail: "Already installed" }); return; }
      set(2, { state: "active", pct: 0, detail: "Connecting…" });
      var tmp = P.model + ".tmp";
      return download(URLS.model, tmp, function (got, total, bps) { set(2, { pct: total ? got / total : null, detail: "Downloading · " + rate(got, total, bps) }); }, job)
        .then(function () {
          if (size(tmp) < MODEL_MIN) throw new Error("The depth model download is incomplete — try again");
          set(2, { pct: 1, detail: "Checking the download…" });
          return sha256(tmp);
        })
        .then(function (hash) {
          if (hash !== MODEL_SHA256) { rm(tmp); throw new Error("The depth model download was damaged — try again"); }
          rm(P.model);
          fs.renameSync(tmp, P.model);
          set(2, { state: "done", pct: 1, detail: "Depth Anything v2 (small)" });
        });
    });
    return chain.then(function () {
      fs.writeFileSync(P.marker, JSON.stringify({ version: 1, installed: new Date().toISOString() }));
      current = null;
      return status();
    }, function (e) {
      current = null;
      for (var i = 0; i < steps.length; i++) { if (steps[i].state === "active") set(i, { state: "error", detail: job.cancelled ? "Cancelled" : String(e.message || e).split("\n")[0] }); }
      throw job.cancelled ? new Error("cancelled") : e;
    });
  }

  // Make the depth map for src ({ file, video }). onUpdate({ pct 0..1 | null, detail }). Resolves { map, sequence }.
  function makeMap(src, opts, onUpdate) {
    if (current) return Promise.reject(new Error("The depth engine is busy"));
    var P = paths(), job = { cancelled: false, abort: null };
    if (!status().installed) return Promise.reject(new Error("ENGINE"));
    current = { kind: "map", cancel: function () { job.cancelled = true; if (job.abort) job.abort(); } };
    var base = path.basename(src.file).replace(/\.[^.]+$/, ""), out = path.join(P.root, "maps", base.replace(/[^A-Za-z0-9._-]/g, "_") + "_" + Date.now()), device = "";
    return Promise.resolve().then(function () {
      mkdirp(out);
      copyRunner(P);
      fs.writeFileSync(path.join(out, "job.txt"), src.file + "\n" + out + "\n" + (opts && opts.invert ? "1" : "0") + "\n");
      onUpdate({ pct: null, detail: "Starting the depth engine…" });
      return run(P.pyRun, [P.runner, "--model", P.model, "--job", path.join(out, "job.txt")], P.root, function (l) {
        var r = runnerLine(l);
        if (!r) return;
        if (r.device) { device = r.device; onUpdate({ pct: null, detail: src.video ? "Reading frames · " + device : "Thinking · " + device }); }
        else onUpdate({ pct: r.total ? r.frame / r.total : null, detail: "Frame " + r.frame + (r.total ? " of " + r.total : "") + (device ? " · " + device : "") });
      }, job);
    }).then(function () {
      current = null;
      if (job.cancelled) throw new Error("cancelled");
      var done = "";
      try { done = String(fs.readFileSync(path.join(out, "done.txt"), "utf8")); } catch (e) {}
      if (done.indexOf("OK") !== 0) {
        var log = "";
        try { log = String(fs.readFileSync(path.join(out, "log.txt"), "utf8")); } catch (e2) {}
        throw new Error("The depth engine couldn't read that file" + (log ? ":\n" + log.slice(-300) : ""));
      }
      return src.video ? { map: path.join(out, "depth_00001.png"), sequence: true } : { map: path.join(out, base + "_depth.png"), sequence: false };
    }, function (e) { current = null; throw job.cancelled ? new Error("cancelled") : e; });
  }

  MSUI.depthEngine = {
    available: available, status: status, install: install, makeMap: makeMap, steps: STEPS,
    busy: function () { return current ? current.kind : null; },
    cancel: function () { if (current) current.cancel(); }
  };
})(typeof window !== "undefined" ? window : this);
