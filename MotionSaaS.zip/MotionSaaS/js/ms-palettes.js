/*
 * MotionSaaS — Palettes: one palette library for every place in the panel that offers colours (SaaS Kit →
 * Palettes, Comp Tools → Colours). Merged from the separate MotionSaaS Petals extension.
 * - A library of palettes: the built-in ones (js/ms-palette-core.js), your own (stored locally,
 *   ms_palettes) and the ones saved in the open project ("In project", read from After Effects).
 * - Click a swatch to colour the selected layers. With "Link" on, the layers are linked to that swatch
 *   instead (MS.paletteLink, jsx/host.jsx): edit the swatch later and every linked layer in every comp follows.
 * - The editor: change, add, remove and reorder swatches, rename, generate harmonies from a swatch or palettes
 *   from a described vibe, grab the colours the selected layers use, import / export Adobe .ase swatch files.
 * Mounted with MSUI.palettes.mount(element, { compact }) — every mount shows the same library and stays in sync.
 * MSUI.palettes.active() is the active palette (SaaS Kit mesh backgrounds and templates use its colours).
 */
(function () {
  "use strict";

  var MSUI = window.MSUI, K = MSUI.paletteCore;
  if (!K) { return; }
  var KEY = "ms_palettes", inCEP = !!(window.__adobe_cep__ && window.__adobe_cep__.evalScript);
  var st = MSUI.store.get(KEY, null) || {};
  var S = {
    mine: st.mine instanceof Array ? st.mine.filter(valid) : [],
    active: st.active || MSUI.store.get("ms_palette", "Apple"),
    link: !!st.link,
    sel: 0,                                   // the swatch being edited in the active palette
    mode: st.mode || "analogous",
    count: st.count || 5
  };
  var project = [];                           // palettes saved in the open project (After Effects)
  var used = null;                            // colours the selection uses, after "From selection"
  var mounts = [];

  function valid(p) { return p && typeof p.name === "string" && p.colors instanceof Array && p.colors.length > 0; }
  function save() { MSUI.store.set(KEY, { mine: S.mine, active: S.active, link: S.link, mode: S.mode, count: S.count }); }
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; }
  function btn(cls, text, title, fn) {
    var b = el("button", cls + " pl-b", text);   // pl-b: not restyled as an ordinary panel button (ms-extra.css)
    b.type = "button";
    if (title) b.title = title;
    b.addEventListener("click", fn);
    return b;
  }
  function find(list, name) { for (var i = 0; i < list.length; i++) { if (list[i].name === name) return list[i]; } return null; }
  function inProject(name) { return !!find(project, name); }
  // Every palette, de-duplicated by name: project first (it's what the layers use), then yours, then built-in.
  function all() {
    var out = [], seen = {};
    [["project", project], ["mine", S.mine], ["builtin", K.BUILTIN]].forEach(function (g) {
      g[1].forEach(function (p) { if (!seen[p.name]) { seen[p.name] = 1; out.push({ name: p.name, colors: p.colors, kind: g[0] }); } });
    });
    return out;
  }
  function active() { var a = all(); return find(a, S.active) || a[0]; }
  function uniqueName(base) {
    var a = all(), n = base, i = 2;
    while (find(a, n)) { n = base + " " + i++; }
    return n;
  }
  function copyText(t) {
    var done = function () { MSUI.toast("Copied " + t); };
    if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(t).then(done, function () { MSUI.toast("Couldn't copy", true); }); return; }
    var ta = el("textarea");
    ta.value = t; document.body.appendChild(ta); ta.select();
    try { document.execCommand("copy"); done(); } catch (e) { MSUI.toast("Couldn't copy", true); }
    document.body.removeChild(ta);
  }

  /* ---------------------------------------------------------- editing */

  // The active palette as an editable one of yours: a built-in palette is copied first ("Apple copy").
  function editable() {
    var p = active();
    if (p.kind === "builtin") {
      var copy = { name: uniqueName(p.name + " copy"), colors: p.colors.slice() };
      S.mine.unshift(copy);
      S.active = copy.name;
      MSUI.toast("Editing your copy: " + copy.name);
      return copy;
    }
    if (p.kind === "project" && !find(S.mine, p.name)) { S.mine.unshift({ name: p.name, colors: p.colors.slice() }); }
    return find(S.mine, p.name);
  }
  var syncT = 0;
  // Something changed: store it, redraw every mount, and push a project palette's colours to After Effects
  // (its linked layers follow).
  function changed(pal) {
    save();
    render();
    if (!pal || !inProject(pal.name) || !inCEP) return;
    var pr = find(project, pal.name);
    pr.colors = pal.colors.slice();
    clearTimeout(syncT);
    syncT = setTimeout(function () {
      MSUI.host("MS.paletteSync", [JSON.stringify({ name: pal.name, colors: pal.colors })]).then(function (r) {
        if (String(r).indexOf("ERR|") === 0) MSUI.toast(String(r).slice(4), true);
      });
    }, 160);
  }
  function setColor(i, hex) {
    var h = K.norm(hex);
    if (!h) return;
    var p = editable();
    p.colors[i] = h;
    S.sel = i;
    changed(p);
  }
  function addSwatch() {
    var p = editable();
    if (p.colors.length >= 12) { MSUI.toast("A palette holds up to 12 colours", true); return; }
    var base = p.colors[S.sel] || p.colors[p.colors.length - 1], c = K.hsl(base);
    p.colors.splice(S.sel + 1, 0, K.fromHsl(c[0] + 24, c[1], c[2]));
    S.sel = S.sel + 1;
    changed(p);
  }
  function removeSwatch() {
    var p = editable();
    if (p.colors.length <= 1) { MSUI.toast("A palette needs at least one colour", true); return; }
    if (inProject(p.name) && S.sel === p.colors.length - 1) {
      // Linked layers point at swatch numbers: removing the last one leaves them on its old colour.
      MSUI.toast("Layers linked to colour " + (S.sel + 1) + " keep its last colour");
    }
    p.colors.splice(S.sel, 1);
    S.sel = Math.max(0, S.sel - 1);
    changed(p);
  }
  function moveSwatch(d) {
    var p = editable(), j = S.sel + d;
    if (j < 0 || j >= p.colors.length) return;
    var t = p.colors[j]; p.colors[j] = p.colors[S.sel]; p.colors[S.sel] = t;
    S.sel = j;
    changed(p);
  }
  function rename() {
    var p = active();
    if (p.kind === "builtin") { MSUI.toast("Built-in palettes keep their names — edit a colour to make your own copy"); return; }
    MSUI.ask("Rename palette", inProject(p.name) ? "Linked layers in this project follow the new name." : "", p.name, "Rename").then(function (name) {
      if (!name || name === p.name) return;
      name = name.slice(0, 40);
      if (find(all(), name)) { MSUI.toast("There's already a palette called " + name, true); return; }
      var go = function () {
        var m = find(S.mine, p.name);
        if (m) m.name = name;
        var pr = find(project, p.name);
        if (pr) pr.name = name;
        S.active = name;
        changed(m || pr);
      };
      if (inProject(p.name) && inCEP) {
        MSUI.host("MS.paletteRename", [p.name, name]).then(function (r) {
          if (String(r).indexOf("OK|") !== 0) { MSUI.toast(String(r).replace(/^ERR\|/, ""), true); return; }
          go();
        });
      } else { go(); }
    });
  }
  function remove() {
    var p = active();
    if (p.kind === "builtin") return;
    var note = inProject(p.name) ? "It's removed from this panel; the copy saved in your project (and its linked layers) stays." : "Your palette is removed from this panel.";
    MSUI.confirm("Delete “" + p.name + "”?", note, "Delete").then(function (ok) {
      if (!ok) return;
      S.mine = S.mine.filter(function (m) { return m.name !== p.name; });
      if (!inProject(p.name)) S.active = K.BUILTIN[0].name;
      S.sel = 0;
      changed(null);
    });
  }
  function addPalette(name, colors, quiet) {
    var p = { name: uniqueName(name), colors: colors.slice(0, 12) };
    S.mine.unshift(p);
    S.active = p.name;
    S.sel = 0;
    changed(null);
    if (!quiet) MSUI.toast("Saved “" + p.name + "”");
    return p;
  }
  function generate() {
    var p = active(), base = p.colors[S.sel] || p.colors[0];
    var cols = K.harmony(base, S.mode, S.count, Math.floor(Math.random() * 1e9));
    var label = (find(K.MODES.map(function (m) { return { name: m[0], label: m[1] }; }), S.mode) || { label: "Harmony" }).label;
    addPalette(label + " " + K.name(base).toLowerCase(), cols, true);
  }
  function fromMood(text) {
    text = String(text || "").trim();
    if (!text) { MSUI.toast("Describe a vibe first, e.g. “calm fintech”", true); return; }
    addPalette(text.charAt(0).toUpperCase() + text.slice(1, 32), K.mood(text, S.count), true);
  }

  /* ------------------------------------------------------ After Effects */

  function applySwatch(p, i) {
    var hex = p.colors[i];
    if (!inCEP) { MSUI.toast((S.link ? "Link " : "Colour ") + hex + " (open MotionSaaS in After Effects)"); return; }
    if (S.link) {
      MSUI.host("MS.paletteLink", [JSON.stringify({ name: p.name, colors: p.colors }), i + 1]).then(function (r) {
        MSUI.report(r);
        if (String(r).indexOf("OK|") === 0) refreshProject();
      });
    } else {
      MSUI.host("MS.color", [hex]).then(function (r) { MSUI.report(r); });
    }
  }
  function unlink() {
    if (!inCEP) return;
    MSUI.host("MS.paletteUnlink", []).then(function (r) { MSUI.report(r); });
  }
  function refreshProject() {
    if (!inCEP) return;
    MSUI.host("MS.paletteProject", []).then(function (r) {
      r = String(r || "");
      if (r.indexOf("OK|") !== 0) return;
      var list;
      try { list = JSON.parse(r.slice(3)); } catch (e) { return; }
      var before = JSON.stringify(project);
      project = list instanceof Array ? list.filter(valid) : [];
      if (JSON.stringify(project) !== before) render();
    });
  }
  function grabUsed() {
    if (!inCEP) { used = ["#0A84FF", "#30D158", "#FF9F0A", "#FFFFFF", "#1C1C1E"]; render(); return; }
    MSUI.host("MS.paletteUsed", []).then(function (r) {
      r = String(r || "");
      if (r.indexOf("OK|") !== 0) { MSUI.report(r); return; }
      try { used = JSON.parse(r.slice(3)); } catch (e) { used = []; }
      if (!used.length) MSUI.toast("No colours found on those layers");
      render();
    });
  }

  /* ------------------------------------------------------ .ase files */

  function exportAse(every) {
    var list = every ? S.mine.concat(project) : [active()], node = MSUI.node || {}, fs = node.fs, path = node.path;
    if (!list.length) { MSUI.toast("Nothing to export yet", true); return; }
    var bytes = K.ase(list.map(function (p) { return { name: p.name, colors: p.colors }; }));
    var fileName = (every ? "MotionSaaS palettes" : active().name).replace(/[\\\/:*?"<>|]+/g, "-") + ".ase";
    if (!fs || !path) { MSUI.toast("Exporting needs MotionSaaS inside After Effects", true); return; }
    var target = "";
    try {
      var cfs = window.cep && window.cep.fs;
      var docs = (MSUI.systemDir && MSUI.systemDir("documents")) || "";
      var dir = docs ? path.join(path.dirname(docs), "Desktop") : "";
      if (dir && !fs.existsSync(dir)) dir = docs;
      if (cfs && cfs.showSaveDialogEx) {
        var r = cfs.showSaveDialogEx("Export swatches", dir, ["ase"], fileName);
        if (!r || r.err !== 0 || !r.data) return;   // cancelled
        target = String(r.data);
        if (!/\.ase$/i.test(target)) target += ".ase";
      } else {
        target = path.join(dir, fileName);
      }
      fs.writeFileSync(target, bytes);   // Node 8+ writes a Uint8Array as is
      MSUI.toast("Saved " + path.basename(target) + " · open it in Illustrator, Photoshop or InDesign", false, 4500);
    } catch (e) {
      MSUI.toast("Couldn't save the swatches: " + e.message, true);
    }
  }
  function importAse() {
    var node = MSUI.node || {}, fs = node.fs, path = node.path;
    if (!fs || !window.CEP) { MSUI.toast("Importing needs MotionSaaS inside After Effects", true); return; }
    var files = window.CEP.pickFiles({ title: "Import swatches (.ase)", types: ["ase"] });
    if (!files.length) return;
    try {
      var got = K.parseAse(fs.readFileSync(files[0]), path.basename(files[0]).replace(/\.ase$/i, ""));
      if (!got.length) { MSUI.toast("No colours in that file", true); return; }
      got.slice(0, 20).forEach(function (p) { addPalette(p.name.slice(0, 40), p.colors, true); });
      MSUI.toast("Imported " + got.length + " palette" + (got.length === 1 ? "" : "s"));
    } catch (e) {
      MSUI.toast(e.message, true);
    }
  }

  /* ---------------------------------------------------------- drawing */

  function swatchBtn(hex, cls, title, onClick) {
    var b = btn("pl-sw" + (cls ? " " + cls : ""), "", title, onClick);
    b.style.setProperty("background", hex, "important");   // the base CSS gives buttons an !important background
    b.style.setProperty("color", K.ink(hex), "important");
    b.addEventListener("contextmenu", function (e) { e.preventDefault(); copyText(hex); });
    return b;
  }
  function strip(p, big) {
    var s = el("div", "pl-strip" + (big ? " pl-strip-big" : ""));
    p.colors.forEach(function (hex, i) {
      var title = K.name(hex) + " · " + hex + "\n" + (S.link ? "Click: link the selected layers to this colour" : "Click: colour the selected layers") + "\nRight-click: copy the hex code";
      var b = swatchBtn(hex, big && i === S.sel ? "on" : "", title, function () {
        if (big) { S.sel = i; render(); return; }
        applySwatch(p, i);
      });
      if (big) {
        b.appendChild(el("span", "pl-hex", hex.slice(1)));
        b.addEventListener("dblclick", function () { applySwatch(p, i); });
        b.title = K.name(hex) + " · " + hex + "\nClick: edit · Double-click: " + (S.link ? "link" : "colour") + " the selection";
      }
      s.appendChild(b);
    });
    return s;
  }
  function row(p) {
    var r = el("div", "pl-row" + (p.name === active().name ? " active" : "")), head = el("div", "pl-row-head"), nm = el("button", "pl-name pl-b", p.name);
    nm.type = "button";
    nm.title = "Make this the active palette";
    nm.addEventListener("click", function () { S.active = p.name; S.sel = 0; save(); render(); });
    head.appendChild(nm);
    if (p.kind === "project") head.appendChild(el("em", "pl-tag pl-tag-proj", "In project"));
    else if (p.kind === "mine") head.appendChild(el("em", "pl-tag", "Yours"));
    if (p.name === active().name) head.appendChild(el("em", "pl-tag pl-tag-on", "Active"));
    r.appendChild(head);
    r.appendChild(strip(p, false));
    return r;
  }
  function switchEl(on, onChange) {
    var sw = el("label", "ms-switch"), input = el("input");
    input.type = "checkbox"; input.checked = on;
    input.addEventListener("change", function () { onChange(input.checked); });
    sw.appendChild(input); sw.appendChild(el("span", "ms-slider"));
    return sw;
  }

  function draw(box, opts) {
    while (box.firstChild) box.removeChild(box.firstChild);
    var p = active(), wrap = el("div", "pl" + (opts.compact ? " pl-compact" : ""));

    // Link bar
    var bar = el("div", "pl-bar"), lk = el("div", "pl-link");
    lk.appendChild(switchEl(S.link, function (on) { S.link = on; save(); render(); if (on) MSUI.toast("Link on: swatches now link the selected layers"); }));
    var lt = el("div", "pl-link-text");
    lt.appendChild(el("b", "", "Link to layers"));
    lt.appendChild(el("span", "", S.link ? "Edit a swatch later: linked layers follow, in every comp" : "Off: swatches simply colour the selection"));
    lk.appendChild(lt);
    bar.appendChild(lk);
    if (S.link) bar.appendChild(btn("pl-mini", "Unlink", "Remove the palette link from the selected layers (they keep their colours)", unlink));
    wrap.appendChild(bar);

    // Library
    var lib = el("div", "pl-lib");
    all().forEach(function (x) { lib.appendChild(row(x)); });
    wrap.appendChild(lib);

    // Colours the selection uses (Petals' "used colours")
    var ub = el("div", "pl-used");
    var uh = el("div", "pl-sub pl-sub-row", "Colours in use");
    uh.appendChild(btn("pl-mini", "🎯 From selection", "Collect the colours the selected layers use (all layers when none is selected)", grabUsed));
    ub.appendChild(uh);
    if (used && used.length) {
      var us = el("div", "pl-strip");
      used.forEach(function (hex) {
        us.appendChild(swatchBtn(hex, "", K.name(hex) + " · " + hex + "\nClick: colour the selection · Right-click: copy", function () {
          if (inCEP) MSUI.host("MS.color", [hex]).then(MSUI.report);
        }));
      });
      ub.appendChild(us);
      ub.appendChild(btn("pl-mini pl-save-used", "Save as palette", "Keep these colours as a palette of yours", function () { addPalette("From selection", used); used = null; render(); }));
    }
    wrap.appendChild(ub);

    if (!opts.compact) {
      // Editor for the active palette
      var ed = el("div", "pl-editor"), eh = el("div", "pl-sub pl-sub-row");
      var title = el("span", "pl-ed-title", p.name);
      eh.appendChild(title);
      var tools = el("span", "pl-tools");
      tools.appendChild(btn("pl-icon", "✏️", "Rename", rename));
      if (p.kind !== "builtin") tools.appendChild(btn("pl-icon", "🗑️", "Delete this palette", remove));
      eh.appendChild(tools);
      ed.appendChild(eh);
      S.sel = Math.max(0, Math.min(S.sel, p.colors.length - 1));
      ed.appendChild(strip(p, true));
      var cur = p.colors[S.sel], line = el("div", "pl-edit-line"), pick = el("input"), hx = el("input", "pl-hex-in");
      pick.type = "color"; pick.value = cur.toLowerCase(); pick.className = "pl-pick";
      pick.addEventListener("change", function () { setColor(S.sel, pick.value); });
      hx.type = "text"; hx.value = cur; hx.maxLength = 7; hx.setAttribute("spellcheck", "false");
      hx.addEventListener("keydown", function (e) { if (e.key === "Enter") setColor(S.sel, hx.value); });
      hx.addEventListener("blur", function () { if (K.norm(hx.value) && K.norm(hx.value) !== cur) setColor(S.sel, hx.value); });
      line.appendChild(pick);
      line.appendChild(hx);
      line.appendChild(el("span", "pl-cname", K.name(cur)));
      line.appendChild(btn("pl-icon", "◀", "Move left", function () { moveSwatch(-1); }));
      line.appendChild(btn("pl-icon", "▶", "Move right", function () { moveSwatch(1); }));
      line.appendChild(btn("pl-icon", "＋", "Add a colour after this one", addSwatch));
      line.appendChild(btn("pl-icon", "－", "Remove this colour", removeSwatch));
      ed.appendChild(line);
      var ct = K.contrast(cur, "#FFFFFF"), ck = K.contrast(cur, "#000000");
      ed.appendChild(el("div", "pl-note", "Contrast · white text " + ct.toFixed(1) + ":1" + (ct >= 4.5 ? " ✓" : "") + " · black text " + ck.toFixed(1) + ":1" + (ck >= 4.5 ? " ✓" : "")));
      wrap.appendChild(ed);

      // Generator
      var gen = el("div", "pl-gen");
      gen.appendChild(el("div", "pl-sub", "Generate from " + K.name(cur).toLowerCase()));
      var chips = el("div", "pl-chips");
      K.MODES.forEach(function (m) {
        var c = btn("pl-chip" + (S.mode === m[0] ? " on" : ""), m[1], "", function () { S.mode = m[0]; save(); render(); });
        chips.appendChild(c);
      });
      gen.appendChild(chips);
      var preview = el("div", "pl-strip pl-preview");
      K.harmony(cur, S.mode, S.count, 7).forEach(function (h) { var d = el("span", "pl-sw"); d.style.background = h; preview.appendChild(d); });
      gen.appendChild(preview);
      var gl = el("div", "pl-gen-line"), cnt = el("select", "pl-count");
      [3, 4, 5, 6, 7, 8].forEach(function (n) { var o = el("option", "", n + " colours"); o.value = n; if (n === S.count) o.selected = true; cnt.appendChild(o); });
      cnt.addEventListener("change", function () { S.count = Number(cnt.value); save(); render(); });
      gl.appendChild(cnt);
      gl.appendChild(btn("btn-accent pl-go", "Generate", "Save a new palette in this harmony", generate));
      gen.appendChild(gl);
      var ml = el("div", "pl-gen-line"), mood = el("input", "pl-mood");
      mood.type = "text"; mood.placeholder = "Or describe a vibe: “calm fintech”, “neon night”…"; mood.maxLength = 60;
      mood.addEventListener("keydown", function (e) { if (e.key === "Enter") fromMood(mood.value); });
      ml.appendChild(mood);
      ml.appendChild(btn("pl-mini", "✨ Make", "Make a palette from the words", function () { fromMood(mood.value); }));
      gen.appendChild(ml);
      wrap.appendChild(gen);

      // Files
      var fl = el("div", "pl-files");
      fl.appendChild(btn("pl-mini", "⬇️ Export .ase", "Save the active palette as an Adobe swatch file (Shift-click: all of yours)", function (e) { exportAse(!!e.shiftKey); }));
      fl.appendChild(btn("pl-mini", "⬆️ Import .ase", "Add palettes from an Adobe swatch file (Illustrator, Photoshop, InDesign, Coolors…)", importAse));
      fl.appendChild(btn("pl-mini", "📋 Copy hex", "Copy the active palette's hex codes", function () { copyText(p.colors.join(", ")); }));
      wrap.appendChild(fl);
    }
    box.appendChild(wrap);
    if (MSUI.panelRangeFill) MSUI.panelRangeFill(box);
  }

  function render() { mounts.forEach(function (m) { if (document.body.contains(m.el)) draw(m.el, m.opts); }); }

  MSUI.palettes = {
    mount: function (box, opts) {
      if (!box) return;
      mounts.push({ el: box, opts: opts || {} });
      draw(box, opts || {});
      refreshProject();
    },
    active: function () { return active(); },
    refresh: refreshProject
  };
  // The project changes under us (another project opened, palettes linked from another panel): check again
  // when the panel gets focus.
  window.addEventListener("focus", refreshProject);
})();
