/*
 * MotionSaaS — OS Kit panel (index.html #oskit-tab): the MotionSaaS OS 2.0 extension's tools — its own code and
 * presets (jsx/os2/, extension/os2/) — in the MotionSaaS panel style. Every tool runs MS.os(cmd, payloadJSON)
 * (jsx/os.jsx), which calls OS 2.0's function for it.
 * Layout: one grid of every tool (small group labels, no tabs), each tile a small animated preview of what it does → the
 * picked tool's settings (inspector) → one Apply bar that says what the tool needs selected, checked live
 * against After Effects (MS.os("osProbe"), polled while the panel is shown). Double-click a tile to apply it.
 * - Versions: tools from OS 2.0's presets need AE 2022+, its cursor / background projects AE 2024+; the tile
 *   says so up front on an older After Effects.
 * - SVG import: OS 2.0's: gradients baked here as presets (js/ms-ffx-gradient.js), the layers built by
 *   jsx/os2/svg.jsx. From a .svg file, or SVG code pasted in (Figma → Copy as SVG).
 * - Depth reveal: the depth engine (js/ms-depth.js: Python + an ONNX model, ~400 MB) installs once, on request,
 *   in the background with its progress shown in the card; maps are made the same way, so After Effects never waits.
 * - The user's last choices are kept (MSUI.store "ms_oskit").
 * Chromium 61 safe (AE 2020): ES5 only. Previews are static artwork; names and paths never go into HTML strings.
 */
(function () {
  "use strict";

  var MSUI = window.MSUI;
  var $ = function (id) { return document.getElementById(id); };
  var inCEP = !!(window.__adobe_cep__ && window.__adobe_cep__.evalScript);
  var KEY = "ms_oskit";
  var opt = MSUI.store.get(KEY, null) || {};
  if (!opt || typeof opt !== "object" || opt instanceof Array) opt = {};
  var probe = { comp: !inCEP, sel: 0, text: 0, shape: 0, footage: 0, props: 0 };
  var busy = false;

  function save() { MSUI.store.set(KEY, opt); }
  function get(id, k, d) { var o = opt[id]; return o && typeof o === "object" && o.hasOwnProperty(k) ? o[k] : d; }
  function put(id, k, v) { if (!opt[id] || typeof opt[id] !== "object") opt[id] = {}; opt[id][k] = v; save(); }
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; }
  function clear(box) { while (box && box.firstChild) box.removeChild(box.firstChild); }
  function shown() { var t = $("oskit-tab"); return !!t && t.classList.contains("active"); }
  function plural(n, w) { return n + " " + w + (n === 1 ? "" : "s"); }

  /* ------------------------------------------------------------ After Effects */

  var reloaded = false;
  // Run an OS Kit tool. Resolves with the raw "OK|…" / "ERR|…". If the engine isn't loaded (os.jsx failed or
  // an older host.jsx is running), load it once and try again.
  function os(cmd, payload) {
    var go = function () { return MSUI.host("MS.os", [cmd, JSON.stringify(payload || {})]); };
    return go().then(function (r) {
      r = String(r || "");
      if (!inCEP || reloaded || !/^EvalScript error|MS\.os|is not a function/i.test(r)) return r;
      reloaded = true;
      var dir = MSUI.systemDir ? MSUI.systemDir("extension") : "";
      return MSUI.host("MS.loadOS", [dir ? dir.replace(/\\/g, "/") + "/jsx/os.jsx" : null]).then(go);
    });
  }
  function report(r) {
    r = String(r || "");
    if (r.indexOf("OK|") === 0) { MSUI.toast(r.slice(3) || "Done"); return true; }
    MSUI.toast(r.replace(/^ERR\|/, "").replace(/^EvalScript error\.?/i, "After Effects couldn't run that tool") || "Something went wrong", true);
    return false;
  }
  function needAE() {
    if (inCEP) return true;
    MSUI.toast("Open MotionSaaS in After Effects to use OS Kit", true);
    return false;
  }

  var probing = false;
  function poll() {
    if (!inCEP || probing || !shown() || document.body.classList.contains("ms-tool-covered")) return;
    probing = true;
    os("osProbe").then(function (r) {
      probing = false;
      r = String(r || "");
      if (r.indexOf("OK|") !== 0) return;
      try { probe = JSON.parse(r.slice(3)); } catch (e) { return; }
      renderNeeds();
    }, function () { probing = false; });
  }

  /* ------------------------------------------------------------------ artwork */

  // Line icons (inspector header) and the tiles' animated previews (css/ms-extra.css, .pv-*). Static only.
  var ICON = {
    typing: '<path d="M4 6h10M9 6v12"/><path d="M17 9v9"/><path d="M15.5 9h3M15.5 18h3"/>',
    reveal: '<path d="M4 18h16"/><path d="M7 14l2-6 2 6M7.7 12h2.6"/><path d="M14 8h3.2a2 2 0 0 1 0 4H14zm0 4h3.6a2 2 0 0 1 0 4H14"/>',
    explode: '<rect x="3.5" y="9" width="5" height="6" rx="1.2"/><rect x="10" y="5" width="5" height="6" rx="1.2"/><rect x="15.5" y="12" width="5" height="6" rx="1.2"/>',
    stagger: '<rect x="4" y="5" width="12" height="3" rx="1.5"/><rect x="6" y="10.5" width="12" height="3" rx="1.5"/><rect x="8" y="16" width="12" height="3" rx="1.5"/>',
    bounce: '<path d="M3 18h18"/><path d="M4 18c2-12 4-12 6 0 1.2-6 2.8-6 4 0 .7-3 1.6-3 2.3 0 .4-1.4.9-1.4 1.3 0"/>',
    glitchWipe: '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M4 9h7M13 9h7M4 13h4M10 13h10M4 17h9"/>',
    gradientWipe: '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M12 4v16"/><path d="M15 4l-6 16" opacity=".5"/>',
    depth: '<path d="M3 17l5-6 4 4 3-3 6 5"/><circle cx="16" cy="7" r="2"/><path d="M3 20h18"/>',
    cursor: '<path d="M6 4l11 8-5 1-2.5 5z"/>',
    proximity: '<circle cx="12" cy="12" r="2.5"/><circle cx="12" cy="12" r="6" opacity=".6"/><circle cx="12" cy="12" r="9.3" opacity=".35"/>',
    glass: '<rect x="4" y="6" width="16" height="12" rx="3.5"/><path d="M8 9.5l3-1.5M7.5 12.5l6-3"/>',
    counter: '<path d="M5 8l2-1.5V17"/><path d="M11 8.5a2.5 2.5 0 0 1 5 .5c0 2-5 4.5-5 8h5"/><path d="M19 6v4"/>',
    carousel: '<ellipse cx="12" cy="12" rx="9" ry="4"/><rect x="9" y="5" width="6" height="8" rx="1.4"/>',
    attach: '<rect x="4" y="4" width="7" height="7" rx="1.5"/><path d="M7.5 11v4.5h5M7.5 15.5V20h5"/><rect x="13" y="13" width="7" height="5" rx="1.5"/>',
    background: '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="3"/><circle cx="15" cy="14" r="3.5"/>',
    svgFile: '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4"/><path d="M9 16c1.5-4 4.5-4 6 0"/>',
    svgPaste: '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V3h6v1"/><path d="M8.5 11l-2 2 2 2M15.5 11l2 2-2 2M13 10l-2 6"/>'
  };
  var PREV = {
    typing: '<div class="pv-type"><span>Hello</span><i></i></div>',
    reveal: '<div class="pv-reveal"><b>M</b><b>o</b><b>t</b><b>i</b><b>o</b><b>n</b></div>',
    explode: '<div class="pv-explode"><b>A</b><b>B</b><b>C</b></div>',
    stagger: '<div class="pv-stagger"><i></i><i></i><i></i></div>',
    bounce: '<div class="pv-bounce"><u></u><i></i></div>',
    glitchWipe: '<div class="pv-glitch"><i></i><i></i><i></i><i></i></div>',
    gradientWipe: '<div class="pv-gwipe"><b><i></i></b></div>',
    depth: '<div class="pv-depth"><i></i><i></i><i></i><b></b></div>',
    cursor: '<div class="pv-cursor"><b></b><u></u><i><svg viewBox="0 0 24 24"><path d="M5 3l13 9-6 1.4-3 5.6z"/></svg></i></div>',
    proximity: '<div class="pv-prox"><i></i><i></i><i></i><i></i><i></i><u></u></div>',
    glass: '<div class="pv-glass"><i></i><i></i><b><s></s></b></div>',
    counter: '<div class="pv-count"><em>$</em><span><b>1</b><b>2</b><b>4</b><b>7</b><b>9</b></span><em>k</em></div>',
    carousel: '<div class="pv-car"><i></i><i></i><i></i><i></i></div>',
    attach: '<div class="pv-attach"><b></b><i></i><i></i><i></i></div>',
    svgFile: '<div class="pv-svg"><svg viewBox="0 0 80 48"><path d="M8 38C18 6 30 6 40 24S62 42 72 10"/><circle cx="8" cy="38" r="3"/><circle cx="72" cy="10" r="3"/></svg></div>',
    svgPaste: '<div class="pv-code"><i></i><i></i><i></i><i></i></div>'
  };
  function icon(name) {
    var s = el("span", "os-ico");
    s.innerHTML = '<svg viewBox="0 0 24 24">' + (ICON[name] || "") + "</svg>";
    return s;
  }

  /* -------------------------------------------------------------------- needs */

  // What each tool needs selected → { ok, text } from the latest probe. `soft`: works either way.
  var NEEDS = {
    text: function (p) { return p.text ? { ok: true, text: plural(p.text, "text layer") } : { ok: false, text: "Select a text layer" }; },
    text1: function (p) { return p.text === 1 ? { ok: true, text: "1 text layer" } : { ok: false, text: p.text > 1 ? "Select just one text layer" : "Select one text layer" }; },
    layers: function (p) { return p.sel ? { ok: true, text: plural(p.sel, "layer") } : { ok: false, text: "Select the layers" }; },
    layer: function (p) { return p.sel ? { ok: true, text: p.sel === 1 ? "1 layer" : plural(p.sel, "layer") + " · uses the first" } : { ok: false, text: "Select the layer to reveal" }; },
    props: function (p) { return p.props ? { ok: true, text: plural(p.props, "property") + " selected" } : { ok: false, text: "Select keyframed properties (2+ keys)" }; },
    shape: function (p) { return p.shape ? { ok: true, text: plural(p.shape, "shape layer") } : { ok: false, text: "Select a shape layer" }; },
    target: function (p) { return { ok: true, soft: true, text: p.sel ? "Clicks the selected layer" : "No button selected: the cursor only plays" }; },
    wrap: function (p) { return { ok: true, soft: true, text: p.sel ? "Attaches to the first selected layer" : "Nothing selected: spans the comp" }; },
    comp: function () { return { ok: true, soft: true, text: "Adds to the active comp" }; },
    footage: function (p) { return p.footage ? { ok: true, text: plural(p.footage, "photo / video layer") } : { ok: false, text: "Select a photo or video layer" }; },
    none: function () { return { ok: true, soft: true, text: "" }; }
  };
  function needOf(t) {
    if (!inCEP) return { ok: true, soft: true, text: "Preview · open MotionSaaS in After Effects to apply" };
    // OS 2.0's presets load from AE 2022, its project rigs (cursors, backgrounds) from AE 2024
    if (t.min && aeMajor() < t.min) return { ok: false, text: "Needs After Effects " + (t.min + 2000) + " or newer" };
    if (!probe.comp && t.need !== "none") return { ok: false, text: "Open a composition" };
    return (NEEDS[t.need || "none"] || NEEDS.none)(probe);
  }
  function renderNeeds() {
    var t = current(), r = needOf(t), n = $("osBarNeed");
    if (t.id === "depth" && dstate && !dstate.ended) {   // the engine at work: its progress
      r = { ok: true, soft: true, text: dstate.kind === "map" ? "Making the depth map…" + (dstate.pct !== null ? " " + Math.round(dstate.pct * 100) + "%" : "") : "Installing the depth engine…" };
    }
    if (n) {
      n.textContent = r.text ? (r.ok && !r.soft ? "✓ " : "") + r.text : "";
      n.className = "os-bar-need" + (r.ok ? (r.soft ? "" : " ok") : " miss");
    }
    // a dot on each tile in view whose needs the selection meets
    Array.prototype.forEach.call(document.querySelectorAll("#osGrid .os-tile"), function (b) {
      var tt = TOOL[b.getAttribute("data-os-tool")], rr = tt ? needOf(tt) : null;
      b.classList.toggle("fits", !!(inCEP && rr && rr.ok && !rr.soft));
    });
  }

  /* --------------------------------------------------------------- controls */

  function chips(box, id, key, items, def, onPick) {
    var row = el("div", "os-chips"), cur = get(id, key, def);
    items.forEach(function (it) {
      var b = el("button", "os-chip" + (it[0] === cur ? " active" : ""), it[1]);
      b.type = "button";
      if (it[2]) b.title = it[2];
      b.addEventListener("click", function () {
        Array.prototype.forEach.call(row.children, function (x) { x.classList.remove("active"); });
        b.classList.add("active");
        put(id, key, it[0]);
        if (onPick) onPick(it[0]);
      });
      row.appendChild(b);
    });
    box.appendChild(row);
    return row;
  }
  function label(box, text) { box.appendChild(el("div", "os-label", text)); }
  function note(box, text) { box.appendChild(el("div", "os-note", text)); }

  /* -------------------------------------------------------------------- tools */
  // The MotionSaaS OS 2.0 tools, as OS 2.0 offered them (same names, same variants). `min`: the oldest After
  // Effects the tool runs on — 2022 for tools built from OS 2.0's presets (its own version patch), 2024 for the
  // ones built from its .aep projects (cursor rigs, backgrounds); script-only tools run everywhere.

  var CATS = [["text", "Text"], ["motion", "Animate"], ["transitions", "Transitions"], ["interaction", "Interaction"],
    ["elements", "Elements"], ["backgrounds", "Backgrounds"], ["rigging", "Rigging"], ["svg", "SVG import"]];
  // OS 2.0's eight gradients and their colours (BG_GRADS in jsx/os2/kit.jsx), for the tiles.
  var BG = [
    ["Gradient 1", ["#530AFF", "#8C5BFF", "#D6C7F9"]], ["Gradient 2", ["#6035FB", "#7BFBFF", "#6035FB"]],
    ["Gradient 4", ["#145EFF", "#92C5FF", "#145EFF"]], ["Gradient 5", ["#9D55FF", "#5569FF", "#FFFFFF"]],
    ["Gradient 6", ["#3A86FB", "#E1EDFF", "#3A86FB"]], ["Gradient 7", ["#8C3AFB", "#AF54FC", "#8C3AFB"]],
    ["Gradient 8", ["#8C3AFB", "#AF54FC", "#5B1FD1"]], ["Star Gradient", ["#0030FF", "#FFFFFF", "#0030FF"]]
  ];
  function simple(cmd) { return function () { return os(cmd, {}).then(report); }; }

  var LIST = [
    { id: "typing", cat: "text", name: "Typing", min: 22, need: "text",
      desc: "Letters type on. Coloured Typing and Typewriter are OS 2.0's presets; Random Letters adds a glowing copy (Deep Glow, when installed).",
      options: function (o) { label(o, "Style"); chips(o, "typing", "variant", [["coloured", "Coloured Typing"], ["random", "Random Letters"], ["typewriter", "Typewriter"]], "coloured"); },
      run: function () { return os("typing", { variant: get("typing", "variant", "coloured") }).then(report); } },
    { id: "reveal", cat: "text", name: "Text Reveal", min: 0, need: "text",
      desc: "Characters or words rise in one after another. Shape it with the Position, Scale, Rotation, Skew, Opacity and Blur effects on the layer.",
      options: function (o) { label(o, "Reveal"); chips(o, "reveal", "by", [["chars", "Characters"], ["words", "Words"]], "chars"); },
      run: function () { return os("textReveal", { by: get("reveal", "by", "chars") }).then(report); } },
    { id: "explode", cat: "text", name: "Exploder", min: 0, need: "text1", button: "Explode",
      desc: "Splits the text layer into one layer per letter, word or line; the original is switched off.",
      options: function (o) { label(o, "Explode"); chips(o, "explode", "by", [["letters", "Letters"], ["words", "Words"], ["lines", "Lines"]], "letters"); },
      run: function () { return os("explode", { by: get("explode", "by", "letters") }).then(report); } },

    { id: "stagger", cat: "motion", name: "UI Stagger", min: 22, need: "layers",
      desc: "The selected layers animate in one after another with OS 2.0's stagger curve. Change Stagger Frames, Position, Scale and Opacity From on UI Stagger Controls — then select that controller and apply again to re-time.",
      run: simple("stagger") },
    { id: "bounce", cat: "motion", name: "Bounce", min: 0, need: "props",
      desc: "An elastic overshoot after the keyframes of the selected properties, with Bounce Amp / Freq / Decay sliders on the layer.",
      run: simple("bounce") },

    { id: "glitchWipe", cat: "transitions", name: "Glitch Wipe", min: 22, need: "layer",
      desc: "Reveals the selected layer with OS 2.0's mosaic / turbulence edge and gradient glow. Wipe, Direction and Radial are on the Wipe Controller.",
      run: simple("glitchWipe") },
    { id: "gradientWipe", cat: "transitions", name: "Gradient Wipe", min: 0, need: "layer",
      desc: "A colour gradient sweeps across and reveals each selected layer. Progress, Angle and the two colours are on Gradient Wipe Controls.",
      run: simple("gradientWipe") },
    { id: "depth", cat: "transitions", name: "Depth Reveal", min: 22, button: "Make", need: "footage",
      desc: "Reveals a photo or video from near to far with OS 2.0's Depth Reveal rigs, using a depth map made on your computer.",
      options: function (o) {
        label(o, "Look");
        chips(o, "depth", "variant", [["1", "Depth Reveal 1"], ["2", "Depth Reveal 2"], ["3", "Depth Reveal 3"]], "1");
        o.appendChild(engineBox());
      },
      run: function () { depthMake(); } },

    { id: "cursor", cat: "interaction", name: "Cursor", min: 24, need: "target", button: "Add",
      desc: "OS 2.0's animated cursor rigs. Select the button it should click; the button gets the click scale and colour.",
      options: function (o) { label(o, "Cursor"); chips(o, "cursor", "variant", [["1", "Cursor 1"], ["2", "Cursor 2"], ["3", "Cursor 3"]], "1"); },
      run: function () { return os("cursor", { variant: get("cursor", "variant", "1") }).then(report); } },
    { id: "proximity", cat: "interaction", name: "Proximity Hover", min: 0, need: "layers",
      desc: "The selected layers grow (and optionally lean in or fade) as the Proximity Target null comes near. Animate the target.",
      run: simple("proximity") },

    { id: "counter", cat: "elements", name: "Number Counter", min: 22, need: "text",
      desc: "OS 2.0's counter preset on the selected text layer: counts 0 → 1000 over 60 frames. Format, separators and symbols are on its Num effect.",
      run: simple("counter") },
    { id: "carousel", cat: "elements", name: "Carousel", min: 0, need: "layers",
      desc: "OS 2.0's 3D carousel: the selected layers circle a Carousel null (Radius, Start Angle, Tilt X / Y).",
      options: function (o) {
        var b = el("button", "os-mini", "Open the Carousel panel");
        b.type = "button";
        b.title = "MotionSaaS's full Carousel: sphere, ring, grid or path layouts with a live preview";
        b.addEventListener("click", function () { if (MSUI.studio && MSUI.studio.openPanel) MSUI.studio.openPanel("carousel"); });
        o.appendChild(b);
      },
      run: simple("carousel") },
    { id: "glass", cat: "elements", name: "Glass", min: 22, need: "shape",
      desc: "OS 2.0's glass from a shape layer: a blurred base plus two styled copies. Blur is on Glass Controls.",
      run: simple("glass") },

    { id: "attach", cat: "rigging", name: "Attach Layer", min: 0, need: "wrap", button: "Add",
      desc: "Adds a null, solid or adjustment layer above the selected layer, trimmed to it, and makes it the layer's parent.",
      options: function (o) { label(o, "Layer"); chips(o, "attach", "kind", [["null", "Null"], ["solid", "Solid"], ["adjustment", "Adjustment"]], "null"); },
      run: function () { return os("attach", { kind: get("attach", "kind", "null") }).then(report); } },

    { id: "svgFile", cat: "svg", name: "SVG file", min: 0, need: "comp", button: "Choose file",
      desc: "OS 2.0's SVG import: shape layers with fills, strokes, gradients, opacity and blur from an .svg file.",
      run: svgPickFile },
    { id: "svgPaste", cat: "svg", name: "Paste SVG", min: 0, need: "comp", button: "Import",
      desc: "From Figma: right-click a frame → Copy as → Copy as SVG, then paste it below.",
      options: function (o) {
        var ta = el("textarea", "os-svg-code");
        ta.id = "osSvgCode";
        ta.spellcheck = false;
        ta.placeholder = "<svg …>  paste here";
        ta.value = pasteDraft;
        ta.addEventListener("input", function () { pasteDraft = ta.value; });
        o.appendChild(ta);
      },
      run: svgPasteImport }
  ];
  BG.forEach(function (b) {
    LIST.push({ id: "bg-" + b[0].replace(/\s+/g, ""), cat: "backgrounds", name: b[0], bg: b[1], min: 24, need: "comp", button: "Add",
      desc: "OS 2.0's animated gradient background, at the bottom of the comp. Its colours are on the Colour Control layer above it.",
      run: function () { return os("background", { name: b[0] }).then(report); } });
  });
  var TOOL = {};
  LIST.forEach(function (t) { TOOL[t.id] = t; });
  var pasteDraft = "";

  function bgColors(id) { return TOOL[id].bg; }

  function current() { return TOOL[opt.tool] || LIST[0]; }

  /* ------------------------------------------------------------------- render */

  function paintTile(id) {
    var t = TOOL[id], tile = document.querySelector('#osGrid [data-os-tool="' + id + '"] .pv-bg');
    if (!t || !t.bg || !tile) return;
    var c = bgColors(id);
    tile.style.backgroundColor = c[0];
    tile.children[0].style.backgroundColor = c[1];
    tile.children[1].style.backgroundColor = c[2];
  }
  function tile(t) {
    var b = el("button", "os-tile" + (t === current() ? " active" : "")), pv = el("span", "os-prev");
    b.type = "button";
    b.setAttribute("data-os-tool", t.id);
    b.setAttribute("data-os-cat", t.cat);
    b.title = t.desc + " (double-click to apply)";
    if (t.bg) {
      var bg = el("span", "pv-bg");
      bg.appendChild(el("i"));
      bg.appendChild(el("i"));
      bg.appendChild(el("b"));
      pv.appendChild(bg);
    } else {
      pv.innerHTML = PREV[t.id] || "";
    }
    b.appendChild(pv);
    b.appendChild(el("span", "os-tile-name", t.name));
    b.appendChild(el("span", "os-fit"));
    b.addEventListener("click", function () {
      opt.tool = t.id;
      save();
      Array.prototype.forEach.call(b.parentNode.querySelectorAll(".os-tile"), function (x) { x.classList.toggle("active", x === b); });
      renderInspector();
    });
    b.addEventListener("dblclick", function () { apply(); });
    return b;
  }
  // Every tool in one grid; a small label (spanning the row) starts each group.
  function renderGrid() {
    var box = $("osGrid"), insp = $("osInspector");
    if (!box) return;
    if (insp && insp.parentNode === box) box.parentNode.appendChild(insp);   // keep it out of the clear
    clear(box);
    CATS.forEach(function (c) {
      box.appendChild(el("div", "os-group", c[1]));
      LIST.forEach(function (t) { if (t.cat === c[0]) { box.appendChild(tile(t)); if (t.bg) paintTile(t.id); } });
    });
  }
  // Wide panels: the settings card sits beside the grid. Narrow ones: it opens right under the picked tool's
  // group, so it's never a long scroll away from the tile that was clicked.
  function placeInspector() {
    var insp = $("osInspector"), grid = $("osGrid"), t = current();
    if (!insp || !grid || !t) return;
    var wide = !!(window.matchMedia && window.matchMedia("(min-width: 820px)").matches), tiles, last;
    if (wide) {
      if (insp.parentNode !== grid.parentNode) grid.parentNode.appendChild(insp);
      insp.classList.remove("os-insp-inline");
      return;
    }
    tiles = grid.querySelectorAll('.os-tile[data-os-cat="' + t.cat + '"]');
    last = tiles[tiles.length - 1];
    if (last && last.nextSibling !== insp) grid.insertBefore(insp, last.nextSibling);
    insp.classList.add("os-insp-inline");
  }
  function renderInspector() {
    var box = $("osInspector"), t = current();
    if (!box || !t) return;
    placeInspector();
    clear(box);
    var head = el("div", "os-insp-head"), txt = el("div", "os-insp-text");
    head.appendChild(icon(t.bg ? "background" : t.id));
    txt.appendChild(el("div", "os-insp-name", t.name));
    txt.appendChild(el("div", "os-insp-desc", t.desc));
    head.appendChild(txt);
    box.appendChild(head);
    if (t.options) {
      var o = el("div", "os-opts");
      t.options(o);
      if (o.childNodes.length) box.appendChild(o);
    }
    if (MSUI.panelRangeFill) MSUI.panelRangeFill(box);
    $("osBarTool").textContent = t.name;
    $("osApply").textContent = t.button || "Apply";
    renderNeeds();
  }
  function renderAll() { renderGrid(); renderInspector(); if (MSUI.gapFix) MSUI.gapFix(); }

  function apply() {
    var t = current(), btn = $("osApply");
    if (!t || busy) return;
    if (t.id !== "carousel" && t.id !== "svgFile" && t.id !== "svgPaste" && !needAE()) return;
    busy = true;
    btn.disabled = true;
    var done = function () { busy = false; btn.disabled = false; setTimeout(poll, 150); };
    var p;
    try { p = t.run(); } catch (e) { MSUI.toast(e.message, true); }
    if (p && p.then) p.then(done, done); else done();
  }

  /* -------------------------------------------------------------- depth reveal */

  // The engine runs in the panel (js/ms-depth.js), in the background, with its progress shown here: the
  // install as three steps with progress bars, a map as one bar with Stop. After Effects is only asked which
  // file to use (depthSource) and, at the end, to import the map and build the reveal (depthImport).
  var D = MSUI.depthEngine, dstate = null, dEngine = null;
  function depthStatus() { dEngine = D && D.available() ? D.status() : null; return dEngine; }
  function depthInstall() {
    if (!needAE()) return;
    if (!D || !D.available()) { MSUI.toast("The depth engine needs MotionSaaS inside After Effects", true); return; }
    if (D.busy()) { MSUI.toast("The depth engine is already working — see its progress in Depth reveal"); return; }
    MSUI.confirm("Install the depth engine?",
      "Depth reveal uses a small AI engine that runs on your computer. MotionSaaS downloads it once — Python, a few AI packages and the depth model, about 400 MB — into its own folder. It installs in the background, so you can keep working.",
      "Install").then(function (ok) { if (ok) startInstall(); });
  }
  function startInstall() {
    dstate = { kind: "install", steps: D.steps.map(function (s) { return { id: s.id, label: s.label, state: "wait", pct: null, detail: "" }; }) };
    paintDepth();
    D.install(function (u) { if (dstate && dstate.kind === "install") { dstate.steps = u.steps; paintDepth(); } }).then(function () {
      dstate = null;
      depthStatus();
      paintDepth();
      MSUI.toast("The depth engine is ready — select a photo or video and click Make");
    }, function (e) {
      var msg = String(e && e.message || e);
      if (dstate) { dstate.ended = true; dstate.error = msg === "cancelled" ? "" : msg.split("\n")[0]; }
      depthStatus();
      paintDepth();
      MSUI.toast(msg === "cancelled" ? "Install stopped — click Install to pick up where it left off" : msg.split("\n")[0], msg !== "cancelled");
    });
  }
  function depthMake() {
    if (!needAE()) return;
    if (D && D.busy()) { MSUI.toast("The depth engine is already working — see its progress in Depth reveal"); return; }
    depthStatus();
    if (!dEngine || !dEngine.installed) { depthInstall(); return; }
    os("depthSource").then(function (r) {
      r = String(r || "");
      if (r.indexOf("OK|") !== 0) { report(r); return; }
      var src;
      try { src = JSON.parse(r.slice(3)); } catch (e) { MSUI.toast("After Effects sent an unreadable answer", true); return; }
      dstate = { kind: "map", name: src.name, pct: null, detail: "Starting the depth engine…" };
      paintDepth();
      D.makeMap(src, {}, function (u) { if (dstate && dstate.kind === "map") { dstate.pct = u.pct; dstate.detail = u.detail; paintDepth(); } }).then(function (res) {
        dstate.pct = 1;
        dstate.detail = "Building the reveal in After Effects…";
        paintDepth();
        return os("depthImport", { map: res.map, sequence: res.sequence, comp: src.comp, index: src.index, name: src.name, variant: get("depth", "variant", "1") });
      }).then(function (r2) {
        dstate = null;
        paintDepth();
        report(r2);
        setTimeout(poll, 150);
      }, function (e) {
        var msg = String(e && e.message || e);
        dstate = null;
        paintDepth();
        MSUI.toast(msg === "cancelled" ? "Stopped" : msg.split("\n")[0], msg !== "cancelled");
      });
    });
  }
  function bar(pct) {
    var b = el("div", "os-prog" + (pct === null || pct === undefined ? " busy" : "")), f = el("i");
    if (pct !== null && pct !== undefined) f.style.width = Math.round(Math.max(0, Math.min(1, pct)) * 100) + "%";
    b.appendChild(f);
    return b;
  }
  function miniBtn(text, fn, primary) {
    var b = el("button", "os-mini" + (primary ? " os-mini-go" : ""), text);
    b.type = "button";
    b.addEventListener("click", fn);
    return b;
  }
  function engineBox() {
    var box = el("div", "os-engine");
    box.id = "osEngine";
    fillEngine(box);
    return box;
  }
  function fillEngine(box) {
    clear(box);
    var head = el("div", "os-engine-head"), dot = el("span", "os-dot"), txt = el("span", "os-engine-text"), i, s, row, ico, body, top;
    head.appendChild(dot);
    head.appendChild(txt);
    box.appendChild(head);
    if (dstate && dstate.kind === "install") {
      dot.className = "os-dot " + (dstate.error ? "off" : dstate.ended ? "" : "busy");
      txt.textContent = dstate.error ? "Install didn't finish" : dstate.ended ? "Install stopped" : "Installing the depth engine";
      if (dstate.ended) head.appendChild(miniBtn(dstate.error ? "Try again" : "Resume", startInstall, true));
      else head.appendChild(miniBtn("Cancel", function () { D.cancel(); }));
      var list = el("div", "os-steps");
      for (i = 0; i < dstate.steps.length; i++) {
        s = dstate.steps[i];
        row = el("div", "os-step is-" + s.state);
        ico = el("span", "os-step-ico");
        body = el("div", "os-step-body");
        top = el("div", "os-step-top");
        top.appendChild(el("span", "os-step-label", s.label));
        if (s.state === "active" && s.pct !== null) top.appendChild(el("span", "os-step-pct", Math.round(s.pct * 100) + "%"));
        body.appendChild(top);
        if (s.state === "active") body.appendChild(bar(s.pct));
        if (s.detail) body.appendChild(el("div", "os-step-detail", s.detail));
        row.appendChild(ico);
        row.appendChild(body);
        list.appendChild(row);
      }
      box.appendChild(list);
      if (dstate.error) box.appendChild(el("div", "os-step-error", dstate.error));
      return;
    }
    if (dstate && dstate.kind === "map") {
      dot.className = "os-dot busy";
      txt.textContent = "Making the depth map · " + dstate.name;
      head.appendChild(miniBtn("Stop", function () { D.cancel(); }));
      box.appendChild(bar(dstate.pct));
      box.appendChild(el("div", "os-step-detail", dstate.detail + (dstate.pct !== null ? " · " + Math.round(dstate.pct * 100) + "%" : "")));
      return;
    }
    if (!inCEP || !D || !D.available()) { txt.textContent = "The depth engine runs inside After Effects"; }
    else if (dEngine && dEngine.installed) { dot.className = "os-dot on"; txt.textContent = "Depth engine ready"; }
    else {
      dot.className = "os-dot off";
      txt.textContent = dEngine && dEngine.partial ? "Depth engine partly installed" : "Depth engine not installed · ~400 MB, once";
      head.appendChild(miniBtn(dEngine && dEngine.partial ? "Finish install" : "Install", depthInstall, true));
    }
    var own = miniBtn("Use my depth map", function () {
      if (!needAE()) return;
      own.disabled = true;
      os("depthRig", { variant: get("depth", "variant", "1") }).then(function (r) { own.disabled = false; report(r); setTimeout(poll, 150); });
    });
    own.title = "Already have a depth map? Select the picture and the map layer (its name contains “depth”), then click";
    var foot = el("div", "os-engine-foot");
    foot.appendChild(el("span", "os-engine-hint", "Have a map already?"));
    foot.appendChild(own);
    box.appendChild(foot);
  }
  // Repaint the engine box (if Depth reveal is open) and the Apply bar's line.
  function paintDepth() {
    var box = $("osEngine");
    if (box) fillEngine(box);
    renderNeeds();
  }

  /* --------------------------------------------------------------- SVG import */

  // OS 2.0's SVG import (jsx/os2/svg.jsx builds the layers). Like OS 2.0's panel, the gradients are baked here
  // first: one .ffx per gradient fill / stroke (js/ms-ffx-gradient.js on OS 2.0's templates in extension/os2/svg),
  // listed in a map the builder applies by shape number — the same parser on both sides keeps the numbers equal.
  function node(name) { try { return MSUI.node.require(name); } catch (e) { return null; } }
  function tmpDir() { var o = node("os"); return o ? o.tmpdir() : ""; }
  // OS 2.0's version patch for presets made by AE 2024 (stamp 0x5F at byte 27): lowered on 2022-2023.
  function aeMajor() { var v = parseInt(String(probe.ae || ""), 10); return v > 0 ? v : 99; }
  function stampFor(buf) {
    var v = aeMajor(), m = v >= 24 ? 0 : v >= 23 ? 0x5E : v >= 22 ? 0x5D : 0;
    if (m && buf.length > 27 && buf.toString("latin1", 0, 4) === "RIFX" && buf.toString("latin1", 8, 12) === "FaFX" && buf[27] > m) buf[27] = m;
    return buf;
  }
  // OS 2.0 cleaned its own temp files before each import (a long session filled the disk otherwise).
  function sweepTemp() {
    var fs = MSUI.node.fs, path = MSUI.node.path, dir = tmpDir(), cut = Date.now() - 30 * 60 * 1000;
    try {
      fs.readdirSync(dir).forEach(function (n) {
        if (n.indexOf("motionsaas_os2_") !== 0) return;
        var p = path.join(dir, n);
        try { if (fs.statSync(p).mtime.getTime() < cut && /\.(ffx|json|svg)$/i.test(n)) fs.unlinkSync(p); } catch (e) { }
      });
    } catch (e2) { }
  }
  function gradientMap(svg) {
    var fs = MSUI.node.fs, path = MSUI.node.path, dir = tmpDir(), ext = MSUI.systemDir ? MSUI.systemDir("extension") : "";
    var gen, tplFill, tplStroke = null, model, map = {}, count = 0, i;
    try {
      gen = MSUI.node.require(path.join(ext, "js", "ms-ffx-gradient.js"));
      tplFill = fs.readFileSync(path.join(ext, "os2", "svg", "grad-template.ffx"));
      try { tplStroke = fs.readFileSync(path.join(ext, "os2", "svg", "gradstroke-template.ffx")); } catch (eS) { }
      model = MSUI.svgParser.parse(svg);
    } catch (e) { return ""; }
    function bake(tpl, g, tag, k) {
      var cs = [], as = [], j, p;
      for (j = 0; j < g.stops.length; j++) {
        cs.push({ loc: g.stops[j].offset, rgb: g.stops[j].color });
        as.push({ loc: g.stops[j].offset, a: g.stops[j].opacity == null ? 1 : g.stops[j].opacity });
      }
      p = path.join(dir, "motionsaas_os2_" + tag + "_" + k + "_" + Date.now() + ".ffx");
      fs.writeFileSync(p, stampFor(gen.generate(tpl, { colorStops: cs, alphaStops: as })));
      return p.replace(/\\/g, "/");
    }
    for (i = 0; i < model.shapes.length; i++) {
      var sh = model.shapes[i], entry = null, eps = sh.extraPaints, e;
      try {
        if (sh.gradient && sh.gradient.stops && sh.gradient.stops.length >= 2) { entry = entry || {}; entry.fill = bake(tplFill, sh.gradient, "gradfill", i); }
        if (tplStroke && sh.strokeGradient && sh.strokeGradient.stops && sh.strokeGradient.stops.length >= 2) { entry = entry || {}; entry.stroke = bake(tplStroke, sh.strokeGradient, "gradstroke", i); }
        if (eps && eps.length) {
          for (e = 0; e < eps.length; e++) {
            var ep = eps[e], tpl = ep.kind === "stroke" ? tplStroke : tplFill;
            if (!tpl || !ep.gradient || !ep.gradient.stops || ep.gradient.stops.length < 2) continue;
            entry = entry || {};
            entry.extras = entry.extras || [];
            entry.extras.push({ i: e, kind: ep.kind, ffx: bake(tpl, ep.gradient, "gradextra", i * 100 + e) });
          }
        }
      } catch (eG) { }
      if (entry) { map[i] = entry; count++; }
    }
    if (!count) return "";
    var jp = path.join(dir, "motionsaas_os2_gradmap_" + Date.now() + ".json");
    fs.writeFileSync(jp, JSON.stringify(map), "utf8");
    return jp.replace(/\\/g, "/");
  }
  // file: the .svg to import (picked, or pasted code written to a temp file named after `name`).
  function svgImport(file, text) {
    if (!needAE()) return Promise.resolve();
    text = String(text || "");
    if (!/<svg[\s>]/i.test(text)) { MSUI.toast("That isn't SVG code — it should start with <svg", true); return Promise.resolve(); }
    sweepTemp();
    var map = "";
    try { map = gradientMap(text); } catch (e) { map = ""; }
    MSUI.toast("Building the shape layers…");
    return os("svgImport", { svg: file.replace(/\\/g, "/"), gradients: map }).then(report);
  }
  function svgPickFile() {
    var fs = MSUI.node && MSUI.node.fs;
    if (!fs || !window.CEP) { MSUI.toast("Choosing a file works inside After Effects — or use Paste SVG", true); return; }
    var files = window.CEP.pickFiles({ title: "Import SVG", types: ["svg"] });
    if (!files.length) return;
    var text;
    try { text = String(fs.readFileSync(files[0], "utf8")); } catch (e) { MSUI.toast("Couldn't read that file: " + e.message, true); return; }
    return svgImport(files[0], text);
  }
  function svgPasteImport() {
    var ta = $("osSvgCode"), fs = MSUI.node && MSUI.node.fs, path = MSUI.node && MSUI.node.path;
    if (!ta || !String(ta.value).trim()) { if (ta) ta.focus(); MSUI.toast("Paste SVG code first (in Figma: right-click → Copy as → Copy as SVG)"); return; }
    if (!fs || !needAE()) { if (!fs) MSUI.toast("Importing works inside After Effects", true); return; }
    // the layers are named after the file: a folder of its own keeps the name plain ("Pasted SVG")
    var dir = path.join(tmpDir(), "motionsaas_os2_paste_" + Date.now()), file = path.join(dir, "Pasted SVG.svg");
    try { fs.mkdirSync(dir); fs.writeFileSync(file, ta.value, "utf8"); } catch (e) { MSUI.toast("Couldn't write the SVG: " + e.message, true); return; }
    return svgImport(file, ta.value).then(function () { pasteDraft = ""; ta.value = ""; });
  }

  MSUI.action("osApply", apply);
  MSUI.os = { run: os, poll: poll };

  function boot() {
    if (!$("oskit-tab")) return;
    renderAll();
    document.addEventListener("ms-tab", function (e) { if (e.detail === "oskit") { placeInspector(); poll(); depthStatus(); paintDepth(); } });
    var resizeT = 0;
    window.addEventListener("resize", function () { clearTimeout(resizeT); resizeT = setTimeout(placeInspector, 120); });
    setInterval(poll, 1200);
    depthStatus();
    if (shown()) poll();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
