// Emojis, two ways:
// - Tool panel icons (their rail buttons, Settings → Rail rows, the Tool panels list, the classic tab bar) are
//   drawn as our own line icons, in the same rounded style as the Studio's rail icons (ICON_ZONE).
// - Every other emoji in the panel's text (buttons, preset cards, About, toasts, …) is shown as Apple's emoji
//   image (emojicdn.elk.sh) instead of the system's (Windows) one; if the image can't load (offline), the
//   plain emoji comes back.
// Runs in the panel and in the Studio frame (studio/index.html loads ../js/ms-emoji.js) and keeps up with
// content added later. Plain ES5 for After Effects 2020 (Chromium 61): no \p{…} regex classes.
(function () {
  "use strict";

  function ring(cx, cy, r) { return "M" + (cx - r) + " " + cy + "a" + r + " " + r + " 0 1 0 " + (2 * r) + " 0a" + r + " " + r + " 0 1 0 " + (-2 * r) + " 0"; }
  // 24 × 24, stroked with round ends and joins (our own drawings).
  var P = {
    rocket: "M12 15.5 8.5 12c1-4.5 4-8 9.5-8.5-.5 5.5-4 8.5-8.5 9.5ZM8.5 12H5.2l2.6-3.4H11M12 15.5v3.3l3.4-2.6V13M5.5 18.5c.2-1.6 1.2-2.6 2.8-2.8" + ring(14.8, 9.2, 1.3).replace(/^M/, "M"),
    save: "M5.5 4h10.8L19 6.7v11.8a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 5 18.5v-13A1.5 1.5 0 0 1 6.5 4ZM8.5 4v4h6.5V4M8.5 20v-5.5h7V20",
    trash: "M4.5 7h15M9.5 7V5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v2M6.5 7l.9 11.6a1.5 1.5 0 0 0 1.5 1.4h6.2a1.5 1.5 0 0 0 1.5-1.4L17.5 7M10.2 11v5M13.8 11v5",
    clipboard: "M9.5 4h5a.5.5 0 0 1 .5.5v1.5a.5.5 0 0 1-.5.5h-5a.5.5 0 0 1-.5-.5V4.5a.5.5 0 0 1 .5-.5ZM9 5.2H7.2A1.7 1.7 0 0 0 5.5 6.9v11.4A1.7 1.7 0 0 0 7.2 20h9.6a1.7 1.7 0 0 0 1.7-1.7V6.9a1.7 1.7 0 0 0-1.7-1.7H15M9 11.5h6M9 15h4",
    refresh: "M19.5 12a7.5 7.5 0 1 1-2.2-5.3M19.5 4.5v4.2h-4.2",
    flask: "M9.5 3.5h5M10.5 3.5v6.2l-5.2 8.6a1.5 1.5 0 0 0 1.3 2.2h10.8a1.5 1.5 0 0 0 1.3-2.2l-5.2-8.6V3.5M7.6 14.5h8.8",
    moon: "M19.5 14.6A7.6 7.6 0 0 1 9.4 4.5a7.6 7.6 0 1 0 10.1 10.1Z",
    arrowsH: "M4 12h16M7.5 8.5 4 12l3.5 3.5M16.5 8.5 20 12l-3.5 3.5",
    lock: "M7 10.5h10a2 2 0 0 1 2 2v5.5a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-5.5a2 2 0 0 1 2-2ZM8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5M12 14.5v2",
    ball: ring(12, 12, 8.2) + "M5.6 6.6c2.8 1.7 3.8 6.6 1.2 10.8M18.4 6.6c-2.8 1.7-3.8 6.6-1.2 10.8",
    folder: "M3.5 7.5A1.5 1.5 0 0 1 5 6h3.8a1 1 0 0 1 .8.4L11 8h8a1.5 1.5 0 0 1 1.5 1.5v8A1.5 1.5 0 0 1 19 19H5a1.5 1.5 0 0 1-1.5-1.5Z",
    sparkles: "M10 3.25c.55 3.9 2.35 5.7 6.25 6.25-3.9.55-5.7 2.35-6.25 6.25-.55-3.9-2.35-5.7-6.25-6.25 3.9-.55 5.7-2.35 6.25-6.25ZM18 14.25c.3 2 1.25 2.95 3.25 3.25-2 .3-2.95 1.25-3.25 3.25-.3-2-1.25-2.95-3.25-3.25 2-.3 2.95-1.25 3.25-3.25Z",
    alarm: ring(12, 13, 7) + "M12 9.8V13l2.2 1.4M4.6 5.8 7 3.8M19.4 5.8 17 3.8",
    timer: ring(12, 13.5, 7) + "M12 10v3.5l2.2 1.6M10 3h4M12 3v3.5",
    file: "M7 3.5h6.3L18.5 8.7v10.3a1.5 1.5 0 0 1-1.5 1.5H7A1.5 1.5 0 0 1 5.5 19V5A1.5 1.5 0 0 1 7 3.5ZM13 3.5v5.5h5.5M8.5 13h7M8.5 16.5h4.5",
    pencil: "M15.4 4.6a1.9 1.9 0 0 1 2.7 0l1.3 1.3a1.9 1.9 0 0 1 0 2.7L9 19l-4.5 1 1-4.5ZM13.5 6.5l4 4",
    pen: "M4.5 19.5l3.9-1 9.8-9.8a2 2 0 0 0-2.9-2.9l-9.8 9.8ZM13.8 7.4l2.8 2.8M12.5 19.5h7",
    link: "M10 14a3.5 3.5 0 0 0 5 0l3-3a3.5 3.5 0 0 0-5-5l-1 1M14 10a3.5 3.5 0 0 0-5 0l-3 3a3.5 3.5 0 0 0 5 5l1-1",
    flame: "M12 20.5c3.4 0 6-2.4 6-5.9 0-3.7-3-5.6-3.6-9.1-2.4 1.4-3.9 3.9-3.9 6.2-1-.5-1.8-1.5-2-2.7-1.6 1.3-2.5 3.4-2.5 5.6 0 3.5 2.6 5.9 6 5.9Z",
    gear: "M12 2.75h0a1.9 1.9 0 0 1 1.85 1.45l.25 1a1.9 1.9 0 0 0 2.7 1.15l.9-.5a1.9 1.9 0 0 1 2.35.4h0a1.9 1.9 0 0 1 .4 2.35l-.5.9a1.9 1.9 0 0 0 1.15 2.7l1 .25A1.9 1.9 0 0 1 21.25 12h0a1.9 1.9 0 0 1-1.45 1.85l-1 .25a1.9 1.9 0 0 0-1.15 2.7l.5.9a1.9 1.9 0 0 1-.4 2.35h0a1.9 1.9 0 0 1-2.35.4l-.9-.5a1.9 1.9 0 0 0-2.7 1.15l-.25 1A1.9 1.9 0 0 1 12 21.25h0a1.9 1.9 0 0 1-1.85-1.45l-.25-1a1.9 1.9 0 0 0-2.7-1.15l-.9.5a1.9 1.9 0 0 1-2.35-.4h0a1.9 1.9 0 0 1-.4-2.35l.5-.9a1.9 1.9 0 0 0-1.15-2.7l-1-.25A1.9 1.9 0 0 1 2.75 12h0a1.9 1.9 0 0 1 1.45-1.85l1-.25a1.9 1.9 0 0 0 1.15-2.7l-.5-.9a1.9 1.9 0 0 1 .4-2.35h0a1.9 1.9 0 0 1 2.35-.4l.9.5a1.9 1.9 0 0 0 2.7-1.15l.25-1A1.9 1.9 0 0 1 12 2.75ZM9 12a3 3 0 1 0 6 0a3 3 0 1 0-6 0",
    x: "M6.5 6.5l11 11M17.5 6.5l-11 11",
    medal: ring(12, 15, 5) + "M8.6 3.5 10.6 10.2M15.4 3.5l-2 6.7M12 13.3v3.4",
    arrowR: "M4.5 12h15M14 6.5l5.5 5.5-5.5 5.5",
    arrowL: "M19.5 12h-15M10 6.5 4.5 12l5.5 5.5",
    arrowU: "M12 19.5v-15M6.5 10 12 4.5l5.5 5.5",
    arrowD: "M12 4.5v15M6.5 14l5.5 5.5 5.5-5.5",
    palette: "M12 3.5a8.5 8.5 0 0 0 0 17c1.2 0 1.8-.8 1.8-1.7 0-1.3-1.3-1.6-1.3-2.8 0-1 .8-1.5 1.8-1.5h2.2a4 4 0 0 0 4-4c0-3.9-3.8-7-8.5-7ZM7.5 11.5h.01M9.5 7.5h.01M14.5 7.5h.01",
    laptop: "M6 5.5h12a1.5 1.5 0 0 1 1.5 1.5v8.5h-15V7A1.5 1.5 0 0 1 6 5.5ZM2.5 18.5h19",
    monitor: "M5 4.5h14a1.5 1.5 0 0 1 1.5 1.5v9a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 15V6A1.5 1.5 0 0 1 5 4.5ZM9 20h6M12 16.5V20",
    phone: "M8.5 3.5h7a2 2 0 0 1 2 2v13a2 2 0 0 1-2 2h-7a2 2 0 0 1-2-2v-13a2 2 0 0 1 2-2ZM11 17.5h2",
    bars: "M4.5 19.5h15M7.5 16v-4M12 16V7.5M16.5 16v-6.5",
    trendUp: "M3.5 16.5 9 11l3.5 3.5 8-8M15 6.5h5.5V12",
    trendDown: "M3.5 7.5 9 13l3.5-3.5 8 8M15 17.5h5.5V12",
    cloud: "M7.5 18.5h10a4 4 0 0 0 .4-8 6 6 0 0 0-11.5 1.4 3.4 3.4 0 0 0 1.1 6.6Z",
    camera: "M4.5 8.2A1.7 1.7 0 0 1 6.2 6.5h2.3l1.4-2h4.2l1.4 2h2.3a1.7 1.7 0 0 1 1.7 1.7v9.1A1.7 1.7 0 0 1 17.8 19H6.2a1.7 1.7 0 0 1-1.7-1.7Z" + ring(12, 12.6, 3.2),
    gem: "M7 4.5h10l3.5 4.5L12 20 3.5 9ZM3.5 9h17M9.6 4.5 8.2 9 12 20l3.8-11-1.4-4.5",
    film: "M6 4h12a1.5 1.5 0 0 1 1.5 1.5v13A1.5 1.5 0 0 1 18 20H6a1.5 1.5 0 0 1-1.5-1.5v-13A1.5 1.5 0 0 1 6 4ZM8.5 4v16M15.5 4v16M4.5 9h4M4.5 15h4M15.5 9h4M15.5 15h4",
    download: "M12 4v10M8 10.5l4 4 4-4M4.5 15v3a1.5 1.5 0 0 0 1.5 1.5h12a1.5 1.5 0 0 0 1.5-1.5v-3",
    balloon: "M12 15c3 0 5.5-3 5.5-6.3a5.5 5.5 0 0 0-11 0C6.5 12 9 15 12 15ZM11 16.6h2L12 15ZM12 16.6c0 2 1.6 2.5 0 3.9",
    star: "M12 3.8l2.5 5.1 5.6.8-4.1 4 1 5.6L12 16.6l-5 2.7 1-5.6-4.1-4 5.6-.8Z",
    square: "M7 5.5h10A1.5 1.5 0 0 1 18.5 7v10a1.5 1.5 0 0 1-1.5 1.5H7A1.5 1.5 0 0 1 5.5 17V7A1.5 1.5 0 0 1 7 5.5Z",
    search: ring(11, 11, 6.5) + "M16 16l4 4",
    wind: "M3.5 9h10a2.5 2.5 0 1 0-2.5-2.5M3.5 13h14a2.5 2.5 0 1 1-2.5 2.5M3.5 17h6",
    keyboard: "M4.5 6.5h15a1.5 1.5 0 0 1 1.5 1.5v8a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 16V8a1.5 1.5 0 0 1 1.5-1.5ZM7 10h.01M10.3 10h.01M13.7 10h.01M17 10h.01M8 14h8",
    note: "M7 4h10a1.5 1.5 0 0 1 1.5 1.5v13A1.5 1.5 0 0 1 17 20H7a1.5 1.5 0 0 1-1.5-1.5v-13A1.5 1.5 0 0 1 7 4ZM8.8 9h6.4M8.8 12.5h6.4M8.8 16h4",
    wave: "M3 9c2-2 4-2 6 0s4 2 6 0 4-2 6 0M3 15c2-2 4-2 6 0s4 2 6 0 4-2 6 0",
    zap: "M13 3.5 5.5 13.5h6l-1 7 7.5-10h-6Z",
    eye: "M2.5 12s3.5-6.5 9.5-6.5 9.5 6.5 9.5 6.5-3.5 6.5-9.5 6.5S2.5 12 2.5 12ZM9 12a3 3 0 1 0 6 0a3 3 0 1 0-6 0",
    eyeOff: "M2.5 12s3.5-6.5 9.5-6.5 9.5 6.5 9.5 6.5-3.5 6.5-9.5 6.5S2.5 12 2.5 12ZM9 12a3 3 0 1 0 6 0a3 3 0 1 0-6 0M4 4l16 16",
    broom: "M15 3.5l-3.8 8M7.2 11.5h7.6l2 2.6-1 6.4H6.2l-.4-6.4ZM9.5 15.5v5M13 15.5v5",
    wand: "M4.5 19.5 15 9M13.4 7.4l3.2 3.2M17.5 3.5v3M16 5h3M20 10v2M19 11h2M10 3.5v2M9 4.5h2",
    box: "M12 3.5l7.5 4v9L12 20.5l-7.5-4v-9ZM4.5 7.5 12 11.5l7.5-4M12 11.5v9",
    swords: "M5 19 17 7M14.5 4.5h5v5M7.2 14.8l2 2M4 20l1.6-1.6",
    point: "M4.5 12h15M14 6.5l5.5 5.5-5.5 5.5",
    dot: ring(12, 12, 3.5)
  };
  // Where emojis are tool panel icons (drawn as line icons); everywhere else they are Apple emoji images.
  var ICON_ZONE = ".ms-rail-panel, .ms-rail-row-icon, .ms-panel-icon, .tab-btn";
  var CDN = "https://emojicdn.elk.sh/";
  // Emoji (variation selectors removed) → icon. Status dots → colour.
  var MAP = {
    "🚀": "rocket", "💾": "save", "🗑": "trash", "📋": "clipboard", "🔄": "refresh", "🔁": "refresh", "🔃": "refresh",
    "🧪": "flask", "🌙": "moon", "↔": "arrowsH", "🔒": "lock", "🔐": "lock", "🔓": "lock", "🎾": "ball", "🏀": "ball", "⚽": "ball",
    "📁": "folder", "📂": "folder", "✨": "sparkles", "🌟": "star", "⭐": "star", "⏰": "alarm", "⏲": "timer", "⏱": "timer", "🕒": "timer",
    "📄": "file", "📃": "file", "✏": "pencil", "🖋": "pen", "✍": "pen", "🖊": "pen", "🔗": "link", "🔥": "flame", "⚙": "gear",
    "❌": "x", "✖": "x", "🥇": "medal", "🏆": "medal", "👉": "point", "➡": "arrowR", "⬅": "arrowL", "⬆": "arrowU", "⬇": "arrowD",
    "🎨": "palette", "💻": "laptop", "🖥": "monitor", "📱": "phone", "📊": "bars", "📈": "trendUp", "📉": "trendDown", "☁": "cloud",
    "📸": "camera", "📷": "camera", "💎": "gem", "🎞": "film", "🎬": "film", "📥": "download", "🎈": "balloon", "⬛": "square",
    "🔍": "search", "🔎": "search", "🌬": "wind", "⌨": "keyboard", "📝": "note", "🗒": "note", "🌊": "wave", "⚡": "zap",
    "👁": "eye", "👀": "eye", "🙈": "eyeOff", "🧹": "broom", "🪄": "wand", "📦": "box", "🤺": "swords"
  };
  var DOTS = { "🟢": "#30d158", "🟡": "#ffd60a", "🔴": "#ff453a", "🔵": "#0a84ff", "🟠": "#ff9f0a", "🟣": "#bf5af2", "⚪": "#e5e5ea", "⚫": "#1c1c1e" };

  var SVGNS = "http://www.w3.org/2000/svg";
  // An emoji: a supplementary-plane pictograph (optionally with a skin tone), a flag, a keycap, or a BMP
  // symbol that is an emoji by default (or followed by U+FE0F) — then any ZWJ-joined parts. BMP symbols
  // without U+FE0F that are only text (arrows, ✓, ✦, ×…) stay text: the panel uses those as glyphs.
  var PIC = "(?:[\\uD83C-\\uD83E][\\uDC00-\\uDFFF])";
  // (⏱ ⏲ ⌨ ☁ ⚙ ✍ ✏ too: written without U+FE0F in our own markup, Windows still draws them as emoji.)
  var BMP_EMOJI = "[\\u231A\\u231B\\u2328\\u23E9-\\u23EC\\u23F0-\\u23F3\\u2601\\u2699\\u270D\\u270F\\u25FD\\u25FE\\u2614\\u2615\\u2648-\\u2653\\u267F\\u2693\\u26A1" +
    "\\u26AA\\u26AB\\u26BD\\u26BE\\u26C4\\u26C5\\u26CE\\u26D4\\u26EA\\u26F2\\u26F3\\u26F5\\u26FA\\u26FD\\u2705\\u270A\\u270B" +
    "\\u2728\\u274C\\u274E\\u2753-\\u2755\\u2757\\u2795-\\u2797\\u27B0\\u27BF\\u2B1B\\u2B1C\\u2B50\\u2B55]";
  var BMP_ANY = "[\\u00A9\\u00AE\\u203C\\u2049\\u2122\\u2139\\u2194-\\u21AA\\u231A-\\u23FF\\u24C2\\u25AA-\\u25FE\\u2600-\\u27BF\\u2934\\u2935\\u2B05-\\u2B55\\u3030\\u303D\\u3297\\u3299]\\uFE0F";
  var ONE = "(?:\\uD83C[\\uDDE6-\\uDDFF]\\uD83C[\\uDDE6-\\uDDFF]|[0-9#*]\\uFE0F?\\u20E3|" + PIC + "\\uFE0F?(?:\\uD83C[\\uDFFB-\\uDFFF])?|" + BMP_ANY + "|" + BMP_EMOJI + "\\uFE0F?)";
  var EMOJI = new RegExp(ONE + "(?:\\u200D" + ONE + ")*", "g");
  var SKIP = { SCRIPT: 1, STYLE: 1, TEXTAREA: 1, INPUT: 1, SELECT: 1, OPTION: 1, CODE: 1, PRE: 1, NOSCRIPT: 1, svg: 1, SVG: 1 };

  function emojiImg(e) {
    var img = document.createElement("img");
    img.className = "ms-emoji";
    img.alt = e;
    img.draggable = false;
    img.setAttribute("aria-label", e);
    img.addEventListener("error", function () {   // no image (offline): the plain emoji comes back, for good
      if (!img.parentNode) { return; }
      var span = document.createElement("span");
      span.className = "ms-no-emoji";
      span.textContent = e;
      img.parentNode.replaceChild(span, img);
    });
    img.src = CDN + encodeURIComponent(e) + "?style=apple";
    return img;
  }

  function iconFor(e) {
    var key = e.replace(/[︎️]/g, "").replace(/\uD83C[\uDFFB-\uDFFF]/g, "").split("‍")[0];
    var span = document.createElement("span");
    span.setAttribute("role", "img");
    span.setAttribute("aria-label", e);
    span.title = "";
    if (DOTS[key]) {
      span.className = "ms-ico ms-ico-dot";
      span.style.backgroundColor = DOTS[key];
      return span;
    }
    span.className = "ms-ico";
    var svg = document.createElementNS(SVGNS, "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("aria-hidden", "true");
    var path = document.createElementNS(SVGNS, "path");
    path.setAttribute("d", P[MAP[key]] || P.dot);
    svg.appendChild(path);
    span.appendChild(svg);
    return span;
  }

  function swapText(node) {
    var text = node.nodeValue;
    if (!text || !EMOJI.test(text)) { EMOJI.lastIndex = 0; return; }
    EMOJI.lastIndex = 0;
    var host = node.parentNode, icons = !!(host && host.closest && host.closest(ICON_ZONE));
    var frag = document.createDocumentFragment(), last = 0, m;
    while ((m = EMOJI.exec(text))) {
      if (m.index > last) { frag.appendChild(document.createTextNode(text.slice(last, m.index))); }
      frag.appendChild(icons ? iconFor(m[0]) : emojiImg(m[0]));
      last = m.index + m[0].length;
    }
    if (last < text.length) { frag.appendChild(document.createTextNode(text.slice(last))); }
    node.parentNode.replaceChild(frag, node);
  }

  function skipped(el) {
    for (; el && el.nodeType === 1; el = el.parentNode) {
      if (SKIP[el.nodeName] || el.isContentEditable || (el.classList && el.classList.contains("ms-no-emoji"))) { return true; }
    }
    return false;
  }

  function scan(root) {
    if (!root) { return; }
    if (root.nodeType === 3) { if (!skipped(root.parentNode)) { swapText(root); } return; }
    if (root.nodeType !== 1 || skipped(root)) { return; }
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null, false), list = [], n;
    while ((n = walker.nextNode())) { if (n.nodeValue && n.nodeValue.length > 0) { list.push(n); } }
    for (var i = 0; i < list.length; i++) { if (list[i].parentNode && !skipped(list[i].parentNode)) { swapText(list[i]); } }
  }

  // Content added or changed later (dialogs, lists, toasts): scan just those parts, batched per frame.
  var pending = [], queued = false;
  function flush() {
    queued = false;
    var todo = pending; pending = [];
    for (var i = 0; i < todo.length; i++) { if (todo[i].isConnected !== false) { scan(todo[i]); } }
  }
  function queue(n) {
    pending.push(n);
    if (!queued) { queued = true; (window.requestAnimationFrame || setTimeout)(flush); }
  }

  function start() {
    scan(document.body);
    if (!window.MutationObserver) { return; }
    new MutationObserver(function (records) {
      for (var i = 0; i < records.length; i++) {
        var r = records[i];
        if (r.type === "characterData") { queue(r.target); continue; }
        for (var j = 0; j < r.addedNodes.length; j++) {
          var a = r.addedNodes[j];
          if (a.nodeType === 1 && a.classList && (a.classList.contains("ms-ico") || a.classList.contains("ms-emoji"))) { continue; }
          queue(a);
        }
      }
    }).observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  // Sized and aligned like the text around them: .ms-ico in css/ms-extra.css and css/studio-extra.css.
  if (document.readyState === "loading") { document.addEventListener("DOMContentLoaded", start); } else { start(); }

  if (window.MSUI) { window.MSUI.emoji = { scan: scan }; }
})();
