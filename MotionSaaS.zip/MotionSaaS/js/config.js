// Updated automatically by scripts/release.js — keep the version in sync with CSXS/manifest.xml.
window.MS_CONFIG = {
  version: "1.0.0",
  // GitHub repo ("owner/name") where releases are published. Must be readable without a login
  // (a public repo, or a separate public "releases" repo). See README → "Updates".
  updateRepo: "hellomotionsaas-coder/MotionSaas",
  // File attached to each GitHub Release by the release workflow.
  assetName: "MotionSaaS.zip"
};
