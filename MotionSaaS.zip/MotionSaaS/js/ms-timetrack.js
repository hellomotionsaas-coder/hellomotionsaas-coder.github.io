/*
 * MotionSaaS — time tracking core for the Timer & Goal tab (no screen code; js/ms-timer.js draws it).
 * Pure functions over one state object, so scripts/check.js can test them in Node:
 *   { v: 2, days: { "2026-10-20": seconds }, projects: { id: { name, days: { day: seconds }, last } },
 *     run: null | { since, start, project, nudged, active }, hold, beat, goalMin, auto, idleMin, focusMin }
 * days = everything tracked that day (all projects); projects = the same time filed per After Effects project.
 * run: since = banked up to, start = this stretch began, active = last activity seen in After Effects.
 * Running time is "banked" into days / projects as it goes, split at midnight so each day gets its own share.
 * Published as MSUI.timeTrack. Plain ES5 (After Effects 2020: Chromium 61).
 */
(function (root) {
  "use strict";

  var T = {};
  var DAY = 86400000;

  function num(v, d) { v = Number(v); return isFinite(v) ? v : d; }
  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
  function own(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }

  T.dayKey = function (d) {
    d = d instanceof Date ? d : new Date(d || Date.now());
    return d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2);
  };
  // The start of the day after the one `t` falls in (local time).
  function nextMidnight(t) { var e = new Date(t); e.setHours(24, 0, 0, 0); return e.getTime(); }

  T.GOAL_DEFAULT = 120;
  T.fresh = function () {
    return { v: 2, days: {}, projects: {}, run: null, hold: false, beat: 0, goalMin: T.GOAL_DEFAULT, auto: true, idleMin: 5, focusMin: 0 };
  };

  // Any stored value (this format, the first Timer format, or garbage) → a valid state.
  T.migrate = function (raw) {
    var s = T.fresh(), k;
    if (!raw || typeof raw !== "object") return s;
    var days = raw.days && typeof raw.days === "object" ? raw.days : {};
    for (k in days) if (own(days, k) && /^\d{4}-\d\d-\d\d$/.test(k) && num(days[k], 0) > 0) s.days[k] = num(days[k], 0);
    if (raw.v === 2) {
      var ps = raw.projects && typeof raw.projects === "object" ? raw.projects : {};
      for (k in ps) {
        if (!own(ps, k) || !ps[k] || typeof ps[k] !== "object") continue;
        var p = { name: String(ps[k].name || k), days: {}, last: num(ps[k].last, 0) }, pd = ps[k].days || {}, d;
        for (d in pd) if (own(pd, d) && /^\d{4}-\d\d-\d\d$/.test(d) && num(pd[d], 0) > 0) p.days[d] = num(pd[d], 0);
        s.projects[k] = p;
      }
      if (raw.run && num(raw.run.since, 0) > 0) {
        var since = num(raw.run.since, 0);
        s.run = { since: since, start: num(raw.run.start, since), project: String(raw.run.project || ""), nudged: num(raw.run.nudged, 0), active: num(raw.run.active, since) };
      }
      s.hold = !!raw.hold;
      s.beat = num(raw.beat, 0);
      s.goalMin = clamp(Math.round(num(raw.goalMin, T.GOAL_DEFAULT)), 15, 720);
      s.auto = raw.auto !== false;
      s.idleMin = clamp(Math.round(num(raw.idleMin, 5)), 0, 60);
      s.focusMin = clamp(Math.round(num(raw.focusMin, 0)), 0, 240);
    } else {
      // First Timer format: { days, sessions, runningSince, sessionSec, beat }. Its goal was a fixed 60 min.
      s.goalMin = 60;
      s.beat = num(raw.beat, 0);
      if (num(raw.runningSince, 0) > 0) s.run = { since: raw.runningSince, start: raw.runningSince, project: "", nudged: 0, active: raw.runningSince };
    }
    return s;
  };

  // Unbanked running time, split by day: { "2026-10-20": seconds }.
  T.unbanked = function (s, now) {
    var out = {};
    if (!s.run || !(now > s.run.since)) return out;
    for (var from = s.run.since; from < now;) {
      var to = Math.min(now, nextMidnight(from)), k = T.dayKey(from);
      out[k] = (out[k] || 0) + (to - from) / 1000;
      from = to;
    }
    return out;
  };

  T.addProject = function (s, id, name, at) {
    if (!id) return null;
    var p = s.projects[id] || (s.projects[id] = { name: name || id, days: {}, last: 0 });
    if (name) p.name = name;
    p.last = Math.max(p.last || 0, at || 0);
    return p;
  };

  // Credit the running time up to `upTo` to its days (and its project), and keep running from there.
  T.bank = function (s, upTo) {
    var r = s.run;
    if (!r || !(upTo > r.since)) return 0;
    var parts = T.unbanked(s, upTo), p = r.project ? s.projects[r.project] : null, total = 0, k;
    for (k in parts) {
      if (!own(parts, k)) continue;
      s.days[k] = (s.days[k] || 0) + parts[k];
      if (p) p.days[k] = (p.days[k] || 0) + parts[k];
      total += parts[k];
    }
    if (p) p.last = Math.max(p.last || 0, upTo);
    r.since = upTo;
    return total;
  };

  T.start = function (s, now, project, name) {
    if (s.run) return false;
    T.addProject(s, project, name, now);
    s.run = { since: now, start: now, project: project || "", nudged: 0, active: now };
    s.hold = false;
    return true;
  };

  // Stop, crediting time only up to `upTo` (e.g. the last moment of activity). hold: don't auto-start again.
  T.stop = function (s, upTo, hold) {
    if (hold !== undefined) s.hold = !!hold;
    if (!s.run) return 0;
    var t = T.bank(s, Math.max(s.run.since, upTo));
    s.run = null;
    return t;
  };

  // The user moved to another After Effects project while tracking: file what came before, carry on.
  T.switchProject = function (s, now, project, name) {
    if (!s.run || s.run.project === (project || "")) { if (s.run) T.addProject(s, project, name, now); return false; }
    T.bank(s, now);
    T.addProject(s, project, name, now);
    s.run.project = project || "";
    return true;
  };

  T.daySec = function (s, key, now) {
    var v = s.days[key] || 0;
    if (s.run && now) v += T.unbanked(s, now)[key] || 0;
    return v;
  };

  // A project's time over `keys` (a list of days), or over all time when keys is omitted.
  T.projectSec = function (s, id, keys, now) {
    var p = s.projects[id], live = s.run && s.run.project === id && now ? T.unbanked(s, now) : {}, sum = 0, k, i;
    if (!p) return 0;
    if (!keys) {
      for (k in p.days) if (own(p.days, k)) sum += p.days[k];
      for (k in live) if (own(live, k)) sum += live[k];
      return sum;
    }
    for (i = 0; i < keys.length; i++) sum += (p.days[keys[i]] || 0) + (live[keys[i]] || 0);
    return sum;
  };

  // The 7 days (Monday first) of the week `offset` weeks from the one containing `now`.
  T.weekKeys = function (offset, now) {
    var d = new Date(now), out = [], i;
    d.setHours(12, 0, 0, 0);
    d.setDate(d.getDate() - ((d.getDay() + 6) % 7) + 7 * (offset || 0));
    for (i = 0; i < 7; i++) { out.push(T.dayKey(d)); d.setDate(d.getDate() + 1); }
    return out;
  };

  // Days in a row that met the goal, ending today (or yesterday while today's goal is still open).
  T.streak = function (s, now) {
    var goal = s.goalMin * 60, d = new Date(now), n = 0;
    d.setHours(12, 0, 0, 0);
    if (T.daySec(s, T.dayKey(d), now) < goal) d.setDate(d.getDate() - 1);
    while (n < 3660 && T.daySec(s, T.dayKey(d), now) >= goal) { n++; d.setDate(d.getDate() - 1); }
    return n;
  };
  // The longest such run in the whole history.
  T.bestStreak = function (s, now) {
    var goal = s.goalMin * 60, keys = [], k, best = 0, run = 0, prev = 0, i;
    var live = s.run ? T.unbanked(s, now) : {};
    for (k in s.days) if (own(s.days, k)) keys.push(k);
    for (k in live) if (own(live, k) && keys.indexOf(k) < 0) keys.push(k);
    keys.sort();
    for (i = 0; i < keys.length; i++) {
      if ((s.days[keys[i]] || 0) + (live[keys[i]] || 0) < goal) { run = 0; continue; }
      var t = new Date(keys[i] + "T12:00:00").getTime();
      run = prev && Math.round((t - prev) / DAY) === 1 && run ? run + 1 : 1;
      prev = t;
      best = Math.max(best, run);
    }
    return best;
  };

  // Remove a project and its time (from the day totals too).
  T.removeProject = function (s, id) {
    var p = s.projects[id], k;
    if (!p) return;
    for (k in p.days) {
      if (!own(p.days, k)) continue;
      s.days[k] = Math.max(0, (s.days[k] || 0) - p.days[k]);
      if (!s.days[k]) delete s.days[k];
    }
    delete s.projects[id];
    if (s.run && s.run.project === id) s.run.project = "";
  };

  // Forget one day (all projects); a running timer keeps going from now.
  T.clearDay = function (s, key, now) {
    var id;
    if (s.run) { T.bank(s, now); s.run.start = now; s.run.nudged = 0; }
    delete s.days[key];
    for (id in s.projects) if (own(s.projects, id)) delete s.projects[id].days[key];
  };

  // Timesheet: one row per day and project ("(no project)" for time from before projects were tracked).
  T.csv = function (s, now) {
    var rows = ["Date,Project,Minutes,Hours"], keys = [], k, id;
    var q = function (v) { v = String(v); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
    var line = function (day, name, sec) { var m = Math.round(sec / 60); if (m > 0) rows.push(day + "," + q(name) + "," + m + "," + (m / 60).toFixed(2)); };
    var live = s.run ? T.unbanked(s, now) : {};
    for (k in s.days) if (own(s.days, k)) keys.push(k);
    for (k in live) if (own(live, k) && keys.indexOf(k) < 0) keys.push(k);
    keys.sort();
    keys.forEach(function (day) {
      var filed = 0, ids = [];
      for (id in s.projects) if (own(s.projects, id)) ids.push(id);
      ids.sort(function (a, b) { return s.projects[a].name.localeCompare(s.projects[b].name); });
      ids.forEach(function (pid) {
        var sec = (s.projects[pid].days[day] || 0) + (s.run && s.run.project === pid ? live[day] || 0 : 0);
        filed += sec;
        line(day, s.projects[pid].name, sec);
      });
      var rest = T.daySec(s, day, now) - filed;
      if (rest >= 30) line(day, "(no project)", rest);
    });
    return rows.join("\r\n") + "\r\n";
  };

  // 0 → "0m", 300 → "5m", 3900 → "1h 05m", 7200 → "2h".
  T.fmt = function (sec) {
    var m = Math.floor(Math.max(0, sec) / 60), h = Math.floor(m / 60);
    m = m % 60;
    return h ? h + "h" + (m ? " " + ("0" + m).slice(-2) + "m" : "") : m + "m";
  };
  // 754 → "12:34", 3754 → "1:02:34".
  T.clock = function (sec) {
    sec = Math.floor(Math.max(0, sec));
    var h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), x = sec % 60;
    return (h ? h + ":" + ("0" + m).slice(-2) : m) + ":" + ("0" + x).slice(-2);
  };

  if (root.MSUI) root.MSUI.timeTrack = T;
  if (typeof module !== "undefined" && module.exports) module.exports = T;
})(typeof window !== "undefined" ? window : this);
