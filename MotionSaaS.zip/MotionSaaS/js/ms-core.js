/*
 * MotionSaaS — panel core.
 * Readable replacement for the old obfuscated core: host bridge (runCore), tabs, tooltips,
 * bezier graph editor, custom colours + AI palette, counter/timer, fit dialog, Magic Reveal,
 * greetings and the one-click GitHub updater.
 *
 * Chromium 61 safe (AE 2020): no ?. / ?? / class fields / Array.flat.
 */
(function () {
  "use strict";

  // Everything this file shares lives on MSUI (js/panel/00-msui.js): MSUI.store, MSUI.toast, MSUI.confirm,
  // MSUI.host, MSUI.runCore, MSUI.report, MSUI.showTab, MSUI.editor, MSUI.colors, MSUI.counter, …
  var MSUI = window.MSUI;
  var cs = MSUI.cs || (MSUI.cs = new CSInterface());
  var inCEP = !!window.__adobe_cep__;          // false when the page is opened in a normal browser (preview)
  var EXT = inCEP ? cs.getSystemPath(SystemPath.EXTENSION) : "";
  var $ = function (id) { return document.getElementById(id); };
  var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };
  var store = MSUI.store = {
    get: function (k, d) { try { var v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    // false when the browser refused (storage full / blocked): noted once per key in Copy diagnostics,
    // so lost settings can be explained instead of vanishing silently.
    set: function (k, v) {
      try { localStorage.setItem(k, JSON.stringify(v)); return true; }
      catch (e) { if (!store.failed[k]) { store.failed[k] = 1; try { logError("storage " + k, e.message || e); } catch (e2) {} } return false; }
    },
    failed: {}
  };

  // Real OS folders from CEP (Documents, app data). Prefer these over Node's os.homedir(), which follows
  // the USERPROFILE variable — broken on some machines (it can point at an old Windows profile).
  MSUI.systemDir = function (which) {
    if (!window.__adobe_cep__) return "";
    var key = which === "documents" ? SystemPath.MY_DOCUMENTS : which === "userData" ? SystemPath.USER_DATA : SystemPath.EXTENSION;
    var p = "";
    try { p = String(cs.getSystemPath(key) || ""); } catch (e) { return ""; }
    p = p.replace(/^file:\/{2,3}/, "");
    try { p = decodeURIComponent(p); } catch (e2) {}
    if (/^\/[A-Za-z]:/.test(p)) p = p.slice(1);
    return p;
  };

  // navigator.clipboard arrived in Chrome 66; AE 2020's panel browser is Chrome 61. "Copy" buttons
  // (actions.copyText, diagnostics) call navigator.clipboard.writeText, so give old browsers a working stand-in.
  function msCopy(text) {
    var ta = document.createElement("textarea");
    ta.value = String(text);
    ta.style.cssText = "position:fixed;left:-9999px;top:0;opacity:0";
    document.body.appendChild(ta);
    ta.select();
    var ok = false;
    try { ok = document.execCommand("copy"); } catch (e) {}
    document.body.removeChild(ta);
    return ok ? Promise.resolve() : Promise.reject(new Error("Copy failed"));
  }
  if (!navigator.clipboard || !navigator.clipboard.writeText) {
    try { Object.defineProperty(navigator, "clipboard", { value: { writeText: msCopy }, configurable: true }); }
    catch (e) { /* read-only navigator: copy buttons just won't work on this AE version */ }
  }

  /* ------------------------------------------------------------ toast */

  var toastEl = null, toastTimer = null;
  function toast(msg, isError, ms) {
    if (!toastEl) {
      toastEl = document.createElement("div");
      toastEl.className = "ms-toast";
      document.body.appendChild(toastEl);
    }
    toastEl.textContent = msg;
    toastEl.classList.toggle("error", !!isError);
    toastEl.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove("show"); }, ms || (isError ? 3400 : 2000));
  }
  MSUI.toast = toast;

  /* --------------------------------------------------- confirm dialog */

  // Shared yes/no dialog (#confirm-modal in index.html). Resolves true/false; the modal's buttons run the
  // closeConfirmModal action, which each call re-points at its own promise.
  // Esc or a click outside the card answers "no". A new question while one is open answers the old one
  // "no" first, so no caller is left waiting forever. Destructive actions focus Cancel (Enter won't delete);
  // others focus OK.
  var confirmDone = null;
  function closeConfirmModal(value) { if (confirmDone) { var d = confirmDone; confirmDone = null; d(value); } }
  document.addEventListener("keydown", function (e) {
    if (!confirmDone || e.key !== "Escape") return;
    e.preventDefault();
    closeConfirmModal(false);
  });
  document.addEventListener("mousedown", function (e) {
    if (confirmDone && e.target === $("confirm-modal")) closeConfirmModal(false);
  });
  MSUI.confirm = function (title, message, okText, cancelText) {
    if (okText === undefined) okText = "Delete";
    if (cancelText === undefined) cancelText = "Cancel";
    closeConfirmModal(false);
    return new Promise(function (resolve) {
      var titleEl = $("confirmTitle"), messageEl = $("confirmMessage");
      if (titleEl) titleEl.innerText = title;
      if (messageEl) messageEl.innerText = message;
      var okBtn = $("confirmOkBtn"), cancelBtn = $("confirmCancelBtn"), danger = false;
      if (okBtn) {
        okBtn.innerText = okText;
        danger = /^(delete|remove|reset|clear)/i.test(okText) || okText.toLowerCase().indexOf("remove") !== -1;
        okBtn.style.background = danger ? "linear-gradient(135deg, #FF3B30 0%, #FF453A 100%)" : "var(--accent-gradient)";
      }
      if (cancelBtn) cancelBtn.innerText = cancelText;
      // The picture on top: a bin only for deleting, otherwise a question / warning.
      var icon = $("confirm-modal").querySelector(".activation-box > div");
      if (icon) icon.textContent = MSUI.confirm.icon || (danger ? "🗑️" : "⚠️");
      MSUI.confirm.icon = null;
      var field = $("confirmInput");
      if (field) field.style.display = "none";
      $("confirm-modal").style.display = "flex";
      setTimeout(function () { var f = danger ? cancelBtn : okBtn; if (f && confirmDone) { try { f.focus(); } catch (e) {} } }, 30);
      confirmDone = function (value) {
        $("confirm-modal").style.display = "none";
        resolve(value);
      };
    });
  };

  // Ask for a line of text in the same dialog (window.prompt is not available in every After Effects panel
  // and blocks it where it is). Resolves the trimmed text, or null when cancelled. Enter confirms, Esc cancels.
  MSUI.ask = function (title, message, value, okText) {
    var box = $("confirm-modal"), field = $("confirmInput");
    if (!field && box) {
      field = document.createElement("input");
      field.type = "text";
      field.id = "confirmInput";
      field.className = "ms-ask-input";
      field.setAttribute("spellcheck", "false");
      var msg = $("confirmMessage");
      msg.parentNode.insertBefore(field, msg.nextSibling);
      field.addEventListener("keydown", function (e) {
        if (e.key === "Enter") { e.preventDefault(); closeConfirmModal(true); }
        else if (e.key === "Escape") { e.preventDefault(); closeConfirmModal(false); }
      });
    }
    MSUI.confirm.icon = "✏️";
    var shown = MSUI.confirm(title, message || "", okText || "Save");
    if (!field) return shown.then(function () { return null; });
    field.style.display = "";
    field.value = value || "";
    setTimeout(function () { field.focus(); field.select(); }, 30);
    return shown.then(function (ok) { return ok ? field.value.trim() : null; });
  };

  /* ------------------------------------------ UI actions (data-action) */

  // index.html names what a control does instead of carrying inline on*="" code:
  //   data-action="name"              on click, with optional JSON arguments in data-args='["a", 1]'
  //   data-action-<event>="name"      on change, input, contextmenu (native menu suppressed) or error,
  //                                   with optional arguments in data-args-<event>='[...]'
  // One listener per event on document calls MSUI.actions[name](el, event, ...args). Clicks visit every
  // [data-action] from the target up, like inline handlers bubbling (a handler can stopPropagation());
  // error doesn't bubble, so it only fires for the element itself.
  // Each script registers the actions it owns with MSUI.action("name", fn, pick) (js/panel/00-msui.js);
  // the generic ones and this file's own are below. scripts/check.js fails if inline on*="" handlers come
  // back or a data-action name has no registration in any panel script.
  var actions = MSUI.actions;
  var slice = function (a, n) { return Array.prototype.slice.call(a, n); };

  MSUI.action("closeConfirmModal", closeConfirmModal);
  MSUI.action("addCustomColor", addCustomColor);
  MSUI.action("setCustomMode", setCustomMode);
  MSUI.action("setTCMode", setTCMode);
  MSUI.action("createTextLayer", createTextLayer);
  MSUI.action("applyTextCounter", applyTextCounter);
  MSUI.action("applyTimerCounter", applyTimerCounter);
  MSUI.action("showFitDialog", showFitDialog);
  MSUI.action("toggleGradLockUI", toggleGradLockUI);
  MSUI.action("organiseProjectUI", organiseProjectUI);
  MSUI.action("doPurgeCache", doPurgeCache);
  MSUI.action("doNudge", doNudge);
  MSUI.action("checkForUpdate", checkForUpdate);
  MSUI.action("msCopyDiagnostics", msCopyDiagnostics);
  MSUI.action("msRunSelfTest", msRunSelfTest);
  MSUI.action("updateUsernameFromSettings", updateUsernameFromSettings, "value");
  MSUI.action("handlePfpUpload", handlePfpUpload, "event");

  actions.core = function (el, ev) { return runCore.apply(null, slice(arguments, 2)); };
  actions.fxPercentFromSlider = function () { return runCore("disableFXByPercent", $("fxSlider").value); };
  actions.show = function (el, ev, id) { $(id).style.display = "flex"; };
  actions.hide = function (el, ev, id) { $(id).style.display = "none"; };
  actions.openSettings = function () { $("settings-modal").style.display = "flex"; MSUI.settings.init(); };
  actions.openFilePicker = function (el, ev, inputId) { $(inputId).click(); };
  actions.showValue = function (el, ev, targetId, upper) { $(targetId).innerText = upper ? el.value.toUpperCase() : el.value; };
  // sourceId null = copy the clicked element's own text.
  actions.copyText = function (el, ev, sourceId, message) {
    navigator.clipboard.writeText((sourceId ? $(sourceId) : el).innerText).then(function () { toast(message || "Copied"); }, function () { toast("Couldn't copy", true); });
  };
  actions.setSrc = function (el, ev, src) { el.src = src; };
  actions.hideSelf = function (el) { el.style.display = "none"; };

  function actionArgs(el, attr) {
    var raw = el.getAttribute(attr.replace("data-action", "data-args"));
    if (!raw) return [];
    try { var a = JSON.parse(raw); return Array.isArray(a) ? a : [a]; }
    catch (e) { logError("ui", "bad data-args " + raw); return []; }
  }
  function runAction(el, attr, ev) {
    var name = el.getAttribute(attr), fn = actions[name];
    if (typeof fn !== "function") { logError("ui", "unknown action " + name); return; }
    if (ev.type === "contextmenu") ev.preventDefault();
    fn.apply(el, [el, ev].concat(actionArgs(el, attr)));
  }
  function delegate(type, attr, bubbles) {
    document.addEventListener(type, function (ev) {
      if (!bubbles) {
        if (ev.target && ev.target.nodeType === 1 && ev.target.hasAttribute(attr)) runAction(ev.target, attr, ev);
        return;
      }
      for (var el = ev.target; el && el.nodeType === 1; el = el.parentNode) {
        if (el.hasAttribute(attr)) {
          runAction(el, attr, ev);
          if (ev.cancelBubble) return;
        }
      }
    }, !bubbles);   // non-bubbling events are only seen by document in the capture phase
  }
  delegate("click", "data-action", true);
  ["change", "input", "contextmenu"].forEach(function (t) { delegate(t, "data-action-" + t, true); });
  delegate("error", "data-action-error", false);

  /* ------------------------------------------------------ host bridge */

  // Panel button names → host functions in jsx/host.jsx. Extra fixed args go after the name.
  var CORE = {
    moveAnchorRobust: ["MS.anchor"],
    alignLayers: ["MS.align"],
    fitToComp: ["MS.fit"],
    applyBezierEase: ["MS.ease"],
    readBezierEase: ["MS.readEase"],
    createSmartLayer: ["MS.create"],
    trueDuplicate: ["MS.trueDuplicate"],
    unPrecomposeLayer: ["MS.unprecompose"],
    matchTopToBotExact: ["MS.trimTo", "bottom"],
    matchBotToTopExact: ["MS.trimTo", "top"],
    smartSpread: ["MS.spread"],
    fitKeyframesToLayer: ["MS.fitKeys"],
    applyExpression: ["MS.bounce"],
    gradLock: ["MS.gradLock"],
    organiseProject: ["MS.organise"],
    setLabelColor: ["MS.label"],
    disableFXByPercent: ["MS.fxPercent"],
    movePlayhead: ["MS.playhead"],
    offsetLayers: ["MS.offset"],
    nudgeLayers: ["MS.nudge"],
    importSRT: ["MS.importSRT"],
    buildSubtitleEditor: ["MS.subtitleBoxes"],
    pairAndStretch: ["MS.pairStretch"],
    selectPairLayers: ["MS.selectPair"],
    applyPresetWithDuration: ["MS.applyPresetWithDuration"],
    applyEffectPreset: ["MS.applyFxPreset"],
    magicReveal: ["MS.magicReveal"],
    counter: ["MS.counter"],
    makeCounterText: ["MS.makeCounterText"],
    colorSelection: ["MS.color"],
    gradientSelection: ["MS.gradient"],
    purgeCache: ["MS.purge"]
  };

  // Evaluate MS.fn(args…) in After Effects. Resolves with the raw "OK|…" / "ERR|…" string.
  function callHost(fn, args) {
    // JSON is valid ExtendScript source except for raw U+2028/U+2029 (line terminators there), so escape them.
    var LS = String.fromCharCode(0x2028), PS = String.fromCharCode(0x2029);
    var call = fn + "(" + (args || []).map(function (a) {
      return JSON.stringify(a === undefined ? null : a).split(LS).join("\\u2028").split(PS).join("\\u2029");
    }).join(",") + ")";
    if (!inCEP) { console.log("[host]", call); return Promise.resolve("OK|Preview: " + fn); }
    return new Promise(function (resolve) {
      cs.evalScript(call, function (res) {
        res = String(res || "");
        // Failures go to the diagnostics log (About → Copy diagnostics), with the function that failed.
        if (/^EvalScript error/i.test(res) || res.indexOf("ERR|") === 0) logError("host " + fn, res.replace(/^ERR\|/, ""));
        resolve(res);
      });
    });
  }
  MSUI.host = callHost;

  /* ------------------------------------------------- diagnostics log */

  var errorLog = [], hostVersion = "unknown";
  function logError(where, msg) {
    errorLog.push(new Date().toTimeString().slice(0, 8) + "  " + where + ": " + String(msg).slice(0, 300));
    if (errorLog.length > 25) errorLog.shift();
  }
  MSUI.logError = logError;   // also used by js/ms-studio.js, so Studio failures show up in "Copy diagnostics"
  window.addEventListener("error", function (e) { logError("panel", (e.message || "error") + (e.filename ? " (" + e.filename.split("/").pop() + ":" + e.lineno + ")" : "")); });
  window.addEventListener("unhandledrejection", function (e) { logError("panel", (e.reason && e.reason.message) || e.reason); });

  function msDiagnostics() {
    var env = {};
    try { env = JSON.parse(window.__adobe_cep__.getHostEnvironment()); } catch (e) {}
    return [
      "MotionSaaS " + ((window.MS_CONFIG && window.MS_CONFIG.version) || "?"),
      "After Effects: " + hostVersion + (env.appVersion ? " (CEP host " + env.appVersion + ")" : ""),
      "OS: " + navigator.platform + " — " + navigator.userAgent.replace(/^.*?\(([^)]*)\).*$/, "$1"),
      "Chromium: " + ((navigator.userAgent.match(/Chrome\/([\d.]+)/) || [])[1] || "?"),
      "Install: " + (window.Updater && window.Updater.isDevInstall && window.Updater.isDevInstall() ? "developer (git)" : "release"),
      "Last errors:",
      errorLog.length ? errorLog.join("\n") : "  (none)"
    ].join("\n");
  }
  function msCopyDiagnostics() {
    navigator.clipboard.writeText(msDiagnostics()).then(function () {
      toast("Diagnostics copied — paste them into your message to support");
    }, function () { toast("Couldn't copy — take a screenshot of this panel instead", true); });
  }

  // About → Run self-test: every tool against a throwaway comp; shows PASS/FAIL and copies the report.
  function msRunSelfTest() {
    var go = function () {
      var btn = $("btnSelfTest");
      if (btn) { btn.disabled = true; btn.textContent = "🧪 Testing… (about 15 s)"; }
      callHost("MS.selfTest", [EXT]).then(function (r) {
        if (btn) { btn.disabled = false; btn.textContent = "🧪 Run self-test"; }
        var text = r.replace(/^(OK|ERR)\|/, ""), fails = (text.match(/^FAIL/gm) || []).length;
        if (fails) logError("self-test", fails + " failed");
        showSelfTest(text, fails);
      });
    };
    MSUI.confirm("Run self-test?",
      "MotionSaaS will build a temporary comp, try every tool on it, then delete everything it made. Your own comps aren't touched. It takes about 15 seconds.",
      "Run test", "Cancel").then(function (ok) { if (ok) go(); });
  }
  MSUI.diagnostics = msDiagnostics;

  function showSelfTest(text, fails) {
    var m = $("msSelfTestModal");
    if (!m) {
      m = document.createElement("div");
      m.id = "msSelfTestModal";
      m.className = "activation-overlay";
      m.style.cssText = "display:none; z-index:22000; align-items:center; justify-content:center;";
      m.innerHTML = '<div class="activation-box glass-panel ms-fit-box" style="width:92%; max-width:520px;">' +
        '<h3 id="msSelfTestTitle"></h3><p>Copy this and send it to support (or your developer).</p>' +
        '<textarea id="msSelfTestText" readonly class="ms-selftest-text"></textarea>' +
        '<div class="ms-fit-grid"><button id="msSelfTestCopy"><b>Copy report</b><span>includes diagnostics</span></button>' +
        '<button id="msSelfTestClose"><b>Close</b><span>&nbsp;</span></button></div></div>';
      document.body.appendChild(m);
      $("msSelfTestClose").addEventListener("click", function () { m.style.display = "none"; });
      $("msSelfTestCopy").addEventListener("click", function () {
        navigator.clipboard.writeText($("msSelfTestText").value + "\n\n" + msDiagnostics()).then(function () { toast("Report copied"); });
      });
    }
    $("msSelfTestTitle").textContent = fails ? "Self-test: " + fails + " problem" + (fails === 1 ? "" : "s") + " found" : "Self-test: everything passed ✓";
    $("msSelfTestText").value = text;
    m.style.display = "flex";
  }

  function report(res, quiet) {
    if (res.indexOf("OK|") === 0) { if (!quiet) toast(res.slice(3)); }
    // (callHost already wrote failures to the diagnostics log.)
    else if (res.indexOf("ERR|") === 0) { toast(res.slice(4), true); }
    else if (/^EvalScript error/i.test(res)) { toast("After Effects didn't run that. Close any dialog open in After Effects and try again; if it keeps failing, reopen the panel (About → Copy diagnostics helps support).", true, 6000); }
    else if (res && !quiet) toast(res, true);
    return res;
  }
  MSUI.report = report;

  function runCore(name) {
    var map = CORE[name], args = Array.prototype.slice.call(arguments, 1);
    if (!map) { toast("Unknown action: " + name, true); return Promise.resolve(""); }
    if (name === "movePlayhead" && window.event && window.event.shiftKey) args[0] = -Math.abs(Number(args[0]) || 0);
    if (name === "disableFXByPercent") args[0] = Number(args[0]) || 0;
    if (name === "applyExpression" && args[0] !== "bounce") { toast("Unknown expression: " + args[0], true); return Promise.resolve(""); }
    if (name === "applyExpression") args = [];
    return callHost(map[0], map.slice(1).concat(args)).then(function (r) { return report(r); });
  }
  MSUI.runCore = runCore;

  // Load the newest host.jsx (so edits/updates apply without restarting AE) and surface load errors.
  function loadHost() {
    if (!inCEP) return;
    var p = (EXT + "/jsx/host.jsx").replace(/\\/g, "/");
    // The path as a JSON string literal: a quote or backslash in a folder name can't break the script.
    cs.evalScript('(function(){try{$.evalFile(' + JSON.stringify(p) + ');return MS.ping();}catch(e){return "ERR|host.jsx line " + e.line + ": " + e.message;}})()', function (r) {
      r = String(r || "");
      if (r.indexOf("OK|") === 0) hostVersion = r.slice(3);
      else logError("host load", r || "no response");
      if (r.indexOf("OK|") !== 0) {
        toast("MotionSaaS couldn't start its After Effects script: " + (r.replace(/^ERR\|/, "") || "no response"), true, 9000);
        if (MSUI.studio && MSUI.studio.engine) MSUI.studio.engine(false, "host.jsx: " + (r.replace(/^ERR\|/, "") || "no response"));
        return;
      }
      loadStudioEngine();
    });
  }

  // The Studio's engine (jsx/studio.jsx), loaded by its full path; its exact error is shown if it fails,
  // instead of a Studio whose buttons silently do nothing.
  function loadStudioEngine() {
    var sp = (EXT + "/jsx/studio.jsx").replace(/\\/g, "/");
    cs.evalScript('(function(){try{if(MS.loadStudio(' + JSON.stringify(sp) + ')){return "OK|studio";}return "ERR|" + MS.studioError;}catch(e){return "ERR|studio.jsx line " + e.line + ": " + e.message;}})()', function (r) {
      r = String(r || "");
      var ok = r.indexOf("OK|") === 0, msg = ok ? "" : (r.replace(/^ERR\|/, "") || "no response");
      if (!ok) {
        logError("studio load", msg);
        toast("The MotionSaaS Studio engine didn't load: " + msg, true, 12000);
      }
      if (MSUI.studio && MSUI.studio.engine) MSUI.studio.engine(ok, msg);
    });
  }
  MSUI.loadStudioEngine = loadStudioEngine;

  /* -------------------------------------------------------------- tabs */

  // The panel that opens rises in (its top-level blocks, a few ms apart): css/ms-extra.css .ms-enter. Only on a
  // real change, and the class comes off again so blocks shown later (sub-tabs, cards) don't replay it.
  var enterT = 0;
  function showTab(id, replay) {
    var found = false;
    $$(".tab-content").forEach(function (c) {
      var on = c.id === id + "-tab", was = c.classList.contains("active");
      if (on) found = true;
      c.style.display = on ? "block" : "none";
      c.classList.toggle("active", on);
      if (on && (!was || replay)) {
        c.classList.remove("ms-enter");
        void c.offsetWidth;   // restart the animation
        c.classList.add("ms-enter");
        clearTimeout(enterT);
        enterT = setTimeout(function () { c.classList.remove("ms-enter"); }, 700);
      }
    });
    if (!found) return;
    $$(".tab-btn").forEach(function (b) { b.classList.toggle("active", b.getAttribute("data-tab") === id); });
    store.set("ms_last_tab", id);
    document.dispatchEvent(new CustomEvent("ms-tab", { detail: id }));
  }
  MSUI.showTab = showTab;

  function initTabs() {
    $$(".tab-btn").forEach(function (b) {
      b.addEventListener("click", function () { showTab(b.getAttribute("data-tab")); });
    });
    var last = store.get("ms_last_tab", "create");
    // Tool panels are off until turned on in Settings (js/ms-studio.js, MSUI.panels).
    if (MSUI.panels && !MSUI.panels.isOn(last)) last = MSUI.panels.firstOn() || "create";
    showTab(last);
  }

  /* ---------------------------------------------------------- tooltips */

  function initTooltips() {
    var tip = document.createElement("div"), current = null;
    tip.className = "ms-tooltip";
    document.body.appendChild(tip);
    document.addEventListener("mouseover", function (e) {
      var el = e.target.closest ? e.target.closest("[data-tip]") : null;
      if (!el || el === current) return;
      current = el;
      tip.textContent = el.getAttribute("data-tip");
      var r = el.getBoundingClientRect();
      tip.classList.add("visible");
      var w = tip.offsetWidth, x = Math.max(6, Math.min(window.innerWidth - w - 6, r.left + r.width / 2 - w / 2));
      var y = r.top - tip.offsetHeight - 8;
      if (y < 4) y = r.bottom + 8;
      tip.style.left = x + "px"; tip.style.top = y + "px";
    });
    document.addEventListener("mouseout", function (e) {
      if (!current) return;
      var to = e.relatedTarget;
      if (to && current.contains(to)) return;
      current = null;
      tip.classList.remove("visible");
    });
  }

  /* ----------------------------------------------------- slider fill */

  // Tool panel sliders show the chosen part of their track in the accent colour, like the Studio's
  // (css/ms-extra.css reads --ms-fill). Kept current on input and on value changes made by scripts.
  function rangeFill(r) {
    var min = +r.min || 0, max = r.max === "" ? 100 : +r.max, v = +r.value;
    r.style.setProperty("--ms-fill", (max > min ? Math.max(0, Math.min(100, (v - min) / (max - min) * 100)) : 0).toFixed(1) + "%");
  }
  function initRangeFill() {
    var all = function () { [].forEach.call(document.querySelectorAll(".tab-content input[type=range]"), rangeFill); };
    document.addEventListener("input", function (e) { if (e.target && e.target.type === "range") rangeFill(e.target); }, true);
    document.addEventListener("change", function (e) { if (e.target && e.target.type === "range") rangeFill(e.target); }, true);
    document.addEventListener("ms-tab", all);
    all();
    // Sliders a panel builds later (Carousel's controls) get their fill right away.
    MSUI.panelRangeFill = function (root) { [].forEach.call((root || document).querySelectorAll("input[type=range]"), rangeFill); };
  }

  /* --------------------------------------------------- bezier editor */

  var bz = { v: [0.33, 0, 0.67, 1], drag: 0 };

  function curvePath(v) {
    return "M 0,100 C " + (v[0] * 100) + "," + (100 - v[1] * 100) + " " + (v[2] * 100) + "," + (100 - v[3] * 100) + " 100,0";
  }
  function fmt(v) { return "[ " + v.map(function (n) { return (Math.round(n * 100) / 100).toFixed(2); }).join(", ") + " ]"; }
  function parseCurve(text) {
    var nums = (String(text).match(/-?\d*\.?\d+/g) || []).map(Number);
    if (nums.length !== 4) return null;
    if (nums[0] < 0 || nums[0] > 1 || nums[2] < 0 || nums[2] > 1) return null;
    return nums;
  }

  function bzGeom(canvas) {
    var w = canvas.clientWidth, h = canvas.clientHeight, px = w * 0.12, py = h * 0.22;
    return {
      w: w, h: h,
      toX: function (x) { return px + x * (w - px * 2); },
      toY: function (y) { return h - py - y * (h - py * 2); },
      fromX: function (X) { return (X - px) / (w - px * 2); },
      fromY: function (Y) { return (h - py - Y) / (h - py * 2); }
    };
  }

  function redrawBezier() {
    var canvas = $("bezierCanvas");
    if (!canvas || !canvas.clientWidth) return;
    var dpr = window.devicePixelRatio || 1, g = bzGeom(canvas), ctx = canvas.getContext("2d"), v = bz.v, i;
    if (canvas.width !== Math.round(g.w * dpr) || canvas.height !== Math.round(g.h * dpr)) {
      canvas.width = Math.round(g.w * dpr); canvas.height = Math.round(g.h * dpr);
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, g.w, g.h);
    var accent = getComputedStyle(document.documentElement).getPropertyValue("--accent-blue").trim() || "#007AFF";

    ctx.lineWidth = 1;
    ctx.strokeStyle = "rgba(255,255,255,0.05)";
    for (i = 0; i <= 4; i++) {
      ctx.beginPath(); ctx.moveTo(g.toX(i / 4), g.toY(0)); ctx.lineTo(g.toX(i / 4), g.toY(1)); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(g.toX(0), g.toY(i / 4)); ctx.lineTo(g.toX(1), g.toY(i / 4)); ctx.stroke();
    }
    ctx.strokeStyle = "rgba(255,255,255,0.12)";
    ctx.setLineDash([4, 4]);
    ctx.beginPath(); ctx.moveTo(g.toX(0), g.toY(0)); ctx.lineTo(g.toX(1), g.toY(1)); ctx.stroke();
    ctx.setLineDash([]);

    ctx.strokeStyle = "rgba(255,255,255,0.45)";
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(g.toX(0), g.toY(0)); ctx.lineTo(g.toX(v[0]), g.toY(v[1])); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(g.toX(1), g.toY(1)); ctx.lineTo(g.toX(v[2]), g.toY(v[3])); ctx.stroke();

    ctx.strokeStyle = accent;
    ctx.lineWidth = 3.5;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(g.toX(0), g.toY(0));
    ctx.bezierCurveTo(g.toX(v[0]), g.toY(v[1]), g.toX(v[2]), g.toY(v[3]), g.toX(1), g.toY(1));
    ctx.stroke();

    ctx.fillStyle = accent;
    [[0, 0], [1, 1]].forEach(function (p) { ctx.beginPath(); ctx.arc(g.toX(p[0]), g.toY(p[1]), 4, 0, Math.PI * 2); ctx.fill(); });

    var h1 = $("handle1"), h2 = $("handle2");
    if (h1) { h1.style.left = g.toX(v[0]) + "px"; h1.style.top = g.toY(v[1]) + "px"; }
    if (h2) { h2.style.left = g.toX(v[2]) + "px"; h2.style.top = g.toY(v[3]) + "px"; }
    var out = $("bezierValues");
    if (out && document.activeElement !== out) out.value = fmt(v);
  }
  function setCurve(v) { bz.v = v.slice(0, 4); redrawBezier(); }
  MSUI.editor = { init: initBezierEditor, redraw: redrawBezier };

  function initBezierEditor() {
    var canvas = $("bezierCanvas");
    if (!canvas || canvas._msReady) { redrawBezier(); return; }
    canvas._msReady = true;
    var bounds = $("graphBounds");
    function start(which) {
      return function (e) { e.preventDefault(); bz.drag = which; };
    }
    if ($("handle1")) $("handle1").addEventListener("mousedown", start(1));
    if ($("handle2")) $("handle2").addEventListener("mousedown", start(2));
    canvas.addEventListener("mousedown", function (e) {
      var r = canvas.getBoundingClientRect(), g = bzGeom(canvas), x = g.fromX(e.clientX - r.left), y = g.fromY(e.clientY - r.top);
      var d1 = Math.abs(x - bz.v[0]) + Math.abs(y - bz.v[1]), d2 = Math.abs(x - bz.v[2]) + Math.abs(y - bz.v[3]);
      bz.drag = d1 <= d2 ? 1 : 2;
      move(e);
    });
    function move(e) {
      if (!bz.drag) return;
      var r = (bounds || canvas).getBoundingClientRect(), g = bzGeom(canvas);
      var x = Math.max(0, Math.min(1, g.fromX(e.clientX - r.left))), y = Math.max(-1, Math.min(2, g.fromY(e.clientY - r.top)));
      x = Math.round(x * 100) / 100; y = Math.round(y * 100) / 100;
      if (bz.drag === 1) { bz.v[0] = x; bz.v[1] = y; } else { bz.v[2] = x; bz.v[3] = y; }
      redrawBezier();
    }
    document.addEventListener("mousemove", move);
    document.addEventListener("mouseup", function () { bz.drag = 0; });
    window.addEventListener("resize", redrawBezier);

    var input = $("bezierValues");
    if (input) input.addEventListener("change", function () {
      var v = parseCurve(input.value);
      if (v) setCurve(v); else { toast("Use 4 numbers like 0.33, 0, 0.67, 1", true); redrawBezier(); }
    });
    if ($("btnBezierApply")) $("btnBezierApply").addEventListener("click", function () {
      runCore("applyBezierEase", bz.v[0], bz.v[1], bz.v[2], bz.v[3]);
    });
    if ($("btnBezierRead")) $("btnBezierRead").addEventListener("click", function () {
      callHost("MS.readEase").then(function (r) {
        if (r.indexOf("OK|") !== 0) { report(r); return; }
        var v = parseCurve(r.slice(3));
        if (v) { setCurve(v); toast("Read curve " + fmt(v)); }
      });
    });
    if ($("btnBezierSave")) $("btnBezierSave").addEventListener("click", function () {
      MSUI.ask("Save this curve", "It appears with your saved curves; right-click one there to remove it.", "My Curve").then(function (name) {
        if (name === null) return;
        addCustomEase(name || "My Curve", bz.v.slice());
      });
    });
    redrawBezier();
  }

  /* ---------------------------------------------------- custom eases */

  function easeButtonHTML(name, v) {
    return '<svg viewBox="0 0 100 100" class="ease-graph"><path stroke="#30d158" stroke-width="10" fill="none" d="' + curvePath(v) + '" /></svg><span></span>';
  }
  function renderCustomEases() {
    var box = $("custom-easing-injection");
    if (!box) return;
    box.innerHTML = "";
    store.get("ms_custom_eases", []).forEach(function (e, i) {
      var b = document.createElement("button");
      b.className = "ease-btn custom-ease";
      b.title = e.n + " [" + e.v.join(", ") + "]\nRight-click to remove";
      b.innerHTML = easeButtonHTML(e.n, e.v);
      b.querySelector("span").textContent = e.n;
      b.addEventListener("click", function () { runCore("applyBezierEase", e.v[0], e.v[1], e.v[2], e.v[3]); });
      b.addEventListener("contextmenu", function (ev) {
        ev.preventDefault();
        var list = store.get("ms_custom_eases", []);
        list.splice(i, 1); store.set("ms_custom_eases", list); renderCustomEases();
        toast("Removed “" + e.n + "”");
      });
      box.appendChild(b);
    });
  }
  function addCustomEase(name, v) {
    var list = store.get("ms_custom_eases", []);
    list.push({ n: name, v: v });
    store.set("ms_custom_eases", list);
    renderCustomEases();
    toast("Saved curve “" + name + "”");
  }

  function initEasing() {
    $$(".ease-btn").forEach(function (b) {
      // Clicking a preset also loads it into the graph editor.
      b.addEventListener("click", function () {
        var m = (b.getAttribute("title") || "").match(/\[([^\]]+)\]/);
        var v = m && parseCurve(m[1]);
        if (v) setCurve(v);
      });
    });
    var graphBtn = $("btnToggleBlueGraph"), editor = $("bezierGraphEditor");
    if (graphBtn && editor) graphBtn.addEventListener("click", function () {
      var open = editor.style.display === "none";
      editor.style.display = open ? "block" : "none";
      if (open) setTimeout(initBezierEditor, 30);
    });
    var setBtn = $("toggleEaseSettings"), box = $("customEaseBox");
    if (setBtn && box) setBtn.addEventListener("click", function () { box.style.display = box.style.display === "none" ? "block" : "none"; });
    if ($("btnApplyCustomEase")) $("btnApplyCustomEase").addEventListener("click", function () {
      var v = parseCurve($("customEaseInput").value);
      if (!v) { toast("Enter 4 numbers, like 0.5, 0, 0.5, 1 (1st and 3rd between 0 and 1)", true); return; }
      addCustomEase(($("customEaseName").value || "").trim() || "Custom", v);
      $("customEaseName").value = ""; $("customEaseInput").value = "";
    });
    renderCustomEases();
  }

  /* -------------------------------------------- fit / grad / organise */

  function showFitDialog() {
    var m = $("msFitModal");
    if (!m) {
      m = document.createElement("div");
      m.id = "msFitModal";
      m.className = "activation-overlay";
      m.style.cssText = "display:none; z-index:900; align-items:center; justify-content:center;";
      m.innerHTML =
        '<div class="activation-box glass-panel ms-fit-box">' +
        '<h3>Fit to Comp</h3><p>Scales the selected layers to the composition.</p>' +
        '<div class="ms-fit-grid">' +
        '<button data-fit="fit"><b>Fit</b><span>Whole layer visible</span></button>' +
        '<button data-fit="fill"><b>Fill</b><span>Cover the frame</span></button>' +
        '<button data-fit="width"><b>Width</b><span>Match comp width</span></button>' +
        '<button data-fit="height"><b>Height</b><span>Match comp height</span></button>' +
        '</div><button class="ms-fit-cancel">Cancel</button></div>';
      document.body.appendChild(m);
      $$("[data-fit]", m).forEach(function (b) {
        b.addEventListener("click", function () { m.style.display = "none"; runCore("fitToComp", b.getAttribute("data-fit")); });
      });
      m.querySelector(".ms-fit-cancel").addEventListener("click", function () { m.style.display = "none"; });
      m.addEventListener("click", function (e) { if (e.target === m) m.style.display = "none"; });
    }
    m.style.display = "flex";
  }
  function toggleGradLockUI() { runCore("gradLock"); }
  function organiseProjectUI() { runCore("organiseProject"); }
  function doPurgeCache() { runCore("purgeCache"); }
  function doNudge(dir) {
    var amt = Math.abs(Number(($("nudgeAmt") || {}).value) || 10);
    runCore("nudgeLayers", dir * amt);
  }

  /* ------------------------------------------- custom colours (C view) */

  var SOLIDS = ["#FFFFFF", "#F2F2F7", "#C7C7CC", "#8E8E93", "#3A3A3C", "#1C1C1E", "#000000", "#0A2540", "#0B0B0F", "#111827",
    "#007AFF", "#0A84FF", "#5AC8FA", "#00C7BE", "#34C759", "#30D158", "#A3E635", "#FFCC00", "#FF9F0A", "#FF9500",
    "#FF6F61", "#FF3B30", "#FF2D55", "#FF375F", "#AF52DE", "#BF5AF2", "#5856D6", "#635BFF", "#8B5CF6", "#5E6AD2"];
  var GRADIENTS = [["#1D90FF", "#006AFF"], ["#A855F7", "#7C3AED"], ["#34D399", "#059669"], ["#FB923C", "#EA580C"], ["#F87171", "#DC2626"],
    ["#FF6B8B", "#FF2D55"], ["#00F2FE", "#00C7BE"], ["#FFE066", "#FFCC00"], ["#0A84FF", "#BF5AF2"], ["#635BFF", "#00D4FF"],
    ["#5E6AD2", "#8B5CF6"], ["#FF7A59", "#FF5E8A"], ["#00C2A8", "#4ADE80"], ["#0F172A", "#334155"], ["#FF9A8B", "#FF6A88"],
    ["#43E97B", "#38F9D7"], ["#FA709A", "#FEE140"], ["#30CFD0", "#330867"], ["#667EEA", "#764BA2"], ["#F093FB", "#F5576C"]];

  var colorMode = "solid";

  function swatch(bg, title, onClick, onContext) {
    var s = document.createElement("div");
    s.className = "ms-swatch";
    s.style.background = bg;
    s.title = title;
    s.addEventListener("click", onClick);
    if (onContext) s.addEventListener("contextmenu", function (e) { e.preventDefault(); onContext(); });
    return s;
  }
  function applySolid(hex) { runCore("colorSelection", hex); }
  function applyGradient(a, b) { runCore("gradientSelection", a, b, false); }

  function renderColorGrids() {
    var solids = $("solids-grid"), grads = $("gradients-grid"), custom = $("custom-colors-grid");
    if (solids && !solids.children.length) SOLIDS.forEach(function (h) { solids.appendChild(swatch(h, h + " — click to colour the selection", function () { applySolid(h); })); });
    if (grads && !grads.children.length) GRADIENTS.forEach(function (g) {
      grads.appendChild(swatch("linear-gradient(135deg," + g[0] + "," + g[1] + ")", g[0] + " → " + g[1], function () { applyGradient(g[0], g[1]); }));
    });
    if (custom) {
      custom.innerHTML = "";
      var list = store.get("ms_custom_colors", []);
      list.forEach(function (c, i) {
        var bg = c.b ? "linear-gradient(135deg," + c.a + "," + c.b + ")" : c.a;
        custom.appendChild(swatch(bg, (c.b ? c.a + " → " + c.b : c.a) + "\nRight-click to remove",
          function () { if (c.b) applyGradient(c.a, c.b); else applySolid(c.a); },
          function () { var l = store.get("ms_custom_colors", []); l.splice(i, 1); store.set("ms_custom_colors", l); renderColorGrids(); }));
      });
      if (!list.length) custom.innerHTML = '<div class="ms-empty" style="grid-column: span 10;">Your colours appear here.</div>';
    }
  }

  function normHex(v) {
    var h = String(v || "").replace(/[^0-9a-f]/gi, "").toUpperCase();
    if (h.length === 3) h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
    return h.length === 6 ? "#" + h : null;
  }

  function setCustomMode(mode) {
    colorMode = mode === "gradient" ? "gradient" : "solid";
    var on = "var(--accent-gradient)", solidBtn = $("btn-mode-solid-pill"), gradBtn = $("btn-mode-grad-pill");
    [[solidBtn, colorMode === "solid"], [gradBtn, colorMode === "gradient"]].forEach(function (p) {
      if (!p[0]) return;
      p[0].classList.toggle("active", p[1]);
      p[0].style.setProperty("background", p[1] ? on : "transparent", "important");
      p[0].style.setProperty("color", p[1] ? "#fff" : "var(--text-secondary)", "important");
      p[0].style.setProperty("box-shadow", p[1] ? "0 4px 12px rgba(var(--accent-rgb), 0.3)" : "none", "important");
    });
    ["custom-hex-2", "custom-color-2"].forEach(function (id) { if ($(id)) $(id).style.display = colorMode === "gradient" ? "" : "none"; });
    if ($("solids-container")) $("solids-container").style.display = colorMode === "solid" ? "" : "none";
    if ($("gradients-container")) $("gradients-container").style.display = colorMode === "gradient" ? "" : "none";
  }

  function addCustomColor() {
    var a = normHex(($("custom-hex-1") || {}).value) || ($("custom-color-1") || {}).value;
    var b = colorMode === "gradient" ? (normHex(($("custom-hex-2") || {}).value) || ($("custom-color-2") || {}).value) : null;
    if (!a) { toast("Enter a colour like #FF5500", true); return; }
    var list = store.get("ms_custom_colors", []);
    list.push({ a: a.toUpperCase(), b: b ? b.toUpperCase() : null });
    store.set("ms_custom_colors", list);
    renderColorGrids();
    toast("Colour added");
  }

  function linkHexPair(hexId, colorId) {
    var hex = $(hexId), col = $(colorId);
    if (!hex || !col) return;
    hex.addEventListener("input", function () { var h = normHex(hex.value); if (h) col.value = h; });
    col.addEventListener("input", function () { hex.value = col.value.toUpperCase(); });
  }

  function initColors() {
    linkHexPair("custom-hex-1", "custom-color-1");
    linkHexPair("custom-hex-2", "custom-color-2");
    setCustomMode("solid");
    renderColorGrids();
    // The shared palette library (js/ms-palettes.js), compact: link, library and colours in use.
    if (MSUI.palettes) MSUI.palettes.mount($("ccPalettes"), { compact: true });
    var slider = $("fxSlider"), lbl = $("fxPctText");
    if (slider && lbl) {
      var upd = function () { lbl.textContent = "Off: " + slider.value + "%"; };
      slider.addEventListener("input", upd); upd();
    }
  }

  /* ------------------------------------------------- counter (T view) */

  function setTCMode(mode) {
    var timer = mode === "timer";
    if ($("tcModeCounter")) $("tcModeCounter").classList.toggle("lc-active", !timer);
    if ($("tcModeTimer")) $("tcModeTimer").classList.toggle("lc-active", timer);
    if ($("tcSectionCounter")) $("tcSectionCounter").style.display = timer ? "none" : "block";
    if ($("tcSectionTimer")) $("tcSectionTimer").style.display = timer ? "block" : "none";
  }
  function createTextLayer() { runCore("makeCounterText"); }
  function val(id, d) { var e = $(id); return e ? e.value : d; }
  function chk(id) { var e = $(id); return !!(e && e.checked); }
  function applyTextCounter() {
    runCore("counter", {
      mode: "counter", pre: val("tcPrefix", ""), post: val("tcPostfix", ""),
      start: Number(val("tcStartVal", 0)) || 0, end: Number(val("tcEndVal", 0)) || 0,
      dur: Number(val("tcDuration", 2)) || 2, mult: Number(val("tcMultiplier", 1)) || 1,
      dec: Number(val("tcDecimals", 1)) || 0, showDec: chk("tcShowDecimals"), comma: chk("tcUseComma"),
      short: chk("tcUseShorthand"), thousands: true
    });
  }
  function applyTimerCounter() {
    runCore("counter", {
      mode: "timer", pre: val("tmPrefix", ""), post: val("tmPostfix", ""),
      tStart: Number(val("tmStartSec", 60)) || 0, speed: Number(val("tmSpeed", 1)) || 1,
      days: chk("tmShowDays"), hours: chk("tmShowHours"), mins: chk("tmShowMinutes"), secs: chk("tmShowSeconds"),
      countdown: chk("tmCountdown")
    });
  }

  /* ------------------------------------------------------ magic reveal */

  function initMagicReveal() {
    var adv = $("mrAdvToggle");
    if (adv) adv.addEventListener("click", function () {
      var p = $("mrAdvPanel"), open = p.style.display === "none";
      p.style.display = open ? "block" : "none";
      if ($("mrAdvChevron")) $("mrAdvChevron").style.transform = open ? "rotate(180deg)" : "";
    });
    var go = $("btnMagicIt");
    if (go) go.addEventListener("click", function () {
      runCore("magicReveal", {
        color: val("mrColor", "#F5C846"), dir: val("mrDirection", "LR"), frames: Number(val("mrDuration", 20)),
        glow: Number(val("mrGlow", 85)), blur: Number(val("mrBlur", 90)), feather: Number(val("mrFeather", 100)),
        rim: Number(val("mrStroke", 6)), blend: val("mrBlend", "normal"),
        easeOut: Number(val("mrEout", 12)), easeIn: Number(val("mrEin", 90))
      });
    });
  }

  /* --------------------------------------------- profile picture */

  // The panel's localStorage holds ~5 MB for everything (curves, colours, timer, layout). A full-size
  // phone photo stored as base64 — twice — would fill it and silently break every later save.
  // Shrink the picture to 160 px before storing it.
  function handlePfpUpload(event) {
    var file = event && event.target && event.target.files && event.target.files[0];
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function (e) {
      var img = new Image();
      img.onload = function () {
        var size = 160, canvas = document.createElement("canvas"), s = Math.min(img.width, img.height);
        canvas.width = size; canvas.height = size;
        canvas.getContext("2d").drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, size, size);
        var data = canvas.toDataURL("image/jpeg", 0.85);
        try {
          localStorage.setItem("ms_user_pfp", data);
          localStorage.removeItem("ms_user_dp");   // old duplicate copy
        } catch (err) { toast("Couldn't save that picture — try a smaller image", true); return; }
        var prev = $("settingsPfpPreview");
        if (prev) prev.src = data;
        toast("Profile picture updated");
      };
      img.onerror = function () { toast("That file isn't an image AE's panel can read", true); };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
    event.target.value = "";
  }

  /* ------------------------------------------- settings + greeting */

  function updateUsernameFromSettings(v) {
    localStorage.setItem("ms_userName", String(v || "").trim() || "Editor");
  }

  function greet() {
    if (localStorage.getItem("ms_disable_greetings") === "true") return;
    var notif = $("greetingNotification");
    if (!notif) return;
    var hour = new Date().getHours(), prefix = "Good Night,", emoji = "🌙";
    if (hour >= 5 && hour < 12) { prefix = "Good Morning,"; emoji = "🌅"; }
    else if (hour >= 12 && hour < 18) { prefix = "Good Afternoon,"; emoji = "☀️"; }
    else if (hour >= 18) { prefix = "Good Evening,"; emoji = "🌆"; }
    var name = (localStorage.getItem("ms_userName") || "Editor").trim().split(/\s+/)[0].replace(/[^a-zA-Z]/g, "") || "Editor";
    name = name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();
    // The greeting script in index.html watches this element and turns it into the toast.
    notif.textContent = prefix + " " + name + " " + emoji;
  }

  /* --------------------------------------------------------- updates */

  var updateInfo = null;

  function updMsg(where, text, isError) {
    if (where === "studio" && MSUI.updates && MSUI.updates.listener) { MSUI.updates.listener(text, !!isError); return; }
    var el = $(where === "settings" ? "updateCheckMsgSettings" : "updateCheckMsg");
    if (!el) return;
    el.style.display = text ? "block" : "none";
    el.style.color = isError ? "var(--accent-red, #FF453A)" : "var(--accent-green)";
    el.textContent = text;
  }

  function showBanner(info) {
    var banner = $("update-banner");
    if (!banner) return;
    if ($("updateBannerVersion")) $("updateBannerVersion").textContent = "v" + info.latest + " is ready";
    var btn = $("btnUpdateDownload");
    if (btn) { btn.textContent = "Install"; btn.onclick = function () { installUpdate("banner"); }; }
    banner.style.display = "block";
    var info2 = $("btnInfo");
    if (info2 && !info2.querySelector(".update-dot")) {
      info2.style.position = "relative";
      var dot = document.createElement("div"); dot.className = "update-dot"; info2.appendChild(dot);
    }
  }

  function installUpdate(where) {
    if (!updateInfo || !updateInfo.available) { checkForUpdate(true, where); return; }
    var btns = [$("btnCheckUpdate"), $("btnCheckUpdateSettings"), $("btnUpdateDownload")];
    btns.forEach(function (b) { if (b) b.disabled = true; });
    updMsg(where, "Downloading v" + updateInfo.latest + "… 0%");
    window.Updater.install(updateInfo, function (p) { updMsg(where, "Downloading v" + updateInfo.latest + "… " + Math.round(p * 100) + "%"); })
      .then(function (v) {
        updMsg(where, "Installed v" + v + " — reloading…");
        toast("MotionSaaS updated to v" + v);
        setTimeout(function () { location.reload(); }, 1200);
      })
      .catch(function (err) {
        btns.forEach(function (b) { if (b) b.disabled = false; });
        updMsg(where, "Update failed: " + err.message, true);
      });
  }

  // manual: user clicked "Check for Update"; where: "about" | "settings" | "auto"
  function checkForUpdate(manual, where) {
    if (!window.Updater) return;
    if (!inCEP) { if (manual) updMsg(where, "Open inside After Effects to check for updates."); return; }
    if (updateInfo && updateInfo.available && manual) { installUpdate(where); return; }
    if (window.Updater.isDevInstall()) { if (manual) updMsg(where, "Developer install — get new code with git pull."); return; }
    if (!manual && window.Updater.shouldAutoCheck && !window.Updater.shouldAutoCheck()) {
      var cached = window.Updater.cachedLatest();
      if (cached && window.Updater.isNewer(cached, window.MS_CONFIG.version)) showBanner({ latest: cached });
      return;
    }
    if (manual) updMsg(where, "Checking…");
    var pending;
    try { pending = window.Updater.check(); } catch (e) { pending = Promise.reject(e); }
    pending.then(function (info) {
      updateInfo = info;
      if (info.available) {
        showBanner(info);
        if (manual) {
          updMsg(where, "v" + info.latest + " is available — click again to install.");
          ["btnCheckUpdate", "btnCheckUpdateSettings"].forEach(function (id) { if ($(id)) $(id).textContent = "⬇️ Install v" + info.latest; });
        }
      } else if (manual) {
        updMsg(where, "You're up to date (v" + window.MS_CONFIG.version + ").");
      }
    }).catch(function (err) { if (manual) updMsg(where, "Couldn't check: " + err.message, true); });
  }

  function showVersion() {
    var v = "v" + ((window.MS_CONFIG && window.MS_CONFIG.version) || "?");
    if ($("aboutVersionDisplay")) $("aboutVersionDisplay").textContent = v;
    if ($("footerVersionText")) $("footerVersionText").textContent = v;
  }

  /* ---------------------------------------------------------- exports */

  var compTools = MSUI.compTools = MSUI.compTools || {};
  compTools.showFitDialog = showFitDialog;
  compTools.gradLock = toggleGradLockUI;
  compTools.organiseProject = organiseProjectUI;
  compTools.purgeCache = doPurgeCache;
  compTools.nudge = doNudge;
  MSUI.colors = { setMode: setCustomMode, add: addCustomColor };
  MSUI.counter = { setMode: setTCMode, createTextLayer: createTextLayer, applyCounter: applyTextCounter, applyTimer: applyTimerCounter };
  MSUI.profile = { uploadPicture: handlePfpUpload };
  (MSUI.settings = MSUI.settings || {}).updateUsername = updateUsernameFromSettings;
  MSUI.updates = { check: checkForUpdate };
  MSUI.diag = {
    copy: msCopyDiagnostics, selfTest: msRunSelfTest, text: msDiagnostics,
    // For the Studio's About dialog: run the self-test and resolve with the report text (no old-style dialogs).
    selfTestText: function () {
      if (!inCEP) return Promise.resolve("Open MotionSaaS inside After Effects to run the self-test.");
      return callHost("MS.selfTest", [EXT]).then(function (r) {
        var text = String(r || "").replace(/^(OK|ERR)\|/, ""), fails = (text.match(/^FAIL/gm) || []).length;
        if (fails) logError("self-test", fails + " failed");
        return text;
      });
    },
    hostVersion: function () { return hostVersion; }
  };

  /* ------------------------------------------------------------- boot */

  function boot() {
    loadHost();
    initTabs();
    initTooltips();
    initRangeFill();
    initEasing();
    initColors();
    initMagicReveal();
    setTCMode("counter");
    showVersion();
    setTimeout(greet, 1200);
    setTimeout(function () { checkForUpdate(false, "auto"); }, 5000);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
