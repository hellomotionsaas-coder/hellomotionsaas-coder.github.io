/*
 * MotionSaaS — Carousel panel: arrange the selected layers (pictures) on a sphere, a ring / arc, a grid, a
 * curved line or any mask / shape path, and set them moving (spin, step, swing) with an optional reveal.
 * Opens from the Studio's Carousel rail button (a built-in tool panel, js/ms-studio.js).
 * - The live preview runs the same layout maths as After Effects (js/ms-carousel-core.js); for Curved line its
 *   three points are dragged right in the preview.
 * - Apply builds a rig in After Effects (MS.carouselBuild, jsx/host.jsx): a null with one effect per setting and
 *   pictures driven by expressions. With a carousel selected, every change here is set live on it
 *   (MS.carouselSet); Rebuild adds newly selected layers or path; Release bakes it and removes the rig.
 * - Built-in presets and the user's own (stored locally, ms_carousel).
 */
(function () {
  "use strict";

  var MSUI = window.MSUI, K = MSUI.carouselCore;
  if (!K) { return; }
  var $ = function (id) { return document.getElementById(id); };
  var KEY = "ms_carousel", inCEP = !!(window.__adobe_cep__ && window.__adobe_cep__.evalScript);
  var stored = MSUI.store.get(KEY, null) || {};
  var P = merge(K.defaults(), stored.P), mine = stored.mine instanceof Array ? stored.mine : [];
  var probe = { comp: !inCEP, w: 1920, h: 1080, pics: 0, path: null, rig: null, ownExpr: false };
  var editing = null;   // the rig being edited (its name), when one is selected in After Effects
  var NAME = {}, KEYOF = {};
  K.FIELDS.forEach(function (f) { NAME[f[0]] = f[1]; KEYOF[f[1]] = f[0]; });

  function merge(base, over) {
    var k;
    if (over && typeof over === "object") { for (k in over) { if (over.hasOwnProperty(k) && base.hasOwnProperty(k)) { base[k] = over[k] instanceof Array ? over[k].slice() : over[k]; } } }
    return base;
  }
  function save() { MSUI.store.set(KEY, { P: P, mine: mine }); }
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; }
  function shown() { var t = $("carousel-tab"); return !!t && t.classList.contains("active"); }

  /* -------------------------------------------------------------- controls */

  var CTRL = {
    size: { label: "Size", min: 80, max: 900, step: 1, unit: " px" },
    spread: { label: "Spread", min: 30, max: 360, step: 1, unit: "°" },
    tilt: { label: "Tilt", min: 0, max: 90, step: 1, unit: "°" },
    cols: { label: "Columns", min: 1, max: 10, step: 1, unit: "" },
    gap: { label: "Gap", min: 0, max: 300, step: 1, unit: " px" },
    bend: { label: "Bend", min: 0, max: 100, step: 1, unit: "%" },
    mid: { label: "Middle size", min: 50, max: 250, step: 1, unit: "%" },
    pic: { label: "Picture size", min: 40, max: 800, step: 1, unit: " px" },
    fade: { label: "Depth fade", min: 0, max: 100, step: 1, unit: "%" },
    speed: { label: "Speed", min: -100, max: 100, step: 1, unit: "" },
    step: { label: "Step every", min: 0.4, max: 6, step: 0.1, unit: " s" },
    offset: { label: "Offset", min: 0, max: 100, step: 1, unit: "%" },
    stagger: { label: "Stagger", min: 0, max: 90, step: 1, unit: "%" },
    revealDur: { label: "Reveal length", min: 0.3, max: 4, step: 0.1, unit: " s" },
    morph: { label: "Morph", min: 0, max: 100, step: 1, unit: "%" },
    shuffle: { label: "Shuffle", min: 0, max: 99, step: 1, unit: "" },
    cascade: { label: "Cascade", min: 0, max: 600, step: 10, unit: " ms" },
    wave: { label: "Wave", min: 0, max: 160, step: 1, unit: " px" },
    effR: { label: "Size", min: 60, max: 1200, step: 1, unit: " px" },
    effScale: { label: "Grow", min: -60, max: 150, step: 1, unit: "%" },
    effPush: { label: "Push away", min: -200, max: 300, step: 1, unit: " px" },
    effLift: { label: "Lift", min: -300, max: 600, step: 1, unit: " px" }
  };
  var SHORT_STYLES = ["Sphere", "Ring", "Grid", "Line", "Path"];
  var STYLE_CTRLS = { 0: ["size", "tilt", "pic", "fade"], 1: ["size", "spread", "tilt", "pic", "fade"], 2: ["cols", "gap", "bend", "tilt", "pic", "fade"], 3: ["gap", "mid", "pic"], 4: ["gap", "mid", "pic"] };
  var FACES = { 0: ["Screen", "Outward", "Inward"], 1: ["Screen", "Centre", "Outward"] };
  var STYLE_ICONS = [
    '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><ellipse cx="12" cy="12" rx="3.6" ry="8.5"/><path d="M3.5 12h17"/></svg>',
    '<svg viewBox="0 0 24 24"><circle cx="12" cy="4.8" r="1.6"/><circle cx="17.1" cy="6.9" r="1.6"/><circle cx="19.2" cy="12" r="1.6"/><circle cx="17.1" cy="17.1" r="1.6"/><circle cx="12" cy="19.2" r="1.6"/><circle cx="6.9" cy="17.1" r="1.6"/><circle cx="4.8" cy="12" r="1.6"/><circle cx="6.9" cy="6.9" r="1.6"/></svg>',
    '<svg viewBox="0 0 24 24"><rect x="4" y="4" width="4.5" height="4.5" rx="1.2"/><rect x="9.75" y="4" width="4.5" height="4.5" rx="1.2"/><rect x="15.5" y="4" width="4.5" height="4.5" rx="1.2"/><rect x="4" y="9.75" width="4.5" height="4.5" rx="1.2"/><rect x="9.75" y="9.75" width="4.5" height="4.5" rx="1.2"/><rect x="15.5" y="9.75" width="4.5" height="4.5" rx="1.2"/><rect x="4" y="15.5" width="4.5" height="4.5" rx="1.2"/><rect x="9.75" y="15.5" width="4.5" height="4.5" rx="1.2"/><rect x="15.5" y="15.5" width="4.5" height="4.5" rx="1.2"/></svg>',
    '<svg viewBox="0 0 24 24"><path d="M4 16.5C7.5 6 16.5 6 20 16.5"/><circle cx="4" cy="16.5" r="1.8"/><circle cx="12" cy="8.6" r="1.8"/><circle cx="20" cy="16.5" r="1.8"/></svg>',
    '<svg viewBox="0 0 24 24"><path d="M4 18c2.5-9 6-11 8-7s5 2 8-6"/><path d="M4 18h.01M20 5h.01"/><path d="M15.5 18.5l2.5-2.5 2.5 2.5" /></svg>'
  ];

  function fmt(key, v) {
    var c = CTRL[key];
    if (key === "gap" && P.style >= 3 && !(v > 0)) { return "Auto"; }
    if (key === "speed") { return v === 0 ? "0" : (v > 0 ? "" : "−") + Math.abs(Math.round(v)); }
    if ((key === "shuffle" || key === "cascade" || key === "wave") && !(v > 0)) { return "Off"; }
    if (key === "shuffle") { return "#" + Math.round(v); }
    if (v < 0) { return "−" + Math.abs(Math.round(v)) + c.unit; }
    return (c.step < 1 ? Number(v).toFixed(1) : Math.round(v)) + c.unit;
  }

  function sliderRow(key) {
    var c = CTRL[key], row = el("label", "cr-row"), head = el("span", "cr-row-head"), val = el("b", "cr-val", fmt(key, P[key])), input = el("input");
    head.appendChild(el("span", "", c.label));
    head.appendChild(val);
    input.type = "range"; input.min = c.min; input.max = c.max; input.step = c.step; input.value = P[key];
    input.setAttribute("data-key", key);
    input.addEventListener("input", function () {
      P[key] = Number(input.value);
      val.textContent = fmt(key, P[key]);
      changed(key);
    });
    row.appendChild(head);
    row.appendChild(input);
    return row;
  }
  function segRow(label, items, value, onPick) {
    var row = el("div", "cr-row cr-seg-row"), seg = el("div", "cr-seg");
    row.appendChild(el("span", "cr-row-label", label));
    items.forEach(function (name, i) {
      var b = el("button", i === value ? "active" : "", name);
      b.type = "button";
      b.addEventListener("click", function () {
        [].forEach.call(seg.children, function (x) { x.classList.remove("active"); });
        b.classList.add("active");
        onPick(i);
      });
      seg.appendChild(b);
    });
    row.appendChild(seg);
    return row;
  }

  function renderStyles() {
    var box = $("crStyles");
    while (box.firstChild) box.removeChild(box.firstChild);
    K.STYLES.forEach(function (name, i) {
      var b = el("button", "cr-style" + (Math.round(P.style) === i ? " active" : ""));
      b.type = "button";
      b.innerHTML = '<span class="cr-style-ico">' + STYLE_ICONS[i] + "</span>";
      b.appendChild(el("span", "cr-style-name", name));
      b.addEventListener("click", function () {
        if (Math.round(P.style) === i) return;
        P.style = i;
        replay();
        renderStyles();
        renderControls();
        renderPowers();
        changed("style");
      });
      box.appendChild(b);
    });
  }

  function renderControls() {
    var box = $("crControls"), st = Math.round(P.style);
    while (box.firstChild) box.removeChild(box.firstChild);
    if (st === 4) {
      var src = probe.path ? probe.path.label : (probe.rig && probe.rig.path ? probe.rig.path : "");
      var note = el("div", "cr-note" + (src ? " ok" : ""), src ? "Path: " + src : "Draw a mask or a shape path in After Effects, then select its layer together with your pictures.");
      box.appendChild(note);
    }
    if (st === 3) { box.appendChild(el("div", "cr-note", "Drag the three points in the preview to bend the line. The middle point makes pictures bigger.")); }
    if (FACES[st]) { box.appendChild(segRow("Pictures face", FACES[st], Math.round(P.face), function (i) { P.face = i; changed("face"); })); }
    STYLE_CTRLS[st].forEach(function (k) { box.appendChild(sliderRow(k)); });
    if (MSUI.panelRangeFill) MSUI.panelRangeFill(box);
  }

  function renderMotion() {
    var box = $("crMotion"), mo = Math.round(P.motion);
    while (box.firstChild) box.removeChild(box.firstChild);
    box.appendChild(segRow("Movement", ["Still", "Spin", "Step", "Swing"], mo, function (i) { P.motion = i; renderMotion(); renderPowers(); changed("motion"); }));
    if (mo !== 0) { box.appendChild(sliderRow("speed")); }
    if (mo === 2) { box.appendChild(sliderRow("step")); }
    box.appendChild(sliderRow("offset"));
    var rv = el("div", "cr-row cr-switch-row"), sw = el("label", "ms-switch"), input = el("input");
    rv.appendChild(el("span", "cr-row-label", "Reveal one by one"));
    input.type = "checkbox"; input.checked = !!P.revealOn;
    input.addEventListener("change", function () { P.revealOn = input.checked; save(); renderMotion(); replay(); if (editing) hint("Press Rebuild to replay the reveal on this carousel"); });
    sw.appendChild(input); sw.appendChild(el("span", "ms-slider"));
    rv.appendChild(sw);
    box.appendChild(rv);
    if (P.revealOn) { box.appendChild(sliderRow("revealDur")); box.appendChild(sliderRow("stagger")); }
    if (MSUI.panelRangeFill) MSUI.panelRangeFill(box);
  }

  function switchRow(label, on, onChange) {
    var row = el("div", "cr-row cr-switch-row"), sw = el("label", "ms-switch"), input = el("input");
    row.appendChild(el("span", "cr-row-label", label));
    input.type = "checkbox"; input.checked = !!on;
    input.addEventListener("change", function () { onChange(input.checked); });
    sw.appendChild(input); sw.appendChild(el("span", "ms-slider"));
    row.appendChild(sw);
    return row;
  }
  // Morph into a second layout, deal the pictures in a new order, ripple and float them, and the effector: a
  // point that grows / pushes / lifts the pictures near it (ideas from the MotionSaaS Grid Builder).
  function renderPowers() {
    var box = $("crPowers"), st = Math.round(P.style), to = Math.round(P.style2), head, dice;
    if (!box) return;
    while (box.firstChild) box.removeChild(box.firstChild);
    box.appendChild(el("div", "cr-sub", "Morph"));
    box.appendChild(segRow("Into", SHORT_STYLES, to, function (i) { P.style2 = i; if (P.morph === 0) { P.morph = 50; renderPowers(); } changed("style2"); changed("morph"); }));
    box.appendChild(sliderRow("morph"));
    if (to === st) { box.appendChild(el("div", "cr-note", "Pick a different layout to morph into. Keyframe Morph on the rig to animate between them.")); }
    else if (to === 4 || st === 4) { box.appendChild(el("div", "cr-note", "Custom path needs its path layer selected when you press Apply.")); }

    head = el("div", "cr-sub cr-sub-row", "Order & flow");
    dice = el("button", "cr-mini", "🎲 Deal again");
    dice.type = "button";
    dice.title = "Shuffle the pictures into a new random order";
    dice.addEventListener("click", function () {
      var v = P.shuffle;
      while (v === P.shuffle) { v = 1 + Math.floor(Math.random() * 99); }
      P.shuffle = v;
      replay();
      renderPowers();
      changed("shuffle");
    });
    head.appendChild(dice);
    box.appendChild(head);
    box.appendChild(sliderRow("shuffle"));
    box.appendChild(sliderRow("cascade"));
    box.appendChild(sliderRow("wave"));
    if (P.cascade > 0 && Math.round(P.motion) === 0) { box.appendChild(el("div", "cr-note", "Cascade delays each picture's movement: pick Step or Swing in Motion to see the ripple.")); }

    box.appendChild(el("div", "cr-sub", "Effector"));
    box.appendChild(switchRow("Effector", Math.round(P.eff) === 1, function (on) { P.eff = on ? 1 : 0; renderPowers(); changed("eff"); }));
    if (Math.round(P.eff) === 1) {
      box.appendChild(el("div", "cr-note", "Drag the ring in the preview, or animate Effector point on the rig, to sweep it across the pictures."));
      ["effR", "effScale", "effPush", "effLift"].forEach(function (k) { box.appendChild(sliderRow(k)); });
    }
    if (MSUI.panelRangeFill) MSUI.panelRangeFill(box);
  }

  function renderPresets() {
    var box = $("crPresets");
    while (box.firstChild) box.removeChild(box.firstChild);
    K.PRESETS.forEach(function (p) { box.appendChild(presetCard(p.name, p.note, K.preset(p.id), null)); });
    var mbox = $("crMine");
    while (mbox.firstChild) mbox.removeChild(mbox.firstChild);
    mine.forEach(function (m, i) {
      mbox.appendChild(presetCard(m.name, "Your preset", merge(K.defaults(), m.P), function () {
        MSUI.confirm("Delete “" + m.name + "”?", "Your saved carousel preset is removed.", "Delete").then(function (ok) {
          if (!ok) return;
          mine.splice(i, 1);
          save();
          renderPresets();
        });
      }));
    });
    $("crMineHead").style.display = mine.length ? "" : "none";
  }
  function presetCard(name, note, values, onDelete) {
    var b = el("button", "cr-preset"), cv = el("canvas", "cr-thumb");
    b.type = "button";
    b.title = note;
    b.appendChild(cv);
    b.appendChild(el("span", "cr-preset-name", name));
    if (onDelete) {
      var x = el("span", "cr-preset-x");
      x.setAttribute("role", "button");
      x.title = "Delete this preset";
      x.innerHTML = '<svg viewBox="0 0 24 24"><path d="M7 7l10 10M17 7 7 17"/></svg>';
      x.addEventListener("click", function (e) { e.stopPropagation(); onDelete(); });
      b.appendChild(x);
    }
    b.addEventListener("click", function () {
      var keepPoints = { p1: P.p1, p2: P.p2, p3: P.p3 };
      P = merge(K.defaults(), values);
      if (Math.round(P.style) !== 3 && Math.round(P.style) !== 4) { P.p1 = keepPoints.p1; P.p2 = keepPoints.p2; P.p3 = keepPoints.p3; }
      replay();
      renderAll();
      changed("*");
      MSUI.toast(name);
    });
    requestAnimationFrame(function () { drawThumb(cv, values); });
    return b;
  }
  function savePreset() {
    var input = $("crPresetName"), name = String(input.value || "").trim();
    if (!name) { input.focus(); MSUI.toast("Give your preset a name first"); return; }
    mine = mine.filter(function (m) { return m.name.toLowerCase() !== name.toLowerCase(); });
    mine.unshift({ name: name.slice(0, 40), P: JSON.parse(JSON.stringify(P)) });
    mine = mine.slice(0, 24);
    input.value = "";
    save();
    renderPresets();
    MSUI.toast("Saved “" + name + "”");
  }

  function renderAll() { renderStyles(); renderControls(); renderMotion(); renderPowers(); renderPresets(); renderBar(); }

  /* ------------------------------------------------------- live editing */

  var pending = {}, sendT = 0;
  function changed(key) {
    save();
    if (!editing) return;
    if (key === "*") { K.FIELDS.forEach(function (f) { if (f[0] !== "reveal") pending[f[1]] = P[f[0]]; }); }
    else if (NAME[key] && key !== "reveal") {
      // Built before this setting existed: it only takes effect after a Rebuild adds it to the rig.
      if (probe.rig && probe.rig.values && !probe.rig.values.hasOwnProperty(NAME[key])) { hint("Press Rebuild to add " + NAME[key] + " to " + editing); return; }
      pending[NAME[key]] = P[key];
    }
    else return;
    clearTimeout(sendT);
    sendT = setTimeout(flush, 140);
  }
  function flush() {
    var body = pending, name = editing;
    pending = {};
    if (!name || !Object.keys(body).length) return;
    MSUI.host("MS.carouselSet", [name, JSON.stringify(body)]).then(function (r) {
      if (String(r).indexOf("ERR|") === 0) { MSUI.toast(String(r).slice(4), true); }
    });
  }
  var hintT = 0;
  function hint(text) { var s = $("crStatus"); s.textContent = text; clearTimeout(hintT); hintT = setTimeout(renderBar, 3500); }

  function renderBar() {
    var s = $("crStatus"), a = $("crApply"), rel = $("crRelease"), n;
    if (!s) return;
    rel.hidden = !editing;
    if (!inCEP) { s.textContent = "Open MotionSaaS in After Effects to build carousels"; a.textContent = "Apply"; return; }
    if (!probe.comp) { s.textContent = "Open a composition first"; a.textContent = "Apply"; a.disabled = true; return; }
    a.disabled = false;
    if (editing) {
      n = probe.rig.items + probe.pics;
      s.textContent = editing + " · " + probe.rig.items + " pictures · changes apply live";
      a.textContent = probe.pics || (probe.path && Math.round(P.style) === 4) ? "Rebuild (+" + (probe.pics ? probe.pics + " layers" : "path") + ")" : "Rebuild";
      return;
    }
    a.textContent = "Apply";
    s.textContent = probe.pics >= 2 ? probe.pics + " layers selected" : probe.pics === 1 ? "1 layer selected · select at least two" : "Select two or more layers (your pictures)";
  }

  /* --------------------------------------------------------- After Effects */

  var probing = false;
  function poll() {
    if (!inCEP || probing || !shown()) return;
    probing = true;
    MSUI.host("MS.carouselProbe").then(function (r) {
      probing = false;
      r = String(r || "");
      if (r.indexOf("OK|") !== 0) return;
      var o;
      try { o = JSON.parse(r.slice(3)); } catch (e) { return; }
      var was = editing, prevPath = probe.path && probe.path.label;
      probe = { comp: !!o.comp, w: o.w || 1920, h: o.h || 1080, pics: o.pics || 0, path: o.path || null, rig: o.rig || null, ownExpr: !!o.ownExpr };
      editing = probe.rig ? probe.rig.name : null;
      // The user renamed the carousel's controller: reconnect its pictures to the new name right away.
      if (probe.rig && probe.rig.renamed) {
        MSUI.host("MS.carouselRelink", [probe.rig.name]).then(function (rr) {
          if (String(rr).indexOf("OK|") === 0 && +String(rr).slice(3) > 0) MSUI.toast("Reconnected " + probe.rig.name + " after its rename");
        });
        probe.rig.renamed = false;
      }
      if (editing && editing !== was) {   // a carousel was selected: show its settings
        var v = probe.rig.values, k;
        for (k in v) { if (v.hasOwnProperty(k) && KEYOF[k] && KEYOF[k] !== "reveal") { P[KEYOF[k]] = v[k] instanceof Array ? v[k].slice(0, 2) : v[k]; } }
        renderStyles(); renderControls(); renderMotion(); renderPowers();
      } else if ((probe.path && probe.path.label) !== prevPath && Math.round(P.style) === 4) {
        renderControls();
      }
      renderBar();
    }, function () { probing = false; });
  }

  function apply() {
    if (!inCEP) { MSUI.toast("Open MotionSaaS in After Effects to build carousels", true); return; }
    if (!probe.comp) { MSUI.toast("Open a composition first", true); return; }
    if (!editing && probe.pics < 2) { MSUI.toast("Select two or more layers (your pictures) first", true); return; }
    var go = function () {
      var o = { fields: K.FIELDS.map(function (f) { return [f[0], f[1], f[2], f[0] === "reveal" ? 100 : P[f[0]]]; }), expr: K.EXPR,
        usePath: Math.round(P.style) === 4, revealOn: !!P.revealOn, revealDur: P.revealDur };
      $("crApply").disabled = true;
      MSUI.host("MS.carouselBuild", [JSON.stringify(o)]).then(function (r) {
        $("crApply").disabled = false;
        r = String(r || "");
        if (r.indexOf("OK|") !== 0) { MSUI.toast(r.replace(/^ERR\|/, ""), true); return; }
        var res = {};
        try { res = JSON.parse(r.slice(3)); } catch (e) {}
        MSUI.toast((editing ? "Rebuilt " : "Built ") + (res.name || "the carousel") + " · " + (res.items || "") + " pictures");
        editing = null;
        setTimeout(poll, 150);
      });
    };
    if (probe.ownExpr) {
      MSUI.confirm("Replace expressions?", "Some selected layers have expressions on position, scale, opacity or rotation. The carousel replaces them.", "Replace").then(function (ok) { if (ok) go(); });
    } else { go(); }
  }
  function release() {
    if (!editing) return;
    var name = editing;
    MSUI.confirm("Release " + name + "?", "The pictures keep how they look right now; the carousel's motion and its controller layer are removed.", "Release").then(function (ok) {
      if (!ok) return;
      MSUI.host("MS.carouselRelease", [name]).then(function (r) {
        r = String(r || "");
        if (r.indexOf("OK|") !== 0) { MSUI.toast(r.replace(/^ERR\|/, ""), true); return; }
        MSUI.toast("Released " + r.slice(3) + " pictures");
        editing = null;
        setTimeout(poll, 150);
      });
    });
  }

  /* --------------------------------------------------------------- preview */

  var cv = null, ctx = null, t0 = Date.now(), revealAt = -1, drag = null, view = { s: 1, cx: 0, cy: 0 };
  function replay() { revealAt = Date.now(); }
  function accent() {
    var cs = getComputedStyle(document.documentElement);
    return { a: (cs.getPropertyValue("--accent-blue") || "#1f6bff").trim(), rgb: (cs.getPropertyValue("--accent-rgb") || "31, 107, 255").trim() };
  }
  function count() { return Math.max(2, Math.min(40, editing ? probe.rig.items + probe.pics : probe.pics >= 2 ? probe.pics : 8)); }
  // A picture in the preview: the layout's point, seen through After Effects' default 50 mm comp camera.
  function project(r, compW, s) {
    var zoom = compW * 50 / 36, f = zoom / Math.max(1, zoom + r[2]);
    return { x: r[0] * f * s, y: r[1] * f * s, f: f };
  }
  function drawScene(c2, W, H, values, t, n, compW, compH, opts) {
    var s = Math.min(W / compW, H / compH) * (opts && opts.zoom || 1), cx = W / 2, cy = H / 2, items = [], i, r, q, col = accent();
    var pathPts = null;
    if (Math.round(values.style) === 4) {   // a stand-in path in the preview: a soft S curve
      pathPts = function (u) { return [(u - 0.5) * compW * 0.7, Math.sin(u * Math.PI * 2) * compH * 0.18, 0]; };
    }
    for (i = 0; i < n; i++) {
      r = K.layout(values, i, n, t, pathPts);
      q = project(r, compW, s);
      items.push({ r: r, q: q, i: i });
    }
    items.sort(function (a, b) { return b.r[2] - a.r[2]; });
    if (opts && opts.guides) {   // the comp's frame
      c2.save();
      c2.strokeStyle = "rgba(" + col.rgb + ", 0.22)";
      c2.lineWidth = 1;
      c2.strokeRect(Math.round(cx - compW * s / 2) + 0.5, Math.round(cy - compH * s / 2) + 0.5, Math.round(compW * s) - 1, Math.round(compH * s) - 1);
      c2.restore();
    }
    if (Math.round(values.style) >= 3 && opts && opts.guides) {
      c2.save();
      c2.strokeStyle = "rgba(" + col.rgb + ", 0.45)";
      c2.setLineDash([4, 5]);
      c2.lineWidth = 1.2;
      c2.beginPath();
      for (i = 0; i <= 40; i++) {
        var u = i / 40, p;
        if (pathPts) { p = pathPts(u); }
        else {
          var w = 1 - u, a = values.p1, m = values.p2, b = values.p3, q0 = 2 * m[0] - (a[0] + b[0]) / 2, q1 = 2 * m[1] - (a[1] + b[1]) / 2;
          p = [w * w * a[0] + 2 * u * w * q0 + u * u * b[0], w * w * a[1] + 2 * u * w * q1 + u * u * b[1]];
        }
        if (i) c2.lineTo(cx + p[0] * s, cy + p[1] * s); else c2.moveTo(cx + p[0] * s, cy + p[1] * s);
      }
      c2.stroke();
      c2.restore();
    }
    items.forEach(function (it) {
      var r2 = it.r, w = values.pic * s * it.q.f * r2[3], h = w * 0.72, D = Math.PI / 180;
      if (!(w > 0.5) || !(r2[4] > 0.01)) return;
      c2.save();
      c2.globalAlpha = Math.max(0, Math.min(1, r2[4]));
      c2.translate(cx + it.q.x, cy + it.q.y);
      c2.rotate(r2[7] * D);
      c2.scale(Math.max(0.08, Math.abs(Math.cos(r2[6] * D))), Math.max(0.08, Math.abs(Math.cos(r2[5] * D))));
      var g = c2.createLinearGradient(-w / 2, -h / 2, w / 2, h / 2);
      g.addColorStop(0, "rgba(" + col.rgb + ", 0.75)");
      g.addColorStop(1, col.a);
      c2.fillStyle = g;
      var rad = Math.min(w, h) * 0.16;
      c2.beginPath();
      c2.moveTo(-w / 2 + rad, -h / 2);
      c2.arcTo(w / 2, -h / 2, w / 2, h / 2, rad); c2.arcTo(w / 2, h / 2, -w / 2, h / 2, rad);
      c2.arcTo(-w / 2, h / 2, -w / 2, -h / 2, rad); c2.arcTo(-w / 2, -h / 2, w / 2, -h / 2, rad);
      c2.closePath();
      c2.fill();
      c2.fillStyle = "rgba(255, 255, 255, 0.22)";
      c2.fillRect(-w / 2 + rad, -h / 2 + h * 0.12, w * 0.35, Math.max(1, h * 0.07));
      c2.restore();
    });
    return { s: s, cx: cx, cy: cy };
  }
  function drawThumb(c2el, values) {
    var dpr = window.devicePixelRatio || 1, W = c2el.clientWidth || 96, H = c2el.clientHeight || 56;
    c2el.width = Math.round(W * dpr); c2el.height = Math.round(H * dpr);
    var c2 = c2el.getContext("2d");
    c2.scale(dpr, dpr);
    var v = merge(K.defaults(), values);
    v.reveal = 100;
    drawScene(c2, W, H, v, 1.2, 8, 1920, 1080, { zoom: 1.1 });
  }
  // The preview animates only while the Carousel panel is on screen (no idle 60 fps loop when it's closed);
  // wake() restarts it when the panel opens.
  var running = false;
  function wake() { if (!running && cv) { running = true; requestAnimationFrame(frame); } }
  function frame() {
    if (!shown() || !cv || document.body.classList.contains("ms-tool-covered")) { running = false; return; }
    requestAnimationFrame(frame);
    var dpr = window.devicePixelRatio || 1, W = cv.clientWidth, H = cv.clientHeight;
    if (!W || !H) return;
    if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    var t = (Date.now() - t0) / 1000, v = {}, k;
    for (k in P) { if (P.hasOwnProperty(k)) v[k] = P[k]; }
    v.reveal = 100;
    if (P.revealOn && revealAt > 0) {
      var e = Math.min(1, (Date.now() - revealAt) / 1000 / Math.max(0.2, P.revealDur));
      v.reveal = 100 * (1 - Math.pow(1 - e, 3));
    }
    view = drawScene(ctx, W, H, v, t, count(), probe.w, probe.h, { guides: true, zoom: 1 });
    var col = accent();
    if (Math.round(P.eff) === 1 && P.effPt) {   // the effector: its reach, and a handle to drag
      var ex = view.cx + P.effPt[0] * view.s, ey = view.cy + P.effPt[1] * view.s;
      var rg = ctx.createRadialGradient(ex, ey, 0, ex, ey, Math.max(1, P.effR * view.s));
      rg.addColorStop(0, "rgba(" + col.rgb + ", 0.16)");
      rg.addColorStop(1, "rgba(" + col.rgb + ", 0)");
      ctx.fillStyle = rg;
      ctx.beginPath(); ctx.arc(ex, ey, Math.max(1, P.effR * view.s), 0, Math.PI * 2); ctx.fill();
      ctx.save();
      ctx.setLineDash([3, 4]); ctx.lineWidth = 1; ctx.strokeStyle = "rgba(" + col.rgb + ", 0.55)"; ctx.stroke();
      ctx.restore();
      ctx.beginPath(); ctx.arc(ex, ey, drag === "effPt" ? 9 : 7.5, 0, Math.PI * 2);
      ctx.lineWidth = 2.5; ctx.strokeStyle = "#fff"; ctx.stroke();
      ctx.beginPath(); ctx.arc(ex, ey, 2.5, 0, Math.PI * 2); ctx.fillStyle = col.a; ctx.fill();
    }
    if (Math.round(P.style) === 3) {   // the three draggable points
      [P.p1, P.p2, P.p3].forEach(function (p, i) {
        var x = view.cx + p[0] * view.s, y = view.cy + p[1] * view.s;
        ctx.beginPath(); ctx.arc(x, y, drag === "p" + (i + 1) ? 8 : 6.5, 0, Math.PI * 2);
        ctx.fillStyle = "#fff"; ctx.fill();
        ctx.lineWidth = 2.5; ctx.strokeStyle = col.a; ctx.stroke();
      });
    }
  }
  // The handles the preview offers right now: the curve's three points and / or the effector.
  function handles() {
    var out = [];
    if (Math.round(P.eff) === 1) out.push("effPt");
    if (Math.round(P.style) === 3) out.push("p1", "p2", "p3");
    return out;
  }
  function pointAt(e) {
    var r = cv.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top, best = null, bd = 14;
    handles().forEach(function (key) {
      var p = P[key], d = Math.sqrt(Math.pow(view.cx + p[0] * view.s - x, 2) + Math.pow(view.cy + p[1] * view.s - y, 2));
      if (d < bd) { bd = d; best = key; }
    });
    return { key: best, x: (x - view.cx) / view.s, y: (y - view.cy) / view.s };
  }
  function initCanvas() {
    cv = $("crCanvas");
    if (!cv) return;
    ctx = cv.getContext("2d");
    cv.addEventListener("mousedown", function (e) {
      var h = pointAt(e);
      if (!h.key) return;
      drag = h.key;
      e.preventDefault();
    });
    window.addEventListener("mousemove", function (e) {
      if (!cv || !shown()) return;
      if (handles().length) { cv.style.cursor = drag !== null ? "grabbing" : pointAt(e).key ? "grab" : ""; }
      if (drag === null) return;
      var h = pointAt(e);
      P[drag] = [Math.round(h.x), Math.round(h.y)];
      changed(drag);
    });
    window.addEventListener("mouseup", function () { drag = null; });
    wake();
  }

  MSUI.action("crApply", apply);
  MSUI.action("crRelease", release);
  MSUI.action("crSavePreset", savePreset);

  function boot() {
    if (!$("carousel-tab")) return;
    renderAll();
    initCanvas();
    replay();
    document.addEventListener("ms-tab", function (e) { if (e.detail === "carousel") { replay(); poll(); renderPresets(); wake(); } });
    // Covered by a Studio dialog and back again: the loop stopped, start it.
    if (window.MutationObserver) {
      new MutationObserver(function () { if (!document.body.classList.contains("ms-tool-covered")) wake(); })
        .observe(document.body, { attributes: true, attributeFilter: ["class"] });
    }
    setInterval(poll, 1200);
    poll();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
