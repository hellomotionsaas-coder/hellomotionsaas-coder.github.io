/*
 * MotionSaaS — SaaS Kit tab: the original MotionSaaS tools in the new panel style.
 * Gradient / mesh / glass backgrounds, SaaS palettes, launch-video templates, quick text
 * animations, layer picker + toggles, tutorials and notes.
 */
(function () {
  "use strict";

  var $ = function (id) { return document.getElementById(id); };
  var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };
  var MSUI = window.MSUI, store = MSUI.store;
  function run(fn) {
    var args = Array.prototype.slice.call(arguments, 1);
    return MSUI.host(fn, args).then(function (r) { return MSUI.report(r); });
  }

  /* --------------------------------------------------------- sub-tabs */

  function showSub(id) {
    $$(".saas-sub-content").forEach(function (c) { c.style.display = c.id === id ? "block" : "none"; });
    $$(".saas-sub-btn").forEach(function (b) { b.classList.toggle("active", b.getAttribute("data-saas") === id); });
    store.set("ms_saas_sub", id);
  }

  /* --------------------------------------------------------- palettes */

  // The shared palette library (js/ms-palettes.js); its active palette colours Mesh backgrounds and templates.
  var FALLBACK = { name: "Apple", colors: ["#0A84FF", "#30D158", "#FF9F0A", "#FF375F", "#BF5AF2"] };
  function activePalette() {
    var p = MSUI.palettes && MSUI.palettes.active();
    if (!p || p.colors.length < 4) return FALLBACK;
    return p;
  }
  function renderPalettes() {
    if (MSUI.palettes) MSUI.palettes.mount($("saasPalettes"), { compact: false });
  }

  /* ------------------------------------------------------------ learn */

  var DEFAULT_LINKS = [
    { t: "SaaS animation tutorial #1", u: "https://www.youtube.com/watch?v=3RneAubq8UY" },
    { t: "SaaS animation tutorial #2", u: "https://www.youtube.com/watch?v=b931Unk4Kg8" },
    { t: "SaaS animation tutorial #3", u: "https://www.youtube.com/watch?v=ulfRedYpP-w" }
  ];
  function openURL(u) {
    try { MSUI.cs.openURLInDefaultBrowser(u); } catch (e) { window.open(u, "_blank"); }
  }
  function renderLinks() {
    var box = $("saasLinks");
    if (!box) return;
    var links = store.get("ms_links", DEFAULT_LINKS);
    box.innerHTML = "";
    links.forEach(function (l, i) {
      var row = document.createElement("div");
      row.className = "saas-link";
      row.innerHTML = '<span class="saas-yt"></span><span class="saas-lt"></span><button class="saas-lx" title="Remove">✕</button>';
      row.querySelector(".saas-lt").textContent = l.t;
      row.addEventListener("click", function () { openURL(l.u); });
      row.querySelector(".saas-lx").addEventListener("click", function (e) {
        e.stopPropagation(); links.splice(i, 1); store.set("ms_links", links); renderLinks();
      });
      box.appendChild(row);
    });
    if (!links.length) box.innerHTML = '<div class="ms-empty">No links yet — add your favourite tutorials below.</div>';
  }

  /* ------------------------------------------------------------- boot */

  function bindRange(id) {
    var r = $(id), out = $(id + "Val");
    if (!r || !out) return;
    var upd = function () { out.textContent = r.value; };
    r.addEventListener("input", upd); upd();
  }

  function boot() {
    $$(".saas-sub-btn").forEach(function (b) { b.addEventListener("click", function () { showSub(b.getAttribute("data-saas")); }); });
    showSub(store.get("ms_saas_sub", "saas-design"));

    ["saasGlassW", "saasGlassH", "saasGlassR", "saasGlassBlur", "saasGlassTint", "saasAnimDur", "saasAnimStagger"].forEach(function (id) { bindRange(id); });

    if ($("saasGradientBtn")) $("saasGradientBtn").addEventListener("click", function () {
      run("MS.gradient", $("saasGradA").value, $("saasGradB").value, $("saasGradShape").value === "1");
    });
    if ($("saasMeshBtn")) $("saasMeshBtn").addEventListener("click", function () {
      var c = activePalette().colors;
      run("MS.mesh", c[0], c[1], c[2], c[3], $("saasMeshAnim").checked);
    });
    if ($("saasGlassBtn")) $("saasGlassBtn").addEventListener("click", function () {
      run("MS.glass", +$("saasGlassW").value, +$("saasGlassH").value, +$("saasGlassR").value, +$("saasGlassBlur").value, +$("saasGlassTint").value);
    });

    $$("#saas-tab [data-mockup]").forEach(function (b) {
      b.addEventListener("click", function () {
        run("MS.mockup", b.getAttribute("data-mockup"), $("saasMockLight") && $("saasMockLight").checked ? "light" : "dark");
      });
    });
    $$("#saas-tab [data-template]").forEach(function (b) {
      b.addEventListener("click", function () { run("MS.template", b.getAttribute("data-template"), activePalette().colors.join(",")); });
    });
    $$("#saas-tab [data-anim]").forEach(function (b) {
      b.addEventListener("click", function () { run("MS.animate", b.getAttribute("data-anim"), +$("saasAnimDur").value, +$("saasAnimStagger").value); });
    });
    $$("#saas-tab [data-select]").forEach(function (b) {
      b.addEventListener("click", function (e) { run("MS.selectByType", b.getAttribute("data-select"), !!e.shiftKey); });
    });
    $$("#saas-tab [data-toggle]").forEach(function (b) {
      b.addEventListener("click", function () { run("MS.toggle", b.getAttribute("data-toggle")); });
    });

    if ($("saasAddLink")) $("saasAddLink").addEventListener("click", function () {
      var t = $("saasLinkTitle").value.trim(), u = $("saasLinkUrl").value.trim();
      if (!/^https?:\/\//.test(u)) { MSUI.toast("Enter a link starting with https://", true); return; }
      var links = store.get("ms_links", DEFAULT_LINKS);
      links.push({ t: t || u, u: u }); store.set("ms_links", links);
      $("saasLinkTitle").value = ""; $("saasLinkUrl").value = ""; renderLinks();
    });

    var notes = $("saasNotes"), timer = null;
    if (notes) {
      notes.value = store.get("ms_notes", "");
      notes.addEventListener("input", function () {
        clearTimeout(timer);
        timer = setTimeout(function () { store.set("ms_notes", notes.value); }, 300);
      });
    }

    renderPalettes();
    renderLinks();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
