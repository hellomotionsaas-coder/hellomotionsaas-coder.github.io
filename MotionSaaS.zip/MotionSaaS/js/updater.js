// One-click updater.
// Reads the latest GitHub Release, downloads its MotionSaaS.zip, unpacks it and
// copies the new files over this installed extension, then reloads the panel.
// Works on macOS (ditto/unzip) and Windows (PowerShell Expand-Archive). Needs Node in CEP.
(function () {
  var cfg = window.MS_CONFIG;

  function parseVer(v) {
    return String(v || "0").replace(/^v/i, "").split(".").map(function (n) { return parseInt(n, 10) || 0; });
  }
  function isNewer(latest, current) {
    var a = parseVer(latest), b = parseVer(current), i;
    for (i = 0; i < 3; i++) {
      if ((a[i] || 0) > (b[i] || 0)) return true;
      if ((a[i] || 0) < (b[i] || 0)) return false;
    }
    return false;
  }

  // GET with redirect support (GitHub release downloads redirect to a CDN).
  function request(url, opts, hops) {
    var https = CEP.node("https");
    hops = hops || 0;
    return new Promise(function (resolve, reject) {
      var u = require_url(url);
      var req = https.get({
        hostname: u.hostname, path: u.path, protocol: "https:",
        headers: Object.assign({ "User-Agent": "MotionSaaS-Updater" }, (opts && opts.headers) || {})
      }, function (res) {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          res.resume();
          if (hops > 6) return reject(new Error("Too many redirects"));
          resolve(request(res.headers.location, { headers: {} }, hops + 1));
          return;
        }
        if (res.statusCode !== 200) {
          res.resume();
          return reject(new Error(res.statusCode === 404
            ? "No release found (is the releases repo public?)"
            : "Server replied " + res.statusCode));
        }
        resolve(res);
      });
      req.on("error", reject);
      req.setTimeout(30000, function () { req.abort(); reject(new Error("Connection timed out")); });
    });
  }

  function require_url(url) {
    var parsed = CEP.node("url").parse(url);
    return { hostname: parsed.hostname, path: parsed.path };
  }

  function getJSON(url) {
    return request(url, { headers: { "Accept": "application/vnd.github+json" } }).then(function (res) {
      return new Promise(function (resolve, reject) {
        var body = "";
        res.setEncoding("utf8");
        res.on("data", function (c) { body += c; });
        res.on("end", function () { try { resolve(JSON.parse(body)); } catch (e) { reject(e); } });
        res.on("error", reject);
      });
    });
  }

  function download(url, dest, onProgress) {
    var fs = CEP.node("fs");
    return request(url, { headers: { "Accept": "application/octet-stream" } }).then(function (res) {
      return new Promise(function (resolve, reject) {
        var total = parseInt(res.headers["content-length"] || "0", 10), got = 0, failed = false;
        var out = fs.createWriteStream(dest);
        var fail = function (err) { if (failed) return; failed = true; try { out.destroy(); } catch (e) {} reject(err); };
        res.on("data", function (c) { got += c.length; if (total && onProgress) onProgress(got / total); });
        res.pipe(out);
        // Every byte or nothing: a connection that drops mid-way must not install a cut-off zip.
        out.on("finish", function () {
          out.close(function () {
            if (failed) return;
            if (total && got !== total) fail(new Error("Download was cut off (" + Math.round(got / 1024) + " of " + Math.round(total / 1024) + " KB) — try again"));
            else resolve(dest);
          });
        });
        out.on("error", fail);
        res.on("error", fail);
        res.on("aborted", function () { fail(new Error("The connection dropped during the download — try again")); });
        // No data for 60 s: give up instead of waiting forever.
        res.setTimeout && res.setTimeout(60000, function () { fail(new Error("The download stalled — try again")); try { res.destroy(); } catch (e) {} });
      });
    });
  }

  // A temp folder we can actually write to. Some machines have a broken TEMP/TMP (e.g. it points at
  // an old Windows profile), so fall back to a folder in the user's home directory.
  function writableTmp() {
    var os = CEP.node("os"), path = CEP.node("path"), fs = CEP.node("fs");
    var appData = (window.MSUI && window.MSUI.systemDir && window.MSUI.systemDir("userData")) || process.env.APPDATA || "";
    var candidates = [os.tmpdir()], i, probe;
    if (appData) candidates.push(path.join(appData, "MotionSaaS", "tmp"));
    candidates.push(path.join(os.homedir(), ".motionsaas-tmp"));
    for (i = 0; i < candidates.length; i++) {
      try {
        mkdirp(candidates[i]);
        probe = path.join(candidates[i], "ms-probe-" + Date.now());
        fs.writeFileSync(probe, "ok");
        fs.unlinkSync(probe);
        return candidates[i];
      } catch (e) {}
    }
    throw new Error("No writable temp folder (check your TEMP environment variable)");
  }

  function mkdirp(dir) {
    var fs = CEP.node("fs"), path = CEP.node("path");
    if (fs.existsSync(dir)) return;
    mkdirp(path.dirname(dir));
    fs.mkdirSync(dir);
  }

  function rmrf(p) {
    var fs = CEP.node("fs"), path = CEP.node("path");
    if (!fs.existsSync(p)) return;
    if (fs.lstatSync(p).isDirectory()) {
      fs.readdirSync(p).forEach(function (f) { rmrf(path.join(p, f)); });
      fs.rmdirSync(p);
    } else {
      fs.unlinkSync(p);
    }
  }

  function copyDir(src, dst) {
    var fs = CEP.node("fs"), path = CEP.node("path");
    mkdirp(dst);
    fs.readdirSync(src).forEach(function (name) {
      var s = path.join(src, name), d = path.join(dst, name);
      if (fs.lstatSync(s).isDirectory()) copyDir(s, d);
      else fs.writeFileSync(d, fs.readFileSync(s));
    });
  }

  function unzip(zip, dest) {
    var cp = CEP.node("child_process");
    mkdirp(dest);
    return new Promise(function (resolve, reject) {
      var cmd, args;
      if (CEP.isWindows) {
        cmd = "powershell.exe";
        args = ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command",
          "Expand-Archive -LiteralPath '" + zip.replace(/'/g, "''") + "' -DestinationPath '" + dest.replace(/'/g, "''") + "' -Force"];
      } else {
        cmd = "/usr/bin/ditto";
        args = ["-x", "-k", zip, dest];
      }
      cp.execFile(cmd, args, { windowsHide: true }, function (err, so, se) {
        if (err) reject(new Error("Could not unpack update: " + (se || err.message)));
        else resolve(dest);
      });
    });
  }

  // Remove files the new version no longer ships (old scripts, renamed presets). Dot-files such as
  // .debug/.dev are left alone; user data never lives inside the extension folder.
  function prune(src, dst) {
    var fs = CEP.node("fs"), path = CEP.node("path");
    fs.readdirSync(dst).forEach(function (name) {
      if (name.charAt(0) === ".") return;
      var s = path.join(src, name), d = path.join(dst, name);
      if (!fs.existsSync(s)) { rmrf(d); return; }
      if (fs.lstatSync(d).isDirectory() && fs.lstatSync(s).isDirectory()) prune(s, d);
    });
  }

  // Find the folder in the unpacked zip that holds CSXS/manifest.xml.
  function findRoot(dir) {
    var fs = CEP.node("fs"), path = CEP.node("path");
    if (fs.existsSync(path.join(dir, "CSXS", "manifest.xml"))) return dir;
    var kids = fs.readdirSync(dir), i, r;
    for (i = 0; i < kids.length; i++) {
      var k = path.join(dir, kids[i]);
      if (fs.lstatSync(k).isDirectory() && kids[i].charAt(0) !== "_" && kids[i].charAt(0) !== ".") {
        r = findRoot(k);
        if (r) return r;
      }
    }
    return null;
  }

  window.Updater = {
    isNewer: isNewer,
    writableTmp: writableTmp,

    // Latest version seen by the last real check (used while automatic checks are throttled).
    cachedLatest: function () {
      try { return localStorage.getItem("ms_update_latest") || ""; } catch (e) { return ""; }
    },

    // Developers run the panel straight from their git folder; never overwrite that.
    isDevInstall: function () {
      try {
        var fs = CEP.node("fs"), path = CEP.node("path");
        return fs.existsSync(path.join(CEP.extensionPath(), ".dev"));
      } catch (e) { return false; }
    },

    // Automatic checks are throttled (GitHub allows 60 anonymous API calls/hour per IP — a studio
    // full of editors reopening panels could hit that). Manual checks always go through.
    shouldAutoCheck: function () {
      try {
        var last = Number(localStorage.getItem("ms_update_checked") || 0);
        return Date.now() - last > 6 * 3600 * 1000;
      } catch (e) { return true; }
    },

    check: function () {
      var url = "https://api.github.com/repos/" + cfg.updateRepo + "/releases/latest";
      try { localStorage.setItem("ms_update_checked", String(Date.now())); } catch (e) {}
      return getJSON(url).then(function (rel) {
        var asset = (rel.assets || []).filter(function (a) { return a.name === cfg.assetName; })[0];
        try { localStorage.setItem("ms_update_latest", String(rel.tag_name || "").replace(/^v/i, "")); } catch (e) {}
        return {
          latest: String(rel.tag_name || "").replace(/^v/i, ""),
          available: isNewer(rel.tag_name, cfg.version) && !!asset,
          notes: rel.body || "",
          url: asset ? asset.browser_download_url : null
        };
      });
    },

    install: function (info, onProgress) {
      var os = CEP.node("os"), path = CEP.node("path"), fs = CEP.node("fs");
      if (this.isDevInstall()) return Promise.reject(new Error("Developer install — use git pull instead"));
      var work = path.join(writableTmp(), "motionsaas-update-" + Date.now());
      var zip = path.join(work, "update.zip"), out = path.join(work, "x"), backup = path.join(work, "backup");
      var target = CEP.extensionPath();
      mkdirp(work);
      return download(info.url, zip, onProgress)
        .then(function () {
          if (!fs.existsSync(zip) || fs.statSync(zip).size < 1024) throw new Error("Download was empty — try again");
          return unzip(zip, out);
        })
        .then(function () {
          var root = findRoot(out);
          if (!root) throw new Error("Update package is missing CSXS/manifest.xml");
          if (!fs.existsSync(path.join(root, "index.html")) || !fs.existsSync(path.join(root, "jsx", "host.jsx"))) {
            throw new Error("Update package is incomplete — nothing was changed");
          }
          // Back up the working install first, so a failed copy can't leave a half-updated panel.
          copyDir(target, backup);
          try {
            copyDir(root, target);
            prune(root, target);
          } catch (err) {
            try { copyDir(backup, target); } catch (e2) {}
            throw new Error("Couldn't write the update (" + err.message + ") — your current version was restored");
          }
          try { rmrf(work); } catch (e) {}
          return info.latest;
        });
    }
  };
})();
