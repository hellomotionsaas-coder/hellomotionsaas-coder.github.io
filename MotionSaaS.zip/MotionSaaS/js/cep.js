// Tiny replacement for Adobe's CSInterface.js — just what MotionSaaS needs.
(function () {
  var adobe = window.__adobe_cep__;
  var inCEP = !!adobe;

  function isWindows() {
    return navigator.platform.indexOf("Win") === 0;
  }

  window.CEP = {
    inCEP: inCEP,
    isWindows: isWindows(),

    // Run ExtendScript in After Effects. Resolves with the returned string.
    eval: function (script) {
      return new Promise(function (resolve) {
        if (!inCEP) { console.log("[eval]", script); resolve("OK|Preview mode (not inside After Effects)"); return; }
        adobe.evalScript(script, function (res) { resolve(res); });
      });
    },

    // Build a safe call string: CEP.call("MS.gradient", "#fff", "#000", true)
    call: function (fn) {
      var args = Array.prototype.slice.call(arguments, 1).map(function (a) { return JSON.stringify(a); });
      return this.eval(fn + "(" + args.join(",") + ")");
    },

    // CEP system folder ("extension", "userData", …) as a plain path.
    systemPath: function (name) {
      if (!inCEP) return "";
      var p = decodeURI(adobe.getSystemPath(name));
      return isWindows() ? p.replace("file:///", "") : p.replace("file://", "");
    },

    // Folder this extension is installed in.
    extensionPath: function () { return this.systemPath("extension"); },

    // Per-user app data: %APPDATA% on Windows, ~/Library/Application Support on macOS.
    userDataPath: function () { return this.systemPath("userData"); },

    // Native open dialog. Returns an array of paths (empty when cancelled or outside CEP).
    pickFiles: function (opts) {
      var fs = window.cep && window.cep.fs;
      if (!fs) return [];
      var r = fs.showOpenDialog(!!opts.multiple, !!opts.folder, opts.title || "", opts.start || "", opts.types || []);
      return r && r.err === 0 && r.data ? r.data : [];
    },

    hostEnv: function () {
      if (!inCEP) return null;
      try { return JSON.parse(adobe.getHostEnvironment()); } catch (e) { return null; }
    },

    openURL: function (url) {
      if (window.cep && window.cep.util) window.cep.util.openURLInDefaultBrowser(url);
      else window.open(url, "_blank");
    },

    node: function (mod) {
      var req = (window.cep_node && window.cep_node.require) || (typeof require === "function" ? require : null);
      if (!req) throw new Error("Node.js is not available in this panel");
      return req(mod);
    },

    onThemeChange: function (cb) {
      if (!inCEP) return;
      adobe.addEventListener("com.adobe.csxs.events.ThemeColorChanged", cb);
    }
  };
})();
