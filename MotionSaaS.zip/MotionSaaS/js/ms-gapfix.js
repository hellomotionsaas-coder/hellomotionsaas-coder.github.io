/*
 * MotionSaaS — flex/grid "gap" fallback for After Effects 2020–2021 (Chromium 61–ish).
 * Old Chromium ignores `gap` on flexbox (and only knows `grid-gap` for grids), so the panel's
 * spacing collapses there. This reads every gap declaration (stylesheets + inline styles) and
 * re-creates it with margins / grid-gap. It does nothing on browsers that support flex gap.
 */
(function () {
  "use strict";

  function supportsFlexGap() {
    var d = document.createElement("div");
    d.style.cssText = "display:flex;flex-direction:column;row-gap:1px;position:absolute;visibility:hidden";
    d.appendChild(document.createElement("div"));
    d.appendChild(document.createElement("div"));
    document.body.appendChild(d);
    var ok = d.scrollHeight === 1;
    document.body.removeChild(d);
    return ok;
  }
  if (supportsFlexGap()) return;

  var req = window.cep_node && window.cep_node.require || (typeof require === "function" ? require : null);
  var rules = [];   // { sel, row, col }

  function parseDecl(text) {
    var out = null, m, re = /(?:^|[;{\s])(row-gap|column-gap|gap)\s*:\s*([^;!}]+)/g;
    while ((m = re.exec(text))) {
      out = out || {};
      var v = m[2].trim().split(/\s+/);
      if (m[1] === "gap") { out.row = v[0]; out.col = v[1] || v[0]; }
      else if (m[1] === "row-gap") out.row = v[0];
      else out.col = v[0];
    }
    return out;
  }

  function collectCss(text) {
    var re = /([^{}]+)\{([^{}]*)\}/g, m;
    while ((m = re.exec(text))) {
      var d = parseDecl(m[2]);
      if (!d) continue;
      m[1].split(",").forEach(function (s) {
        s = s.trim();
        if (s && s.charAt(0) !== "@" && !/::|:hover|:active|:focus/.test(s)) rules.push({ sel: s, row: d.row, col: d.col });
      });
    }
  }

  Array.prototype.forEach.call(document.querySelectorAll("style"), function (s) { collectCss(s.textContent); });
  if (req) {
    try {
      var fs = req("fs"), path = req("path"), ext = window.MSUI.cs.getSystemPath(SystemPath.EXTENSION);
      Array.prototype.forEach.call(document.querySelectorAll('link[rel="stylesheet"]'), function (l) {
        var href = (l.getAttribute("href") || "").split("?")[0].split("#")[0];   // drop ?v= cache-busting
        if (href && !/^https?:/.test(href)) { try { collectCss(fs.readFileSync(path.join(ext, href), "utf8")); } catch (e) {} }
      });
    } catch (e) {}
  }

  function px(v) { return v && v !== "normal" ? v : null; }

  function applyTo(el, row, col) {
    var cs = getComputedStyle(el);
    if (cs.display === "none") return;
    if (cs.display === "grid" || cs.display === "inline-grid") {
      if (px(row) && el.style.gridRowGap !== row) el.style.gridRowGap = row;
      if (px(col) && el.style.gridColumnGap !== col) el.style.gridColumnGap = col;
      return;
    }
    if (cs.display !== "flex" && cs.display !== "inline-flex") return;
    var dir = cs.flexDirection, wrap = cs.flexWrap !== "nowrap", first = true;
    Array.prototype.forEach.call(el.children, function (c) {
      var ccs = getComputedStyle(c);
      if (ccs.display === "none" || ccs.position === "absolute" || ccs.position === "fixed") return;
      var inline = c.getAttribute("style") || "";
      function set(prop, v) {
        if (!px(v) || new RegExp("(^|;)\\s*" + prop + "\\s*:").test(inline) || /(^|;)\s*margin\s*:/.test(inline)) return;
        c.style.setProperty(prop, v);
      }
      if (wrap) {
        set(dir.indexOf("column") === 0 ? "margin-bottom" : "margin-right", dir.indexOf("column") === 0 ? row : col);
        set(dir.indexOf("column") === 0 ? "margin-right" : "margin-bottom", dir.indexOf("column") === 0 ? col : row);
      } else if (!first) {
        if (dir === "row") set("margin-left", col);
        else if (dir === "row-reverse") set("margin-right", col);
        else if (dir === "column") set("margin-top", row);
        else set("margin-bottom", row);
      }
      first = false;
    });
  }

  function run() {
    rules.forEach(function (r) {
      var els;
      try { els = document.querySelectorAll(r.sel); } catch (e) { return; }
      Array.prototype.forEach.call(els, function (el) { applyTo(el, r.row, r.col); });
    });
    Array.prototype.forEach.call(document.querySelectorAll('[style*="gap"]'), function (el) {
      var d = parseDecl(el.getAttribute("style") || "");
      if (d) applyTo(el, d.row, d.col);
    });
  }

  var timer = null;
  function soon() { clearTimeout(timer); timer = setTimeout(run, 120); }
  // Only structural changes, tab switches and clicks (which reveal hidden panels) — not style
  // attribute changes, so our own margins and the timer's per-second updates don't retrigger it.
  new MutationObserver(soon).observe(document.body, { childList: true, subtree: true });
  document.addEventListener("ms-tab", soon);
  document.addEventListener("click", soon, true);
  window.addEventListener("resize", soon);
  run();
  window.MSUI.gapFix = run;
})();
