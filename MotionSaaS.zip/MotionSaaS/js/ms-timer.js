/*
 * MotionSaaS — Timer & Goal tab: automatic time tracking per After Effects project.
 * - While the panel is open it asks After Effects every few seconds what is being worked on (MS.timerProbe in
 *   jsx/host.jsx: project, comp, and a value that changes with every user action). Activity starts tracking;
 *   no activity for the idle time stops it, crediting time only up to the last activity. Opening another
 *   project files the time under that project. Start / Pause work by hand too.
 * - Today (ring against the daily goal, status, goal streak), This week (bars + goal line, totals, earlier
 *   weeks), Projects (today / week / total per project, CSV timesheet, week summary) and Tracking settings.
 * The numbers come from js/ms-timetrack.js (MSUI.timeTrack, tested in scripts/check.js). Stored locally (ms_timer).
 */
(function () {
  "use strict";

  var MSUI = window.MSUI, T = MSUI.timeTrack;
  var $ = function (id) { return document.getElementById(id); };
  var KEY = "ms_timer", PROBE_MS = 4000, CIRC = 2 * Math.PI * 52;
  var inCEP = !!(window.__adobe_cep__ && window.__adobe_cep__.evalScript);
  var s = T.migrate(MSUI.store.get(KEY, null));
  var weekOffset = 0, showAll = false;
  // What After Effects reported last: the project (id = file path, "unsaved" before the first save), its
  // name, the active comp, the activity signature, and whether AE answered. idleStopped: the last stop was idle.
  var live = { id: "", name: "", comp: "", sig: null, aeOk: null, idleStopped: false };

  function save() { s.beat = Date.now(); MSUI.store.set(KEY, s); }
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; }
  function panelOn() { return !MSUI.panels || MSUI.panels.isOn("timer"); }
  // Activity is watched in After Effects (idle pause on): time is banked only up to the last activity, so
  // idle minutes never reach the history. They count once activity comes back before the idle limit.
  function watching() { return inCEP && s.idleMin > 0; }
  function bankPoint(now) { return watching() && s.run ? Math.min(now, s.run.active + PROBE_MS) : now; }
  // Over the Studio the panel's own toast is hidden: show it in the Studio instead.
  function notify(text) {
    var b = document.body.classList;
    if (b.contains("ms-studio-mode") && !b.contains("ms-tool-mode") && MSUI.studio) MSUI.studio.toast(text);
    else MSUI.toast(text, false, 6000);
  }

  /* ------------------------------------------------------------ tracking */

  function startTracking(now) {
    T.start(s, now, live.id, live.name);
    live.idleStopped = false;
    save();
    loop();
  }

  // Start / Pause by hand. A pause while auto-tracking holds it off until Start (it would restart at once).
  function toggle() {
    var now = Date.now();
    if (s.run) {
      T.stop(s, now, true);
      live.idleStopped = false;
      if (s.auto && inCEP) MSUI.toast("Paused. Tracking stays off until you press Start.");
    } else {
      startTracking(now);
    }
    save();
    render(true);
  }

  var probing = false, sentAt = 0;
  function probe() {
    if (!inCEP || probing) return;
    if (!panelOn()) {   // the panel was turned off in Settings: stop tracking
      if (s.run) { T.stop(s, bankPoint(Date.now()), false); save(); }
      return;
    }
    probing = true;
    sentAt = Date.now();
    MSUI.host("MS.timerProbe").then(function (r) {
      probing = false;
      r = String(r || "");
      var info = null;
      if (r.indexOf("OK|") === 0) { try { info = JSON.parse(r.slice(3)); } catch (e) { info = null; } }
      live.aeOk = !!info;
      if (info) onProbe(info, Date.now());
      else render(false);
    }, function () { probing = false; live.aeOk = false; render(false); });
  }

  function onProbe(info, now) {
    // Something changed in After Effects since the last look, or it was too busy to answer for a while
    // (rendering, a long apply): both count as work. The first answer is only the starting point.
    var changed = live.sig !== null && (info.sig !== live.sig || now - sentAt > 10000);
    live.sig = info.sig;
    live.id = info.path || "unsaved";
    live.name = info.name || "Unsaved project";
    live.comp = info.comp || "";
    var full = false;
    if (s.run) {
      if (changed) s.run.active = now;
      if (T.switchProject(s, now, live.id, live.name)) { save(); full = true; }
      // No activity for the idle time: stop, crediting only up to the last activity (plus one probe).
      if (s.idleMin && now - s.run.active > s.idleMin * 60000) {
        T.stop(s, bankPoint(now), false);
        live.idleStopped = true;
        save();
        full = true;
      }
    } else if (s.auto && !s.hold && changed) {
      startTracking(now);
      full = true;
    }
    render(full);
  }

  // A heartbeat while running: bank time now and then (so a crash loses little), break reminders, redraw.
  var tick = null, beats = 0;
  function loop() {
    if (tick) return;
    tick = setInterval(function () {
      if (!s.run) { clearInterval(tick); tick = null; render(true); return; }
      var now = Date.now();
      beats++;
      if (beats % 15 === 0) { T.bank(s, bankPoint(now)); save(); }
      if (s.focusMin) {
        var k = Math.floor((now - s.run.start) / (s.focusMin * 60000));
        if (k > (s.run.nudged || 0)) {
          s.run.nudged = k;
          save();
          notify(T.fmt((now - s.run.start) / 1000) + " of editing without a pause. Time for a short break.");
        }
      }
      render(beats % 10 === 0);
    }, 1000);
  }

  /* -------------------------------------------------------------- drawing */

  function setText(id, v) { var e = $(id); if (e && e.textContent !== v) e.textContent = v; }

  // full: also the week and the projects (every 10 s while running, at once after a change).
  function render(full) {
    if (!$("tgToday")) return;
    var now = Date.now(), today = T.daySec(s, T.dayKey(now), now), goal = s.goalMin * 60, met = today >= goal;
    var ring = $("tgRing");
    ring.style.strokeDasharray = (CIRC * Math.min(1, today / goal)).toFixed(1) + " " + CIRC.toFixed(1);
    ring.classList.toggle("done", met);
    ring.classList.toggle("empty", today < 30);   // a round cap would draw a lone dot at 0
    ring.parentNode.parentNode.classList.toggle("met", met);
    setText("tgToday", T.fmt(today));
    setText("tgGoalOf", met ? "goal met" : "of " + T.fmt(goal) + " goal");

    var st, hint, cls;
    if (s.run) {
      var still = watching() ? now - s.run.active : 0;
      st = s.auto ? "Tracking" : "Timer running"; cls = "on";
      hint = !watching() ? "Runs until you pause it."
        : still > 60000 ? "No activity for " + T.fmt(still / 1000) + ". Pauses at " + s.idleMin + " min and leaves the idle time out."
        : "Pauses by itself after " + s.idleMin + " min without activity.";
    } else if (live.idleStopped) {
      st = "Paused while idle"; cls = "idle";
      hint = s.auto ? "Starts again as soon as you work in After Effects." : "Press Resume to carry on.";
    } else if (s.hold || !s.auto) {
      st = "Paused"; cls = "off";
      hint = s.auto ? "Press Start to track again." : "Press Start to track your time.";
    } else {
      st = "Waiting for activity"; cls = "wait";
      hint = "Starts by itself when you work in After Effects.";
    }
    if (!inCEP) hint = "Open MotionSaaS in After Effects to track time.";
    else if (live.aeOk === false) hint = "After Effects is busy. Tracking catches up when it answers.";
    var stEl = $("tgStatus");
    if (stEl.className !== "tg-status " + cls) stEl.className = "tg-status " + cls;
    setText("tgStatusText", st);
    setText("tgHint", hint);

    var projName = s.run ? (s.run.project && s.projects[s.run.project] ? s.projects[s.run.project].name : live.name) : live.name;
    setText("tgWhere", [projName, live.comp].filter(Boolean).join(" · "));
    setText("tgStretch", s.run ? "This stretch " + T.clock((now - s.run.start) / 1000) : "");
    var streak = T.streak(s, now), best = T.bestStreak(s, now);
    setText("tgStreakText", streak ? streak + "-day goal streak" + (best > streak ? " · best " + best : "")
      : best ? "Best goal streak: " + best + " day" + (best === 1 ? "" : "s") : "Meet your goal to start a streak");
    $("tgStreak").classList.toggle("lit", streak > 0);
    var btn = $("tgStart");
    setText("tgStart", s.run ? "Pause" : (live.idleStopped || today > 0 ? "Resume" : "Start"));
    btn.classList.toggle("running", !!s.run);

    if (full) { renderWeek(now); renderProjects(now); renderSettings(); }
  }

  function shortDate(key) {
    var d = new Date(key + "T12:00:00");
    try { return d.toLocaleDateString(undefined, { month: "short", day: "numeric" }); } catch (e) { return key.slice(5); }
  }

  function weekInfo(now) {
    var keys = T.weekKeys(weekOffset, now), todayKey = T.dayKey(now), upto = weekOffset === 0 ? keys.indexOf(todayKey) + 1 : 7;
    var vals = keys.map(function (k) { return T.daySec(s, k, now); }), goal = s.goalMin * 60, total = 0, met = 0, i;
    for (i = 0; i < 7; i++) { total += vals[i]; if (vals[i] >= goal) met++; }
    var label = weekOffset === 0 ? "This week" : weekOffset === -1 ? "Last week" : shortDate(keys[0]) + " – " + shortDate(keys[6]);
    return { keys: keys, vals: vals, total: total, met: met, upto: Math.max(1, upto), label: label, todayKey: todayKey };
  }

  var DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], cols = [];
  // The 7 columns are made once and then only updated, so the bars grow and shrink smoothly (CSS transition).
  function renderWeek(now) {
    var w = weekInfo(now), goal = s.goalMin * 60, max = Math.max(goal * 1.2, Math.max.apply(null, w.vals)), bars = $("tgBars"), i;
    bars.style.setProperty("--tg-goal", (goal / max * 100).toFixed(1) + "%");
    if (!cols.length) {
      for (i = 0; i < 7; i++) {
        var c = { col: el("div", "tg-bar-col"), track: el("div", "tg-bar-track"), bar: el("div", "tg-bar"), day: el("small", "", DAYS[i]), val: el("em", "") };
        c.track.appendChild(c.bar);
        c.col.appendChild(c.val);
        c.col.appendChild(c.track);
        c.col.appendChild(c.day);
        bars.appendChild(c.col);
        cols.push(c);
      }
    }
    for (i = 0; i < 7; i++) {
      var k = w.keys[i], v = w.vals[i], x = cols[i];
      x.col.className = "tg-bar-col" + (k === w.todayKey ? " today" : "") + (k > w.todayKey ? " future" : "");
      x.col.title = DAYS[i] + " " + shortDate(k) + ": " + T.fmt(v) + (v >= goal ? " (goal met)" : "");
      x.bar.className = "tg-bar" + (v >= goal ? " met" : "");
      x.bar.style.height = (v > 0 ? Math.max(3, v / max * 100) : 0).toFixed(1) + "%";
      x.val.textContent = v >= 60 ? T.fmt(v) : "";
    }
    setText("tgWeekLabel", w.label);
    $("tgWeekNext").disabled = weekOffset >= 0;
    setText("tgWeekTotal", T.fmt(w.total));
    setText("tgWeekAvg", T.fmt(w.total / w.upto));
    setText("tgWeekGoal", w.met + " of " + w.upto + (w.upto === 1 ? " day" : " days"));
    setText("tgProjWeekHead", weekOffset === 0 ? "Week" : weekOffset === -1 ? "Last wk" : "That wk");
  }

  function renderProjects(now) {
    var keys = T.weekKeys(weekOffset, now), todayKey = T.dayKey(now), list = $("tgProjects"), runId = s.run ? s.run.project : "";
    var rows = Object.keys(s.projects).map(function (id) {
      return { id: id, name: s.projects[id].name, last: s.projects[id].last || 0,
        today: T.projectSec(s, id, [todayKey], now), week: T.projectSec(s, id, keys, now), total: T.projectSec(s, id, null, now) };
    }).filter(function (p) { return p.total >= 30 || p.id === runId; });
    rows.sort(function (a, b) { return (b.id === runId) - (a.id === runId) || b.week - a.week || b.last - a.last; });
    while (list.firstChild) list.removeChild(list.firstChild);
    if (!rows.length) {
      list.appendChild(el("div", "tg-empty", "No project time yet. It appears here as you work."));
      return;
    }
    var shown = showAll ? rows : rows.slice(0, 6);
    shown.forEach(function (p) {
      var row = el("div", "tg-proj" + (p.id === runId ? " current" : ""));
      var name = el("span", "tg-proj-name");
      name.appendChild(el("i", "tg-dot"));
      name.appendChild(el("span", "", p.name));
      name.title = p.id === "unsaved" ? "Projects that weren't saved yet" : p.id;
      row.appendChild(name);
      row.appendChild(el("span", "tg-num", p.today >= 60 ? T.fmt(p.today) : "–"));
      row.appendChild(el("span", "tg-num", p.week >= 60 ? T.fmt(p.week) : "–"));
      row.appendChild(el("span", "tg-num tg-total", T.fmt(p.total)));
      var x = el("button", "tg-proj-x");
      x.type = "button";
      x.title = "Remove this project's time";
      x.setAttribute("aria-label", "Remove the time tracked for " + p.name);
      x.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 7l10 10M17 7 7 17"></path></svg>';
      x.addEventListener("click", function () { removeProject(p); });
      row.appendChild(x);
      list.appendChild(row);
    });
    if (rows.length > 6) {
      var more = el("button", "tg-more", showAll ? "Show fewer" : "Show all " + rows.length + " projects");
      more.type = "button";
      more.addEventListener("click", function () { showAll = !showAll; renderProjects(Date.now()); });
      list.appendChild(more);
    }
  }

  function renderSettings() {
    setText("tgGoalVal", T.fmt(s.goalMin * 60));
    var auto = $("tgAuto");
    if (auto && auto.checked !== s.auto) auto.checked = s.auto;
    [["tgIdle", s.idleMin], ["tgFocus", s.focusMin]].forEach(function (g) {
      var box = $(g[0]);
      if (box) [].forEach.call(box.querySelectorAll("button"), function (b) { b.classList.toggle("active", Number(b.getAttribute("data-v")) === g[1]); });
    });
  }

  /* -------------------------------------------------------------- actions */

  function removeProject(p) {
    MSUI.confirm("Remove " + p.name + "?", "Its " + T.fmt(p.total) + " of tracked time is deleted from your history and totals.", "Remove").then(function (ok) {
      if (!ok) return;
      T.removeProject(s, p.id);
      save();
      render(true);
    });
  }

  function exportCsv() {
    var now = Date.now(), upTo = bankPoint(now);
    if (s.run) { T.bank(s, upTo); save(); }
    var csv = T.csv(s, upTo), node = MSUI.node || {}, fs = node.fs, path = node.path;
    if (csv.split("\r\n").length <= 2) { MSUI.toast("Nothing tracked yet"); return; }
    var docs = (MSUI.systemDir && MSUI.systemDir("documents")) || "";
    if (!fs || !path || !docs) {
      navigator.clipboard.writeText(csv).then(function () { MSUI.toast("Timesheet copied (CSV)"); }, function () { MSUI.toast("Couldn't save or copy the timesheet", true); });
      return;
    }
    try {
      var dir = path.join(path.dirname(docs), "Desktop");
      if (!fs.existsSync(dir)) dir = docs;
      var file = path.join(dir, "MotionSaaS timesheet " + T.dayKey(now) + ".csv");
      fs.writeFileSync(file, String.fromCharCode(0xFEFF) + csv);   // the BOM makes Excel read names as UTF-8
      MSUI.toast("Timesheet saved to " + file, false, 4500);
      MSUI.host("MS.openFolder", [dir]);
    } catch (e) {
      MSUI.toast("Couldn't save the timesheet: " + e.message, true);
    }
  }

  function copySummary() {
    var now = Date.now(), w = weekInfo(now), lines = [], keys = w.keys;
    lines.push("MotionSaaS · " + w.label + " (" + shortDate(keys[0]) + " – " + shortDate(keys[6]) + ")");
    lines.push("Total " + T.fmt(w.total) + " · goal met " + w.met + " of " + w.upto + " days");
    Object.keys(s.projects).map(function (id) { return { name: s.projects[id].name, sec: T.projectSec(s, id, keys, now) }; })
      .filter(function (p) { return p.sec >= 60; })
      .sort(function (a, b) { return b.sec - a.sec; })
      .forEach(function (p) { lines.push("• " + p.name + ": " + T.fmt(p.sec)); });
    navigator.clipboard.writeText(lines.join("\n")).then(function () { MSUI.toast("Week summary copied"); }, function () { MSUI.toast("Couldn't copy", true); });
  }

  function setGoal(step) {
    s.goalMin = Math.max(15, Math.min(720, s.goalMin + step));
    save();
    render(true);
  }
  function setAuto(on) {
    s.auto = !!on;
    if (s.auto) s.hold = false;
    save();
    render(true);
  }
  function setIdle(min) { s.idleMin = min; save(); render(true); }
  function setFocus(min) { s.focusMin = min; if (s.run) s.run.nudged = min ? Math.floor((Date.now() - s.run.start) / (min * 60000)) : 0; save(); render(true); }
  function setWeek(step) { weekOffset = Math.min(0, weekOffset + step); render(true); }

  function clearToday() {
    MSUI.confirm("Clear today?", "Today's " + T.fmt(T.daySec(s, T.dayKey(Date.now()), Date.now())) + " is removed from every project.", "Remove").then(function (ok) {
      if (!ok) return;
      T.clearDay(s, T.dayKey(Date.now()), Date.now());
      save();
      render(true);
    });
  }
  function clearAll() {
    MSUI.confirm("Clear all history?", "Every tracked day and project is deleted. Your goal and tracking settings stay.", "Delete").then(function (ok) {
      if (!ok) return;
      var keep = { goalMin: s.goalMin, auto: s.auto, idleMin: s.idleMin, focusMin: s.focusMin };
      s = T.fresh();
      s.goalMin = keep.goalMin; s.auto = keep.auto; s.idleMin = keep.idleMin; s.focusMin = keep.focusMin;
      live.idleStopped = false;
      save();
      render(true);
    });
  }

  MSUI.action("tgToggle", toggle);
  MSUI.action("tgWeek", setWeek);
  MSUI.action("tgGoal", setGoal);
  MSUI.action("tgAuto", setAuto, "checked");
  MSUI.action("tgIdle", setIdle);
  MSUI.action("tgFocus", setFocus);
  MSUI.action("tgExport", exportCsv);
  MSUI.action("tgCopy", copySummary);
  MSUI.action("tgClearToday", clearToday);
  MSUI.action("tgClearAll", clearAll);
  MSUI.timer = { render: function () { render(true); } };

  /* ----------------------------------------------------------------- boot */

  function boot() {
    var now = Date.now();
    if (s.run) {
      // The panel or After Effects was closed while tracking: count only up to the last heartbeat (and the
      // last activity), not the whole gap — a forgotten timer must not log the night as editing.
      var seen = Math.max(s.beat || 0, s.run.since);
      if (now - seen > 2 * 60 * 1000) { T.stop(s, Math.min(seen, bankPoint(seen)), false); save(); }
      else loop();
    }
    render(true);
    if (inCEP) { probe(); setInterval(probe, PROBE_MS); }
    setInterval(function () { if (!s.run) render(true); }, 60000);   // the date changes, idle redraws
    document.addEventListener("ms-tab", function (e) { if (e.detail === "timer") render(true); });
    window.addEventListener("beforeunload", function () { if (s.run) T.bank(s, bankPoint(Date.now())); save(); });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
