/*
 * MotionSaaS — Assetbox.
 * A personal library of compositions: <library>/<Category>/<Name>.aep + .png thumbnail (+ .gif preview).
 * Save the active comp, browse by category, search, favourite, rename, delete, click to import.
 */
(function () {
  "use strict";

  var MSUI = window.MSUI, ab = MSUI.assetbox = {};
  var $ = function (id) { return document.getElementById(id); };
  var store = MSUI.store;
  var req = window.cep_node && window.cep_node.require || (typeof require === "function" ? require : null);
  var fs = req ? req("fs") : null, path = req ? req("path") : null, os = req ? req("os") : null;
  var EXT = window.__adobe_cep__ ? MSUI.cs.getSystemPath(SystemPath.EXTENSION) : "";
  var state = { cat: store.get("ms_ab_cat", "All"), query: "", target: null };

  function toast(m, e) { MSUI.toast(m, e); }
  function host(fn, args) { return MSUI.host(fn, args || []); }

  /* ------------------------------------------------------------ paths */

  function root() {
    var p = store.get("ms_ab_path", ""), docs;
    if (!p && path) {
      docs = (MSUI.systemDir && MSUI.systemDir("documents")) || (os ? path.join(os.homedir(), "Documents") : "");
      p = path.join(docs, "MotionSaaS Assetbox");
    }
    return p;
  }
  function mkdirp(dir) {
    if (!dir || fs.existsSync(dir)) return;
    mkdirp(path.dirname(dir));
    fs.mkdirSync(dir);
  }
  function safeName(s) { return String(s || "").trim().replace(/[\/\\:\*\?"<>\|]/g, "_").slice(0, 80); }
  function fileUrl(p) { return "file:///" + String(p).replace(/\\/g, "/").replace(/^\/+/, "").replace(/#/g, "%23").replace(/\?/g, "%3F"); }

  function categories() {
    var r = root(), out = [];
    try {
      mkdirp(r);
      fs.readdirSync(r).forEach(function (f) {
        if (f.charAt(0) !== "." && fs.statSync(path.join(r, f)).isDirectory()) out.push(f);
      });
    } catch (e) {}
    if (!out.length) { try { mkdirp(path.join(r, "General")); out.push("General"); } catch (e2) {} }
    return out.sort(function (a, b) { return a.localeCompare(b); });
  }

  function assets() {
    var r = root(), list = [];
    categories().forEach(function (cat) {
      var dir = path.join(r, cat);
      try {
        fs.readdirSync(dir).forEach(function (f) {
          if (!/\.aep$/i.test(f)) return;
          var base = path.join(dir, f.replace(/\.aep$/i, ""));
          list.push({
            cat: cat, name: f.replace(/\.aep$/i, ""), aep: base + ".aep",
            png: fs.existsSync(base + ".png") ? base + ".png" : null,
            gif: fs.existsSync(base + ".gif") ? base + ".gif" : null,
            mtime: fs.statSync(base + ".aep").mtime.getTime(),
            id: cat + "/" + f
          });
        });
      } catch (e) {}
    });
    return list;
  }

  /* ----------------------------------------------------------- render */

  function renderCategories() {
    var box = $("ab-category-filters");
    if (!box) return;
    var cats = ["All", "★ Favourites"].concat(categories());
    if (cats.indexOf(state.cat) === -1) state.cat = "All";
    box.innerHTML = "";
    cats.forEach(function (c) {
      var b = document.createElement("button");
      b.className = "ab-category-btn" + (c === state.cat ? " active" : "");
      b.textContent = c;
      b.addEventListener("click", function () { state.cat = c; store.set("ms_ab_cat", c); render(false); });
      box.appendChild(b);
    });
    var add = document.createElement("button");
    add.className = "ab-category-btn";
    add.textContent = "+ Folder";
    add.title = "Create a category folder";
    add.addEventListener("click", function () { $("ab-folder-input").value = ""; $("ab-folder-modal").style.display = "flex"; });
    box.appendChild(add);
  }

  // Disk scan is cached: typing in search, switching category or starring only re-filters.
  // Anything that changes files (save/rename/delete/new folder/new path/tab open) calls render() → rescan.
  var cache = null;
  function listAssets(rescan) {
    if (rescan || !cache) cache = assets();
    return cache;
  }

  function render(rescan) {
    var grid = $("ab-grid");
    if (!grid) return;
    if (!fs) { grid.innerHTML = '<div class="ms-empty">Assetbox needs Node.js in the panel.</div>'; return; }
    renderCategories();
    grid.style.setProperty("--card-min", store.get("ms_ab_card", 110) + "px");
    var favs = store.get("ms_ab_favs", []), mode = store.get("ms_ab_preview", "png"), q = state.query.toLowerCase();
    var list = listAssets(rescan !== false).filter(function (a) {
      if (state.cat === "★ Favourites" && favs.indexOf(a.id) === -1) return false;
      if (state.cat !== "All" && state.cat !== "★ Favourites" && a.cat !== state.cat) return false;
      return !q || a.name.toLowerCase().indexOf(q) !== -1 || a.cat.toLowerCase().indexOf(q) !== -1;
    });
    list.sort(function (a, b) {
      var fa = favs.indexOf(a.id) !== -1, fb = favs.indexOf(b.id) !== -1;
      if (fa !== fb) return fa ? -1 : 1;
      return b.mtime - a.mtime;
    });
    grid.innerHTML = "";
    if (!list.length) {
      grid.innerHTML = '<div class="ms-empty" style="grid-column: 1 / -1;">' +
        (q || state.cat !== "All" ? "Nothing here yet." : "Open a comp and press 💾 to save your first asset.") + "</div>";
      return;
    }
    list.forEach(function (a) {
      var card = document.createElement("div"), fav = favs.indexOf(a.id) !== -1;
      card.className = "ab-item";
      card.title = a.name + " — click to add to your comp\nRight-click for more";
      var thumb = document.createElement("div");
      thumb.className = "ab-thumb";
      if (a.png || a.gif) {
        var img = document.createElement("img");
        var still = fileUrl(a.png || a.gif) + "?v=" + a.mtime;
        img.src = still;
        if (a.gif && mode === "gif") {
          card.addEventListener("mouseenter", function () { img.src = fileUrl(a.gif) + "?v=" + a.mtime; });
          card.addEventListener("mouseleave", function () { img.src = still; });
        }
        thumb.appendChild(img);
      } else {
        thumb.innerHTML = '<div class="ms-ab-noprev">🎬</div>';
      }
      card.appendChild(thumb);
      var name = document.createElement("div");
      name.className = "ab-item-name";
      name.textContent = a.name;
      card.appendChild(name);
      var star = document.createElement("button");
      star.className = "ab-item-fav" + (fav ? " active" : "");
      star.textContent = fav ? "★" : "☆";
      star.title = fav ? "Remove from favourites" : "Add to favourites";
      star.addEventListener("click", function (e) {
        e.stopPropagation();
        var f = store.get("ms_ab_favs", []), i = f.indexOf(a.id);
        if (i === -1) f.push(a.id); else f.splice(i, 1);
        store.set("ms_ab_favs", f); render(false);
      });
      card.appendChild(star);
      card.addEventListener("click", function () {
        card.style.transform = "scale(0.96)";
        setTimeout(function () { card.style.transform = ""; }, 120);
        host("MS.assetImport", [a.aep]).then(function (r) { MSUI.report(r); });
      });
      card.addEventListener("contextmenu", function (e) { e.preventDefault(); menu(e, a); });
      grid.appendChild(card);
    });
  }

  /* ------------------------------------------------------- context menu */

  var menuEl = null;
  function menu(e, a) {
    if (!menuEl) {
      menuEl = document.createElement("div");
      menuEl.className = "context-menu";
      menuEl.innerHTML = '<div class="context-menu-item" data-a="import">⤵︎ Add to comp</div>' +
        '<div class="context-menu-item" data-a="rename">✎ Rename</div>' +
        '<div class="context-menu-item" data-a="folder">📂 Show in folder</div>' +
        '<div class="context-menu-item danger" data-a="delete">🗑 Delete</div>';
      document.body.appendChild(menuEl);
      document.addEventListener("click", function () { menuEl.style.display = "none"; });
      Array.prototype.forEach.call(menuEl.children, function (item) {
        item.addEventListener("click", function () {
          var t = state.target, act = item.getAttribute("data-a");
          menuEl.style.display = "none";
          if (!t) return;
          if (act === "import") host("MS.assetImport", [t.aep]).then(function (r) { MSUI.report(r); });
          if (act === "folder") host("MS.openFolder", [path.dirname(t.aep)]);
          if (act === "rename") { $("ab-rename-input").value = t.name; $("ab-rename-modal").style.display = "flex"; setTimeout(function () { $("ab-rename-input").select(); }, 30); }
          if (act === "delete") { $("ab-delete-name").textContent = t.name; $("ab-delete-modal").style.display = "flex"; }
        });
      });
    }
    state.target = a;
    menuEl.style.display = "flex";
    menuEl.style.left = Math.min(e.clientX, window.innerWidth - 150) + "px";
    menuEl.style.top = Math.min(e.clientY, window.innerHeight - 150) + "px";
  }

  /* -------------------------------------------------------- save flow */

  function overlay(on, title, sub) {
    var o = $("ab-loading-overlay");
    if (!o) return;
    o.style.display = on ? "flex" : "none";
    if (title) $("ab-loading-title").textContent = title;
    if (sub) $("ab-loading-subtitle").textContent = sub;
  }

  function waitForFile(p, ms) {
    return new Promise(function (resolve) {
      var t0 = Date.now(), last = -1;
      (function poll() {
        var size = -1;
        try { size = fs.statSync(p).size; } catch (e) {}
        if (size > 0 && size === last) { resolve(true); return; }
        last = size;
        if (Date.now() - t0 > ms) { resolve(size > 0); return; }
        setTimeout(poll, 250);
      })();
    });
  }

  function loadImage(p) {
    return new Promise(function (resolve, reject) {
      var img = new Image();
      img.onload = function () { resolve(img); };
      img.onerror = function () { reject(new Error("Couldn't read " + path.basename(p))); };
      // A data: URL keeps the canvas untainted, so getImageData works for the GIF encoder.
      try { img.src = "data:image/png;base64," + fs.readFileSync(p).toString("base64"); }
      catch (e) { reject(e); }
    });
  }

  // Render frames in AE, then encode them into a small looping GIF with gifenc.
  function makeGif(gifPath) {
    var base = os.tmpdir();
    try { if (window.Updater) base = window.Updater.writableTmp(); } catch (e) { return Promise.resolve(false); }
    var tmp = path.join(base, "motionsaas-ab-" + Date.now()), count = 16, gifenc;
    try { gifenc = req(path.join(EXT, "js", "gifenc.js")); } catch (e) { return Promise.resolve(false); }
    mkdirp(tmp);
    return host("MS.assetFrames", [tmp, count]).then(function (r) {
      if (r.indexOf("OK|") !== 0) return false;
      count = Number(r.slice(3)) || count;
      var files = [], i;
      for (i = 0; i < count; i++) files.push(path.join(tmp, "frame_" + (i < 10 ? "0" : "") + i + ".png"));
      return files.reduce(function (p, f) { return p.then(function () { return waitForFile(f, 15000); }); }, Promise.resolve())
        .then(function () { return Promise.all(files.map(loadImage)); })
        .then(function (imgs) {
          var w = 240, h = Math.round(w * imgs[0].height / imgs[0].width), canvas = document.createElement("canvas"), ctx;
          canvas.width = w; canvas.height = h;
          ctx = canvas.getContext("2d");
          var gif = gifenc.GIFEncoder();
          imgs.forEach(function (img) {
            ctx.drawImage(img, 0, 0, w, h);
            var px = ctx.getImageData(0, 0, w, h).data, palette = gifenc.quantize(px, 128), index = gifenc.applyPalette(px, palette);
            gif.writeFrame(index, w, h, { palette: palette, delay: 1000 / 12 });
          });
          gif.finish();
          fs.writeFileSync(gifPath, Buffer.from(gif.bytes()));
          files.forEach(function (f) { try { fs.unlinkSync(f); } catch (e) {} });
          try { fs.rmdirSync(tmp); } catch (e) {}
          return true;
        });
    }).catch(function () { return false; });
  }

  function openAbSaveModal() {
    host("MS.activeCompName").then(function (r) {
      if (r.indexOf("OK|") !== 0) { MSUI.report(r); return; }
      var sel = $("ab-category-select"), cats = categories(), want = state.cat;
      sel.innerHTML = "";
      cats.forEach(function (c) {
        var o = document.createElement("option");
        o.value = c; o.textContent = c;
        if (c === want) o.selected = true;
        sel.appendChild(o);
      });
      $("ab-save-name-input").value = r.slice(3);
      $("ab-save-new-cat").value = "";
      $("ab-save-title").textContent = "Save “" + r.slice(3) + "”";
      $("ab-save-modal").style.display = "flex";
    });
  }
  function closeAbSaveModal() { $("ab-save-modal").style.display = "none"; }

  function confirmAbSaveAsset() {
    var name = safeName($("ab-save-name-input").value), cat = safeName($("ab-save-new-cat").value) || $("ab-category-select").value || "General";
    if (!name) { toast("Give the asset a name", true); return; }
    var dir = path.join(root(), cat), base = path.join(dir, name);
    try { mkdirp(dir); } catch (e) { toast("Can't create " + dir, true); return; }
    var go = function () {
      closeAbSaveModal();
      overlay(true, "Saving Asset…", "Rendering thumbnail");
      ["png", "gif"].forEach(function (x) { try { fs.unlinkSync(base + "." + x); } catch (e) {} });
      host("MS.assetThumb", [base + ".png"])
        .then(function () { return waitForFile(base + ".png", 15000); })
        .then(function () {
          if (store.get("ms_ab_preview", "png") !== "gif") return false;
          overlay(true, "Saving Asset…", "Building GIF preview");
          return makeGif(base + ".gif");
        })
        .then(function () { overlay(true, "Saving Asset…", "Packing project"); return host("MS.assetSave", [base + ".aep"]); })
        .then(function (r) {
          overlay(false);
          MSUI.report(r);
          if (r.indexOf("OK|") === 0) { state.cat = cat; store.set("ms_ab_cat", cat); render(); }
        })
        .catch(function (e) { overlay(false); toast("Save failed: " + e.message, true); });
    };
    // Saving packs the comp into its own project, which means saving and briefly closing the user's
    // project. Say so the first time instead of surprising them.
    var explained = function (next) {
      if (store.get("ms_ab_save_ok", false)) { next(); return; }
      MSUI.confirm("Save to Assetbox",
        "MotionSaaS will save your project, pack this comp into its own file, then reopen your project. " +
        "Undo history is cleared by the reopen. Continue?", "Continue", "Cancel").then(function (ok) {
        if (!ok) return;
        store.set("ms_ab_save_ok", true);
        next();
      });
    };
    if (fs.existsSync(base + ".aep")) {
      MSUI.confirm("Replace asset?", "“" + name + "” already exists in " + cat + ".", "Replace", "Cancel")
        .then(function (ok) { if (ok) explained(go); });
    } else explained(go);
  }

  /* ------------------------------------------ rename / delete / folder */

  function closeAbRenameModal() { $("ab-rename-modal").style.display = "none"; }
  function confirmAbRenameAsset() {
    var t = state.target, n = safeName($("ab-rename-input").value);
    if (!t || !n || n === t.name) { closeAbRenameModal(); return; }
    var dir = path.dirname(t.aep), to = path.join(dir, n);
    // Case-only renames ("logo" → "Logo") hit the same file on Windows/macOS; that's fine, not a clash.
    if (fs.existsSync(to + ".aep") && n.toLowerCase() !== t.name.toLowerCase()) { toast("“" + n + "” already exists", true); return; }
    ["aep", "png", "gif"].forEach(function (x) {
      var from = path.join(dir, t.name + "." + x);
      if (fs.existsSync(from)) fs.renameSync(from, to + "." + x);
    });
    var favs = store.get("ms_ab_favs", []), i = favs.indexOf(t.id);
    if (i !== -1) { favs[i] = t.cat + "/" + n + ".aep"; store.set("ms_ab_favs", favs); }
    closeAbRenameModal();
    render();
  }

  function closeAbDeleteModal() { $("ab-delete-modal").style.display = "none"; }
  function confirmAbDeleteAsset() {
    var t = state.target;
    closeAbDeleteModal();
    if (!t) return;
    ["aep", "png", "gif"].forEach(function (x) { try { fs.unlinkSync(path.join(path.dirname(t.aep), t.name + "." + x)); } catch (e) {} });
    toast("Deleted “" + t.name + "”");
    render();
  }

  function closeAbFolderModal() { $("ab-folder-modal").style.display = "none"; }
  function confirmAbCreateFolder() {
    var n = safeName($("ab-folder-input").value);
    if (!n) { toast("Enter a folder name", true); return; }
    try { mkdirp(path.join(root(), n)); } catch (e) { toast("Couldn't create folder: " + e.message, true); return; }
    closeAbFolderModal();
    state.cat = n; store.set("ms_ab_cat", n);
    render();
  }

  /* -------------------------------------------------- toolbar + settings */

  function handleAbSearch(q) { state.query = String(q || "").trim(); render(false); }
  function setAbCardSize(px) { store.set("ms_ab_card", Number(px) || 110); var g = $("ab-grid"); if (g) g.style.setProperty("--card-min", px + "px"); }
  function switchAbTab() { render(); }
  function toggleAbSettingsPanel() {
    var p = $("ab-settings-panel");
    if (!p) return;
    var open = p.style.display === "none" || !p.style.display;
    p.style.display = open ? "flex" : "none";
    if (open) syncSettings();
  }
  function setAbPreviewMode(mode) {
    store.set("ms_ab_preview", mode === "gif" ? "gif" : "png");
    syncSettings();
    render();
    if (mode === "gif") toast("New saves get a GIF preview (hover a card to play it)");
  }
  function changeAbLibraryPath() {
    if (!window.cep || !window.cep.fs) return;
    var r = window.cep.fs.showOpenDialog(false, true, "Choose your Assetbox folder", root(), "");
    if (r && r.data && r.data.length) {
      var p = decodeURIComponent(String(r.data[0]).replace(/^file:\/\/\/?/, ""));
      if (/^\/[A-Za-z]:/.test(p)) p = p.slice(1);
      store.set("ms_ab_path", p);
      syncSettings();
      render();
    }
  }

  function syncSettings() {
    if ($("settings-ab-path")) { $("settings-ab-path").textContent = root(); $("settings-ab-path").title = root(); }
    var mode = store.get("ms_ab_preview", "png");
    [["ab-mode-png", "png"], ["ab-mode-gif", "gif"]].forEach(function (p) {
      var b = $(p[0]);
      if (!b) return;
      var on = mode === p[1];
      b.style.background = on ? "var(--accent-gradient)" : "none";
      b.style.color = on ? "#fff" : "rgba(255,255,255,0.5)";
    });
    if ($("ab-card-slider")) $("ab-card-slider").value = store.get("ms_ab_card", 110);
  }

  ab.refresh = render;
  ab.openSaveModal = openAbSaveModal;
  ab.search = handleAbSearch;
  ab.setPreviewMode = setAbPreviewMode;
  ab.changeLibraryPath = changeAbLibraryPath;
  MSUI.action("openAbSaveModal", openAbSaveModal);
  MSUI.action("closeAbSaveModal", closeAbSaveModal);
  MSUI.action("confirmAbSaveAsset", confirmAbSaveAsset);
  MSUI.action("closeAbRenameModal", closeAbRenameModal);
  MSUI.action("confirmAbRenameAsset", confirmAbRenameAsset);
  MSUI.action("closeAbDeleteModal", closeAbDeleteModal);
  MSUI.action("confirmAbDeleteAsset", confirmAbDeleteAsset);
  MSUI.action("closeAbFolderModal", closeAbFolderModal);
  MSUI.action("confirmAbCreateFolder", confirmAbCreateFolder);
  MSUI.action("switchAbTab", switchAbTab);
  MSUI.action("toggleAbSettingsPanel", toggleAbSettingsPanel);
  MSUI.action("setAbPreviewMode", setAbPreviewMode);
  MSUI.action("changeAbLibraryPath", changeAbLibraryPath);
  MSUI.action("handleAbSearch", handleAbSearch, "value");
  MSUI.action("setAbCardSize", setAbCardSize, "value");

  function boot() {
    syncSettings();
    document.addEventListener("ms-tab", function (e) { if (e.detail === "assetbox") render(); });
    ["ab-folder-modal", "ab-save-modal", "ab-rename-modal", "ab-delete-modal"].forEach(function (id) {
      var m = $(id);
      if (m) m.addEventListener("click", function (e) { if (e.target === m) m.style.display = "none"; });
    });
    if ($("ab-rename-input")) $("ab-rename-input").addEventListener("keydown", function (e) { if (e.key === "Enter") confirmAbRenameAsset(); });
    if ($("ab-folder-input")) $("ab-folder-input").addEventListener("keydown", function (e) { if (e.key === "Enter") confirmAbCreateFolder(); });
    if ($("assetbox-tab") && $("assetbox-tab").style.display === "block") render();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
