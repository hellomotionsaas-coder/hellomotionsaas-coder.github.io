/*
 * MotionSaaS — Carousel layout math, shared by the panel's preview (js/ms-carousel.js) and the After Effects rig.
 * msCarousel() is written in plain ES3 on purpose: its source text (msCarousel.toString()) is placed inside the
 * expressions of every carousel picture, so the preview and After Effects compute exactly the same layout.
 * The rig: one null ("MS Carousel 1") holding an effect per FIELDS entry; each picture's position, scale,
 * opacity and X / Y / Z rotation expressions read those effects and call msCarousel(P, index, count, time).
 * Published as MSUI.carouselCore (+ module.exports for scripts/check.js).
 */
(function (root) {
  "use strict";

  /* Styles: 0 sphere · 1 radial · 2 grid · 3 curved line · 4 custom path.
     Motion: 0 still · 1 spin · 2 step · 3 swing. Face (sphere): 0 screen · 1 outward · 2 inward;
     (radial): 0 screen · 1 centre · 2 outward (standing cards, a turntable).
     On top of the layout (all optional, all keyframeable on the rig):
     - Morph: blends the layout into a second style ("Morph to"), 0–100 %.
     - Shuffle: a seed (0 = off) that deals the pictures into the layout's places in a random order.
     - Cascade: each picture's motion starts this many ms after the one before (a ripple through a step or swing).
     - Wave: pictures float up and down in a travelling wave of this height (px).
     - Effector: a point (dragged in the preview, or in the comp) that grows, pushes away and lifts the pictures
       within its size, with a soft falloff. Animate the point to sweep it across the layout.
     pathPt (optional): u (0–1) → [x, y] in the rig's space, the custom path for style 4.
     Returns [x, y, z, scale, opacity, rotX, rotY, rotZ] in the rig's space. */
  function msCarousel(P, i, n, t, pathPt) {
    var PI = Math.PI, D = 180 / PI, j, k, f;
    function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
    function wrap(v, m) { return ((v % m) + m) % m; }
    function num(v, d) { return typeof v === "number" && v === v ? v : d; }
    n = Math.max(1, n);
    var sd = Math.round(num(P.shuffle, 0)), slot = i;
    function hsh(q) { var v = Math.sin(q * 12.9898 + sd * 78.233) * 43758.5453; return v - Math.floor(v); }
    if (sd > 0) {   // the picture's place: its rank among the seeded hashes of all pictures
      var hi = hsh(i);
      slot = 0;
      for (j = 0; j < n; j++) { k = hsh(j); if (k < hi || (k === hi && j < i)) { slot++; } }
    }
    var tt = t - slot * Math.max(0, num(P.cascade, 0)) / 1000;
    var mo = Math.round(P.motion), sp = P.speed / 50, s = 0, h = Math.max(0.25, P.step);
    if (mo === 1) { s = tt * sp; }
    else if (mo === 2) {
      k = Math.floor(tt / h);
      f = clamp((tt - k * h) / Math.min(0.6, h * 0.8), 0, 1);
      f = f < 0.5 ? 4 * f * f * f : 1 - Math.pow(-2 * f + 2, 3) / 2;
      s = (k + f) * (sp < 0 ? -1 : 1);
    }
    else if (mo === 3) { s = Math.sin(tt * 2 * PI / 4) * sp * 2; }
    s += P.offset / 100 * n;
    var R = Math.max(1, P.size), T = P.tilt / D, face = Math.round(P.face);

    // One layout style: [x, y, z, sc, op, rx, ry, rz, depth]
    function place(st) {
      var x = 0, y = 0, z = 0, sc = 1, op = 1, rx = 0, ry = 0, rz = 0, depth = 0;
      if (st === 0) {   // sphere: even points (Fibonacci), turning around the vertical axis
        var phi = Math.acos(1 - 2 * (slot + 0.5) / n), th = PI * (1 + Math.sqrt(5)) * slot + s * 2 * PI / n, yy;
        x = Math.cos(th) * Math.sin(phi) * R; y = -Math.cos(phi) * R; z = -Math.sin(th) * Math.sin(phi) * R;
        yy = y * Math.cos(T) - z * Math.sin(T); z = y * Math.sin(T) + z * Math.cos(T); y = yy;
        depth = (z / R + 1) / 2;
        if (face === 1 || face === 2) {
          ry = Math.atan2(x, -z) * D + (face === 2 ? 180 : 0);
          rx = Math.atan2(y, Math.sqrt(x * x + z * z)) * D * (face === 2 ? -1 : 1);
        }
      } else if (st === 1) {   // radial: a circle (or an arc of `spread` degrees), tilted back by `tilt`
        var full = P.spread >= 359.5, a, uu, v;
        if (full) { uu = wrap(slot + s, n); a = uu / n * 2 * PI; }
        else {
          uu = wrap(slot + s + 0.5, n) - 0.5;
          a = (n > 1 ? uu / (n - 1) - 0.5 : 0) * P.spread / D;
          if (s !== 0) { op = clamp(Math.min(uu + 0.5, n - 0.5 - uu) * 2, 0, 1); }
        }
        x = Math.sin(a) * R; v = Math.cos(a) * R;
        y = v * Math.cos(T); z = -v * Math.sin(T);
        depth = (z / R + 1) / 2;
        if (face === 1) { rz = -a * D; rx = P.tilt; }
        else if (face === 2) { ry = -a * D; }
      } else if (st === 2) {   // grid, scrolling sideways when it moves, optionally bent into a curved wall
        var c = Math.max(1, Math.round(P.cols)), rows = Math.ceil(n / c), cell = Math.max(1, P.pic + P.gap), W = c * cell,
          gx = (slot % c + 0.5) * cell + s * cell, b = clamp(P.bend / 100, 0, 1), y2;
        if (s !== 0) { gx = wrap(gx, W); op = clamp(Math.min(gx, W - gx) / (cell * 0.5), 0, 1); }
        x = gx - W / 2; y = (Math.floor(slot / c) - (rows - 1) / 2) * cell;
        if (b > 0.001) {
          var ang = x / (W / 2) * b * PI / 2, rr = (W / 2) / (b * PI / 2);
          x = Math.sin(ang) * rr; z = (1 - Math.cos(ang)) * rr; ry = ang * D;
          depth = clamp(z / rr, 0, 1);
        }
        y2 = y * Math.cos(T) - z * Math.sin(T); z = y * Math.sin(T) + z * Math.cos(T); y = y2;
      } else {   // curved line through three points, or a custom path: pictures evenly spaced along it
        var p1 = P.p1, p2 = P.p2, p3 = P.p3, q0 = 2 * p2[0] - (p1[0] + p3[0]) / 2, q1 = 2 * p2[1] - (p1[1] + p3[1]) / 2;
        var pt = st === 4 && pathPt ? pathPt : function (u) {
          var w = 1 - u;
          return [w * w * p1[0] + 2 * u * w * q0 + u * u * p3[0], w * w * p1[1] + 2 * u * w * q1 + u * u * p3[1], 0];
        };
        var N = 32, L = 0, acc = [0], prev = pt(0), cur, dx, dy, m;
        for (m = 1; m <= N; m++) { cur = pt(m / N); dx = cur[0] - prev[0]; dy = cur[1] - prev[1]; L += Math.sqrt(dx * dx + dy * dy); acc.push(L); prev = cur; }
        L = Math.max(L, 0.001);
        var spacing = P.gap > 0 ? P.pic + P.gap : (n > 1 ? L / (n - 1) : 0), start = P.gap > 0 ? (L - (n - 1) * spacing) / 2 : 0,
          dist = start + (slot + s) * spacing;
        if (s !== 0 && spacing > 0) { dist = start + wrap((slot + s) * spacing + spacing / 2, n * spacing) - spacing / 2; }
        if (spacing > 0 && (dist < 0 || dist > L)) { op = clamp(1 - Math.max(-dist, dist - L) / (spacing * 0.6), 0, 1); }
        var dd = clamp(dist, 0, L), seg = 1;
        while (seg < N && acc[seg] < dd) { seg++; }
        var u = (seg - 1 + (dd - acc[seg - 1]) / Math.max(0.0001, acc[seg] - acc[seg - 1])) / N, p = pt(clamp(u, 0, 1));
        x = p[0]; y = p[1]; z = p.length > 2 ? p[2] : 0;
        var g = dist / L - 0.5;
        sc = 1 + (P.mid / 100 - 1) * Math.exp(-g * g / 0.03);
        z -= (sc - 1) * 120;   // bigger pictures come forward, so they sit on top of their neighbours
      }
      return [x, y, z, sc, op, rx, ry, rz, depth];
    }

    var r = place(Math.round(P.style)), mm = clamp(num(P.morph, 0) / 100, 0, 1), r2;
    if (mm > 0.0005) {
      r2 = place(Math.round(num(P.style2, 0)));
      for (j = 0; j < 9; j++) { r[j] += (r2[j] - r[j]) * mm; }
    }

    // Wave: a travelling ripple through the pictures, in their layout order.
    var wv = num(P.wave, 0);
    if (wv !== 0) { r[1] += Math.sin(t * PI - slot * 0.55) * wv; }

    // Effector: grow, push away and lift what is near the point, fading out smoothly at its edge.
    var ef = Math.round(num(P.eff, 0)), ep = P.effPt, er = Math.max(1, num(P.effR, 300));
    if (ef === 1 && ep) {
      var ex = r[0] - ep[0], ey = r[1] - ep[1], ed = Math.sqrt(ex * ex + ey * ey), w2 = clamp(1 - ed / er, 0, 1);
      w2 = w2 * w2 * (3 - 2 * w2);
      if (w2 > 0) {
        r[3] *= 1 + num(P.effScale, 0) / 100 * w2;
        if (ed > 0.001) { r[0] += ex / ed * num(P.effPush, 0) * w2; r[1] += ey / ed * num(P.effPush, 0) * w2; }
        r[2] -= num(P.effLift, 0) * w2;
        r[8] *= 1 - w2;   // in focus: no depth fade
      }
    }

    // Reveal: pictures grow in one after another while Reveal goes 0 to 100 (keyframed when built).
    var rv = clamp(P.reveal / 100, 0, 1), sg = clamp(P.stagger / 100, 0, 0.95), win = 1 / (1 + sg * (n - 1)), loc = clamp((rv - i * sg * win) / win, 0, 1);
    r[3] *= 1 - Math.pow(1 - loc, 3);
    r[4] *= clamp(loc * 1.6, 0, 1);
    r[4] *= 1 - clamp(P.fade / 100, 0, 1) * 0.85 * r[8];
    return [r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7]];
  }

  // Every setting is an effect on the rig's null (name shown in After Effects' Effect Controls), so it can
  // also be keyframed there. [key, effect name, "slider" | "point", default]
  var FIELDS = [
    ["style", "Style", "slider", 1], ["size", "Size", "slider", 380], ["spread", "Spread", "slider", 360],
    ["tilt", "Tilt", "slider", 0], ["face", "Face", "slider", 0], ["cols", "Columns", "slider", 4],
    ["gap", "Gap", "slider", 30], ["bend", "Bend", "slider", 0], ["mid", "Middle size", "slider", 135],
    ["pic", "Picture size", "slider", 220], ["fade", "Depth fade", "slider", 30], ["motion", "Motion", "slider", 1],
    ["speed", "Speed", "slider", 12], ["step", "Step every", "slider", 2], ["offset", "Offset", "slider", 0],
    ["reveal", "Reveal", "slider", 100], ["stagger", "Stagger", "slider", 35],
    ["p1", "Start", "point", [-560, 40]], ["p2", "Middle", "point", [0, 160]], ["p3", "End", "point", [560, 40]],
    ["morph", "Morph", "slider", 0], ["style2", "Morph to", "slider", 2], ["shuffle", "Shuffle", "slider", 0],
    ["cascade", "Cascade", "slider", 0], ["wave", "Wave", "slider", 0],
    ["eff", "Effector", "slider", 0], ["effPt", "Effector point", "point", [0, 0]], ["effR", "Effector size", "slider", 320],
    ["effScale", "Effector scale", "slider", 45], ["effPush", "Effector push", "slider", 50], ["effLift", "Effector lift", "slider", 160]
  ];
  function defaults() {
    var o = {}, i;
    for (i = 0; i < FIELDS.length; i++) { o[FIELDS[i][0]] = FIELDS[i][3] instanceof Array ? FIELDS[i][3].slice() : FIELDS[i][3]; }
    o.revealOn = true; o.revealDur = 1.2;
    return o;
  }

  // Built-in presets: a layout plus a motion. Each only lists what differs from defaults().
  var PRESETS = [
    { id: "turntable", name: "Turntable", note: "Cards stand in a ring that turns", v: { style: 1, size: 460, tilt: 74, face: 2, motion: 1, speed: 10, fade: 45, pic: 260 } },
    { id: "globe", name: "Globe", note: "A sphere of pictures, slowly turning", v: { style: 0, size: 360, face: 1, motion: 1, speed: 8, fade: 55, pic: 150 } },
    { id: "halo", name: "Halo", note: "A flat circle that steps round", v: { style: 1, size: 340, tilt: 0, face: 0, motion: 2, speed: 50, step: 1.6, pic: 170 } },
    { id: "fan", name: "Fan", note: "An arc of cards pointing to the centre", v: { style: 1, size: 520, spread: 120, tilt: 0, face: 1, motion: 0, pic: 210, offset: 0 } },
    { id: "coverflow", name: "Cover flow", note: "A row with a big middle picture, one step at a time", v: { style: 3, motion: 2, speed: 50, step: 1.8, mid: 150, gap: 120, pic: 220, p1: [-620, 0], p2: [0, 0], p3: [620, 0] } },
    { id: "smile", name: "Smile", note: "Pictures glide along a soft curve", v: { style: 3, motion: 1, speed: 14, mid: 135, gap: 80, pic: 190 } },
    { id: "wall", name: "Photo wall", note: "A grid that builds in, picture by picture", v: { style: 2, cols: 4, gap: 28, motion: 0, pic: 200, stagger: 55 } },
    { id: "curved-wall", name: "Curved wall", note: "A bent grid that scrolls sideways", v: { style: 2, cols: 5, gap: 24, bend: 70, motion: 1, speed: 10, pic: 180 } },
    { id: "ticker", name: "Ticker", note: "An endless straight line of pictures", v: { style: 3, motion: 1, speed: 20, mid: 100, gap: 40, pic: 180, p1: [-700, 0], p2: [0, 0], p3: [700, 0] } },
    { id: "ocean", name: "Ocean wall", note: "A grid floating on a slow wave", v: { style: 2, cols: 5, gap: 26, motion: 0, pic: 170, wave: 34, tilt: 18, stagger: 45 } },
    { id: "domino", name: "Domino", note: "A ring stepping round in a ripple", v: { style: 1, size: 360, tilt: 0, motion: 2, speed: 50, step: 2, cascade: 70, pic: 160 } },
    { id: "scatter", name: "Shuffled wall", note: "A grid with the pictures dealt at random", v: { style: 2, cols: 4, gap: 30, motion: 0, pic: 190, shuffle: 7, stagger: 60 } },
    { id: "spotlight", name: "Spotlight", note: "A wall that grows where the effector sits", v: { style: 2, cols: 5, gap: 22, motion: 0, pic: 160, eff: 1, effPt: [0, 0], effR: 360, effScale: 70, effPush: 60, effLift: 200 } },
    { id: "globe-wall", name: "Globe → wall", note: "Morph halfway between a sphere and a grid", v: { style: 0, style2: 2, morph: 50, size: 340, cols: 4, face: 0, motion: 1, speed: 8, pic: 160 } }
  ];
  function preset(id) {
    var o = defaults(), p = null, k, i;
    for (i = 0; i < PRESETS.length; i++) { if (PRESETS[i].id === id) { p = PRESETS[i]; } }
    if (!p) { return o; }
    for (k in p.v) { if (p.v.hasOwnProperty(k)) { o[k] = p.v[k] instanceof Array ? p.v[k].slice() : p.v[k]; } }
    return o;
  }

  // The expressions every picture gets. {CTRL} the rig null's name (as a JS string literal), {IDX} / {N} the
  // picture's place and the count, {LONG} its long side in pixels, {PATH} the custom path accessor or "null".
  // If the rig layer is gone (or renamed before the panel reconnects it) or the path layer is missing, the
  // pictures simply keep their own values (C === null / no path) instead of showing expression errors.
  // A setting the rig doesn't have (a carousel built by an older version) reads as its default.
  // The custom path is turned into the rig's own space, so it morphs with the other layouts.
  function fieldsExpr() {
    var out = [], i, d;
    for (i = 0; i < FIELDS.length; i++) {
      d = FIELDS[i][3] instanceof Array ? "[" + FIELDS[i][3].join(", ") + "]" : String(FIELDS[i][3]);
      out.push(FIELDS[i][0] + ": V(\"" + FIELDS[i][1] + "\", " + d + ")");
    }
    return out.join(", ");
  }
  var HEAD = "// MotionSaaS Carousel (driven by the rig layer's effects; edit it in the MotionSaaS panel)\n" +
    "var C = null;\ntry { C = thisComp.layer({CTRL}); } catch (eC) { C = null; }\n" +
    "function V(e, d) { try { return C.effect(e)(1).value; } catch (eV) { return d; } }\n" +
    "var P = null, r = null, useP = false;\n" +
    "var PATH = {PATH};\n" +
    "function PL(u) { var q = PATH(u), l = C.fromComp([q[0], q[1], 0]); return [l[0], l[1], 0]; }\n" +
    msCarousel.toString() + "\n" +
    "if (C) {\n" +
    "  P = {" + fieldsExpr() + "};\n" +
    "  if (PATH !== null) { try { PL(0); useP = true; } catch (eP) { useP = false; } }\n" +
    "  r = msCarousel(P, {IDX}, {N}, time, useP ? PL : null);\n" +
    "}\n";
  var EXPR = {
    position: HEAD + "!r ? value : C.toWorld([r[0], r[1], r[2]]);",
    scale: HEAD + "var k = r ? r[3] * V(\"Picture size\", 220) / {LONG} * 100 : 0;\n!r ? value : [k, k, k];",
    opacity: HEAD + "!r ? value : value * r[4];",
    rotateX: HEAD + "!r ? value : value + r[5];",
    rotateY: HEAD + "!r ? value : value + r[6];",
    rotateZ: HEAD + "!r ? value : value + r[7];"
  };

  var api = { layout: msCarousel, FIELDS: FIELDS, PRESETS: PRESETS, defaults: defaults, preset: preset, EXPR: EXPR,
    STYLES: ["Spherical", "Radial", "Grid", "Curved line", "Custom path"] };
  if (root && root.MSUI) { root.MSUI.carouselCore = api; }
  if (typeof module !== "undefined" && module.exports) { module.exports = api; }
})(typeof window !== "undefined" ? window : this);
