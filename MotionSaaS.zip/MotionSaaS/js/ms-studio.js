/*
 * MotionSaaS — Studio host and tool-panel switches.
 *
 * MSUI.studio  The MotionSaaS Studio (extension/studio/, built by scripts/build-studio.js) is the main view.
 *              It runs in an iframe and asks for After Effects work with postMessage:
 *                frame → here   { ms:"studio", id, cmd, payload }
 *                here → frame   { ms:"studio-reply", id, result }
 *              Each call runs MS.studio(cmd, payloadJSON) (jsx/studio.jsx) and answers with its JSON result.
 *              The frame's rail also has ⚙ / ⓘ (→ the footer's Settings / About buttons) and one button
 *              per tool panel turned on in Settings.
 * MSUI.panels  The classic tool panels (Comp Tools, Workflow, …) are off until turned on in Settings,
 *              either whole or section by section (a section = a top-level .section with a .section-title).
 *              Stored in localStorage "ms_panels": { panelId: true | ["section-key", …] }.
 *
 * Chromium 61 safe (AE 2020): ES5 only. Loads before js/ms-core.js (which asks MSUI.panels which tab to open).
 */
(function () {
  "use strict";

  var MSUI = window.MSUI;
  var $ = function (id) { return document.getElementById(id); };
  var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };
  var inCEP = !!window.__adobe_cep__;
  function load(k, d) { try { var v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } }
  function save(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }

  /* ------------------------------------------------------------ panels */

  var LIST = [
    { id: "create", name: "Comp Tools", icon: "✨" },
    { id: "workflow", name: "Workflow", icon: "⚡" },
    { id: "timer", name: "Timer & Goal", icon: "⏲" },
    { id: "translate", name: "Effects Saver", icon: "🪄" },
    { id: "text", name: "Text Presets", icon: "✍" },
    { id: "assetbox", name: "Assetbox", icon: "📦" },
    { id: "saas", name: "SaaS Kit", icon: "🖥" },
    { id: "oskit", name: "OS Kit", icon: "🧰" }
  ];
  var KEY = "ms_panels";
  var state = load(KEY, {});
  if (!state || typeof state !== "object" || state instanceof Array) state = {};
  // OS Kit is new: turned on once for everyone (it can be switched off in Settings like any other panel).
  if (!load("ms_oskit_offered", false)) { state.oskit = true; save(KEY, state); save("ms_oskit_offered", true); }

  function slug(s) { return String(s).toLowerCase().replace(/&/g, " and ").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "section"; }
  function nice(s) {
    s = String(s).replace(/[●•]/g, "").replace(/\s+/g, " ").trim();
    if (s && s === s.toUpperCase()) s = s.charAt(0) + s.slice(1).toLowerCase();   // "PLAYHEAD JUMPS" → "Playhead jumps"
    return s;
  }

  // Top-level titled sections of one panel. Tags each with data-ms-section so CSS can hide it.
  var sectionCache = {};
  function sections(id) {
    if (sectionCache[id]) return sectionCache[id];
    var tab = $(id + "-tab"), out = [], used = {};
    if (!tab) return out;
    $$(".section", tab).forEach(function (sec) {
      for (var p = sec.parentElement; p && p !== tab; p = p.parentElement) { if (p.classList.contains("section")) return; }
      var t = sec.querySelector(".section-title"), name = t ? nice(t.textContent) : "";
      if (!name) return;
      var key = slug(name), k = key, n = 2;
      while (used[k]) k = key + "-" + n++;
      used[k] = true;
      sec.setAttribute("data-ms-section", k);
      out.push({ key: k, name: name, el: sec });
    });
    return (sectionCache[id] = out);
  }

  // Built-in panels: always available, opened by a Studio category button instead of a rail button of their
  // own, and not listed under Settings → Tool panels. Carousel (js/ms-carousel.js) is the Studio's Carousel.
  var BUILTIN = [{ id: "carousel", name: "Carousel", icon: "", category: "Carousel" }];
  function builtin(id) { for (var i = 0; i < BUILTIN.length; i++) { if (BUILTIN[i].id === id) return BUILTIN[i]; } return null; }
  function find(id) { for (var i = 0; i < LIST.length; i++) { if (LIST[i].id === id) return LIST[i]; } return builtin(id); }
  function isOn(id) { if (builtin(id)) return true; var v = state[id]; return v === true || (v instanceof Array && v.length > 0); }
  function sectionOn(id, key) { var v = state[id]; return v === true || (v instanceof Array && v.indexOf(key) !== -1); }
  function enabled() { return LIST.filter(function (p) { return isOn(p.id); }); }

  function setPanel(id, on) {
    if (on) state[id] = true; else delete state[id];
    commit();
  }
  function setSection(id, key, on) {
    var all = sections(id).map(function (s) { return s.key; });
    var cur = state[id] === true ? all.slice() : (state[id] instanceof Array ? state[id].slice() : []);
    var i = cur.indexOf(key);
    if (on && i === -1) cur.push(key);
    if (!on && i !== -1) cur.splice(i, 1);
    if (!cur.length) delete state[id];
    else if (all.length && all.every(function (k) { return cur.indexOf(k) !== -1; })) state[id] = true;
    else state[id] = cur;
    commit();
  }
  function commit() { save(KEY, state); apply(); studio.sendPanels(); }

  // Show only what is turned on: tab buttons, and inside a partly-on panel only its chosen sections.
  function apply() {
    LIST.forEach(function (p) {
      var btn = document.querySelector('.tab-btn[data-tab="' + p.id + '"]');
      if (btn) btn.style.display = isOn(p.id) ? "" : "none";
      var partial = state[p.id] instanceof Array;
      sections(p.id).forEach(function (s) { s.el.classList.toggle("ms-section-off", partial && !sectionOn(p.id, s.key)); });
      var tab = $(p.id + "-tab");
      if (tab) tab.classList.toggle("ms-panel-partial", partial);
    });
    // The open tool panel was switched off: back to the Studio.
    if (studio.toolId && studio.toolId() && !isOn(studio.toolId())) studio.open();
  }

  // Settings → "Tool panels": one switch per panel; panels with sections get a "Sections" list to pick from.
  function renderSettings(box) {
    if (!box) return;
    box.innerHTML = "";
    var intro = document.createElement("div");
    intro.className = "ms-panels-intro";
    intro.textContent = "The Studio is always on. Turn on a whole tool panel, or only the sections you use — they appear in the Studio's left rail.";
    box.appendChild(intro);
    LIST.forEach(function (p) {
      var secs = sections(p.id), row = document.createElement("div"), v = state[p.id];
      row.className = "ms-panel-row";
      var head = document.createElement("div");
      head.className = "ms-panel-head";
      var label = document.createElement("span");
      label.className = "ms-panel-name";
      label.innerHTML = '<span class="ms-panel-icon"></span><span class="ms-panel-text"></span><small class="ms-panel-count"></small>';
      label.querySelector(".ms-panel-icon").textContent = p.icon;
      label.querySelector(".ms-panel-text").textContent = p.name;
      label.querySelector(".ms-panel-count").textContent = v instanceof Array ? v.length + " of " + secs.length : "";
      head.appendChild(label);
      if (secs.length) {
        var more = document.createElement("button");
        more.type = "button";
        more.className = "ms-panel-more";
        more.textContent = "Sections";
        more.setAttribute("aria-expanded", "false");
        more.addEventListener("click", function () {
          var open = row.classList.toggle("open");
          more.setAttribute("aria-expanded", open ? "true" : "false");
        });
        head.appendChild(more);
      }
      head.appendChild(makeSwitch(v === true, v instanceof Array, function (on) { setPanel(p.id, on); renderSettings(box); }));
      row.appendChild(head);
      if (secs.length) {
        var list = document.createElement("div");
        list.className = "ms-panel-sections";
        secs.forEach(function (s) {
          var item = document.createElement("label");
          item.className = "ms-panel-section";
          var cb = document.createElement("input");
          cb.type = "checkbox";
          cb.checked = sectionOn(p.id, s.key);
          cb.addEventListener("change", function () { setSection(p.id, s.key, cb.checked); renderSettings(box); });
          var txt = document.createElement("span");
          txt.textContent = s.name;
          item.appendChild(cb);
          item.appendChild(txt);
          list.appendChild(item);
        });
        row.appendChild(list);
        if (v instanceof Array) row.classList.add("open");
      }
      box.appendChild(row);
    });
    if (MSUI.gapFix) MSUI.gapFix();
  }

  function makeSwitch(on, mixed, onChange) {
    var wrap = document.createElement("label");
    wrap.className = "ms-switch" + (mixed ? " ms-switch-mixed" : "");
    var input = document.createElement("input");
    input.type = "checkbox";
    input.checked = on || mixed;
    // Partly on (some sections) shows as on; clicking it turns the whole panel on.
    if (mixed) input.addEventListener("click", function (e) { e.preventDefault(); onChange(true); });
    else input.addEventListener("change", function () { onChange(input.checked); });
    var slider = document.createElement("span");
    slider.className = "ms-slider";
    wrap.appendChild(input);
    wrap.appendChild(slider);
    return wrap;
  }

  MSUI.panels = {
    list: LIST, find: find, isOn: isOn, sectionOn: sectionOn, enabled: enabled, sections: sections,
    setPanel: setPanel, setSection: setSection, apply: apply, renderSettings: renderSettings,
    firstOn: function () { var e = enabled(); return e.length ? e[0].id : null; }
  };

  /* ------------------------------------------------------------ studio */

  var view = null, frame = null, ready = false, engineState = null;
  var VIEW_KEY = "ms_view";   // "studio" or a panel id

  // The rail as the user arranged it (Settings → Rail): order of its buttons, Studio categories hidden from
  // it, and the hero panel that opens whenever the extension starts. Ids: "cat:<Category>" for the Studio's
  // categories, "panel:<id>" for tool panels (shown / hidden by turning the panel on / off).
  var RAIL_KEY = "ms_rail", HERO_DEFAULT = "cat:Easing";
  function cleanRail(r) {
    r = r && typeof r === "object" ? r : {};
    var ids = function (a) {   // valid ids, each once
      var seen = {};
      return (a instanceof Array ? a : []).filter(function (x) {
        if (typeof x !== "string" || !/^(cat|panel):[\w-]{1,40}$/.test(x) || seen[x]) return false;
        seen[x] = 1;
        return true;
      }).slice(0, 60);
    };
    var hero = typeof r.hero === "string" && /^(cat|panel):[\w-]{1,40}$/.test(r.hero) ? r.hero : HERO_DEFAULT;
    var hidden = ids(r.hidden).filter(function (x) { return x !== hero && x.indexOf("cat:") === 0; });
    return { order: ids(r.order), hidden: hidden, hero: hero };
  }
  var rail = cleanRail(load(RAIL_KEY, null));
  function heroOk() {   // the hero must exist and be shown: a turned-off panel can't be the hero
    if (rail.hero.indexOf("panel:") === 0 && !isOn(rail.hero.slice(6))) rail.hero = HERO_DEFAULT;
  }

  function darkHost() {
    try {
      var c = JSON.parse(window.__adobe_cep__.getHostEnvironment()).appSkinInfo.panelBackgroundColor.color;
      return (c.red * 0.2126 + c.green * 0.7152 + c.blue * 0.0722) < 128;
    } catch (e) { return true; }
  }

  function post(msg) { if (frame && frame.contentWindow) frame.contentWindow.postMessage(msg, "*"); }

  // MS.studio answers with JSON. Anything else means the After Effects side is missing or broke.
  function parseResult(raw) {
    raw = String(raw || "");
    if (!inCEP && !window.MSMockAE) return { ok: false, errors: ["Open MotionSaaS inside After Effects to apply."] };
    if (raw.indexOf("ERR|") === 0) return { ok: false, errors: [raw.slice(4)] };
    if (!raw || /^EvalScript error/i.test(raw) || raw === "undefined") {
      if (engineState && !engineState.ok) return { ok: false, errors: ["Studio engine didn't load: " + engineState.error] };
      return { ok: false, errors: ["The MotionSaaS Studio script isn't loaded in After Effects. Close and reopen the panel; if it stays, use About → Copy diagnostics."] };
    }
    try {
      var r = JSON.parse(raw);
      if (r && typeof r === "object") return r;
    } catch (e) {}
    return { ok: false, errors: ["Unexpected answer from After Effects: " + raw.slice(0, 160)] };
  }

  // Make sure the engine runs, from this file alone: load host.jsx / studio.jsx by full path if they aren't
  // there, and report the exact reason when they can't load. (ms-core does this too, but a cached old
  // ms-core must not leave the Studio silently dead.)
  var lastEnsure = 0;
  function ensureEngine(force) {
    if (!inCEP || !MSUI.cs) return;
    if (!force && Date.now() - lastEnsure < 5000) return;
    lastEnsure = Date.now();
    var ext = "";
    try { ext = String(MSUI.cs.getSystemPath(SystemPath.EXTENSION)).replace(/\\/g, "/"); } catch (e) { return; }
    var hostPath = JSON.stringify(ext + "/jsx/host.jsx"), studioPath = JSON.stringify(ext + "/jsx/studio.jsx");
    var script = "(function(){try{" +
      "if(typeof MS==='undefined'||typeof MS.loadStudio!=='function'){$.evalFile(" + hostPath + ");}" +
      "if(typeof MS.studio==='function'){return 'OK|';}" +
      "if(MS.loadStudio(" + studioPath + ")){return 'OK|';}" +
      "return 'ERR|'+(MS.studioError||'studio.jsx did not load');" +
      "}catch(e){return 'ERR|'+(e.fileName?String(e.fileName).split('/').pop()+' ':'')+'line '+e.line+': '+e.message;}})()";
    MSUI.cs.evalScript(script, function (r) {
      r = String(r || "");
      var ok = r.indexOf("OK|") === 0;
      studio.engine(ok, ok ? "" : (r.replace(/^ERR\|/, "") || "After Effects didn't answer"));
      if (!ok && MSUI.logError) MSUI.logError("studio engine", r);
    });
  }
  // When the Studio's own status calls fail, show why (in the banner), and try loading the engine again.
  var linkDown = false;
  function linkResult(res) {
    if (res.ok) { if (linkDown) { linkDown = false; studio.engine(true, ""); } return; }
    linkDown = true;
    post({ ms: "studio-engine", ok: false, error: (res.errors && res.errors[0]) || "After Effects didn't answer" });
    ensureEngine(false);
  }

  // Run MS.studio in After Effects inside a try/catch, so a failure answers "ERR|<what> line N: <message>"
  // instead of After Effects' bare "EvalScript error." (which says nothing about why).
  function evalStudio(cmd, payload) {
    var LS = String.fromCharCode(0x2028), PS = String.fromCharCode(0x2029);
    var lit = function (s) { return JSON.stringify(s).split(LS).join("\\u2028").split(PS).join("\\u2029"); };
    var script = "(function(){" +
      "if(typeof MS==='undefined'){return 'ERR|host.jsx is not loaded in After Effects';}" +
      "if(typeof MS.studio!=='function'){return 'ERR|studio.jsx is not loaded: '+(MS.studioError||'unknown reason');}" +
      "try{var r=MS.studio(" + lit(cmd) + "," + lit(payload) + ");return (typeof r==='string')?r:'ERR|MS.studio returned '+(typeof r);}" +
      "catch(e){return 'ERR|'+" + lit(cmd) + "+' failed: '+(e.fileName?String(e.fileName).split('/').pop()+' ':'')+(e.line?'line '+e.line+': ':'')+e.message;}" +
      "})()";
    if (!inCEP) return Promise.resolve("OK|Preview: MS.studio");
    return new Promise(function (resolve) { MSUI.cs.evalScript(script, function (r) { resolve(String(r || "")); }); });
  }

  var LIGHT = { poll: 1, context: 1, fonts: 1, diagnose: 1 };
  function onCall(d) {
    var cmd = String(d.cmd || "");
    if (!/^[a-z0-9-]{1,40}$/.test(cmd)) { post({ ms: "studio-reply", id: d.id, result: { ok: false, errors: ["Unknown command"] } }); return; }
    var payload;
    // poll / context run every second and only read the selection: don't make ExtendScript parse ~170
    // control values each time.
    if (LIGHT[cmd]) payload = "{}";
    else { try { payload = JSON.stringify(d.payload && typeof d.payload === "object" ? d.payload : {}); } catch (e) { payload = "{}"; } }
    // window.MSMockAE: the dev-only fake After Effects (scripts/make-mock-ae.js), never present in the extension.
    var ask = window.MSMockAE
      ? new Promise(function (resolve) { try { resolve(String(window.MSMockAE.call(cmd, payload))); } catch (e) { resolve("ERR|" + e.message); } })
      : evalStudio(cmd, payload);
    ask.then(function (raw) {
      var res = parseResult(raw);
      if (cmd === "poll" || cmd === "context") linkResult(res);
      if (!res.ok && cmd !== "poll" && cmd !== "context" && MSUI.logError) MSUI.logError("studio " + cmd, (res.errors && res.errors[0]) || "failed");
      post({ ms: "studio-reply", id: d.id, result: res });
    }, function (err) {
      post({ ms: "studio-reply", id: d.id, result: { ok: false, errors: [String(err && err.message || err)] } });
    });
  }

  function clickFooter(id) { var b = $(id); if (b) b.click(); }

  /* ---------------------------------------------- Studio Settings / About */
  // The Studio draws its own Settings and About dialogs (studio/studio-tools.js); this side owns the data.
  function accentName() {
    var a = "blue";
    try { a = localStorage.getItem("ms_app_theme") || "blue"; } catch (e) {}
    return MSUI.theme && MSUI.theme.themes && !MSUI.theme.themes[a] ? "blue" : a;
  }
  function settingsData() {
    var name = "Editor";
    try { name = localStorage.getItem("ms_userName") || "Editor"; } catch (e) {}
    return {
      panels: LIST.map(function (p) {
        var v = state[p.id];
        return {
          id: p.id, name: p.name, icon: p.icon, state: v === true ? "all" : (v instanceof Array && v.length ? "some" : "off"),
          sections: sections(p.id).map(function (s) { return { key: s.key, name: s.name, on: sectionOn(p.id, s.key) }; })
        };
      }),
      accent: accentName(),
      accents: MSUI.theme && MSUI.theme.themes ? Object.keys(MSUI.theme.themes).map(function (k) { return { id: k, hex: MSUI.theme.themes[k].hex }; }) : [],
      name: name,
      rail: rail,
      version: (window.MS_CONFIG && window.MS_CONFIG.version) || "?",
      ae: MSUI.diag && MSUI.diag.hostVersion ? MSUI.diag.hostVersion() : "",
      engine: engineState
    };
  }
  function aboutAction(action) {
    var say = function (kind, text, isError, extra) { var m = { ms: "studio-about-msg", kind: kind, text: text, error: !!isError }; if (extra) m.report = extra; post(m); };
    if (action === "update") {
      if (!MSUI.updates || !MSUI.updates.check) { say("update", "Updates aren't available here.", true); return; }
      MSUI.updates.listener = function (text, isError) { say("update", text, isError); };
      MSUI.updates.check(true, "studio");
    } else if (action === "diagnostics") {
      say("diagnostics", MSUI.diag && MSUI.diag.text ? MSUI.diag.text() : "Diagnostics aren't available.", false);
    } else if (action === "selftest") {
      if (!MSUI.diag || !MSUI.diag.selfTestText) { say("selftest", "Self-test isn't available.", true); return; }
      say("selftest-start", "Testing… about 15 seconds. Don't touch After Effects meanwhile.");
      MSUI.diag.selfTestText().then(function (text) {
        var fails = (String(text).match(/^FAIL/gm) || []).length;
        say("selftest", fails ? fails + " problem" + (fails === 1 ? "" : "s") + " found" : "Everything passed ✓", fails > 0, text + "\n\n" + (MSUI.diag.text ? MSUI.diag.text() : ""));
      });
    }
  }

  // If the Studio page never says it's ready (a missing file, a script error on an old After Effects),
  // show what happened and a way out instead of an empty panel.
  var failBox = null;
  function watchdog() {
    setTimeout(function () {
      if (ready || !view) return;
      if (MSUI.logError) MSUI.logError("studio", "the Studio page did not start within 10 s");
      if (failBox) return;
      failBox = document.createElement("div");
      failBox.className = "ms-studio-fail";
      var msg = document.createElement("p");
      msg.textContent = "The MotionSaaS Studio didn't load. Reload it, or turn on the classic tool panels in Settings. If this keeps happening, use About → Copy diagnostics.";
      var again = document.createElement("button");
      again.type = "button";
      again.textContent = "Reload";
      again.addEventListener("click", function () { failBox.parentNode.removeChild(failBox); failBox = null; studio.reload(); watchdog(); });
      var settingsBtn = document.createElement("button");
      settingsBtn.type = "button";
      settingsBtn.textContent = "Settings";
      settingsBtn.addEventListener("click", function () { clickFooter("btnSettings"); });
      failBox.appendChild(msg);
      failBox.appendChild(again);
      failBox.appendChild(settingsBtn);
      view.appendChild(failBox);
    }, 10000);
  }

  window.addEventListener("message", function (ev) {
    if (!frame || ev.source !== frame.contentWindow) return;
    var d = ev.data;
    if (!d || typeof d !== "object") return;
    if (d.ms === "studio") onCall(d);
    else if (d.ms === "studio-ready") {
      ready = true;
      document.body.classList.remove("ms-tool-covered");   // a fresh Studio has no dialog open
      if (failBox && failBox.parentNode) { failBox.parentNode.removeChild(failBox); failBox = null; }
      studio.sendPanels();
      post({ ms: "studio-rail", rail: rail });
      if (toolId) post({ ms: "studio-tool", id: toolId });
      else if (pendingHero) post({ ms: "studio-hero", category: pendingHero });
      pendingHero = null;
      if (engineState) post({ ms: "studio-engine", ok: engineState.ok, error: engineState.error });
      post({ ms: "studio-theme", accent: accentName() });
    }
    else if (d.ms === "studio-settings-get") post({ ms: "studio-settings", data: settingsData() });
    else if (d.ms === "studio-settings-set") {
      if (d.what === "panel" && find(d.id)) setPanel(d.id, !!d.on);
      else if (d.what === "section" && find(d.id)) setSection(d.id, String(d.key), !!d.on);
      else if (d.what === "accent") {
        if (MSUI.theme && MSUI.theme.set) MSUI.theme.set(String(d.value));
        else { try { localStorage.setItem("ms_app_theme", String(d.value)); } catch (e) {} }
        post({ ms: "studio-theme", accent: accentName() });
      }
      else if (d.what === "name" && MSUI.settings && MSUI.settings.updateUsername) MSUI.settings.updateUsername(String(d.value || ""));
      else if (d.what === "rail") { rail = cleanRail(d.value); heroOk(); save(RAIL_KEY, rail); }
      if (d.what === "panel") heroOk();
      post({ ms: "studio-rail", rail: rail });
      post({ ms: "studio-settings", data: settingsData() });
    }
    else if (d.ms === "studio-about") aboutAction(String(d.action || ""));
    else if (d.ms === "studio-tool-rect" && d.rect) placeTool(d.rect);
    // A Studio dialog (Settings & About, colour picker, …) is open: the tool panel steps aside so it shows.
    else if (d.ms === "studio-overlay") document.body.classList.toggle("ms-tool-covered", !!d.open);
    // The Studio is light or dark: the tool panels (css/ms-extra.css) dress to match.
    else if (d.ms === "studio-mode") document.documentElement.classList.toggle("ms-skin-light", !d.dark);
    else if (d.ms === "studio-toast-up" && d.text && MSUI.toast) MSUI.toast(String(d.text));
    else if (d.ms === "studio-ui") {
      if (d.action === "settings") clickFooter("btnSettings");
      else if (d.action === "about") clickFooter("btnInfo");
      else if (d.action === "panel" && find(d.id) && isOn(d.id)) studio.openPanel(d.id);
      else if (d.action === "studio") studio.open();
      else if (d.action === "reload-engine" && MSUI.loadStudioEngine) MSUI.loadStudioEngine();
    }
  });

  function frameSrc() {
    var ver = "";
    try { ver = JSON.parse(window.__adobe_cep__.getHostEnvironment()).appVersion || ""; } catch (e) {}
    return "studio/index.html?embedded=1&cep=" + (inCEP || window.MSMockAE ? 1 : 0) + "&dark=" + (darkHost() ? 1 : 0) + "&ae=" + encodeURIComponent(ver);
  }

  function build() {
    if (view) return;
    view = document.createElement("div");
    view.id = "msStudioView";
    view.className = "ms-studio-view";
    frame = document.createElement("iframe");
    frame.id = "msStudioFrame";
    frame.title = "MotionSaaS Studio";
    frame.src = frameSrc();
    view.appendChild(frame);
    document.body.appendChild(view);
    watchdog();

    // "Studio" button at the start of the classic tab bar, to come back.
    var bar = document.querySelector(".tabs-container");
    if (bar) {
      var home = document.createElement("button");
      home.type = "button";
      home.className = "ms-home-btn";
      home.title = "Back to MotionSaaS Studio";
      home.setAttribute("aria-label", "Back to MotionSaaS Studio");
      home.textContent = "‹ Studio";
      home.addEventListener("click", function () { studio.open(); });
      bar.insertBefore(home, bar.firstChild);
    }
  }

  // Tool panels are part of the Studio: the Studio stays on screen (rail, toolbar) and the panel's content is
  // drawn exactly over the Studio's content column, whose position the Studio reports (studio-tool-rect).
  var toolId = null;
  function placeTool(r) {
    var s = document.documentElement.style;
    s.setProperty("--tp-x", Math.round(+r.x || 0) + "px");
    s.setProperty("--tp-y", Math.round(+r.y || 0) + "px");
    s.setProperty("--tp-w", Math.max(0, Math.round(+r.w || 0)) + "px");
    s.setProperty("--tp-h", Math.max(0, Math.round(+r.h || 0)) + "px");
    // The tool panel's own width class (css/ms-extra.css lays panels out by it): "xs" < 300 px, "sm" < 420 px.
    var w = +r.w || 0;
    document.body.setAttribute("data-tw", w < 300 ? "xs" : (w < 420 ? "sm" : "md"));
  }

  var studio = MSUI.studio = {
    isOpen: function () { return document.body.classList.contains("ms-studio-mode") && !toolId; },
    open: function () {
      build();
      toolId = null;
      document.body.classList.add("ms-studio-mode");
      document.body.classList.remove("ms-tool-mode");
      // The classic page under the Studio must not scroll (it would steal the mouse wheel and show a scrollbar).
      document.documentElement.style.overflow = "hidden";
      save(VIEW_KEY, "studio");
      post({ ms: "studio-tool", id: null });
      try { frame.focus(); } catch (e) {}
    },
    openPanel: function (id) {
      if (!isOn(id)) return;
      build();
      toolId = id;
      document.body.classList.add("ms-studio-mode", "ms-tool-mode");
      document.documentElement.style.overflow = "hidden";
      MSUI.showTab(id, true);   // rises in even when it was the last panel open
      var tab = $(id + "-tab");
      if (tab) tab.setAttribute("data-ms-title", find(id).name);   // the card's title row (css/ms-extra.css)
      save(VIEW_KEY, id);
      post({ ms: "studio-tool", id: id });
    },
    toolId: function () { return toolId; },
    sendPanels: function () {
      if (!ready) return;
      post({ ms: "studio-panels", panels: enabled().map(function (p) { return { id: p.id, name: p.name, icon: p.icon }; }) });
    },
    toast: function (text) { post({ ms: "studio-toast", text: String(text) }); },
    // Called by ms-core once it has tried to load jsx/studio.jsx: shown in the Studio as a banner.
    engine: function (ok, msg) { engineState = { ok: !!ok, error: msg || "" }; post({ ms: "studio-engine", ok: engineState.ok, error: engineState.error }); },
    reload: function () { if (frame) { ready = false; frame.src = frameSrc(); } }
  };
  MSUI.action("openStudio", studio.open);

  function boot() {
    build();
    // After Effects' interface brightness changed: the Studio follows it when set to Follow AE.
    try {
      if (inCEP && MSUI.cs && MSUI.cs.addEventListener) {
        MSUI.cs.addEventListener("com.adobe.csxs.events.ThemeColorChanged", function () { post({ ms: "studio-host-theme", dark: darkHost() }); });
      }
    } catch (e) {}
    setTimeout(function () { ensureEngine(true); }, 2500);   // after ms-core's own host load
    apply();
    // Start on the hero panel (Settings → Rail → ⌂): a tool panel, or a Studio category picked once the
    // Studio is ready. Default: Easing.
    heroOk();
    if (rail.hero.indexOf("panel:") === 0) studio.openPanel(rail.hero.slice(6));
    else { studio.open(); pendingHero = rail.hero.slice(4); if (ready) { post({ ms: "studio-hero", category: pendingHero }); pendingHero = null; } }
  }
  var pendingHero = null;
  // After ms-core's own boot (it runs initTabs on DOMContentLoaded too, and was registered first).
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", function () { setTimeout(boot, 0); });
  else setTimeout(boot, 0);
})();
