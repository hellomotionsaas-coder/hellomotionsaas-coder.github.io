// MotionSaaS panel script 07-changelog (moved out of index.html — loads in the same place, as a classic script).
(function() {
    var changelogOpen = false;
    var MS_CHANGELOG = [
        {
            version: (window.MS_CONFIG && MS_CONFIG.version) || '2.0.0',
            date: 'Oct 2026',
            changes: [
                '## 🚀 MotionSaaS 2.0',
                'Brand-new panel built for SaaS video editors: Comp Tools, Workflow, Timer, Effects Saver, Text Presets, Assetbox and the new SaaS Kit tab.',
                '32 easing curves with a live bezier editor, custom curves and read-back from keyframes.',
                'Magic Reveal, captions (SRT import, subtitle boxes, pair & stretch), counters and timers.',
                'SaaS Kit: gradient / mesh / glass backgrounds, launch-video templates, palettes and a layer picker.',
                'One-click updates from GitHub.'
            ]
        },
        {
            version: '1.0.0',
            date: 'Oct 2026',
            changes: ['First MotionSaaS release: layer picker, gradient & glass tools, text animations, palettes, templates.']
        }
    ];

    function renderChangelog(changelog) {
        var container = document.getElementById('changelogList');
        if (!container) return;
        if (!changelog || changelog.length === 0) {
            container.innerHTML =
                '<div style="text-align:center; font-size:10px; color:var(--text-secondary); padding:12px; font-style:italic;">No changelog entries yet</div>';
            return;
        }
        container.innerHTML = '';
        changelog.forEach(function(entry, idx) {
            var isLatest = idx === 0;
            var entryDiv = document.createElement('div');
            entryDiv.className = 'changelog-entry' + (isLatest ? ' latest' : '');
            
            var header = document.createElement('div');
            header.className = 'changelog-version-header';
            var versionPill = document.createElement('span');
            versionPill.className = 'changelog-version-pill';
            versionPill.innerText = 'v' + (entry.version || '?');
            header.appendChild(versionPill);
            
            if (isLatest) {
                var newBadge = document.createElement('span');
                newBadge.className = 'changelog-new-badge';
                newBadge.innerText = 'NEW';
                header.appendChild(newBadge);
            }
            if (entry.date) {
                var dateEl = document.createElement('span');
                dateEl.className = 'changelog-date';
                dateEl.innerText = entry.date;
                header.appendChild(dateEl);
            }
            entryDiv.appendChild(header);

            var changes = entry.changes || [];
            if (changes.length > 0) {
                var ul = document.createElement('ul');
                ul.className = 'changelog-items';
                changes.forEach(function(change) {
                    if (change.indexOf('## ') === 0) {
                        var div = document.createElement('div');
                        div.style.fontWeight = 'bold';
                        div.style.marginTop = '8px';
                        div.style.marginBottom = '2px';
                        div.style.color = 'var(--text-primary, #fff)';
                        div.style.fontSize = '11px';
                        div.innerText = change.replace('## ', '');
                        ul.appendChild(div);
                    } else {
                        var li = document.createElement('li');
                        li.textContent = change;
                        ul.appendChild(li);
                    }
                });
                entryDiv.appendChild(ul);
            }
            container.appendChild(entryDiv);
        });
    }

    window.MSUI.action("toggleChangelog", toggleChangelog);
    window.MSUI.changelog = { toggle: toggleChangelog };

    function toggleChangelog() {
        var content = document.getElementById('changelogContent');
        var arrow = document.getElementById('changelogArrow');
        changelogOpen = !changelogOpen;
        if (changelogOpen) {
            content.style.display = 'block';
            arrow.style.transform = 'rotate(180deg)';
            renderChangelog(MS_CHANGELOG);
        } else {
            content.style.display = 'none';
            arrow.style.transform = 'rotate(0deg)';
        }
    }
})();
