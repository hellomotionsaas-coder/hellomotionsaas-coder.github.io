// MotionSaaS panel script 05a: colour-picker popup sync, accent themes (setAppTheme) and the bezier-canvas
// accent recolouring (MSUI.theme). Loads as a classic script; order matters (see index.html).
(function () {
var MSUI = window.MSUI, theme = MSUI.theme = {};

(function () {
    // Wait for DOM + main.js to be ready
    function initCpSync() {
        var cpInput = document.getElementById("cpInput");
        var cpHexInp = document.getElementById("cpHexInput");
        var cpPreview = document.getElementById("cpPreview");
        var cpSwatch = document.getElementById("cpSwatchPreview");
        if (!cpInput || !cpHexInp) return;

        // Update preview + swatch from a hex string (without #)
        function applyHex(hex) {
            var full = "#" + hex.toUpperCase();
            cpPreview.style.background = full;
            if (cpSwatch) cpSwatch.style.background = full;
            cpInput.value = full;
            var h2 = cpHexInp.value.toUpperCase().replace(/[^0-9A-F]/g, "");
            if (h2 !== hex.toUpperCase()) cpHexInp.value = hex.toUpperCase();
            var lbl = document.getElementById("cpHexLabel"); if (lbl) lbl.innerText = full;
        }

        // Color picker -> hex input
        cpInput.addEventListener("input", function () {
            var hex = cpInput.value.replace("#", "").toUpperCase();
            cpHexInp.value = hex;
            var lbl = document.getElementById("cpHexLabel"); if (lbl) lbl.innerText = cpInput.value.toUpperCase();
            cpPreview.style.background = cpInput.value;
            if (cpSwatch) cpSwatch.style.background = cpInput.value;
        });

        // Hex input -> color picker
        cpHexInp.addEventListener("input", function () {
            var raw = cpHexInp.value.replace(/[^0-9a-fA-F]/g, "").slice(0, 6);
            cpHexInp.value = raw.toUpperCase();
            if (raw.length === 6) {
                var full = "#" + raw;
                var lbl = document.getElementById("cpHexLabel"); if (lbl) lbl.innerText = full;
                cpInput.value = full;
                cpPreview.style.background = full;
                if (cpSwatch) cpSwatch.style.background = full;
            }
        });

        cpHexInp.addEventListener("keydown", function (e) {
            if (e.key === "Enter") { if (typeof confirmColorPick === "function") confirmColorPick(); }
            if (e.key === "Escape") { if (typeof cancelColorPick === "function") cancelColorPick(); }
        });
    }

    // Preset swatch click
    theme.pickPreset = function (el) {
        var hex = el.getAttribute("data-hex").replace("#", "");
        var cpInput = document.getElementById("cpInput");
        var cpHexInp = document.getElementById("cpHexInput");
        var cpPreview = document.getElementById("cpPreview");
        var cpSwatch = document.getElementById("cpSwatchPreview");
        if (!cpInput) return;
        var full = "#" + hex.toUpperCase();
        cpInput.value = full;
        cpHexInp.value = hex.toUpperCase();
        var lbl = document.getElementById("cpHexLabel"); if (lbl) lbl.innerText = full;
        cpPreview.style.background = full;
        if (cpSwatch) cpSwatch.style.background = full;
    };

    // Use MutationObserver instead of patching global function to avoid conflicts
    var popupObs = new MutationObserver(function (mutations) {
        mutations.forEach(function (m) {
            if (m.attributeName === 'style') {
                var popup = document.getElementById('colorPickerPopup');
                if (popup && popup.style.display !== 'none') {
                    // Popup just opened, sync
                    setTimeout(function () {
                        var cpInput = document.getElementById('cpInput');
                        var cpHexInp = document.getElementById('cpHexInput');
                        var cpPreview = document.getElementById('cpPreview');
                        var cpSwatch = document.getElementById('cpSwatchPreview');
                        var lbl = document.getElementById('cpHexLabel');
                        if (cpInput && cpHexInp) {
                            if (lbl && lbl.innerText && lbl.innerText.startsWith('#')) {
                                cpInput.value = lbl.innerText;
                            }
                            cpHexInp.value = cpInput.value.replace('#', '').toUpperCase();
                            cpPreview.style.background = cpInput.value;
                            if (cpSwatch) cpSwatch.style.background = cpInput.value;
                        }
                    }, 20);
                }
            }
        });
    });
    var popupEl = document.getElementById('colorPickerPopup');
    if (popupEl) {
        popupObs.observe(popupEl, { attributes: true });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", initCpSync);
    } else {
        initCpSync();
    }
})();

// Global app theme settings
// Same colours and soft gradients as the Studio's themes (studio-src/studio-tools.js THEMES): highlight →
// colour → only 10% darker → a gentle lift.
const appThemes = {
    blue: { hex: '#1F6BFF', rgb: '31, 107, 255', grad: 'linear-gradient(135deg, #3ab7ff 0%, #1f6bff 45%, #1c60e6 82%, #2a8aff 100%)' },
    purple: { hex: '#9B55F5', rgb: '155, 85, 245', grad: 'linear-gradient(135deg, #cd84fe 0%, #9b55f5 45%, #8c4ddd 82%, #b068f9 100%)' },
    green: { hex: '#30C15A', rgb: '48, 193, 90', grad: 'linear-gradient(135deg, #73db83 0%, #30c15a 45%, #2bae51 82%, #4ccc6b 100%)' },
    orange: { hex: '#FF9500', rgb: '255, 149, 0', grad: 'linear-gradient(135deg, #ffba41 0%, #ff9500 45%, #e68600 82%, #ffa41b 100%)' },
    red: { hex: '#FF453A', rgb: '255, 69, 58', grad: 'linear-gradient(135deg, #ff8064 0%, #ff453a 45%, #e63e34 82%, #ff5d4b 100%)' },
    pink: { hex: '#FF4787', rgb: '255, 71, 135', grad: 'linear-gradient(135deg, #ff84b1 0%, #ff4787 45%, #e6407a 82%, #ff6098 100%)' },
    teal: { hex: '#14B8C6', rgb: '20, 184, 198', grad: 'linear-gradient(135deg, #54dae1 0%, #14b8c6 45%, #12a6b2 82%, #2ec6d1 100%)' },
    yellow: { hex: '#F7C600', rgb: '247, 198, 0', grad: 'linear-gradient(135deg, #fedf57 0%, #f7c600 45%, #deb200 82%, #fad024 100%)' },
    mint: { hex: '#1CCF96', rgb: '28, 207, 150', grad: 'linear-gradient(135deg, #63ebbf 0%, #1ccf96 45%, #19ba87 82%, #39dba7 100%)' },
    indigo: { hex: '#5F5FF0', rgb: '95, 95, 240', grad: 'linear-gradient(135deg, #889afd 0%, #5f5ff0 45%, #5656d8 82%, #7077f5 100%)' },
    coral: { hex: '#FF7A5C', rgb: '255, 122, 92', grad: 'linear-gradient(135deg, #ffa883 0%, #ff7a5c 45%, #e66e53 82%, #ff8d6c 100%)' },
    silver: { hex: '#B4B7C0', rgb: '180, 183, 192', grad: 'linear-gradient(135deg, #e4e6eb 0%, #b4b7c0 45%, #a2a5ad 82%, #c8cad2 100%)' }
};

theme.themes = appThemes;
theme.set = function (name) {
    const t = appThemes[name] || appThemes.blue;
    document.documentElement.style.setProperty('--accent-blue', t.hex);
    document.documentElement.style.setProperty('--accent-rgb', t.rgb);
    document.documentElement.style.setProperty('--accent-gradient', t.grad);
    document.documentElement.style.setProperty('--accent-glow', `rgba(${t.rgb}, 0.3)`);
    document.documentElement.style.setProperty('--text-accent', t.hex);

    // Central Theme Color Fix
    document.documentElement.style.setProperty('--theme-color', t.hex);

    // Sync the green accent for graphs as well
    document.documentElement.style.setProperty('--accent-green', t.hex);

    // Dynamic Background Gradient shift
    const bgTop = t.hex + '22';
    const bgGlow = t.hex + '05';
    document.documentElement.style.setProperty('--body-gradient', `radial-gradient(circle at top left, ${bgTop} 0%, transparent 40%), linear-gradient(180deg, ${bgGlow} 0%, #0d0d0f 30%, #080808 100%)`);

    // Every other fixed blue in the panel's CSS (light skin pages, cards, text, glows) follows the accent too
    // (js/ms-tint.js); blue keeps the original colours.
    if (MSUI.tint) MSUI.tint.apply(document, appThemes[name] && name !== 'blue' ? t.hex : null);

    // Fix Bezier Curve color (SVG)
    const curve = document.getElementById('bezierCurve');
    if (curve) curve.setAttribute('stroke', t.hex);

    // Fix Graph active dot
    const graphDot = document.querySelector('.current-dot');
    if (graphDot) graphDot.style.fill = t.hex;

    // Redraw the bezier editor in the new accent (ms-core loads later; not there yet at startup)
    if (MSUI.editor) MSUI.editor.init();

    localStorage.setItem('ms_app_theme', name);
};
MSUI.action("setAppTheme", theme.set);

// Monkey-patch Canvas Context for the obfuscated graph
(function () {
    const originalStrokeDescriptor = Object.getOwnPropertyDescriptor(CanvasRenderingContext2D.prototype, 'strokeStyle');
    const originalFillDescriptor = Object.getOwnPropertyDescriptor(CanvasRenderingContext2D.prototype, 'fillStyle');

    // All possible theme accent colors (including variations)
    const accentColors = [
        '#00aaff', '#007AFF', '#1d90ff', '#006aff', // Blue
        '#BF5AF2', '#a855f7', '#7c3aed',           // Purple
        '#30D158', '#34d399', '#059669',           // Green
        '#FF9F0A', '#fb923c', '#ea580c',           // Orange
        '#FF3B30', '#f87171', '#dc2626',           // Red
        '#FF2D55', '#ff6b8b',                      // Pink
        '#00C7BE', '#00f2fe',                      // Teal
        '#FFCC00', '#ffe066',                      // Yellow
        '#00E676', '#69f0ae',                      // Mint
        '#5856D6', '#7877e6',                      // Indigo
        '#FF6F61', '#ff9e80',                      // Coral
        '#E5E5EA', '#ffffff',                      // Silver
        'rgba(0, 122, 255', 'rgba(191, 90, 242', 'rgba(48, 209, 88', 'rgba(255, 159, 10', 'rgba(255, 59, 48', 'rgba(255, 45, 85', 'rgba(0, 199, 190', 'rgba(255, 204, 0', 'rgba(0, 230, 118', 'rgba(88, 86, 214', 'rgba(255, 111, 97', 'rgba(229, 229, 234'
    ];

    function getThemeColor(val) {
        const isAccent = accentColors.some(c =>
            typeof val === 'string' && val.toLowerCase().includes(c.toLowerCase())
        );
        if (isAccent) {
            return document.documentElement.style.getPropertyValue('--accent-blue').trim() || '#007AFF';
        }
        return val;
    }

    Object.defineProperty(CanvasRenderingContext2D.prototype, 'strokeStyle', {
        get: function () { return originalStrokeDescriptor.get.call(this); },
        set: function (val) {
            if (this.canvas && (this.canvas.id === 'bezierCanvas' || this.canvas.id === 'bezierCanvas-tab')) {
                return originalStrokeDescriptor.set.call(this, getThemeColor(val));
            }
            return originalStrokeDescriptor.set.call(this, val);
        }
    });

    Object.defineProperty(CanvasRenderingContext2D.prototype, 'fillStyle', {
        get: function () { return originalFillDescriptor.get.call(this); },
        set: function (val) {
            if (this.canvas && (this.canvas.id === 'bezierCanvas' || this.canvas.id === 'bezierCanvas-tab')) {
                return originalFillDescriptor.set.call(this, getThemeColor(val));
            }
            return originalFillDescriptor.set.call(this, val);
        }
    });
})();

// Sync theme on startup
(function () {
    const saved = localStorage.getItem('ms_app_theme');
    if (saved) theme.set(saved);
})();
})();
