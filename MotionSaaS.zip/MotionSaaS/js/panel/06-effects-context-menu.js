// MotionSaaS panel script 06-effects-context-menu: right-click menu on Effects Saver presets (MSUI.effects.showContextMenu).
(function () {
const MSUI = window.MSUI, fs = MSUI.node.fs;
let activeContextPreset = null;
const ctxMenu = document.getElementById('presetContextMenu');

MSUI.effects.showContextMenu = function (e, name, fullPath, folderPath) {
    activeContextPreset = { name: name, fullPath: fullPath, folderPath: folderPath };

    ctxMenu.style.display = 'block';
    let posX = e.clientX;
    let posY = e.clientY;

    if (posX + 120 > window.innerWidth) posX = window.innerWidth - 124;
    if (posY + 100 > window.innerHeight) posY = window.innerHeight - 104;

    ctxMenu.style.left = posX + 'px';
    ctxMenu.style.top = posY + 'px';
};

document.addEventListener('click', function (e) {
    if (e.target.closest('#presetContextMenu') == null) {
        ctxMenu.style.display = 'none';
    }
});

document.getElementById('ctxRename').onclick = async function () {
    ctxMenu.style.display = 'none';
    if (!activeContextPreset) return;
    const preset = activeContextPreset;
    const newName = await MSUI.ask("Rename preset", "New name for “" + preset.name + "”:", preset.name, "Rename");
    if (newName && newName !== preset.name) {
        const sanitizedNewName = newName.replace(/[\/\\:\*\?"<>\|]/g, "_");
        const oldPath = preset.fullPath;
        const newPath = preset.folderPath + "/" + sanitizedNewName + (/\.msfx$/i.test(oldPath) ? ".msfx" : ".ffx");
        activeContextPreset = preset;

        try {
            // a case-only rename ("glow" → "Glow") is the same file on Windows / macOS, not a clash
            if (newPath.toLowerCase() !== oldPath.toLowerCase() && fs.existsSync(newPath)) {
                MSUI.toast("A preset with this name already exists", true);
                return;
            }
            fs.renameSync(oldPath, newPath);

            // Rename associated GIF if exists in localStorage
            let gifs = MSUI.readJSON('ms_preset_gifs', {});
            if (gifs[activeContextPreset.name.toLowerCase()]) {
                gifs[sanitizedNewName.toLowerCase()] = gifs[activeContextPreset.name.toLowerCase()];
                delete gifs[activeContextPreset.name.toLowerCase()];
                localStorage.setItem('ms_preset_gifs', JSON.stringify(gifs));
            }

            MSUI.effects.load();
        } catch (err) {
            MSUI.toast("Couldn't rename: " + err.message, true);
        }
    }
};

document.getElementById('ctxLinkGif').onclick = function () {
    ctxMenu.style.display = 'none';
    if (!activeContextPreset) return;
    MSUI.effects.linkGif(activeContextPreset.name);
};

document.getElementById('ctxDelete').onclick = async function () {
    ctxMenu.style.display = 'none';
    if (!activeContextPreset) return;
    if (await MSUI.confirm("Delete preset?", "“" + activeContextPreset.name + "” is removed from your Effects Saver folder. This can't be undone.", "Delete")) {
        try {
            fs.unlinkSync(activeContextPreset.fullPath);
            let gifs = MSUI.readJSON('ms_preset_gifs', {});
            delete gifs[activeContextPreset.name.toLowerCase()];
            localStorage.setItem('ms_preset_gifs', JSON.stringify(gifs));
            MSUI.effects.load();
        } catch (err) {
            MSUI.toast("Couldn't delete the file: " + err.message, true);
        }
    }
};
})();
