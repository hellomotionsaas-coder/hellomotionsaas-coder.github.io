// MotionSaaS panel script 04-cs-interface: the one CSInterface the panel shares (MSUI.cs). Loads right after js/CSInterface.js.
window.MSUI.cs = new CSInterface();
