// MotionSaaS panel script 05e: workspace layout — display mode, edit-layout mode with drag & drop,
// per-section show/hide, layout import/export/reset, notification toggles, and the Clear Cache overlay.
// MSUI.layout. Classic script.
(function () {
    const MSUI = window.MSUI;
    // --- Workspace Customization System ---
    function toggleDisplayMode(mode) {
        if (mode === 'laptop') {
            document.body.classList.add('laptop-mode');
        } else {
            document.body.classList.remove('laptop-mode');
        }
        localStorage.setItem('ms_display_mode', mode);
    }

    const savedMode = localStorage.getItem('ms_display_mode') || 'pc';
    const displaySelect = document.getElementById('displayModeSelect');
    if (displaySelect) displaySelect.value = savedMode;
    if (savedMode === 'laptop') document.body.classList.add('laptop-mode');

    function toggleEditLayout(isEditing) {
        localStorage.setItem('ms_edit_layout', isEditing);
        const toggle = document.getElementById('editLayoutToggle');
        if (toggle) toggle.checked = isEditing;

        if (isEditing) {
            document.body.classList.add('customize-mode');
            enableDragAndDrop();
        } else {
            document.body.classList.remove('customize-mode');
            disableDragAndDrop();
        }
    }

    function toggleGreetingNotifications(isEnabled) {
        localStorage.setItem('ms_disable_greetings', isEnabled ? 'false' : 'true');
    }

    function toggleNotificationSound(isEnabled) {
        localStorage.setItem('ms_disable_sound', isEnabled ? 'false' : 'true');
    }

    async function resetEntireLayout() {
        let confirmReset = await MSUI.confirm("Reset the layout?", "Hidden buttons come back and every section returns to its original order.", "Reset");
        if (!confirmReset) return;

        const keysToRemove = [];
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key.startsWith('ms_order_') || key.startsWith('ms_hidden_') || key === 'ms_display_mode' || key === 'ms_edit_layout') {
                keysToRemove.push(key);
            }
        }
        keysToRemove.forEach(k => localStorage.removeItem(k));
        location.reload();
    }

    function exportWorkspaceLayout() {
        const layoutData = {};
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key.startsWith('ms_order_') || key.startsWith('ms_hidden_') || key === 'ms_display_mode') {
                layoutData[key] = localStorage.getItem(key);
            }
        }
        const json = JSON.stringify(layoutData, null, 2);
        // Inside After Effects there are no browser downloads: write the file next to the user's Documents
        // (Desktop when it exists) and say where.
        const node = MSUI.node || {}, docs = MSUI.systemDir ? MSUI.systemDir("documents") : "";
        if (node.fs && node.path && docs) {
            try {
                let dir = node.path.join(node.path.dirname(docs), "Desktop");
                if (!node.fs.existsSync(dir)) dir = docs;
                const file = node.path.join(dir, "MotionSaaS workspace.json");
                node.fs.writeFileSync(file, json);
                MSUI.toast("Workspace saved to " + file, false, 4500);
            } catch (e) {
                MSUI.toast("Couldn't save the workspace: " + e.message, true);
            }
            return;
        }
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(json);
        const downloadAnchorNode = document.createElement('a');
        downloadAnchorNode.setAttribute("href", dataStr);
        downloadAnchorNode.setAttribute("download", "motionsaas_workspace.json");
        document.body.appendChild(downloadAnchorNode);
        downloadAnchorNode.click();
        downloadAnchorNode.remove();
    }

    function importWorkspaceLayout(event) {
        const file = event.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = function (e) {
            try {
                const data = JSON.parse(e.target.result);
                let n = 0;
                if (!data || typeof data !== 'object') throw new Error('not a layout');
                for (const key in data) {
                    if ((key.startsWith('ms_order_') || key.startsWith('ms_hidden_') || key === 'ms_display_mode') && typeof data[key] === 'string') {
                        localStorage.setItem(key, data[key]);
                        n++;
                    }
                }
                if (!n) throw new Error('nothing to import');
                MSUI.toast('Workspace imported. Reloading…');
                setTimeout(function () { location.reload(); }, 900);
            } catch (err) {
                MSUI.toast("That file isn't a MotionSaaS workspace (export one from Settings first)", true);
            }
            event.target.value = '';
        };
        reader.readAsText(file);
    }

    function openSectionSettings(sectionId, sectionEl) {
        let modal = document.getElementById('sectionSettingsModal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'sectionSettingsModal';
            modal.className = 'activation-overlay';
            modal.style.cssText = 'display:none; z-index:900; align-items:center; justify-content:center;';
            modal.innerHTML = `
                <div class="activation-box glass-panel" style="width: 85%; max-height: 80%; display: flex; flex-direction: column; position:relative; padding: 20px !important;">
                    <button
                        style="position:absolute; top:15px; right:15px; background:rgba(255,255,255,0.1); border:none; border-radius:50%; color:white; width:26px; height:26px; display:flex; justify-content:center; align-items:center; cursor:pointer;">✕</button>
                    <h3 style="margin: 0 0 15px 0; font-size:16px; font-weight:800; color:white;">Customize Section</h3>
                    <div id="sectionSettingsList" style="flex:1; overflow-y:auto; display:flex; flex-direction:column; gap:10px; padding-right:10px;"></div>
                </div>
            `;
            modal.querySelector('button').addEventListener('click', function () {
                document.getElementById('sectionSettingsModal').style.display = 'none';
            });
            document.body.appendChild(modal);
        }

        const list = document.getElementById('sectionSettingsList');
        list.innerHTML = '';

        const interactiveEls = sectionEl.querySelectorAll('button:not(.section-settings-btn):not(.tab-btn), .icon-card, .preset-row, .tool-card');
        const hiddenItems = MSUI.readJSON('ms_hidden_' + sectionId, []);

        if (interactiveEls.length === 0) {
            list.innerHTML = '<div style="color:rgba(255,255,255,0.4); font-size:11px; text-align:center;">No customizable items in this section.</div>';
        }

        interactiveEls.forEach(el => {
            if (!el.id) return;
            let label = "Tool / Item";
            if (el.innerText && el.innerText.trim()) label = el.innerText.trim().replace(/\\n/g, ' ').substring(0, 25);
            else if (el.dataset.tip) label = el.dataset.tip;
            else if (el.title) label = el.title;
            else if (el.querySelector('.icon-name')) label = el.querySelector('.icon-name').innerText;

            const isVisible = !hiddenItems.includes(el.id);

            const tmp = document.createElement('div');
            tmp.innerHTML = `
                <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.03); padding:10px 14px; border-radius:10px; border:1px solid rgba(255,255,255,0.05);">
                    <span class="ms-item-label" style="font-size:12px; font-weight:600; color:rgba(255,255,255,0.9);"></span>
                    <label class="ms-switch">
                        <input type="checkbox" ${isVisible ? 'checked' : ''}>
                        <span class="ms-slider"></span>
                    </label>
                </div>
            `;
            const row = tmp.firstElementChild;
            row.querySelector('.ms-item-label').textContent = label;   // text (icon names come from file names), never HTML
            const itemId = el.id;
            row.querySelector('input').addEventListener('change', function () { toggleSectionItem(sectionId, itemId, this.checked); });
            list.appendChild(row);
        });

        modal.style.display = 'flex';
    }

    function updateSectionVisibility(sectionId) {
        const sectionEl = document.querySelector(`[data-section-id="${sectionId}"]`);
        if (!sectionEl) return;

        const interactiveEls = sectionEl.querySelectorAll('button:not(.section-settings-btn):not(.tab-btn), .icon-card, .preset-row, .tool-card');
        if (interactiveEls.length === 0) return; // if no customizable items, keep visible

        const hiddenItems = MSUI.readJSON('ms_hidden_' + sectionId, []);

        // Check if all interactive elements are hidden
        let allHidden = true;
        interactiveEls.forEach(el => {
            if (el.id && !hiddenItems.includes(el.id)) {
                allHidden = false;
            }
        });

        if (allHidden) {
            sectionEl.style.setProperty('display', 'none', 'important');
        } else {
            sectionEl.style.removeProperty('display');
        }
    }

    function toggleSectionItem(sectionId, elId, isVisible) {
        let hiddenItems = MSUI.readJSON('ms_hidden_' + sectionId, []);
        const el = document.getElementById(elId);

        if (isVisible) {
            hiddenItems = hiddenItems.filter(id => id !== elId);
            if (el) el.style.removeProperty('display');
        } else {
            if (!hiddenItems.includes(elId)) hiddenItems.push(elId);
            if (el) el.style.setProperty('display', 'none', 'important');
        }
        localStorage.setItem('ms_hidden_' + sectionId, JSON.stringify(hiddenItems));
        
        // Immediately update section visibility!
        updateSectionVisibility(sectionId);
    }

    function injectSectionSettings() {
        const sections = document.querySelectorAll('.section-title');
        const usedIds = {};
        sections.forEach((title, idx) => {
            // Key by the section's title (not its position) so adding a section later doesn't
            // shift every saved hidden/ordered item onto the wrong buttons.
            const slug = (title.textContent || '').replace(/[^a-z0-9]+/gi, '_').replace(/^_+|_+$/g, '').toLowerCase().slice(0, 40) || String(idx);
            let sectionId = 'section_' + slug;
            if (usedIds[sectionId]) sectionId += '_' + idx;
            usedIds[sectionId] = true;
            const sectionEl = title.closest('.section') || title.parentElement;
            sectionEl.setAttribute('data-section-id', sectionId);
            // Sections whose controls all belong together (Timer & Goal) can't have buttons hidden or moved.
            if (sectionEl.hasAttribute('data-ms-fixed')) return;

            if (!title.querySelector('.section-settings-btn')) {
                const btn = document.createElement('button');
                btn.className = 'section-settings-btn';
                btn.title = 'Customize Section';
                btn.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>';
                btn.onclick = (e) => {
                    e.stopPropagation();
                    openSectionSettings(sectionId, sectionEl);
                };
                title.appendChild(btn);
            }

            const interactiveEls = sectionEl.querySelectorAll('button:not(.section-settings-btn):not(.tab-btn), .icon-card, .preset-row, .tool-card');
            interactiveEls.forEach((el, i) => {
                if (!el.id) el.id = sectionId + '_item_' + i;

                const hiddenItems = MSUI.readJSON('ms_hidden_' + sectionId, []);
                if (hiddenItems.includes(el.id)) {
                    el.style.setProperty('display', 'none', 'important');
                }
            });

            const savedOrder = MSUI.readJSON('ms_order_' + sectionId, []);
            if (savedOrder.length > 0) {
                const containers = sectionEl.querySelectorAll('.icon-grid, .grid-3x3, .preset-list-container, .grid, .anchor-align-panel > div, .tool-grid');
                containers.forEach(container => {
                    const items = Array.from(container.children).filter(c => c.id);
                    items.sort((a, b) => {
                        let indexA = savedOrder.indexOf(a.id);
                        let indexB = savedOrder.indexOf(b.id);
                        if (indexA === -1) indexA = 999;
                        if (indexB === -1) indexB = 999;
                        return indexA - indexB;
                    });
                    items.forEach(item => container.appendChild(item));
                });
            }

            // Update section visibility on load!
            updateSectionVisibility(sectionId);
        });
    }

    let draggedItem = null;
    function handleDragStart(e) {
        draggedItem = this;
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/html', this.outerHTML);
        this.style.opacity = '0.4';
    }
    function handleDragOver(e) {
        if (e.preventDefault) e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        this.classList.add('drag-over');
        return false;
    }
    function handleDragEnter(e) { this.classList.add('drag-over'); }
    function handleDragLeave(e) { this.classList.remove('drag-over'); }
    function handleDrop(e) {
        if (e.stopPropagation) e.stopPropagation();
        if (draggedItem != this && this.parentNode === draggedItem.parentNode) {
            this.parentNode.insertBefore(draggedItem, this.nextSibling);
            const section = this.closest('.section');
            if (section) {
                const sectionId = section.getAttribute('data-section-id');
                const siblings = Array.from(this.parentNode.children);
                const order = siblings.map(s => s.id).filter(id => id);
                localStorage.setItem('ms_order_' + sectionId, JSON.stringify(order));
            }
        }
        return false;
    }
    function handleDragEnd(e) {
        this.style.opacity = '1';
        document.querySelectorAll('[draggable="true"]').forEach(el => el.classList.remove('drag-over'));
    }

    function enableDragAndDrop() {
        const draggables = document.querySelectorAll('.customize-mode .section button:not(.section-settings-btn):not(.tab-btn), .customize-mode .section .icon-card, .customize-mode .preset-row, .customize-mode .section .tool-card');
        draggables.forEach(el => {
            el.setAttribute('draggable', 'true');
            el.addEventListener('dragstart', handleDragStart);
            el.addEventListener('dragenter', handleDragEnter);
            el.addEventListener('dragover', handleDragOver);
            el.addEventListener('dragleave', handleDragLeave);
            el.addEventListener('drop', handleDrop);
            el.addEventListener('dragend', handleDragEnd);
        });
    }

    function disableDragAndDrop() {
        const draggables = document.querySelectorAll('[draggable="true"]');
        draggables.forEach(el => {
            el.setAttribute('draggable', 'false');
            el.removeEventListener('dragstart', handleDragStart);
            el.removeEventListener('dragenter', handleDragEnter);
            el.removeEventListener('dragover', handleDragOver);
            el.removeEventListener('dragleave', handleDragLeave);
            el.removeEventListener('drop', handleDrop);
            el.removeEventListener('dragend', handleDragEnd);
        });
    }

    MSUI.layout = {
        setDisplayMode: toggleDisplayMode, setEditing: toggleEditLayout, setGreetings: toggleGreetingNotifications,
        setSound: toggleNotificationSound, reset: resetEntireLayout, exportLayout: exportWorkspaceLayout,
        importLayout: importWorkspaceLayout, openSectionSettings: openSectionSettings, toggleSectionItem: toggleSectionItem
    };
    MSUI.action("toggleDisplayMode", toggleDisplayMode, "value");
    MSUI.action("toggleEditLayout", toggleEditLayout, "checked");
    MSUI.action("toggleGreetingNotifications", toggleGreetingNotifications, "checked");
    MSUI.action("toggleNotificationSound", toggleNotificationSound, "checked");
    MSUI.action("resetEntireLayout", resetEntireLayout);
    MSUI.action("exportWorkspaceLayout", exportWorkspaceLayout);
    MSUI.action("importWorkspaceLayout", importWorkspaceLayout, "event");

    setTimeout(() => {
        injectSectionSettings();

        const savedEditMode = localStorage.getItem('ms_edit_layout') === 'true';
        const editToggle = document.getElementById('editLayoutToggle');
        if (editToggle) editToggle.checked = savedEditMode;
        toggleEditLayout(savedEditMode);

        const greetingsDisabled = localStorage.getItem('ms_disable_greetings') === 'true';
        const greetingToggle = document.getElementById('greetingToggle');
        if (greetingToggle) greetingToggle.checked = !greetingsDisabled;

        const soundDisabled = localStorage.getItem('ms_disable_sound') === 'true';
        const soundToggle = document.getElementById('soundToggle');
        if (soundToggle) soundToggle.checked = !soundDisabled;

        MSUI.effects.load();

    }, 900);

    // Override doPurgeCache for Full Screen Animation and Strip Old Listeners
    setTimeout(() => {
        let oldBtn = document.querySelector('.cache-bar');
        if (oldBtn) {
            let newBtn = oldBtn.cloneNode(true);
            newBtn.removeAttribute('data-action');   // its click is replaced below, not added to
            oldBtn.parentNode.replaceChild(newBtn, oldBtn);

            newBtn.onclick = function () {
                let txt = document.getElementById('cacheBtnText');
                if (txt) txt.innerText = 'Clearing...';
                newBtn.style.opacity = '0.6';

                MSUI.cs.evalScript('purgeCache()', () => {
                    // Create overlay if it doesn't exist
                    let overlay = document.getElementById('cacheSuccessOverlay');
                    if (!overlay) {
                        overlay = document.createElement('div');
                        overlay.id = 'cacheSuccessOverlay';
                        overlay.className = 'cache-success-overlay';
                        overlay.innerHTML = `
                            <div class="cache-success-card">
                                <div class="cache-success-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                                </div>
                                <div class="cache-success-title">Cache Cleared!</div>
                                <div class="cache-success-subtitle">AE is fresh & ready to go.</div>
                            </div>
                        `;
                        document.body.appendChild(overlay);
                    }

                    // Show Animation
                    requestAnimationFrame(() => {
                        overlay.classList.add('show');
                        try { if (typeof playPremiumDing === 'function') playPremiumDing(); } catch (e) { }
                    });

                    // Reset Button UI
                    if (txt) txt.innerText = 'Cleared! ✓';
                    newBtn.style.opacity = '1';
                    newBtn.style.backgroundColor = 'rgba(48,209,88,0.15)';
                    newBtn.style.borderColor = 'rgba(48,209,88,0.3)';
                    newBtn.style.color = 'var(--accent-green)';

                    // Hide Animation & reset button after delay
                    setTimeout(() => {
                        overlay.classList.remove('show');
                        if (txt) txt.innerText = 'Clear Cache';
                        newBtn.style.backgroundColor = '';
                        newBtn.style.borderColor = '';
                        newBtn.style.color = '';
                    }, 2500);
                });
            };
        }
    }, 1000); // Run after ms-core.js has initialized
})();
