// MotionSaaS panel script 03-workflow-subtabs (moved out of index.html — loads in the same place, as a classic script).
(function () {
document.querySelectorAll('.sub-tab-btn').forEach(btn => {
    btn.addEventListener('click', function () {
        const target = this.getAttribute('data-subtab');

        document.querySelectorAll('.sub-tab-btn').forEach(b => {
            b.classList.remove('active');
            b.style.background = 'transparent';
            b.style.color = 'var(--text-secondary)';
            b.style.boxShadow = 'none';
        });
        this.classList.add('active');
        this.style.background = 'var(--accent-gradient)';
        this.style.color = '#fff';
        this.style.boxShadow = '0 4px 12px rgba(var(--accent-rgb), 0.3)';

        document.querySelectorAll('.wf-sub-content').forEach(content => {
            content.style.display = 'none';
        });
        document.getElementById(target).style.display = 'block';
    });
});
})();
