// MotionSaaS panel script 05c: Text Presets tab — prebuilt presets + favourites, user .ffx presets and the
// interactive text animator (MSUI.textPresets). Classic script; MSUI.confirm lives in js/ms-core.js.
(function () {
    const MSUI = window.MSUI, fs = MSUI.node.fs, path = MSUI.node.path, tp = MSUI.textPresets = {};
    const prebuiltStyles = [
        { name: 'Color Fade Bounce', icon: '🎨' },
        { name: 'Classic Position Fade', icon: '🚀' },
        { name: 'Dynamic Letter Flicker', icon: '✨' },
        { name: 'Glitchy Tech Style', icon: '💻' },
        { name: 'Left Push Slide', icon: '⬅️' },
        { name: 'Modern Title Duo', icon: '🖋️' },
        { name: 'Playful Bounce', icon: '🏀' },
        { name: 'Professional Bounce', icon: '📊' },
        { name: 'Right Push Reveal', icon: '➡️' },
        { name: 'Sleek Character Move', icon: '🤺' },
        { name: 'Smooth Ramp Exit', icon: '📉' },
        { name: 'Social Media Slide', icon: '📱' },
        { name: 'Soft Slide In Blur', icon: '☁️' },
        { name: 'Strobe Flash Reveal', icon: '📸' },
        { name: 'Ultimate Bounce HQ', icon: '💎' },
        { name: 'Cinematic Word Blur', icon: '🎞️' },
        { name: 'Drop In Word', icon: '📥' },
        { name: 'Floating Rise', icon: '🎈' },
        { name: 'Glowy Bounce Pro', icon: '🌟' },
        { name: 'Minimalist Bold', icon: '⬛' },
        { name: 'Mystic Code Reveal', icon: '🔐' },
        { name: 'Pop Zoom Word', icon: '🔍' },
        { name: 'Quick Rise In', icon: '⬆️' },
        { name: 'Signature Elegance', icon: '✍️' },
        { name: 'Smooth Fade and Exit', icon: '🌬️' },
        { name: 'Smooth Ramp Intro', icon: '📈' },
        { name: 'Sparkle Flicker In', icon: '✨' },
        { name: 'Typewriter Classic', icon: '⌨️' },
        { name: 'Word Pop-up Fade', icon: '📝' },
        { name: 'Soft Ascent Blur', icon: '🌊' },
        { name: 'Protype', icon: '⚡' }
    ];

    function toggleFavorite(name, btn) {
        let favs = MSUI.readJSON('ms_text_favs', []);
        const isFav = favs.includes(name);

        if (isFav) {
            favs = favs.filter(f => f !== name);
        } else {
            favs.push(name);
        }

        localStorage.setItem('ms_text_favs', JSON.stringify(favs));
        initTextPresets(); // Re-render to update order and icons
    }

    function initTextPresets() {
        const container = document.getElementById('prebuilt-text-presets');
        if (!container) return;

        const favs = MSUI.readJSON('ms_text_favs', []);

        // Sort styles: Favorites first
        const sortedStyles = [...prebuiltStyles].sort((a, b) => {
            const aFav = favs.includes(a.name);
            const bFav = favs.includes(b.name);
            if (aFav && !bFav) return -1;
            if (!aFav && bFav) return 1;
            return 0;
        });

        container.innerHTML = '';
        sortedStyles.forEach(style => {
            const isFav = favs.includes(style.name);
            const row = document.createElement('div');
            row.className = 'prebuilt-preset-card' + (isFav ? ' is-fav' : '');

            row.innerHTML = `
                <div class="ppc-row">
                    <div class="prebuilt-icon">${style.icon}</div>
                    <span class="prebuilt-name">${style.name}</span>
                    <div class="prebuilt-fav-heart">${isFav ? '❤️' : '🤍'}</div>
                </div>
            `;
            row.querySelector('.prebuilt-fav-heart').addEventListener('click', function (event) {
                event.stopPropagation();   // don't also apply the preset (row.onclick)
                toggleFavorite(style.name, this);
            });

            row.onmouseenter = () => {
                const img = document.getElementById('topTapPreviewImg');
                const empty = document.getElementById('topTapEmpty');
                const name = document.getElementById('topTapName');
                if (img && empty && name) {
                    img.src = "./previews/" + style.name + ".gif";
                    img.style.display = 'block';
                    empty.style.display = 'none';
                    name.innerText = style.name;
                }
            };

            row.onclick = () => applyPresetToStart(style.name + '.ffx', false);
            container.appendChild(row);
        });
    }

    // JSX Helper for applying to start of selected layers
    function applyPresetToStart(fileName, isUserPreset) {
        const extPath = MSUI.systemDir ? MSUI.systemDir("extension") : "";
        const userPath = MSUI.storage.getUserPresetsPath();
        if (!path || (!extPath && !(isUserPreset && userPath))) { MSUI.toast("Open MotionSaaS in After Effects to apply presets", true); return; }

        let fullPath = "";
        if (isUserPreset && userPath) {
            fullPath = path.join(userPath, fileName);
        } else {
            fullPath = path.join(extPath, 'TEXT PRESET', fileName);
        }

        // Host applies it to one layer at a time at each layer's in point (AE's applyPreset hits
        // every selected layer, so a plain loop would stack the preset N times). 0 = keep its timing.
        MSUI.runCore('applyPresetWithDuration', fullPath, 0, 0);
    }

    // SCAN TEXT PRESET FOLDER (DYNAMIC)
    function loadCollectedPresets() {
        const grid = document.getElementById('text-preset-container');
        if (!grid || !fs || !path) return;
        grid.innerHTML = '';

        try {
            const userPath = MSUI.storage.getUserPresetsPath();
            if (userPath && fs.existsSync(userPath)) {
                const files = fs.readdirSync(userPath);
                const ffxFiles = files.filter(f => f.toLowerCase().endsWith('.ffx'));

                ffxFiles.forEach(file => {
                    const displayName = file.replace('.ffx', '');
                    const row = document.createElement('div');
                    row.style.cssText = `
                        display: flex;
                        align-items: center;
                        justify-content: space-between;
                        padding: 8px 12px;
                        background: rgba(255,255,255,0.03);
                        border: 1px solid rgba(255,255,255,0.05);
                        border-radius: 12px;
                        cursor: pointer;
                        transition: background-color 0.2s, border-color 0.2s, color 0.2s, box-shadow 0.2s, transform 0.2s, opacity 0.2s, filter 0.2s;
                    `;

                    row.onmouseover = () => {
                        row.style.background = 'rgba(255,255,255,0.07)';
                        row.style.borderColor = 'var(--accent-gradient)';
                    };
                    row.onmouseout = () => {
                        row.style.background = 'rgba(255,255,255,0.03)';
                        row.style.borderColor = 'rgba(255,255,255,0.05)';
                    };

                    row.innerHTML = `
                        <div style="display:flex; align-items:center; gap:12px;">
                            <div style="background:rgba(0,0,0,0.3); width:32px; height:32px; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:16px;">
                                📄
                            </div>
                            <div class="ms-user-preset-name" style="font-size:11px; font-weight:700; color:rgba(255,255,255,0.85);"></div>
                        </div>
                        <button
                            style="background:transparent; border:none; color:rgba(255,255,255,0.2); font-size:14px; cursor:pointer; transition: background-color 0.2s, border-color 0.2s, color 0.2s, box-shadow 0.2s, transform 0.2s, opacity 0.2s, filter 0.2s;">✕</button>
                    `;
                    // The file name goes in as text, never as HTML.
                    row.querySelector('.ms-user-preset-name').textContent = displayName;
                    const delBtn = row.querySelector('button');
                    delBtn.addEventListener('click', function (event) {
                        event.stopPropagation();   // don't also apply the preset (row.onclick)
                        deletePreset(file);
                    });
                    delBtn.addEventListener('mouseover', function () { this.style.color = '#ff3b30'; });
                    delBtn.addEventListener('mouseout', function () { this.style.color = 'rgba(255,255,255,0.2)'; });

                    row.onclick = () => applyPresetToStart(file, true);
                    grid.appendChild(row);
                });
            }
        } catch (e) { console.error("Error loading user presets:", e); }
    }

    // --- INTERACTIVE TEXT ANIMATOR MODULE ---
    const textAnimationsList = [
        { id: 'Color Fade Bounce', name: 'Color Fade Bounce', icon: '🎨', desc: 'Beautiful color fade intro with bouncy scale dynamics.' },
        { id: 'Classic Position Fade', name: 'Classic Position Fade', icon: '🚀', desc: 'Classic position slide-up reveal with smooth opacity fade.' },
        { id: 'Dynamic Letter Flicker', name: 'Dynamic Letter Flicker', icon: '✨', desc: 'Flickery, dynamic letter-by-letter reveal style.' },
        { id: 'Glitchy Tech Style', name: 'Glitchy Tech Style', icon: '💻', desc: 'Matrix/Glitch style tech text intro animation.' },
        { id: 'Left Push Slide', name: 'Left Push Slide', icon: '⬅️', desc: 'Text slides in rapidly from the left margin.' },
        { id: 'Modern Title Duo', name: 'Modern Title Duo', icon: '🖋️', desc: 'Two-tier title reveal with sleek timing.' },
        { id: 'Playful Bounce', name: 'Playful Bounce', icon: '🏀', desc: 'Playful letter bounce intro.' },
        { id: 'Professional Bounce', name: 'Professional Bounce', icon: '📊', desc: 'Clean, professional bounce style for business titles.' },
        { id: 'Right Push Reveal', name: 'Right Push Reveal', icon: '➡️', desc: 'Text slides in rapidly from the right margin.' },
        { id: 'Sleek Character Move', name: 'Sleek Character Move', icon: '🤺', desc: 'Sleek letter slide-in with scale easing.' },
        { id: 'Smooth Ramp Exit', name: 'Smooth Ramp Exit', icon: '📉', desc: 'Smooth, clean ramp-down text exit animation.' },
        { id: 'Social Media Slide', name: 'Social Media Slide', icon: '📱', desc: 'Modern slide reveal optimized for social media captions.' },
        { id: 'Soft Slide In Blur', name: 'Soft Slide In Blur', icon: '☁️', desc: 'Dreamy slide-in with soft Gaussian blur.' },
        { id: 'Strobe Flash Reveal', name: 'Strobe Flash Reveal', icon: '📸', desc: 'Stroboscopic flash reveal animation.' },
        { id: 'Ultimate Bounce HQ', name: 'Ultimate Bounce HQ', icon: '💎', desc: 'High-end bouncy text reveal with maximum precision.' },
        { id: 'Cinematic Word Blur', name: 'Cinematic Word Blur', icon: '🎞️', desc: 'Cinematic word-by-word reveal with directional blur.' },
        { id: 'Drop In Word', name: 'Drop In Word', icon: '📥', desc: 'Words drop in from above with springy bounce.' },
        { id: 'Floating Rise', name: 'Floating Rise', icon: '🎈', desc: 'Graceful rising text with floating wave physics.' },
        { id: 'Glowy Bounce Pro', name: 'Glowy Bounce Pro', icon: '🌟', desc: 'Glowy, warm color bounce intro.' },
        { id: 'Minimalist Bold', name: 'Minimalist Bold', icon: '⬛', desc: 'Clean, bold scale-up reveal.' },
        { id: 'Mystic Code Reveal', name: 'Mystic Code Reveal', icon: '🔐', desc: 'Cryptic/Matrix style decryption reveal.' },
        { id: 'Pop Zoom Word', name: 'Pop Zoom Word', icon: '🔍', desc: 'Words zoom in and pop out rapidly.' },
        { id: 'Quick Rise In', name: 'Quick Rise In', icon: '⬆️', desc: 'Snappy slide-up reveal with quick ease.' },
        { id: 'Signature Elegance', name: 'Signature Elegance', icon: '✍️', desc: 'Elegant tracking and signature reveal.' },
        { id: 'Smooth Fade and Exit', name: 'Smooth Fade and Exit', icon: '🌬️', desc: 'Smooth fade out text exit.' },
        { id: 'Smooth Ramp Intro', name: 'Smooth Ramp Intro', icon: '📈', desc: 'Smooth, ramp-up text reveal.' },
        { id: 'Sparkle Flicker In', name: 'Sparkle Flicker In', icon: '✨', desc: 'Sparkly neon style glow flicker reveal.' },
        { id: 'Typewriter Classic', name: 'Typewriter Classic', icon: '⌨️', desc: 'Classic typewriter character reveal.' },
        { id: 'Word Pop-up Fade', name: 'Word Pop-up Fade', icon: '📝', desc: 'Words pop up with soft opacity fades.' },
        { id: 'Soft Ascent Blur', name: 'Soft Ascent Blur', icon: '🌊', desc: 'Smooth rising text with directional blur.' },
        { id: 'Protype', name: 'Protype', icon: '⚡', desc: 'Custom motion preset.' }
    ];

    const defaultPresetParams = [
        { name: 'Duration', key: 'duration', min: 0.2, max: 5.0, step: 0.1, def: 1.2, unit: 's' },
        { name: 'Start Offset', key: 'offset', min: 0.0, max: 3.0, step: 0.1, def: 0.0, unit: 's' }
    ];

    let activeTextAnimId = 'Color Fade Bounce';

    function selectTextAnimation(animId) {
        activeTextAnimId = animId;
        const anim = textAnimationsList.find(a => a.id === animId);
        if (!anim) return;
        
        // Update active list selection styling
        document.querySelectorAll('.text-anim-card').forEach(card => {
            card.classList.remove('active');
        });
        const activeCard = document.getElementById('anim-card-' + animId);
        if (activeCard) activeCard.classList.add('active');
        
        // Update title and desc
        document.getElementById('activeAnimName').innerText = anim.name;
        document.getElementById('activeAnimDesc').innerText = anim.desc;
        
        // Update favorite star button state
        const favs = MSUI.readJSON('ms_text_favs', []);
        const isFav = favs.includes(anim.name);
        const favBtn = document.getElementById('btnTextAnimFav');
        if (favBtn) {
            favBtn.innerText = isFav ? '★' : '☆';
            favBtn.style.color = isFav ? '#FFCC00' : 'rgba(255,255,255,0.25)';
            favBtn.title = isFav ? 'Remove from Favorites' : 'Add to Favorites';
        }
        
        // Load actual preview GIF
        const img = document.getElementById('activeAnimPreviewImg');
        if (img) {
            img.src = "./previews/" + anim.name + ".gif";
            img.style.display = 'block';
        }
        
        // Render sliders
        const paramsContainer = document.getElementById('activeAnimParams');
        paramsContainer.innerHTML = '';
        
        defaultPresetParams.forEach(param => {
            const group = document.createElement('div');
            group.className = 'param-slider-group';
            
            const valueDisplayId = 'slider-val-' + param.key;
            const isInt = param.step % 1 === 0;
            
            group.innerHTML = `
                <div class="param-slider-header">
                    <span>${param.name}</span>
                    <span class="param-slider-value"><span id="${valueDisplayId}">${param.def}</span>${param.unit}</span>
                </div>
                <input type="range" class="param-slider-input text-anim-param-input" 
                    data-key="${param.key}"
                    min="${param.min}" 
                    max="${param.max}" 
                    step="${param.step}" 
                    value="${param.def}">
            `;
            group.querySelector('input').addEventListener('input', function () {
                document.getElementById(valueDisplayId).innerText = parseFloat(this.value).toFixed(isInt ? 0 : 1);
            });
            paramsContainer.appendChild(group);
        });
    }

    function replayAnimPreview() {
        const img = document.getElementById('activeAnimPreviewImg');
        if (!img) return;
        const currentSrc = img.src;
        img.src = '';
        img.src = currentSrc;
    }

    function applyActiveTextAnimation() {
        const anim = textAnimationsList.find(a => a.id === activeTextAnimId);
        if (!anim) return;
        
        const params = {};
        const inputs = document.querySelectorAll('.text-anim-param-input');
        inputs.forEach(input => {
            const key = input.getAttribute('data-key');
            const val = parseFloat(input.value);
            params[key] = val;
        });
        
        const extPath = MSUI.systemDir ? MSUI.systemDir("extension") : "";
        if (!extPath || !path) { MSUI.toast("Open MotionSaaS in After Effects to apply presets", true); return; }
        // Plain path: runCore JSON-encodes its arguments (escaping the backslashes here doubled them).
        MSUI.runCore('applyPresetWithDuration', path.join(extPath, 'TEXT PRESET', anim.name + '.ffx'), params.duration, params.offset);
    }

    function toggleActiveTextAnimFavorite() {
        const anim = textAnimationsList.find(a => a.id === activeTextAnimId);
        if (!anim) return;
        
        let favs = MSUI.readJSON('ms_text_favs', []);
        const isFav = favs.includes(anim.name);
        
        if (isFav) {
            favs = favs.filter(f => f !== anim.name);
        } else {
            favs.push(anim.name);
        }
        
        localStorage.setItem('ms_text_favs', JSON.stringify(favs));
        
        // Re-render sidebar list
        initInteractiveTextAnimations();
    }

    function initInteractiveTextAnimations() {
        const sidebar = document.getElementById('textAnimSidebar');
        if (!sidebar) return;
        
        const favs = MSUI.readJSON('ms_text_favs', []);
        
        // Sort styles: Favorites first
        const sortedList = [...textAnimationsList].sort((a, b) => {
            const aFav = favs.includes(a.name);
            const bFav = favs.includes(b.name);
            if (aFav && !bFav) return -1;
            if (!aFav && bFav) return 1;
            return 0;
        });
        
        sidebar.innerHTML = '';
        sortedList.forEach(anim => {
            const isFav = favs.includes(anim.name);
            const card = document.createElement('div');
            card.className = 'text-anim-card' + (anim.id === activeTextAnimId ? ' active' : '');
            card.id = 'anim-card-' + anim.id;
            card.onclick = () => selectTextAnimation(anim.id);
            
            card.innerHTML = `
                <div style="display:flex; align-items:center; justify-content:space-between; width:100%;">
                    <div style="display:flex; align-items:center; gap:8px;">
                        <div class="text-anim-icon">${anim.icon}</div>
                        <div class="text-anim-name">${anim.name}</div>
                    </div>
                    ${isFav ? '<span style="color:#FFCC00; font-size:11px;">★</span>' : ''}
                </div>
            `;
            sidebar.appendChild(card);
        });
        
        // Select default
        selectTextAnimation(activeTextAnimId);
    }

    async function deletePreset(fileName) {
        if (!await MSUI.confirm("Delete “" + fileName + "”?", "The text preset is deleted from your presets folder. This can't be undone.", "Delete")) return;
        try {
            const userPath = MSUI.storage.getUserPresetsPath();
            const fullPath = path.join(userPath, fileName);
            if (fs.existsSync(fullPath)) {
                fs.unlinkSync(fullPath);
                loadCollectedPresets();
            }
        } catch (e) { console.error("Error deleting preset:", e); }
    }

    function handleFfxUpload(e) {
        const files = e.target.files;
        if (!files || files.length === 0 || !fs || !path) return;

        const userPath = MSUI.storage.getUserPresetsPath();
        if (!userPath) return;

        for (let i = 0; i < files.length; i++) {
            const src = files[i].path;
            if (!src) continue;
            const dest = path.join(userPath, files[i].name);
            try {
                fs.copyFileSync(src, dest);
            } catch (err) { console.error("Failed to copy .ffx:", err); }
        }
        setTimeout(() => { loadCollectedPresets(); }, 300);
        e.target.value = '';
    }

    tp.toggleFavorite = toggleFavorite;
    tp.init = initTextPresets;
    tp.applyToStart = applyPresetToStart;
    tp.loadCollected = loadCollectedPresets;
    tp.selectAnimation = selectTextAnimation;
    tp.replayPreview = replayAnimPreview;
    tp.applyActive = applyActiveTextAnimation;
    tp.toggleActiveFavorite = toggleActiveTextAnimFavorite;
    tp.initAnimations = initInteractiveTextAnimations;
    tp.deletePreset = deletePreset;
    tp.uploadFfx = handleFfxUpload;
    MSUI.action("applyActiveTextAnimation", applyActiveTextAnimation);
    MSUI.action("replayAnimPreview", replayAnimPreview);
    MSUI.action("toggleActiveTextAnimFavorite", toggleActiveTextAnimFavorite);

    /* Maintainer tool (About → Rebuild text previews): re-render every built-in preset's preview GIF in After
       Effects, on the word "MotionSaaS" (the old GIFs were made on another brand's text). Each preset is applied
       to a temporary comp (MS.textPreviewFrames), its frames are encoded here with gifenc on the same dark stage
       the panel shows them on, and the comp is removed again (MS.textPreviewDone) whatever happens. */
    function waitFile(p, ms) {
        return new Promise((resolve, reject) => {
            const t0 = Date.now();
            (function look() {
                try { if (fs.statSync(p).size > 0) { setTimeout(resolve, 80); return; } } catch (e) { }
                if (Date.now() - t0 > ms) { reject(new Error("After Effects didn't write " + path.basename(p))); return; }
                setTimeout(look, 120);
            })();
        });
    }
    function loadFrame(p, tries) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => resolve(img);
            img.onerror = () => tries > 0 ? setTimeout(() => loadFrame(p, tries - 1).then(resolve, reject), 300) : reject(new Error("Unreadable frame " + path.basename(p)));
            try { img.src = "data:image/png;base64," + fs.readFileSync(p).toString("base64"); } catch (e) { reject(e); }
        });
    }
    async function renderPreview(gifenc, ffx, outGif, tmp) {
        const r = String(await MSUI.host("MS.textPreviewFrames", [ffx, tmp, 36]) || "");
        if (r.indexOf("OK|") !== 0) throw new Error(r.replace(/^ERR\|/, ""));
        const info = JSON.parse(r.slice(3));
        try {
            const files = [];
            for (let i = 0; i < info.frames; i++) files.push(path.join(tmp, "frame_" + (i < 10 ? "0" : "") + i + ".png"));
            for (const f of files) await waitFile(f, 20000);
            const imgs = [];
            for (const f of files) imgs.push(await loadFrame(f, 3));
            const w = 480, h = Math.round(w * imgs[0].height / imgs[0].width), cv = document.createElement("canvas"), ctx = cv.getContext("2d"), gif = gifenc.GIFEncoder();
            cv.width = w; cv.height = h;
            imgs.forEach((img) => {
                ctx.fillStyle = "#15161b";
                ctx.fillRect(0, 0, w, h);
                ctx.drawImage(img, 0, 0, w, h);
                const px = ctx.getImageData(0, 0, w, h).data, palette = gifenc.quantize(px, 128);
                gif.writeFrame(gifenc.applyPalette(px, palette), w, h, { palette: palette, delay: Math.round(1000 / info.fps) });
            });
            gif.finish();
            fs.writeFileSync(outGif, Buffer.from(gif.bytes()));
            files.forEach((f) => { try { fs.unlinkSync(f); } catch (e) { } });
        } finally {
            await MSUI.host("MS.textPreviewDone", [info.comp]);
        }
    }
    let rebuilding = false;
    async function rebuildTextPreviews() {
        const ext = MSUI.systemDir ? MSUI.systemDir("extension") : "";
        if (!ext || !fs) { MSUI.toast("Rebuilding previews works inside After Effects", true); return; }
        if (rebuilding) { MSUI.toast("Already rebuilding the previews"); return; }
        if (!await MSUI.confirm("Rebuild the text previews?",
            "Each of the " + prebuiltStyles.length + " text presets is applied to “MotionSaaS” in a temporary comp and saved as its preview GIF. Takes a few minutes; leave After Effects alone until it's done.", "Rebuild")) return;
        let gifenc;
        try { gifenc = MSUI.node.require(path.join(ext, "js", "gifenc.js")); } catch (e) { MSUI.toast("The GIF encoder didn't load: " + e.message, true); return; }
        const outDir = path.join(ext, "previews"), tmp = path.join(MSUI.node.require("os").tmpdir(), "motionsaas-textprev-" + Date.now());
        try { fs.accessSync(outDir, fs.constants.W_OK); } catch (e) { MSUI.toast("The extension folder is read-only here — run this from a developer install", true); return; }
        try { fs.mkdirSync(tmp); } catch (e) { }
        rebuilding = true;
        let done = 0;
        const failed = [];
        try {
            for (const s of prebuiltStyles) {
                MSUI.toast("Rendering " + (done + failed.length + 1) + " of " + prebuiltStyles.length + " · " + s.name, false, 60000);
                try { await renderPreview(gifenc, path.join(ext, "TEXT PRESET", s.name + ".ffx"), path.join(outDir, s.name + ".gif"), tmp); done++; }
                catch (e) { failed.push(s.name + " (" + e.message + ")"); }
            }
        } finally {
            rebuilding = false;
            try { fs.rmdirSync(tmp); } catch (e) { }
        }
        MSUI.toast(failed.length ? "Rebuilt " + done + " previews; failed: " + failed.join(", ") : "Rebuilt all " + done + " text previews", !!failed.length, 6000);
        const img = document.getElementById("activeAnimPreviewImg");
        if (img) img.src = img.src.replace(/\?.*$/, "") + "?r=" + Date.now();
    }
    MSUI.action("rebuildTextPreviews", rebuildTextPreviews);

    setTimeout(() => {
        initInteractiveTextAnimations();
        initTextPresets();
        loadCollectedPresets();
    }, 800);
})();
