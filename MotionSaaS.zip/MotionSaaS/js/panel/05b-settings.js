// MotionSaaS panel script 05b: Settings modal (profile picture, tab visibility, system info — MSUI.settings)
// plus small Comp Tools helpers that call into ms-core (MSUI.compTools.setLCMode / applyOffset). Classic script.
// The profile-picture upload itself is in js/ms-core.js (MSUI.profile).
(function () {
var MSUI = window.MSUI;
var settings = MSUI.settings = MSUI.settings || {};
var compTools = MSUI.compTools = MSUI.compTools || {};

settings.removePfp = function () {
    localStorage.removeItem('ms_user_pfp');
    localStorage.removeItem('ms_user_dp');
    document.getElementById('settingsPfpPreview').src = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iI2ZmZmZmZiI+PHBhdGggZD0iTTEyIDJDMi4yNyAyIDIgMi4yNyAyIDEyYzAgOS43My4yNyAxMCAxMCAxMCA5LjczIDAgMTAtLjI3IDEwLTEwIDAtOS43My0uMjctMTAtMTAtMTBaIiBvcGFjaXR5PSIuMSIvPjxwYXRoIGQ9Ik0xMiAxMmMxLjkzIDAgMy41LTEuNTcgMy41LTMuNVMxMy45MyA1IDEyIDUgOC41IDYuNTcgOC41IDguNSAxMC4wNyAxMiAxMiAxMlpNMjAuNSA5QzE5LjY3IDkgMTkgOS42NyAxOSAxMC41UzE5LjY3IDEyIDIwLjUgMTIgMjIgMTEuMzMgMjIgMTAuNSAyMS4zMyA5IDIwLjUgOVpNMy41IDlDMy41IDkuNjcgNC4xNyAxMiA1IDEydjBINS41QzQuNjcgMTIgNCAxMS4zMyA0IDEwLjVTMi42NyA5IDMuNSA5Wk0xMiAxNmMtMy41IDAtOCAzLThgOXYwaDIwdi-xYy0xLTYtNC41LThgLThgLTh6IiBvcGFjaXR5PSIuNSIvPjwvc3ZnPg==';
    const img = document.getElementById('pa-dp-preview');
    if (img) img.src = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDAgMTAwIj48Y2lyY2xlIGN4PSI1MCIgY3k9IjUwIiByPSI1MCIgZmlsbD0iI2U4ZjBmZiIgLz48Y2lyY2xlIGN4PSI1MCIgY3k9IjM1IiByPSIxOCIgZmlsbD0iIzAwN2FmZiIgLz48cGF0aCBkPSJNIDEwIDkwIEEgNDAgNDAgMCAwIDEgOTAgOTAgWiIgZmlsbD0iIzAwN2FmZiIgLz48L3N2Zz4=';
};
MSUI.action("removePfp", settings.removePfp);

compTools.setLCMode = function (mode) {
    ['L', 'C', 'F', 'O', 'T'].forEach(m => {
        const btn = document.getElementById('toggle' + m);
        const view = document.getElementById('lcView-' + m);
        if (m === mode) {
            if (btn) btn.classList.add('lc-active');
            if (view) view.style.display = 'block';
        } else {
            if (btn) btn.classList.remove('lc-active');
            if (view) view.style.display = 'none';
        }
    });
};
MSUI.action("setLCMode", compTools.setLCMode);

compTools.applyOffset = function (mode) {
    const num = parseInt(document.getElementById('offsetNum').value) || 0;
    const step = parseInt(document.getElementById('offsetStep').value) || 0;
    MSUI.runCore('offsetLayers', mode, num, step);
};
MSUI.action("applyOffset", compTools.applyOffset);

// Settings: profile, system info and the tool-panel switches (the switches themselves are MSUI.panels in js/ms-studio.js).
(function () {
    settings.init = function () {
        const switchContainer = document.getElementById('settingsTabSwitches');

        const pfpPreview = document.getElementById('settingsPfpPreview');
        if (pfpPreview) {
            pfpPreview.src = localStorage.getItem('ms_user_pfp') || localStorage.getItem('ms_user_dp') || 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDAgMTAwIj48Y2lyY2xlIGN4PSI1MCIgY3k9IjUwIiByPSI1MCIgZmlsbD0iI2U4ZjBmZSIgLz48Y2lyY2xlIGN4PSI1MCIgY3k9IjM4IiByPSIxNyIgZmlsbD0iIzNiODJmNiIgLz48cGF0aCBkPSJNIDEwIDkwIEMgMjAgNjUgMzUgNjAgNTAgNjAgQyA2NSA2MCA4MCA2NSA5MCA5MCBMIDkwIDEwMCBMIDEwIDEwMCBaIiBmaWxsPSIjM2I4MmY2IiAvPjwvc3ZnPg==';
        }

        const usernameInput = document.getElementById('settingsUsernameInput');
        if (usernameInput) {
            usernameInput.value = localStorage.getItem('ms_userName') || 'Editor';
        }
        const sysOs = document.getElementById('sys_os');
        const sysPc = document.getElementById('sys_pc');

        if (sysOs) {
            const platform = window.navigator.platform;
            let osName = 'Windows';
            if (platform.toLowerCase().indexOf('mac') !== -1) osName = 'macOS';
            sysOs.innerText = osName;
        }

        if (sysPc) {
            try {
                MSUI.cs.evalScript("app.settings.getSetting('Main', 'MachineName')", (res) => {
                    if (res && res !== 'undefined' && res.indexOf('EvalScript') === -1 && res.indexOf('Error') === -1) sysPc.innerText = res;
                    else sysPc.innerText = "Active Workstation";
                });
            } catch (e) { sysPc.innerText = "Workstation"; }
        }

        if (switchContainer && MSUI.panels) MSUI.panels.renderSettings(switchContainer);
    };
})();
})();
