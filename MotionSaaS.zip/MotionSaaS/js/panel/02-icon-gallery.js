// MotionSaaS panel script 02-icon-gallery: built-in + user icons, favourites, upload, search (MSUI.icons).
(function () {
var MSUI = window.MSUI, fs = MSUI.node.fs, path = MSUI.node.path;

function loadIcons() {
    var grid = document.getElementById('icon-gallery-grid');
    if (!grid) return;
    grid.innerHTML = '';

    function createIconUI(iconPath, displayName, isUserIcon, isFav, iconName) {
        var container = document.createElement('div');
        container.className = 'icon-card';
        container.style.position = 'relative';

        var el = document.createElement('div');
        el.className = 'icon-card-preview';
        el.title = "Click to import icon into After Effects";

        el.onclick = function () {
            importIconToAE(iconPath);
            this.style.transform = 'scale(0.95)';
            setTimeout(() => this.style.transform = '', 100);
        };

        // Built as an element, never as HTML text: a file name with quotes or tags must stay a file name.
        var img = document.createElement('img');
        img.src = "file:///" + iconPath.replace(/\\/g, '/').split('/').map(function (s, i) { return i === 0 && /:$/.test(s) ? s : encodeURIComponent(s); }).join('/');
        el.appendChild(img);

        var label = document.createElement('div');
        label.className = 'icon-name';
        label.innerText = displayName;

        container.appendChild(el);
        container.appendChild(label);

        // Favorite button
        const favBtn = document.createElement('div');
        favBtn.innerHTML = isFav ? '★' : '☆';
        favBtn.style.cssText = 'position:absolute; top:4px; right:4px; color:' + (isFav ? '#ffd700' : 'rgba(255,255,255,0.4)') + '; font-size:14px; cursor:pointer; z-index:10; transition:background-color 0.2s, border-color 0.2s, color 0.2s, box-shadow 0.2s, transform 0.2s, opacity 0.2s, filter 0.2s; line-height:1; text-shadow:0 0 5px rgba(0,0,0,0.8);';
        favBtn.title = isFav ? "Remove from Favorites" : "Add to Favorites";

        if (!isFav) {
            favBtn.style.opacity = '0';
            container.addEventListener('mouseover', () => favBtn.style.opacity = '1');
            container.addEventListener('mouseout', () => favBtn.style.opacity = '0');
        }

        favBtn.onmouseover = () => { if (!isFav) favBtn.style.color = 'rgba(255,255,255,0.8)'; };
        favBtn.onmouseout = () => { if (!isFav) favBtn.style.color = 'rgba(255,255,255,0.4)'; };

        favBtn.onclick = (e) => {
            e.stopPropagation();
            let favs = MSUI.readJSON('ms_fav_icons', []);
            if (isFav) {
                favs = favs.filter(f => f !== iconName);
            } else {
                if (!favs.includes(iconName)) favs.push(iconName);
            }
            localStorage.setItem('ms_fav_icons', JSON.stringify(favs));
            loadIcons(); // Re-render gallery
        };
        container.appendChild(favBtn);

        if (isUserIcon) {
            const delBtn = document.createElement('div');
            delBtn.innerHTML = '✕';
            delBtn.style.cssText = 'position:absolute; top:-4px; left:-4px; background:#ff3b30; color:white; width:14px; height:14px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:8px; cursor:pointer; opacity:0; transition:opacity 0.2s; z-index:5; box-shadow:0 0 5px rgba(0,0,0,0.5);';
            container.addEventListener('mouseover', () => delBtn.style.opacity = '1');
            container.addEventListener('mouseout', () => delBtn.style.opacity = '0');
            delBtn.onclick = async (e) => {
                e.stopPropagation();
                let confirmDelete = await MSUI.confirm("Delete this icon?", "It's removed from your icon library.", "Delete");
                if (confirmDelete) {
                    try { fs.unlinkSync(iconPath); loadIcons(); } catch (err) { }
                }
            };
            container.appendChild(delBtn);

            // User icon indicator
            const badge = document.createElement('div');
            badge.style.cssText = 'position:absolute; bottom:4px; right:4px; width:4px; height:4px; border-radius:50%; background:var(--accent-gradient); z-index:5; box-shadow:0 0 4px var(--accent-gradient);';
            container.appendChild(badge);
        }

        grid.appendChild(container);
    }

    if (fs && path) {
        try {
            const extensionPath = MSUI.cs.getSystemPath(SystemPath.EXTENSION);
            const builtinPath = path.join(extensionPath, 'icons');
            const userPath = MSUI.storage.getUserIconsPath();

            let allIcons = [];
            const favIcons = MSUI.readJSON('ms_fav_icons', []);

            // 1. Load Builtin Icons
            if (fs.existsSync(builtinPath)) {
                fs.readdirSync(builtinPath).forEach(f => {
                    if (/\.(png|jpg|jpeg|svg|ai|psd)$/i.test(f)) {
                        allIcons.push({ path: path.join(builtinPath, f), name: f, isUser: false, mtime: 0, isFav: favIcons.includes(f) });
                    }
                });
            }

            // 2. Load User Icons (Private)
            if (userPath && fs.existsSync(userPath)) {
                fs.readdirSync(userPath).forEach(f => {
                    if (/\.(png|jpg|jpeg|svg|ai|psd)$/i.test(f)) {
                        const full = path.join(userPath, f);
                        const stats = fs.statSync(full);
                        allIcons.push({ path: full, name: f, isUser: true, mtime: stats.mtime, isFav: favIcons.includes(f) });
                    }
                });
            }

            // Sort: Favorites first, then User icons, then buildin icons
            allIcons.sort((a, b) => {
                if (a.isFav !== b.isFav) return a.isFav ? -1 : 1;
                if (a.isUser !== b.isUser) return a.isUser ? -1 : 1;
                return b.mtime - a.mtime;
            });

            allIcons.forEach(icon => {
                let displayName = icon.name.substring(0, icon.name.lastIndexOf('.')) || icon.name;
                createIconUI(icon.path, displayName, icon.isUser, icon.isFav, icon.name);
            });
        } catch (err) { console.error("Error reading icons:", err); }
    }
}

function handleIconUpload(e) {
    var files = e.target.files;
    if (!files || files.length === 0) return;

    if (fs && path) {
        const userPath = MSUI.storage.getUserIconsPath();
        if (!userPath) return;

        for (var i = 0; i < files.length; i++) {
            const src = files[i].path;
            if (!src) continue;
            const dest = path.join(userPath, files[i].name);
            try {
                fs.copyFileSync(src, dest);
                fs.utimesSync(dest, new Date(), new Date());
            } catch (err) { console.error("Failed to copy icon:", err); }
        }
        setTimeout(loadIcons, 200);
    }
    e.target.value = '';
}

function importIconToAE(filePath) {
    // Host call with JSON-quoted args: safe for names with quotes, reuses an already-imported
    // file instead of importing duplicates, and reports errors as a toast instead of an alert.
    MSUI.host('MS.importFile', [filePath]).then(MSUI.report);
}

function filterIconGallery(term) {
    const icons = document.querySelectorAll('#icon-gallery-grid .icon-card');
    icons.forEach(card => {
        const name = card.querySelector('.icon-name').innerText.toLowerCase();
        if (name.includes(term.toLowerCase())) {
            card.style.display = 'flex';
        } else {
            card.style.display = 'none';
        }
    });
}

MSUI.icons = { load: loadIcons, upload: handleIconUpload, importToAE: importIconToAE, filter: filterIconGallery };
MSUI.action("handleIconUpload", handleIconUpload, "event");
MSUI.action("filterIconGallery", filterIconGallery, "value");

setTimeout(loadIcons, 500);
})();
