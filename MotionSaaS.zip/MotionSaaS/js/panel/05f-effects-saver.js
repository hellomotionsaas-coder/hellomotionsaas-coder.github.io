// MotionSaaS panel script 05f: Effects Saver tab — custom effects folder, save-preset modal with linked
// GIFs, preset grid (MSUI.effects). Classic script; MSUI.confirm lives in js/ms-core.js.
(function () {
    const MSUI = window.MSUI, fs = MSUI.node.fs, path = MSUI.node.path;
    const effects = MSUI.effects = MSUI.effects || {};
    function normalizeLocalPath(p) {
        if (!p) return "";
        let normalized = p;
        if (normalized.startsWith('file:/')) {
            if (normalized.startsWith('file:///')) {
                normalized = normalized.substring(7);
            } else if (normalized.startsWith('file://')) {
                normalized = normalized.substring(7);
            } else {
                normalized = normalized.substring(5);
            }
            if (normalized.charAt(0) === '/' && normalized.charAt(2) === ':') {
                normalized = normalized.substring(1);
            }
            normalized = decodeURIComponent(normalized);
        }
        return normalized;
    }

    function selectCustomEffectsFolder() {
        if (!window.cep) return;
        const pathResult = window.cep.fs.showOpenDialog(false, true, "Select Custom Effects Folder", "", "");
        if (pathResult && pathResult.data && pathResult.data.length > 0) {
            const cleanPath = normalizeLocalPath(pathResult.data[0]);
            localStorage.setItem('ms_custom_effects_path', cleanPath);

            // Update settings input if it exists
            const input = document.getElementById('customEffectsPath');
            if (input) input.value = cleanPath;

            MSUI.effects.load();
        }
    }

    let currentModalLinkedGif = "";

    function saveNewCustomEffect() {
        let folderPath = normalizeLocalPath(localStorage.getItem('ms_custom_effects_path'));
        if (folderPath) {
            localStorage.setItem('ms_custom_effects_path', folderPath);
        }
        if (!folderPath) {
            MSUI.toast("Choose a folder for your presets first (the folder button next to the search)", true);
            return;
        }
        
        // Clear any previous state and open the modal
        document.getElementById('modalPresetNameInput').value = "";
        const urlInput = document.getElementById('modalGifUrlInput');
        if (urlInput) urlInput.value = "";
        modalClearGif();
        document.getElementById('save-preset-modal').style.display = 'flex';
    }

    function closeSavePresetModal() {
        document.getElementById('save-preset-modal').style.display = 'none';
    }

    function onModalGifUrlInput(value) {
        let trimmed = value.trim();
        if (!trimmed) {
            updateModalGifState("");
            return;
        }

        // If it is a Tenor link, we can extract the direct GIF
        if (trimmed.includes("tenor.com")) {
            let tenorUrl = "";
            if (trimmed.includes("tenor.com/view/")) {
                const urlMatch = trimmed.match(/https:\/\/tenor\.com\/view\/[^\s"'>]+/i);
                if (urlMatch) tenorUrl = urlMatch[0];
            }
            if (tenorUrl) {
                fetch(tenorUrl).then(res => res.text()).then(html => {
                    const mediaGifRegex = /https:\/\/media\.tenor\.com\/[A-Za-z0-9_\-\/]+\.gif/i;
                    let match = html.match(mediaGifRegex);
                    if (!match) match = html.match(/https:\/\/c\.tenor\.com\/[A-Za-z0-9_\-\/]+\.gif/i);
                    if (!match) match = html.match(/<meta\s+property=["']og:image["']\s+content=["']([^"']+)["']/i);
                    if (match) {
                        updateModalGifState(match[1] || match[0]);
                    } else {
                        updateModalGifState(trimmed);
                    }
                }).catch(err => {
                    updateModalGifState(trimmed);
                });
            } else {
                updateModalGifState(trimmed);
            }
        } else {
            updateModalGifState(trimmed);
        }
    }

    function modalBrowseLocalGif() {
        const nameInput = document.getElementById('modalPresetNameInput');
        const name = nameInput ? nameInput.value.trim() : "Preset";

        if (window.cep) {
            const result = window.cep.fs.showOpenDialog(false, false, "Select GIF/Image for " + name, "", ["gif", "png", "jpg", "jpeg"]);
            if (result && result.data && result.data.length > 0) {
                const filePath = result.data[0];
                const urlInput = document.getElementById('modalGifUrlInput');
                if (urlInput) urlInput.value = filePath;
                updateModalGifState(filePath);
            }
        }
    }

    function updateModalGifState(pathOrUrl) {
        currentModalLinkedGif = pathOrUrl;
        
        const statusDiv = document.getElementById('modalGifStatus');
        const thumbDiv = document.getElementById('modalGifThumb');
        const textSpan = document.getElementById('modalGifPathText');
        
        if (pathOrUrl) {
            if (statusDiv) statusDiv.style.display = 'flex';
            if (textSpan) {
                let displayName = pathOrUrl;
                if (pathOrUrl.length > 25) {
                    displayName = "..." + pathOrUrl.substring(pathOrUrl.length - 22);
                }
                textSpan.innerText = displayName;
            }
            if (thumbDiv) {
                let bgUrl = pathOrUrl;
                if (!pathOrUrl.startsWith('http://') && !pathOrUrl.startsWith('https://')) {
                    bgUrl = "file:///" + pathOrUrl.replace(/\\/g, '/');
                }
                thumbDiv.style.backgroundImage = `url('${bgUrl}')`;
            }
        } else {
            if (statusDiv) statusDiv.style.display = 'none';
            currentModalLinkedGif = "";
        }
    }

    function modalClearGif() {
        currentModalLinkedGif = "";
        const urlInput = document.getElementById('modalGifUrlInput');
        if (urlInput) urlInput.value = "";
        const statusDiv = document.getElementById('modalGifStatus');
        if (statusDiv) statusDiv.style.display = 'none';
    }

    function confirmSavePreset() {
        const nameInput = document.getElementById('modalPresetNameInput');
        let rawName = nameInput ? nameInput.value.trim() : "";
        if (!rawName) rawName = "My Preset " + Math.floor(Math.random() * 1000);
        const sanitizedName = rawName.replace(/[\/\\:\*\?"<>\|]/g, "_");

        let folderPath = normalizeLocalPath(localStorage.getItem('ms_custom_effects_path'));
        if (folderPath) {
            localStorage.setItem('ms_custom_effects_path', folderPath);
        }
        if (!folderPath) { MSUI.toast("Choose a folder for your presets first", true); return; }
        const targetFilePath = path.join(folderPath, sanitizedName + '.msfx').replace(/\\/g, '/');
        const encodedFilePath = encodeURI(targetFilePath);

        // The path goes over as a JSON argument (MSUI.host), never pasted into ExtendScript source.
        MSUI.host('saveSelectedEffectsPreset', [encodedFilePath]).then(function (result) {
            result = String(result || "");
            if (result === "SUCCESS") {
                // Link the GIF if one was specified
                if (currentModalLinkedGif) {
                    let gifs = MSUI.readJSON('ms_preset_gifs', {});
                    gifs[rawName.toLowerCase()] = currentModalLinkedGif;
                    localStorage.setItem('ms_preset_gifs', JSON.stringify(gifs));
                }

                // Close modal and reload
                closeSavePresetModal();
                
                // Show animated success toast overlay
                showSaveSuccessToast(rawName);

                MSUI.effects.load();
            } else {
                MSUI.toast(result.replace(/^ERR\|/, "") || "Couldn't save the preset", true);
            }
        });
    }

    function showSaveSuccessToast(presetName) {
        let overlay = document.getElementById('presetSuccessOverlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'presetSuccessOverlay';
            overlay.className = 'cache-success-overlay';
            overlay.innerHTML = `
                <div class="cache-success-card">
                    <div class="cache-success-icon" style="background: var(--accent-gradient);">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                    </div>
                    <div class="cache-success-title">Preset Saved!</div>
                    <div class="cache-success-subtitle" style="font-size:11px; opacity:0.8;"></div>
                </div>
            `;
            document.body.appendChild(overlay);
        }
        overlay.querySelector('.cache-success-subtitle').innerText = presetName + ".msfx";
        
        requestAnimationFrame(() => {
            overlay.classList.add('show');
            try { if (typeof playPremiumDing === 'function') playPremiumDing(); } catch (e) { }
        });
        
        setTimeout(() => {
            overlay.classList.remove('show');
        }, 2500);
    }


    async function linkPresetGif(targetName) {
        const nameInput = document.getElementById('msPresetNameInput');
        const name = targetName || (nameInput ? nameInput.value.trim() : "");
        if (!name) {
            MSUI.toast("Enter the preset's name first, then link a GIF or picture to it", true);
            return;
        }

        let rawVal = await MSUI.ask("Link a preview", "Paste a Tenor GIF or image link, or leave it empty to pick a file from your computer.", "", "Link");

        function saveGifLink(presetName, linkPath) {
            let gifs = MSUI.readJSON('ms_preset_gifs', {});
            gifs[presetName.toLowerCase()] = linkPath;
            localStorage.setItem('ms_preset_gifs', JSON.stringify(gifs));
            MSUI.effects.load();
        }

        if (rawVal !== null && rawVal.trim() !== "") {
            let tenorUrl = "";
            if (rawVal.includes("tenor.com/view/")) {
                const urlMatch = rawVal.match(/https:\/\/tenor\.com\/view\/[^\s"'>]+/i);
                if (urlMatch) tenorUrl = urlMatch[0];
            }
            if (tenorUrl) {
                fetch(tenorUrl).then(res => res.text()).then(html => {
                    const mediaGifRegex = /https:\/\/media\.tenor\.com\/[A-Za-z0-9_\-\/]+\.gif/i;
                    let match = html.match(mediaGifRegex);
                    if (!match) match = html.match(/https:\/\/c\.tenor\.com\/[A-Za-z0-9_\-\/]+\.gif/i);
                    if (!match) match = html.match(/<meta\s+property=["']og:image["']\s+content=["']([^"']+)["']/i);
                    if (match) {
                        saveGifLink(name, match[1] || match[0]);
                        MSUI.toast("Tenor GIF linked");
                    } else {
                        saveGifLink(name, rawVal);
                        MSUI.toast("Link saved (the GIF itself couldn't be found on that page)");
                    }
                }).catch(err => {
                    saveGifLink(name, rawVal);
                    MSUI.toast("Link saved (Tenor couldn't be reached to find the GIF)");
                });
            } else {
                saveGifLink(name, rawVal);
                MSUI.toast("Link saved");
            }
        } else if (rawVal !== null) {
            if (!window.cep) { MSUI.toast("Choosing a file works inside After Effects", true); return; }
            const result = window.cep.fs.showOpenDialog(false, false, "Select GIF/Image for " + name, "", ["gif", "png", "jpg", "jpeg"]);
            if (result && result.data && result.data.length > 0) {
                saveGifLink(name, result.data[0]);
                MSUI.toast("Linked to “" + name + "”");
            }
        }
    }

    function toggleEffectsGridLayout() {
        const currentCols = localStorage.getItem('ms_effects_layout_cols') || '3';
        const nextCols = currentCols === '3' ? '2' : '3';
        localStorage.setItem('ms_effects_layout_cols', nextCols);
        MSUI.effects.load();
    }

    function loadCustomEffects(searchQuery = '') {
        const grid = document.getElementById('custom-effects-grid');
        if (!grid) return;

        let folderPath = normalizeLocalPath(localStorage.getItem('ms_custom_effects_path'));
        if (folderPath) {
            localStorage.setItem('ms_custom_effects_path', folderPath);
        }

        // Update Settings Input
        const inputEl = document.getElementById('customEffectsPath');
        if (inputEl && folderPath) inputEl.value = folderPath;

        // Update Tab Folder Path Display
        const pathDisplay = document.getElementById('msEffectsFolderPathDisplay');
        if (pathDisplay) {
            pathDisplay.innerText = folderPath ? "Folder: " + folderPath : "Folder: Not selected";
            pathDisplay.title = folderPath || "";
        }

        if (!folderPath) return; // Leave default UI message

        if (!fs) return;

        if (!fs.existsSync(folderPath)) {
            grid.innerHTML = '<div style="grid-column: span 3; text-align:center; color:#ff453a; font-size:11px; padding:30px 10px;">Folder not found! Please select a valid folder using ⚙️.</div>';
            return;
        }

        grid.innerHTML = '';
        let ffxCount = 0;
        let matchedCount = 0;

        // Read grid layout columns (2 or 3)
        const cols = localStorage.getItem('ms_effects_layout_cols') || '3';
        grid.style.gridTemplateColumns = 'repeat(' + cols + ', 1fr)';

        const gifs = MSUI.readJSON('ms_preset_gifs', {});

        try {
            fs.readdirSync(folderPath).forEach(f => {
                if (/\.(ffx|msfx)$/i.test(f)) {
                    ffxCount++;
                    const name = f.replace(/\.(ffx|msfx)$/i, '');

                    // Apply Search Filter
                    if (searchQuery && name.toLowerCase().indexOf(searchQuery.toLowerCase()) === -1) {
                        return;
                    }

                    matchedCount++;
                    const fullPath = path.join(folderPath, f).replace(/\\/g, '/');

                    // Create Preset Card
                    const card = document.createElement('div');
                    card.className = 'preset-card-item';
                    card.title = "Apply " + name + " (Preset)";

                    // Image/GIF display or Initials
                    const linkedGif = gifs[name.toLowerCase()];
                    if (linkedGif) {
                        let imgUri = "";
                        if (linkedGif.startsWith('http://') || linkedGif.startsWith('https://')) {
                            imgUri = linkedGif;
                        } else if (fs.existsSync(linkedGif)) {
                            imgUri = "file:///" + linkedGif.replace(/\\/g, '/');
                        }

                        if (imgUri) {
                            const img = document.createElement('img');
                            img.src = imgUri;
                            img.style.cssText = 'width:100%; height:100%; object-fit:cover; pointer-events:none;';
                            card.appendChild(img);
                        } else {
                            const initials = (name.split(/[\\s_-]+/).map(w => w[0]).join('').substring(0, 2) || name.substring(0, 2)).toUpperCase();
                            const initialsEl = document.createElement('div');
                            initialsEl.className = 'preset-initials';
                            initialsEl.innerText = initials;
                            card.appendChild(initialsEl);
                        }
                    } else {
                        const initials = (name.split(/[\\s_-]+/).map(w => w[0]).join('').substring(0, 2) || name.substring(0, 2)).toUpperCase();
                        const initialsEl = document.createElement('div');
                        initialsEl.className = 'preset-initials';
                        initialsEl.innerText = initials;
                        card.appendChild(initialsEl);
                    }

                    // Bottom Label
                    const label = document.createElement('div');
                    label.className = 'preset-card-label';
                    label.innerText = name;
                    card.appendChild(label);

                    // Delete button (on hover)
                    const delBtn = document.createElement('div');
                    delBtn.innerHTML = '✕';
                    delBtn.style.cssText = 'position:absolute; top:4px; left:4px; background:#ff3b30; color:white; width:14px; height:14px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:8px; cursor:pointer; opacity:0; transition:opacity 0.2s; z-index:10; box-shadow:0 0 5px rgba(0,0,0,0.5);';

                    card.addEventListener('mouseover', () => delBtn.style.opacity = '1');
                    card.addEventListener('mouseout', () => delBtn.style.opacity = '0');

                    delBtn.onclick = async function (e) {
                        e.stopPropagation();
                        if (await MSUI.confirm("Delete “" + name + "”?", "The preset file is deleted from your presets folder. This can't be undone.", "Delete")) {
                            try {
                                fs.unlinkSync(path.join(folderPath, f));
                                delete gifs[name.toLowerCase()];
                                localStorage.setItem('ms_preset_gifs', JSON.stringify(gifs));
                                MSUI.effects.load();
                            } catch (err) {
                                MSUI.toast("Couldn't delete the file: " + (err && err.message || err), true);
                            }
                        }
                    };
                    card.appendChild(delBtn);

                    // Click handler to apply the preset
                    card.onclick = function () {
                        MSUI.runCore('applyEffectPreset', fullPath);
                        this.style.transform = 'scale(0.95)';
                        setTimeout(() => this.style.transform = '', 100);
                    };

                    // Context Menu handler
                    card.addEventListener('contextmenu', (e) => {
                        e.preventDefault();
                        MSUI.effects.showContextMenu(e, name, fullPath, folderPath);
                    });

                    grid.appendChild(card);
                }
            });
        } catch (e) {
            console.error("Error reading effects folder:", e);
        }

        // Update badge count
        const badge = document.getElementById('msEffectsCountBadge');
        if (badge) {
            badge.innerText = ffxCount + " FFX";
        }

        if (matchedCount === 0) {
            grid.innerHTML = '<div style="grid-column: span ' + cols + '; text-align:center; color:rgba(255,255,255,0.4); font-size:11px; padding:30px 10px; line-height:1.6;">No presets found matching search.</div>';
        }
    }

    effects.load = loadCustomEffects;
    effects.selectFolder = selectCustomEffectsFolder;
    effects.openSaveModal = saveNewCustomEffect;
    effects.closeSaveModal = closeSavePresetModal;
    effects.confirmSave = confirmSavePreset;
    effects.linkGif = linkPresetGif;
    effects.toggleGridLayout = toggleEffectsGridLayout;
    MSUI.action("loadCustomEffects", loadCustomEffects, "value");
    MSUI.action("selectCustomEffectsFolder", selectCustomEffectsFolder);
    MSUI.action("saveNewCustomEffect", saveNewCustomEffect);
    MSUI.action("closeSavePresetModal", closeSavePresetModal);
    MSUI.action("confirmSavePreset", confirmSavePreset);
    MSUI.action("linkPresetGif", linkPresetGif);
    MSUI.action("toggleEffectsGridLayout", toggleEffectsGridLayout);
    MSUI.action("onModalGifUrlInput", onModalGifUrlInput, "value");
    MSUI.action("modalBrowseLocalGif", modalBrowseLocalGif);
    MSUI.action("modalClearGif", modalClearGif);
})();
