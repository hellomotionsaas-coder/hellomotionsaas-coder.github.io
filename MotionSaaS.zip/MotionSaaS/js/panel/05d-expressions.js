// MotionSaaS panel script 05d: Custom Expressions (save/load/delete/apply — MSUI.expressions) and the Align
// buttons (MSUI.compTools.align). Classic script.
(function () {
    const MSUI = window.MSUI;
    // --- CUSTOM EXPRESSION LOGIC ---
    function saveCustomExpression() {
        const btnNameInp = document.getElementById('custExprBtnName');
        const codeInp = document.getElementById('custExprCode');
        const name = btnNameInp.value.trim();
        const code = codeInp.value.trim();

        if (!name || !code) {
            MSUI.toast("Enter both a button name and the expression code", true);
            return;
        }

        try {
            let customExprs = MSUI.readJSON('ms_custom_expressions', []);
            customExprs.push({ name: name, code: code });
            localStorage.setItem('ms_custom_expressions', JSON.stringify(customExprs));

            btnNameInp.value = '';
            codeInp.value = '';

            MSUI.toast("Added “" + name + "” to your expressions");
            loadCustomExpressions();
        } catch (e) { console.error("Save Error:", e); }
    }

    function loadCustomExpressions() {
        const container = document.getElementById('expr-btns');
        if (!container) return;

        // Clear existing custom buttons (marked with custom-expr-btn class)
        document.querySelectorAll('.custom-expr-btn').forEach(el => el.remove());

        try {
            const customExprs = MSUI.readJSON('ms_custom_expressions', []);
            customExprs.forEach((item, index) => {
                const btn = document.createElement('button');
                btn.className = 'custom-expr-btn';
                btn.innerText = '⚡ ' + item.name;
                btn.title = "Apply expression to selected properties\nRight-click to delete";

                btn.onclick = () => applyCustomExpr(item.code);
                btn.oncontextmenu = async (e) => {
                    e.preventDefault();
                    let confirmRemove = await MSUI.confirm("Remove expression?", "“" + item.name + "” is removed from your expressions.", "Remove");
                    if (confirmRemove) {
                        deleteCustomExpression(index);
                    }
                };

                container.appendChild(btn);
            });
        } catch (e) { console.error("Load Error:", e); }
    }

    function deleteCustomExpression(index) {
        try {
            let customExprs = MSUI.readJSON('ms_custom_expressions', []);
            customExprs.splice(index, 1);
            localStorage.setItem('ms_custom_expressions', JSON.stringify(customExprs));
            loadCustomExpressions();
        } catch (e) { console.error("Delete Error:", e); }
    }

    function doAlign(dir) {
        const modeVal = document.getElementById('alignMode').value; // 0 for Comp, 1 for Selection
        // LEFT, HCENTER, RIGHT, TOP, VCENTER, BOTTOM — handled in jsx/host.jsx (works with parents, rotation, 3D, keyed position)
        MSUI.runCore('alignLayers', String(dir).toLowerCase(), modeVal === '1');
    }

    // Applied by MS.applyExpression (jsx/host.jsx): the code travels as a JSON argument, never pasted into
    // ExtendScript source. Expressions already on the selected properties are only replaced after asking.
    function applyCustomExpr(code, replace) {
        MSUI.host("MS.applyExpression", [code, !!replace]).then(function (r) {
            r = String(r || "");
            if (r.indexOf("ASK|") === 0) {
                MSUI.confirm("Replace expressions?", r.slice(4) + " selected " + (r.slice(4) === "1" ? "property already has" : "properties already have") + " an expression. Replace " + (r.slice(4) === "1" ? "it" : "them") + "?", "Replace")
                    .then(function (ok) { if (ok) applyCustomExpr(code, true); });
            } else if (r.indexOf("OK|") === 0) {
                MSUI.toast("Expression applied to " + r.slice(3) + (r.slice(3) === "1" ? " property" : " properties"));
            } else {
                MSUI.toast(r.replace(/^ERR\|/, "") || "Couldn't apply the expression", true);
            }
        });
    }

    MSUI.expressions = { save: saveCustomExpression, load: loadCustomExpressions, remove: deleteCustomExpression, apply: applyCustomExpr };
    MSUI.compTools.align = doAlign;
    MSUI.action("saveCustomExpression", saveCustomExpression);
    MSUI.action("doAlign", doAlign);

    // Runs after 05c's 800 ms timer (same delay, registered later), as before the split.
    setTimeout(() => {
        loadCustomExpressions();
    }, 800);
})();
