// MotionSaaS panel script 00: the MSUI namespace. Loads before every other panel script.
// Panel code lives under window.MSUI (MSUI.theme, MSUI.effects, MSUI.assetbox, …) instead of one window.*
// global per function. scripts/check.js counts the globals left and fails if that number goes up.
//
// UI actions: index.html names what a control does (data-action="name", see "UI actions" in js/ms-core.js).
// Each script registers its own actions with MSUI.action("name", fn, pick):
//   pick omitted   fn(...data-args)
//   "value"        fn(el.value)       inputs / selects
//   "checked"      fn(el.checked)     switches
//   "event"        fn(event)          file inputs
// or sets MSUI.actions.name = function (el, event, ...args) {} when it needs the element itself.
(function () {
    "use strict";

    var MSUI = window.MSUI = window.MSUI || {};
    MSUI.actions = MSUI.actions || {};

    MSUI.action = function (name, fn, pick) {
        MSUI.actions[name] = function (el, ev) {
            var args = pick === "value" ? [el.value] : pick === "checked" ? [el.checked] : pick === "event" ? [ev] : Array.prototype.slice.call(arguments, 2);
            return fn.apply(null, args);
        };
    };

    // A saved setting as JSON, never throwing: a missing, broken or wrong-shaped value (an object where a list
    // belongs, "undefined", …) gives `fallback` instead of breaking the script that asked.
    MSUI.readJSON = function (key, fallback) {
        var v;
        try { v = localStorage.getItem(key); if (v === null) return fallback; v = JSON.parse(v); } catch (e) { return fallback; }
        if (fallback instanceof Array) return v instanceof Array ? v : fallback;
        if (fallback && typeof fallback === "object") return v && typeof v === "object" && !(v instanceof Array) ? v : fallback;
        return v;
    };

    // Node in the panel (CEP --enable-nodejs). null in a normal browser (preview).
    var req = (window.cep_node && window.cep_node.require) || (typeof require === "function" ? require : null);
    var fs = null, path = null;
    if (req) { try { fs = req("fs"); path = req("path"); } catch (e) { fs = path = null; } }
    if (!fs) console.warn("Node.js FS not available, using fallback.");
    MSUI.node = { require: req, fs: fs, path: path };

    // ~/Library/Application Support/MotionSaaS (macOS) or %APPDATA%\MotionSaaS (Windows): user icons and presets.
    function ensureDir(p) {
        if (!fs.existsSync(p)) { try { fs.mkdirSync(p); } catch (e) { } }
        return p;
    }
    MSUI.storage = {
        getUserDataPath: function () {
            if (!fs || !path) return null;
            var basePath = "";
            try {
                if (window.navigator.platform.toLowerCase().indexOf("win") !== -1) {
                    basePath = process.env.APPDATA || (process.env.USERPROFILE + "/AppData/Roaming");
                } else {
                    basePath = process.env.HOME + "/Library/Application Support";
                }
            } catch (e) { basePath = MSUI.cs.getSystemPath(SystemPath.MY_DOCUMENTS); }
            return ensureDir(path.join(basePath, "MotionSaaS"));
        },
        getUserPresetsPath: function () {
            var msPath = this.getUserDataPath();
            return msPath ? ensureDir(path.join(msPath, "Presets")) : null;
        },
        getUserIconsPath: function () {
            var msPath = this.getUserDataPath();
            return msPath ? ensureDir(path.join(msPath, "Icons")) : null;
        }
    };
})();
