// MotionSaaS panel script 01-greeting (moved out of index.html — loads in the same place, as a classic script).
(function () {
    var hideTimeout = null, hideTimeout2 = null;
    const notif = document.getElementById('greetingNotification');
    if (!notif) return;
    const defaultPfp = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDAgMTAwIj48Y2lyY2xlIGN4PSI1MCIgY3k9IjUwIiByPSI1MCIgZmlsbD0iI2U4ZjBmZSIgLz48Y2lyY2xlIGN4PSI1MCIgY3k9IjM4IiByPSIxNyIgZmlsbD0iIzNiODJmNiIgLz48cGF0aCBkPSJNIDEwIDkwIEMgMjAgNjUgMzUgNjAgNTAgNjAgQyA2NSA2MCA4MCA2NSA5MCA5MCBMIDkwIDEwMCBMIDEwIDEwMCBaIiBmaWxsPSIjM2I4MmY2IiAvPjwvc3ZnPg==';
    let currentPrefix = "";

    // One audio context for the whole session: Chromium allows only a handful, and a new one per greeting
    // (never closed) used them up — after that the ding went silent and kept audio resources busy.
    var audio = null;
    function playPremiumDing() {
        if (localStorage.getItem('ms_disable_sound') === 'true') return;
        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (!AudioContext) return;
            if (!audio) audio = new AudioContext();
            const ctx = audio;
            if (ctx.state === 'suspended' && ctx.resume) ctx.resume();
            const osc = ctx.createOscillator();
            const gainNode = ctx.createGain();
            osc.connect(gainNode);
            gainNode.connect(ctx.destination);
            osc.type = 'sine';
            osc.frequency.setValueAtTime(1046.50, ctx.currentTime); // C6 Note
            gainNode.gain.setValueAtTime(0, ctx.currentTime);
            gainNode.gain.linearRampToValueAtTime(0.3, ctx.currentTime + 0.05);
            gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.5);
            osc.start(ctx.currentTime);
            osc.stop(ctx.currentTime + 1.5);
        } catch (e) { }
    }

    function showToast(prefix, rest) {
        if (localStorage.getItem('ms_disable_greetings') === 'true') return;

        let pfp = localStorage.getItem('ms_user_pfp') || localStorage.getItem('ms_user_dp') || defaultPfp;
        notif.innerHTML = '<img id="greetingPfp" class="greeting-pfp">' +
            '<div class="greeting-text-container">' +
            '<div id="greetingLine1" class="greeting-line1"></div>' +
            '<div id="greetingLine2" class="greeting-line2"></div>' +
            '</div>';
        // Picture and name set as a property / text, never pasted into HTML.
        notif.querySelector('#greetingPfp').src = pfp;
        notif.querySelector('#greetingLine1').textContent = prefix;
        notif.querySelector('#greetingLine2').textContent = rest;

        playPremiumDing();

        // (no opacity !important here: it would freeze the slide's fade — the keyframes end at opacity 1)
        notif.style.setProperty('animation', 'slideDownToast 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards', 'important');
        notif.style.removeProperty('opacity');
        notif.style.setProperty('display', 'flex', 'important');

        clearTimeout(hideTimeout);
        clearTimeout(hideTimeout2);

        hideTimeout = setTimeout(() => {
            notif.style.setProperty('animation', 'slideUpToast 0.4s cubic-bezier(0.6, -0.28, 0.735, 0.045) forwards', 'important');
            hideTimeout2 = setTimeout(() => {
                notif.style.setProperty('display', 'none', 'important');
                notif.style.removeProperty('animation');
            }, 400);
        }, 3500);
    }

    const observer = new MutationObserver((mutations) => {
        mutations.forEach(m => {
            if (!notif.querySelector('.greeting-text-container') && notif.innerText.trim().length > 0) {
                let text = notif.innerText.trim();
                if (text.startsWith('Good')) {
                    observer.disconnect();
                    notif.style.setProperty('display', 'none', 'important');

                    let parts = text.split(',');
                    currentPrefix = parts[0] ? parts[0] + ',' : 'Good Morning,';
                    let rest = parts[1] ? parts[1].trim() : 'User';

                    setTimeout(() => {
                        showToast(currentPrefix, rest);
                        observer.observe(notif, { childList: true });
                    }, 1000);
                }
            }
        });
    });
    observer.observe(notif, { childList: true });

    setInterval(() => {
        let hour = new Date().getHours();
        let prefix = "Good Night,";
        let emoji = "🌙";
        if (hour >= 5 && hour < 12) { prefix = "Good Morning,"; emoji = "🌅"; }
        else if (hour >= 12 && hour < 18) { prefix = "Good Afternoon,"; emoji = "☀️"; }
        else if (hour >= 18 && hour < 24) { prefix = "Good Evening,"; emoji = "🌆"; }

        if (currentPrefix !== "" && currentPrefix !== prefix) {
            currentPrefix = prefix;
            let name = localStorage.getItem('ms_userName') || 'Editor';
            name = name.trim();
            let firstWord = name.split(/\s+/)[0].replace(/[^a-zA-Z]/g, '') || 'Editor';
            name = firstWord.charAt(0).toUpperCase() + firstWord.slice(1).toLowerCase();
            showToast(prefix, name + ' ' + emoji);
        }
    }, 60000);
})();
