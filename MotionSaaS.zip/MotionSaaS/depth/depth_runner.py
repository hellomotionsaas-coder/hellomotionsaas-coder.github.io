#!/usr/bin/env python3
# MotionSaaS depth engine runner (OS Kit → Depth reveal). Copied into the user's app-data folder by
# MS.os("depthInstall") (jsx/os.jsx) and run there by MS.os("depthMap"):
#   python depth_runner.py --model depth_anything_v2_vits.onnx --job job.txt
# job.txt: input file, output folder, "1" to invert. Writes <name>_depth.png (a picture) or depth_00001.png …
# (a video), plus log.txt and done.txt (OK / FAIL) in the output folder.
import argparse, os, sys, traceback
import numpy as np
try:
    import cv2
except ImportError:
    cv2 = None
try:
    import onnxruntime as ort
except ImportError:
    ort = None
MEAN=np.array([0.485,0.456,0.406],dtype=np.float32); STD=np.array([0.229,0.224,0.225],dtype=np.float32)
VIDEO_EXT=(".mp4",".mov",".avi",".mkv",".m4v",".webm"); LOG=[None]; DONE=[None]
def log(m):
    try:
        with open(LOG[0],"a",encoding="utf-8") as f: f.write(str(m)+"\n")
    except Exception: pass
def done(status):
    try:
        if DONE[0]:
            with open(DONE[0],"w",encoding="utf-8") as f: f.write(status)
    except Exception: pass
def providers():
    a=ort.get_available_providers(); order=["CUDAExecutionProvider","CoreMLExecutionProvider","DmlExecutionProvider","CPUExecutionProvider"]
    return [x for x in order if x in a] or ["CPUExecutionProvider"]
class Model:
    def __init__(self,path):
        so=ort.SessionOptions(); so.log_severity_level=3
        try:
            self.s=ort.InferenceSession(path,sess_options=so,providers=providers())
        except Exception:
            # GPU/accelerator provider failed to initialize on this machine - retry on plain CPU
            log("provider init failed, retrying on CPU\n"+traceback.format_exc())
            self.s=ort.InferenceSession(path,sess_options=so,providers=["CPUExecutionProvider"])
        self.inp=self.s.get_inputs()[0].name
        shp=self.s.get_inputs()[0].shape; self.size=int(shp[-1]) if isinstance(shp[-1],int) else 518
    def infer_rgb(self,rgb,invert):
        h,w=rgb.shape[:2]; r=cv2.resize(rgb.astype(np.float32)/255.0,(self.size,self.size),interpolation=cv2.INTER_CUBIC)
        x=np.transpose((r-MEAN)/STD,(2,0,1))[None].astype(np.float32); out=np.squeeze(self.s.run(None,{self.inp:x})[0]).astype(np.float32)
        mn,mx=float(out.min()),float(out.max()); d=np.zeros_like(out) if mx-mn<1e-6 else (out-mn)/(mx-mn)
        if invert: d=1.0-d
        return cv2.resize((d*255).clip(0,255).astype(np.uint8),(w,h),interpolation=cv2.INTER_CUBIC)
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--model",required=True); ap.add_argument("--job",required=True); a=ap.parse_args()
    lines=open(a.job,encoding="utf-8-sig").read().splitlines(); inp=lines[0].strip(); outdir=lines[1].strip(); invert=(len(lines)>2 and lines[2].strip()=="1")
    os.makedirs(outdir,exist_ok=True); LOG[0]=os.path.join(outdir,"log.txt"); DONE[0]=os.path.join(outdir,"done.txt")
    log("input="+inp); log("exists="+str(os.path.exists(inp)))
    if ort is None: log("FATAL no onnxruntime"); done("FAIL"); sys.exit(1)
    if cv2 is None: log("FATAL no opencv"); done("FAIL"); sys.exit(1)
    if not os.path.exists(a.model): log("FATAL no model"); done("FAIL"); sys.exit(1)
    if not os.path.exists(inp): log("FATAL input not found"); done("FAIL"); sys.exit(1)
    try:
        m=Model(a.model); prov=m.s.get_providers()[0]; open(os.path.join(outdir,"provider.txt"),"w").write(prov); log("provider="+prov)
        print("Compute device: "+prov,flush=True)
        ext=os.path.splitext(inp)[1].lower()
        if ext in VIDEO_EXT:
            import imageio; rdr=imageio.get_reader(inp,format="FFMPEG"); i=0
            nf=0
            try: nf=rdr.count_frames()
            except Exception: nf=0
            for frame in rdr:
                rgb=np.asarray(frame)[:,:,:3]; i+=1; cv2.imwrite(os.path.join(outdir,"depth_%05d.png"%i),m.infer_rgb(rgb,invert))
                if i%5==0:
                    if nf: print("Progress: frame %d / %d (%d%%)"%(i,nf,int(i*100/nf)),flush=True)
                    else: print("Progress: frame %d"%i,flush=True)
            rdr.close(); log("frames="+str(i))
            if i==0: log("FATAL 0 frames"); done("FAIL"); sys.exit(1)
            print("OK seq %d"%i); done("OK")
        else:
            bgr=cv2.imread(inp,cv2.IMREAD_COLOR)
            if bgr is None:
                import imageio.v2 as iio; rgb=np.asarray(iio.imread(inp))[:,:,:3]
            else: rgb=cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)
            base=os.path.splitext(os.path.basename(inp))[0]; cv2.imwrite(os.path.join(outdir,base+"_depth.png"),m.infer_rgb(rgb,invert)); print("OK image"); done("OK")
    except Exception:
        log("EXC\n"+traceback.format_exc()); done("FAIL"); sys.exit(1)
if __name__=="__main__": main()
