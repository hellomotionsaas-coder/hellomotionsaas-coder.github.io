/*
 * MotionSaaS Studio — After Effects engine behind the Studio panel (extension/studio/).
 * ExtendScript ES3 only. Loaded by host.jsx; uses its helpers (MS._json, MS._parseJSON, MS.rgb, MS._set …).
 *
 * The panel sends MS.studio(command, payloadJSON); payload = { id: "text.rise", category, params: {...}, ...extra }.
 * Every reply is a JSON string shaped like the panel expects: { ok, applied, errors, skipped, warnings, ... }.
 *
 * Everything Studio adds is tagged so Remove can take it back:
 *   effects / text animators are named "MS <preset>", expressions start with "// MotionSaaS <preset id>",
 *   created helper layers are named "<layer> • MS <preset>", and the applied settings live in the layer comment
 *   (a line starting "MotionSaaS:") so the panel can re-open a layer with its settings.
 *
 * Contents: entry point · helpers · context/poll · treatments · keyframe helpers · Easing · Expressions · Shake ·
 *           Transitions · Text · Styles · Glass · Carousel · Backgrounds · tools (anchor, ease copy/paste, setup,
 *           remove, diagnose, repair, bake, fonts, Alive, FPS, glass card)
 */

// Attach to the one global MS, however this file is loaded: $.evalFile called from inside a function
// (MS.loadStudio) can turn a plain `var MS` into a new local object, leaving MS.studio undefined.
var MS = (typeof $ !== "undefined" && $.global) ? ($.global.MS = $.global.MS || {}) : (MS || {});
MS.S = MS.S || {};

/* ------------------------------------------------------------------ entry point */

MS.S.READ_ONLY = { context: 1, poll: 1, fonts: 1, "expression-plan": 1, "ease-copy": 1, "copy-setup": 1, diagnose: 1, code: 1 };

MS.studio = function (cmd, payloadJSON) {
    var p = {}, res, fn, undo;
    try { if (payloadJSON) { p = MS._parseJSON(String(payloadJSON)) || {}; } }
    catch (eP) { return MS._json({ ok: false, errors: ["MotionSaaS sent a request After Effects couldn't read (" + eP.message + ")"] }); }
    fn = MS.S.cmd[cmd];
    if (!fn) { return MS._json({ ok: false, errors: ["“" + cmd + "” isn't available in this version of MotionSaaS yet."] }); }
    if (!app.project) { return MS._json({ ok: false, connected: true, errors: ["Open a project first"] }); }
    undo = MS.S.READ_ONLY[cmd] ? null : "MotionSaaS: " + (p.id ? MS.S.title(p.id) : cmd);
    if (undo) { app.beginUndoGroup(undo); }
    MS.S._keylog = [];
    try { res = fn(p, p.params || {}); }
    catch (e) { res = { ok: false, errors: [MS.friendly(e)] }; }
    if (undo) { app.endUndoGroup(); }
    try { return MS._json(res || { ok: false, errors: ["Nothing happened"] }); }
    catch (eJ) { return '{"ok":false,"errors":["Couldn\'t encode the answer (' + String(eJ.message).replace(/["\\]/g, "'") + ')"]}'; }
};

/* ---------------------------------------------------------------------- helpers */

MS.S.title = function (id) {
    var s = String(id || "").split(".").pop().replace(/-/g, " ");
    return s.charAt(0).toUpperCase() + s.slice(1);
};
MS.S.num = function (v, d) { var n = Number(v); return (v === undefined || v === null || v === "" || isNaN(n)) ? d : n; };
MS.S.ok = function (n, extra) { var r = { ok: true, applied: n }, k; if (extra) { for (k in extra) { if (extra.hasOwnProperty(k)) { r[k] = extra[k]; } } } return r; };
MS.S.fail = function (msg) { return { ok: false, applied: 0, errors: [msg] }; };
MS.S.comp = function () { var c = MS.comp(); if (!c) { throw new Error("Open a composition in After Effects first"); } return c; };
MS.S.layers = function (c, filter) {
    var sel = MS.selectedLayers(c), out = [], i;
    MS.S.lockedSkipped = 0;
    for (i = 0; i < sel.length; i++) {
        if (sel[i].locked) { if (!filter || filter(sel[i])) { MS.S.lockedSkipped++; } continue; }
        if (!filter || filter(sel[i])) { out.push(sel[i]); }
    }
    return out;
};
MS.S.isAV = function (l) { return MS.isVisual(l); };
MS.S.isText = function (l) { return l instanceof TextLayer; };
MS.S.need = function (list, what) {
    if (!list.length) {
        // Layers of the right kind are selected but all locked: say that, not "select … first".
        if (MS.S.lockedSkipped) { throw new Error((MS.S.lockedSkipped === 1 ? "The selected layer is" : "The selected layers are") + " locked — unlock " + (MS.S.lockedSkipped === 1 ? "it" : "them") + " and try again"); }
        throw new Error("Select " + what + " in After Effects first");
    }
    return list;
};
MS.S.marker = function (id) { return "// MotionSaaS " + id + "\n"; };
MS.S.fxName = function (id) { return "MS " + MS.S.title(id); };
MS.S.isOurs = function (name) { return /^MS /.test(String(name)); };

// Add an effect, rename it, return a fresh reference (AE invalidates references after addProperty).
MS.S.fx = function (l, matchName, id) {
    var fxp = l.property("ADBE Effect Parade"), idx;
    if (!fxp || !fxp.canAddProperty(matchName)) { return null; }
    idx = fxp.addProperty(matchName).propertyIndex;
    try { l.property("ADBE Effect Parade").property(idx).name = MS.S.fxName(id); } catch (e) {}
    return l.property("ADBE Effect Parade").property(idx);
};
// Write an expression unless the property holds the user's own one (never overwrite that silently).
// Returns false when it was left alone.
MS.S.setExpr = function (p, expr) {
    if (!p || !p.canSetExpression) { return false; }
    if (p.expression && p.expression.indexOf("// MotionSaaS ") !== 0) { return false; }
    MS.S.replaceExpr(p, expr);
    return true;
};
// The preset id in a MotionSaaS expression's first line ("// MotionSaaS <id>"), or "".
MS.S.markerId = function (expr) { var m = /^\/\/ MotionSaaS (\S+)/.exec(String(expr || "")); return m ? m[1] : ""; };
// Write expr; when it replaces a different preset's expression and nothing else on the layer uses that
// preset any more, drop its saved settings too (else the Studio would offer to "Update" a preset that's gone).
MS.S.replaceExpr = function (p, expr) {
    var old = MS.S.markerId(p.expression), now = MS.S.markerId(expr), l, props, i;
    p.expression = expr;
    if (!old || old === now) { return; }
    try { l = p.propertyGroup(p.propertyDepth); } catch (e) { return; }
    props = MS._exprProps(l, []);
    for (i = 0; i < props.length; i++) { if (MS.S.markerId(props[i].expression) === old) { return; } }
    MS.S.forget(l, old);
};
// setValue throws on a property that has keyframes; set (or add) the key at time t there instead.
// Separated position (X/Y fields) is written per dimension.
MS.S.put = function (p, v, t) {
    var tr, d;
    if (p.matchName === "ADBE Position" && p.dimensionsSeparated) {
        tr = p.parentProperty;
        for (d = 0; d < v.length && d < 3; d++) { MS.S.put(tr.property("ADBE Position_" + d), v[d], t); }
        return;
    }
    if (p.numKeys > 0) { p.setValueAtTime(t, v); } else { p.setValue(v); }
};
MS.S.prop = function (group, key) { try { return group.property(key); } catch (e) { return null; } };
MS.S.setP = function (group, key, v) { var p = MS.S.prop(group, key); if (p) { try { p.setValue(v); } catch (e) {} } return p; };

/* ------------------------------------------------------------------ treatments */
// The settings of each preset applied to a layer, kept in the layer comment as "MotionSaaS:{...json}".

MS.S.readTreat = function (l) {
    var c = "", i, lines;
    try { c = String(l.comment || ""); } catch (e) { return {}; }
    lines = c.split(/\r\n|\r|\n/);
    for (i = 0; i < lines.length; i++) {
        if (lines[i].indexOf("MotionSaaS:") === 0) { try { return MS._parseJSON(lines[i].slice(11)) || {}; } catch (e2) { return {}; } }
    }
    return {};
};
MS.S.writeTreat = function (l, t) {
    var c = "", lines, out = [], i, k, any = false;
    try { c = String(l.comment || ""); } catch (e) { return; }
    lines = c ? c.split(/\r\n|\r|\n/) : [];
    for (i = 0; i < lines.length; i++) { if (lines[i].indexOf("MotionSaaS:") !== 0) { out.push(lines[i]); } }
    for (k in t) { if (t.hasOwnProperty(k)) { any = true; break; } }
    if (any) { out.push("MotionSaaS:" + MS._json(t)); }
    try { l.comment = out.join("\r"); } catch (e3) {}
};
// remember() also files the keyframes this command just added to that layer (see MS.S.tween) under
// t.__keys[id], so Remove / re-apply can take exactly those keys back and restore the original value.
MS.S.remember = function (l, id, params) {
    var t = MS.S.readTreat(l), mine = MS.S.takeKeys(l), k, list, j, found;
    t[id] = params;
    if (mine.length) {
        t.__keys = t.__keys || {};
        list = t.__keys[id] || [];
        for (k = 0; k < mine.length; k++) {
            found = null;
            for (j = 0; j < list.length; j++) { if (list[j].path.join("/") === mine[k].path.join("/")) { found = list[j]; break; } }
            if (found) { found.t = found.t.concat(mine[k].t); } else { list.push(mine[k]); }
        }
        t.__keys[id] = list;
    }
    MS.S.writeTreat(l, t);
};
MS.S.forget = function (l, id) {
    var t = MS.S.readTreat(l), k, any = false;
    if (!id) { t = {}; }
    else {
        delete t[id];
        if (t.__keys) { delete t.__keys[id]; for (k in t.__keys) { if (t.__keys.hasOwnProperty(k)) { any = true; } } if (!any) { delete t.__keys; } }
    }
    MS.S.writeTreat(l, t);
};

/* ---------------------------------------------------------------- key log */
// Every MS.S.tween notes which property of which layer got keys at which times (and the value the property
// had if it had no keys before). remember() moves the notes for its layer into the layer comment.

MS.S._keylog = [];
MS.S.layerKey = function (l) { var id; try { id = l.id; } catch (e) { id = undefined; } return id !== undefined && id !== null ? "id" + id : l.index + ":" + l.name; };
MS.S.pathOf = function (p) {
    var out = [], g = p;
    while (g && g.propertyDepth > 0) { out.unshift(g.matchName); g = g.parentProperty; }
    return out;
};
MS.S.logKeys = function (p, times) {
    var path, layer, v = null;
    try {
        path = MS.S.pathOf(p);
        // Keys inside effects and text animators go away with them; only plain layer properties need notes.
        if (path[0] === "ADBE Effect Parade" || path.join("/").indexOf("ADBE Text Animators") !== -1) { return; }
        layer = p.propertyGroup(p.propertyDepth);
        if (p.numKeys === 0) { v = p.valueAtTime(0, true); }   // pre-expression: the value the user set
        else {
            // A time where the user already had a key: we overwrite its value, but Remove must not delete it.
            var half = layer.containingComp.frameDuration / 2, keep = [], i, k;
            for (i = 0; i < times.length; i++) { k = p.nearestKeyIndex(times[i]); if (Math.abs(p.keyTime(k) - times[i]) > half) { keep.push(times[i]); } }
            times = keep;
        }
        if (times.length) { MS.S._keylog.push({ lid: MS.S.layerKey(layer), path: path, t: times, v: v }); }
    } catch (e) {}
};
MS.S.takeKeys = function (l) {
    var lid = MS.S.layerKey(l), out = [], rest = [], i, e;
    for (i = 0; i < MS.S._keylog.length; i++) {
        e = MS.S._keylog[i];
        if (e.lid === lid) { out.push({ path: e.path, t: e.t, v: e.v }); } else { rest.push(e); }
    }
    MS.S._keylog = rest;
    return out;
};
// Take back the keys a preset added on layer l (all presets when id is ""), restoring the original value
// on properties left without keys. Returns how many keys were removed.
MS.S.unkey = function (l, id) {
    var t = MS.S.readTreat(l), ids = [], i, j, k, e, p, n = 0, half, list, key;
    if (!t.__keys) { return 0; }
    for (key in t.__keys) { if (t.__keys.hasOwnProperty(key) && (!id || key === id)) { ids.push(key); } }
    try { half = l.containingComp.frameDuration / 2; } catch (eC) { half = 0.02; }
    for (i = 0; i < ids.length; i++) {
        list = t.__keys[ids[i]] || [];
        for (j = 0; j < list.length; j++) {
            e = list[j];
            p = MS.S.group(l, e.path);
            if (!p || !p.numKeys) { continue; }
            for (k = p.numKeys; k >= 1; k--) {
                if (MS.S.timeIn(p.keyTime(k), e.t, half)) { try { p.removeKey(k); n++; } catch (eR) {} }
            }
            if (p.numKeys === 0 && e.v !== null && e.v !== undefined) { try { p.setValue(e.v); } catch (eV) {} }
        }
        delete t.__keys[ids[i]];
    }
    for (key in t.__keys) { if (t.__keys.hasOwnProperty(key)) { MS.S.writeTreat(l, t); return n; } }
    delete t.__keys;
    MS.S.writeTreat(l, t);
    return n;
};
MS.S.timeIn = function (time, list, tol) {
    for (var i = 0; i < list.length; i++) { if (Math.abs(time - list[i]) <= tol) { return true; } }
    return false;
};

/* ------------------------------------------------------------- context / poll */

MS.S.cmd = {};

MS.S.snapshot = function () {
    var c = MS.comp(), sel, i, j, props, p, keys = 0, keyed = 0, text = 0, token = "", r;
    r = { ok: true, connected: true, composition: "", layers: 0, text: 0, properties: 0, keyedProperties: 0, keys: 0,
          selectionToken: "", treatments: {}, glassCard: null, carouselRig: false, carouselSourceCount: 0 };
    if (!c) { return r; }
    sel = MS.selectedLayers(c);
    props = c.selectedProperties;
    for (i = 0; i < sel.length; i++) {
        if (sel[i] instanceof TextLayer) { text++; }
        token += sel[i].index + ":" + sel[i].name + "|";
        if (/^MS Carousel/.test(sel[i].name)) { r.carouselRig = true; }
        if (!r.glassCard && MS.S.glassCtrlOf(c, sel[i])) { r.glassCard = MS.S.glassInfo(c, MS.S.glassCtrlOf(c, sel[i])); }
    }
    for (j = 0; j < props.length; j++) {
        p = props[j];
        if (p.propertyType !== PropertyType.PROPERTY) { continue; }
        if (p.numKeys > 0) { keyed++; keys += p.selectedKeys.length || p.numKeys; }
    }
    r.composition = c.name;
    r.layers = sel.length;
    r.text = text;
    r.properties = props.length;
    r.keyedProperties = keyed;
    r.keys = keys;
    r.selectionToken = c.id + "#" + token;
    r.carouselSourceCount = sel.length;
    if (sel.length) { r.treatments = MS.S.readTreat(sel[0]); delete r.treatments.__keys; }
    // Motion Blur switch in the Studio's Controls: on when every selected layer has it on.
    r.motionBlur = false;
    for (i = 0; i < sel.length; i++) { if (!(MS.isVisual(sel[i])) || !sel[i].motionBlur) { r.motionBlur = false; break; } r.motionBlur = true; }
    return r;
};

MS.S.cmd.context = function () { return MS.S.snapshot(); };
MS.S.cmd.poll = function () {
    var s = MS.S.snapshot(), c = MS.comp();
    return { ok: true, signature: s.selectionToken + "/" + s.properties + "/" + s.keys + "/" + (c ? Math.round(c.time * 100) : 0) };
};

/* ----------------------------------------------------------- keyframe helpers */

MS.S.EASE_OUT = [0.22, 1, 0.36, 1];
MS.S.EASE_IN = [0.64, 0, 0.78, 0];
MS.S.EASE_INOUT = [0.65, 0, 0.35, 1];

// Two keys on p (from v0 at t0 to v1 at t1) with a cubic-bezier between them.
MS.S.tween = function (p, t0, t1, v0, v1, curve) {
    var a, b, cv = curve || MS.S.EASE_OUT;
    MS.S.logKeys(p, [t0, t1]);
    p.setValueAtTime(t0, v0);
    p.setValueAtTime(t1, v1);
    a = p.nearestKeyIndex(t0); b = p.nearestKeyIndex(t1);
    if (b > a) { try { MS._easePair(p, a, b, cv[0], cv[1], cv[2], cv[3]); } catch (e) {} }
};

// Position as an offset tween that respects separated dimensions; offset = [dx, dy].
MS.S.tweenOffset = function (l, t0, t1, off, entering, curve) {
    var pos = l.transform.position, base, from, to, i;
    if (pos.dimensionsSeparated) {
        var px = l.transform.property("ADBE Position_0"), py = l.transform.property("ADBE Position_1");
        var bx = px.valueAtTime(entering ? t1 : t0, false), by = py.valueAtTime(entering ? t1 : t0, false);
        if (off[0]) { MS.S.tween(px, t0, t1, entering ? bx + off[0] : bx, entering ? bx : bx + off[0], curve); }
        if (off[1]) { MS.S.tween(py, t0, t1, entering ? by + off[1] : by, entering ? by : by + off[1], curve); }
        return;
    }
    base = pos.valueAtTime(entering ? t1 : t0, false);
    from = base.slice(0); to = base.slice(0);
    for (i = 0; i < 2; i++) { if (entering) { from[i] += off[i]; } else { to[i] += off[i]; } }
    MS.S.tween(pos, t0, t1, from, to, curve);
};

// When a transition should run: "in" at the layer's start, "out" before its end, "both" = both.
MS.S.windows = function (l, P, c) {
    var d = Math.max(c.frameDuration * 2, MS.S.num(P.duration, 0.8)), dir = String(P.direction || "in"), w = [];
    if (dir === "in-out" || dir === "inout") { dir = "both"; }   // the Studio's Phase control says "in-out"
    if (dir !== "in" && dir !== "out" && dir !== "both") { dir = "in"; }
    var len = l.outPoint - l.inPoint;
    d = Math.min(d, Math.max(c.frameDuration * 2, len / (dir === "both" ? 2 : 1)));
    if (dir === "in" || dir === "both") { w.push({ t0: l.inPoint, t1: l.inPoint + d, entering: true }); }
    if (dir === "out" || dir === "both") { w.push({ t0: l.outPoint - d, t1: l.outPoint - c.frameDuration, entering: false }); }
    return w;
};

// Half the layer's visible width / height in comp pixels at time t (content bounds × scale).
MS.S.halfSize = function (l, t) {
    var r, s = [100, 100];
    try { s = l.transform.scale.valueAtTime(t, false); } catch (eS) {}
    try { r = l.sourceRectAtTime(t, false); } catch (eR) { r = { width: l.width, height: l.height }; }
    return [Math.abs(r.width * s[0] / 200), Math.abs(r.height * s[1] / 200)];
};
MS.S.scale3 = function (l, k) { var s = l.transform.scale.value; return [s[0] * k, s[1] * k, s.length > 2 ? s[2] : 100]; };

/* ------------------------------------------------------------------- apply */

MS.S.apply = {};

MS.S.cmd.apply = function (p, P) {
    var id = String(p.id || ""), cat = id.split(".")[0], key = id.slice(cat.length + 1), fn = MS.S.apply[cat];
    if (!id) { return MS.S.fail("Pick a preset first"); }
    if (!fn) { return MS.S.fail(MS.S.title(cat) + " presets aren't supported in this version yet"); }
    return fn(key, P, id, p);
};
MS.S.cmd.update = MS.S.cmd.apply;

// Re-applying a preset replaces the previous copy of the same preset on that layer.
MS.S.clearPreset = function (l, id) {
    var name = MS.S.fxName(id), i, props, p, mark = MS.S.marker(id), same = function (n) { return n === name; };
    MS.S.unkey(l, id);
    MS.S.removeWhere(l, ["ADBE Effect Parade"], same);
    if (l instanceof TextLayer) { MS.S.removeWhere(l, ["ADBE Text Properties", "ADBE Text Animators"], same); }
    props = MS._exprProps(l, []);
    for (i = 0; i < props.length; i++) {
        p = props[i];
        if (p.expression.indexOf(mark) === 0) { p.expression = ""; }
    }
};

// Remove the children of a layer group (path of matchNames) whose name passes test, last first. The group is
// fetched again before every step: AE can invalidate a reference to a group whose children just changed.
MS.S.group = function (l, path) {
    var g = l, i;
    try { for (i = 0; i < path.length; i++) { g = g.property(path[i]); if (!g) { return null; } } } catch (e) { return null; }
    return g;
};
MS.S.removeWhere = function (l, path, test) {
    var g = MS.S.group(l, path), i, n = 0;
    if (!g) { return 0; }
    for (i = g.numProperties; i >= 1; i--) {
        g = MS.S.group(l, path);
        if (!g || i > g.numProperties) { continue; }
        if (test(g.property(i).name)) { g.property(i).remove(); n++; }
    }
    return n;
};

// All properties of a layer that currently hold an expression.
MS._exprProps = function (group, out) {
    var i, p;
    for (i = 1; i <= group.numProperties; i++) {
        try { p = group.property(i); } catch (e) { continue; }
        if (!p) { continue; }
        if (p.propertyType === PropertyType.PROPERTY) { if (p.canSetExpression && p.expression) { out.push(p); } }
        else { MS._exprProps(p, out); }
    }
    return out;
};

/* ------------------------------------------------------------------ Easing */

// Easing presets whose shape isn't a single cubic Bézier: a base curve for the keys (used unless the user
// edited the curve in the Studio's editor) plus, for springs / bounce / wind-up, a physical expression on the
// eased properties (the same generators as the Expressions category, tagged with the easing preset's id).
MS.S.STUDIO_DEFAULT_CURVE = [0.4, 0, 0.2, 1];
MS.S.EASE_CURVE = {
    snap: [0.1, 0.9, 0.2, 1], "hold-release": [0.8, 0, 0.12, 1],
    "spring-soft": [0.2, 0.8, 0.3, 1], "spring-bouncy": [0.2, 0.8, 0.3, 1], bounce: [0.5, 0, 1, 1], anticipate: [0.4, 0, 0.2, 1]
};
MS.S.EASE_EXPR = {
    "spring-soft": ["bounce-out", { amount: 40, frequency: 2, decay: 6 }],
    "spring-bouncy": ["bounce-out", { amount: 90, frequency: 3, decay: 3.5 }],
    bounce: ["impact-bounce", { amount: 45, frequency: 2.5, decay: 0.55 }],
    anticipate: ["anticipation", { amount: 18, duration: 0.3 }]
};
MS.S.sameCurve = function (a, b) { var i; if (!a || a.length !== 4) { return true; } for (i = 0; i < 4; i++) { if (Math.abs(a[i] - b[i]) > 1e-6) { return false; } } return true; };
MS.S.apply.easing = function (key, P, id) {
    var curve = P.curve && P.curve.length === 4 ? P.curve : [0.33, 0, 0.67, 1], r, extra = MS.S.EASE_EXPR[key], props, i, n = 0, layer, k;
    if (key === "linear") { curve = [0, 0, 1, 1]; }
    else if (MS.S.EASE_CURVE[key] && MS.S.sameCurve(P.curve, MS.S.STUDIO_DEFAULT_CURVE)) { curve = MS.S.EASE_CURVE[key]; }
    props = MS.S.selectedKeyed();
    // Re-applying (or switching presets) replaces an easing expression we added before.
    for (i = 0; i < props.length; i++) { if (props[i].expression.indexOf("// MotionSaaS easing.") === 0) { props[i].expression = ""; } }
    r = MS.ease(curve[0], curve[1], curve[2], curve[3]);
    if (r.indexOf("OK|") !== 0) { return MS.S.fail(r.replace(/^ERR\|/, "")); }
    n = Number((r.match(/(\d+)/) || [0, 1])[1]) || 1;
    if (extra) {
        var skipped = [], opts = {};
        for (k in extra[1]) { if (extra[1].hasOwnProperty(k)) { opts[k] = extra[1][k]; } }
        // Spring presets show Frequency / Decay in the Studio: use what the user set.
        if (/^spring-/.test(key)) { opts.frequency = MS.S.num(P.frequency, opts.frequency); opts.decay = MS.S.num(P.decay, opts.decay); }
        for (i = 0; i < props.length; i++) {
            if (!MS.S.setExpr(props[i], MS.S.marker(id) + MS.S.EXPR[extra[0]](opts))) { skipped.push(props[i].name + " already has your own expression"); continue; }
            layer = props[i].propertyGroup(props[i].propertyDepth);
            MS.S.remember(layer, id, P);
        }
        return MS.S.ok(n, { skipped: skipped });
    }
    return MS.S.ok(n);
};

/* -------------------------------------------------------------- Expressions */

// Expression bodies. They read `value`, keys and time, and work for numbers and arrays (sub/mul/add).
MS.S.EXPR = {
    "impact-bounce": function (P) {
        return "var amt = " + MS.S.num(P.amount, 35) / 100 + ", freq = " + Math.max(0.1, MS.S.num(P.frequency, 2)) + ", rest = " + Math.min(0.95, Math.max(0.05, MS.S.num(P.decay, 0.55))) + ";\n" +
            "var out = value;\n" +
            "if (numKeys > 1 && time > key(numKeys).time) {\n" +
            "  var t = time - key(numKeys).time, v = velocityAtTime(key(numKeys).time - thisComp.frameDuration / 10);\n" +
            "  var period = 1 / freq, h = 1, k = 0;\n" +
            "  while (t > period && k < 12) { t -= period; period *= Math.sqrt(rest); h *= rest; k++; }\n" +
            "  var s = (k < 12) ? Math.sin(Math.PI * t / period) * h * amt * period / Math.PI : 0;\n" +
            "  out = (value instanceof Array) ? sub(value, mul(v, s)) : value - v * s;\n" +
            "}\nout;";
    },
    anticipation: function (P) {
        return "var amt = " + MS.S.num(P.amount, 18) / 100 + ", lead = " + Math.max(0.05, MS.S.num(P.duration, 0.3)) + ";\n" +
            "var out = value;\n" +
            "if (numKeys > 1) {\n" +
            "  var t1 = key(1).time, d = sub(key(2).value, key(1).value);\n" +
            "  if (time >= t1 - lead && time < t1) {\n" +
            "    var s = Math.sin(Math.PI * (time - (t1 - lead)) / lead) * amt;\n" +
            "    out = (value instanceof Array) ? sub(value, mul(d, s)) : value - d * s;\n" +
            "  }\n" +
            "}\nout;";
    },
    "stop-motion": function (P) {
        var f = Math.max(1, MS.S.num(P.frequency, 12));
        return "var fps = " + f + ";\n(numKeys > 1 && time > key(1).time && time < key(numKeys).time) ? valueAtTime(Math.floor(time * fps) / fps) : value;";
    },
    "bounce-out": function (P) {
        return "var amp = " + MS.S.num(P.amount, 70) / 1000 + ", freq = " + MS.S.num(P.frequency, 2.5) + ", decay = " + MS.S.num(P.decay, 5) + ";\n" +
            "var out = value;\n" +
            "if (numKeys > 1 && time > key(numKeys).time) {\n" +
            "  var t = time - key(numKeys).time, v = velocityAtTime(key(numKeys).time - thisComp.frameDuration / 10);\n" +
            "  var s = Math.sin(freq * t * 2 * Math.PI) / Math.exp(decay * t) * amp;\n" +
            "  out = (value instanceof Array) ? add(value, mul(v, s)) : value + v * s;\n" +
            "}\nout;";
    },
    bounce: function (P) {
        var rest = Math.min(0.95, Math.max(0.05, MS.S.num(P.decay, 0.65)));
        return "var freq = " + MS.S.num(P.frequency, 1.5) + ", decay = " + (2 + (1 - rest) * 10) + ", amp = 0.05;\n" +
            "var n = 0, out = value;\n" +
            "if (numKeys > 0) { n = nearestKey(time).index; if (key(n).time > time) { n--; } }\n" +
            "if (n > 0) {\n" +
            "  var t = time - key(n).time, v = velocityAtTime(key(n).time - thisComp.frameDuration / 10);\n" +
            "  var s = Math.sin(freq * t * 2 * Math.PI) / Math.exp(decay * t) * amp;\n" +
            "  out = (value instanceof Array) ? add(value, mul(v, s)) : value + v * s;\n" +
            "}\nout;";
    },
    "loop-wiggle": function (P) {
        return "seedRandom(" + Math.round(MS.S.num(P.seed, 1)) + ", true);\n" +
            "var freq = " + MS.S.num(P.frequency, 0.5) + ", amp = " + MS.S.num(P.amount, 36) + ", loopTime = " + Math.max(0.2, MS.S.num(P.duration, 4)) + ";\n" +
            "var t = time % loopTime;\n" +
            "var w1 = wiggle(freq, amp, 1, 0.5, t), w2 = wiggle(freq, amp, 1, 0.5, t - loopTime);\n" +
            "linear(t, 0, loopTime, w1, w2);";
    },
    "squash-stretch": function (P) {
        return "var amt = " + MS.S.num(P.amount, 5) / 100 + ", ref = " + Math.max(1, MS.S.num(P.distance, 600)) + ";\n" +
            "var sp = 0;\ntry { sp = length(transform.position.velocity); } catch (e) { sp = 0; }\n" +
            "var s = Math.min(1, sp / ref) * amt * 4;\n" +
            "(value instanceof Array) ? [value[0] * (1 + s), value[1] * (1 - s / 2)].concat(value.length > 2 ? [value[2]] : []) : value;";
    },
    "auto-orient": function (P) {
        return "var off = " + MS.S.num(P.rotation, 0) + ";\n" +
            "var v = transform.position.velocity, out = value;\n" +
            "if (length(v) > 0.5) { out = radiansToDegrees(Math.atan2(v[1], v[0])) + off; }\nout;";
    },
    "ping-pong": function () { return "numKeys > 1 ? loopOut(\"pingpong\") : value;"; },
    "loop-offset": function () { return "numKeys > 1 ? loopOut(\"offset\") : value;"; },
    loop: function () { return "numKeys > 1 ? loopOut(\"cycle\") : value;"; },
    "throw": function (P) {
        return "var decay = " + Math.max(0.1, MS.S.num(P.decay, 3)) + ", out = value;\n" +
            "if (numKeys > 1 && time > key(numKeys).time) {\n" +
            "  var t = time - key(numKeys).time, v = velocityAtTime(key(numKeys).time - thisComp.frameDuration / 10);\n" +
            "  var s = (1 - Math.exp(-decay * t)) / decay;\n" +
            "  out = (value instanceof Array) ? add(value, mul(v, s)) : value + v * s;\n" +
            "}\nout;";
    },
    hover: function (P) {
        return "seedRandom(" + Math.round(MS.S.num(P.seed, 3)) + ", true);\n" +
            "var amp = " + MS.S.num(P.amount, 12) + ", freq = " + MS.S.num(P.frequency, 0.28) + ", ph = random(0, 6.283);\n" +
            "var y = Math.sin(time * freq * 2 * Math.PI + ph) * amp, x = Math.sin(time * freq * Math.PI + ph * 2) * amp * 0.35;\n" +
            "(value instanceof Array) ? add(value, [x, y].concat(value.length > 2 ? [0] : [])) : value + y;";
    },
    breathe: function (P) {
        return "var amt = " + MS.S.num(P.amount, 4) / 100 + ", freq = " + MS.S.num(P.frequency, 0.3) + ";\n" +
            "var k = 1 + Math.sin(time * freq * 2 * Math.PI) * amt;\n(value instanceof Array) ? mul(value, k) : value * k;";
    },
    sine: function (P) {
        return "var amp = " + MS.S.num(P.amount, 24) + ", freq = " + MS.S.num(P.frequency, 0.5) + ";\n" +
            "var s = Math.sin(time * freq * 2 * Math.PI) * amp;\n" +
            "(value instanceof Array) ? add(value, [0, s].concat(value.length > 2 ? [0] : [])) : value + s;";
    },
    wiggle: function (P) {
        return "seedRandom(" + Math.round(MS.S.num(P.seed, 1)) + ", true);\nwiggle(" + MS.S.num(P.frequency, 0.6) + ", " + MS.S.num(P.amount, 28) + ");";
    },
    random: function (P) {
        return "var freq = " + Math.max(0.1, MS.S.num(P.frequency, 4)) + ", amp = " + MS.S.num(P.amount, 24) + ";\n" +
            "seedRandom(Math.floor(time * freq) + " + Math.round(MS.S.num(P.seed, 1)) * 1000 + ", true);\n" +
            "if (value instanceof Array) { var o = []; for (var i = 0; i < value.length; i++) { o.push(value[i] + random(-amp, amp)); } o; } else { value + random(-amp, amp); }";
    },
    "auto-fade": function (P) {
        return "var d = Math.min(" + Math.max(0.04, MS.S.num(P.duration, 0.5)) + ", (outPoint - inPoint) / 2);\n" +
            "Math.min(linear(time, inPoint, inPoint + d, 0, value), linear(time, outPoint - d, outPoint, value, 0));";
    },
    flicker: function (P) {
        return "var freq = " + Math.max(0.1, MS.S.num(P.frequency, 5)) + ", depth = " + MS.S.num(P.amount, 25) / 100 + ";\n" +
            "seedRandom(Math.floor(time * freq) + " + Math.round(MS.S.num(P.seed, 1)) * 1000 + ", true);\n" +
            "value * (random() < 0.4 ? 1 - random(0, depth) : 1);";
    }
};

// Which property each behaviour is built for (when the user hasn't picked one).
MS.S.EXPR_TARGET = { "squash-stretch": "ADBE Scale", "auto-orient": "ADBE Rotate Z", breathe: "ADBE Scale", "auto-fade": "ADBE Opacity", flicker: "ADBE Opacity" };
MS.S.TARGETS = { position: "ADBE Position", scale: "ADBE Scale", rotation: "ADBE Rotate Z", opacity: "ADBE Opacity", anchor: "ADBE Anchor Point" };

// Properties an expression preset will be written to, for every selected layer.
MS.S.exprTargets = function (key, P) {
    var c = MS.S.comp(), props = c.selectedProperties, out = [], i, l, layers, p, mn, keyed, own = MS.S.EXPR_TARGET[key], seen = {};
    var needsKeys = /^(impact-bounce|anticipation|stop-motion|bounce-out|bounce|ping-pong|loop-offset|loop|throw)$/.test(key);
    // Behaviours built for one property (fade → Opacity, heading → Rotation, breathe / squash → Scale)
    // always go there, even when other properties are selected: on Position they'd just error.
    if (!own) {
        for (i = 0; i < props.length; i++) {
            p = props[i];
            if (p.propertyType === PropertyType.PROPERTY && p.canSetExpression) { out.push({ p: p, l: p.propertyGroup(p.propertyDepth) }); }
        }
        if (out.length) { return out; }
    }
    layers = MS.S.layers(c);
    if (own) {   // also the layers whose properties are selected (selecting a key doesn't always select its layer)
        for (i = 0; i < props.length; i++) { l = props[i].propertyGroup(props[i].propertyDepth); if (l && !l.locked) { layers.push(l); } }
    }
    mn = own || MS.S.TARGETS[String(P.exprTarget || "").toLowerCase()] || null;
    for (i = 0; i < layers.length; i++) {
        l = layers[i];
        if (seen[l.index]) { continue; }
        seen[l.index] = true;
        if (mn) {
            p = MS.S.prop(l.property("ADBE Transform Group"), mn);
            if (p && mn === "ADBE Position" && p.dimensionsSeparated) {   // X / Y fields: one expression each
                out.push({ p: l.property("ADBE Transform Group").property("ADBE Position_0"), l: l });
                out.push({ p: l.property("ADBE Transform Group").property("ADBE Position_1"), l: l });
            } else if (p) { out.push({ p: p, l: l }); }
            continue;
        }
        keyed = MS._keyedProps(l.property("ADBE Transform Group"));
        if (keyed.length) { for (var j = 0; j < keyed.length; j++) { out.push({ p: keyed[j], l: l }); } }
        else if (!needsKeys) {
            if (l.transform.position.dimensionsSeparated) {
                out.push({ p: l.property("ADBE Transform Group").property("ADBE Position_0"), l: l });
                out.push({ p: l.property("ADBE Transform Group").property("ADBE Position_1"), l: l });
            } else { out.push({ p: l.transform.position, l: l }); }
        }
    }
    return out;
};

MS.S.apply.expressions = function (key, P, id) {
    var make = MS.S.EXPR[key], targets, i, t, n = 0, skipped = [];
    if (!make) { return MS.S.fail(MS.S.title(id) + " isn't available yet"); }
    targets = MS.S.exprTargets(key, P);
    if (!targets.length) { return MS.S.fail("Select a layer with keyframes (or a property) first"); }
    for (i = 0; i < targets.length; i++) {
        t = targets[i];
        if (t.l.locked) { skipped.push(t.l.name + " is locked"); continue; }
        if (t.p.expression && t.p.expression.indexOf("// MotionSaaS ") !== 0 && P.exprMode !== "replace") {
            skipped.push(t.l.name + " · " + t.p.name + " already has your own expression"); continue;
        }
        MS.S.replaceExpr(t.p, MS.S.marker(id) + make(P));
        MS.S.remember(t.l, id, P);
        n++;
    }
    return n ? MS.S.ok(n, { skipped: skipped }) : { ok: false, applied: 0, errors: skipped.length ? skipped : ["Nothing to apply to"] };
};

MS.S.cmd["expression-plan"] = function (p, P) {
    var key = String(p.id || "").split(".").pop(), targets = [], reports = [], i;
    try { targets = MS.S.exprTargets(key, P); } catch (e) { return { ok: false, errors: [MS.friendly(e)], reports: [] }; }
    for (i = 0; i < targets.length && i < 12; i++) {
        reports.push({ layerName: targets[i].l.name, targetMatchName: targets[i].p.matchName, totalTargetKeyCount: targets[i].p.numKeys });
    }
    return { ok: true, reports: reports, errors: reports.length ? [] : ["Select a layer with keyframes (or a property) first"] };
};

/* -------------------------------------------------------------------- Shake */

MS.S.SHAKE = {   // property, amplitude multiplier, frequency, default duration
    punch: { mn: "ADBE Scale", amp: 1, freq: 8, dur: 0.35 },
    micro: { mn: "ADBE Position", amp: 0.25, freq: 14, dur: 0.6 },
    bump: { mn: "ADBE Position", amp: 0.8, freq: 6, dur: 0.4 },
    zoom: { mn: "ADBE Scale", amp: 1.4, freq: 4, dur: 0.5 },
    whip: { mn: "ADBE Rotate Z", amp: 0.6, freq: 5, dur: 0.45 },
    slam: { mn: "ADBE Position", amp: 1.6, freq: 10, dur: 0.5 },
    jitter: { mn: "ADBE Position", amp: 0.5, freq: 20, dur: 0.8 },
    handheld: { mn: "ADBE Position", amp: 0.6, freq: 1.2, dur: 0 }
};

// The shake expression for one property. mask = which dimensions move ([1, 0] = horizontal only);
// envelope fades it out over d seconds from t0 (d = 0: runs for the whole layer), with an extra exp(-decay·t).
MS.S.shakeExpr = function (id, seed, t0, dur, amp, freq, decay, mask, isScale) {
    return MS.S.marker(id) + "seedRandom(" + seed + ", true);\n" +
        "var t0 = " + t0 + ", d = " + dur + ", amp = " + amp + ", freq = " + freq + ", decay = " + decay + ";\n" +
        (dur ? "var t = time - t0, env = (t < 0 || t > d) ? 0 : Math.pow(1 - t / d, 2) * Math.exp(-decay * t);\n" : "var env = 1;\n") +
        (isScale
            ? "var w = sub(wiggle(freq, amp / 4), value), k = (w instanceof Array ? w[0] : w) * env;\n(value instanceof Array) ? [value[0] + k, value[1] + k].concat(value.length > 2 ? [value[2]] : []) : value + k;"
            : "var w = sub(wiggle(freq, amp), value), m = " + MS._json(mask || [1, 1]) + ";\n" +
              "(value instanceof Array) ? add(value, [w[0] * m[0] * env, w[1] * m[1] * env].concat(value.length > 2 ? [0] : [])) : value + w * env;");
};
MS.S.apply.shake = function (key, P, id) {
    var c = MS.S.comp(), layers = MS.S.need(MS.S.layers(c, MS.S.isAV), "the layers to shake"), d = MS.S.SHAKE[key] || MS.S.SHAKE.bump,
        amt = MS.S.num(P.amount, 20) * d.amp, freq = Math.max(0.1, MS.S.num(P.frequency, d.freq)), dur = d.dur ? MS.S.num(P.duration, d.dur) : 0,
        decay = Math.max(0, MS.S.num(P.decay, 0)), t0 = c.time, i, j, l, tr, targets, locs = [], skipped = [], ax = MS.S.axis(P.axis, ""),
        mask = ax === "left" || ax === "right" ? [1, 0] : (ax === "up" || ax === "down" ? [0, 1] : [1, 1]);
    if (key === "punch" || key === "zoom") { amt = MS.S.num(P.scale, MS.S.num(P.amount, 20)) * d.amp; }
    for (i = 0; i < layers.length; i++) {
        l = layers[i];
        MS.S.clearPreset(l, id);
        tr = l.property("ADBE Transform Group");
        // Separated position (X / Y fields) can't take an expression on "Position" itself.
        if (d.mn === "ADBE Position" && tr.property("ADBE Position").dimensionsSeparated) {
            targets = [];
            if (mask[0]) { targets.push([tr.property("ADBE Position_0"), [1, 1]]); }
            if (mask[1]) { targets.push([tr.property("ADBE Position_1"), [1, 1]]); }
        } else {
            targets = [[tr.property(d.mn), mask]];
        }
        var done = false;
        for (j = 0; j < targets.length; j++) {
            if (MS.S.setExpr(targets[j][0], MS.S.shakeExpr(id, i + 7 + j, t0, dur, amt, freq, decay, targets[j][1], d.mn === "ADBE Scale"))) { done = true; }
        }
        // Jitter / handheld also wobble the rotation a little (the Studio's Rotation control).
        if ((key === "jitter" || key === "handheld") && MS.S.num(P.rotation, 0) > 0) {
            MS.S.setExpr(tr.property("ADBE Rotate Z"), MS.S.shakeExpr(id, i + 31, t0, dur, MS.S.num(P.rotation, 12) / 6, freq, decay, [1, 1], false));
        }
        if (P.motionBlur) { try { l.motionBlur = true; c.motionBlur = true; } catch (eMB) {} }
        if (!done) { skipped.push(l.name + " already has your own expression there"); continue; }
        MS.S.remember(l, id, P);
        locs.push({ layer: l.name, start: t0, end: dur ? t0 + dur : l.outPoint });
    }
    return locs.length ? MS.S.ok(locs.length, { locations: locs, skipped: skipped }) : MS.S.fail(skipped[0] || "Nothing to shake");
};

/* -------------------------------------------------------------- Transitions */

MS.S.apply.transitions = function (key, P, id) {
    var c = MS.S.comp(), layers = MS.S.need(MS.S.layers(c, MS.S.isAV), "the layers to animate"), i, j, l, w, ws, n = 0,
        dist = MS.S.num(P.distance, 140), axis = String(P.axis || "left");
    for (i = 0; i < layers.length; i++) {
        l = layers[i];
        MS.S.clearPreset(l, id);
        ws = MS.S.windows(l, P, c);
        for (j = 0; j < ws.length; j++) {
            w = ws[j];
            MS.S.transition(l, key, w, P, dist, axis, id, c, ws);
        }
        MS.S.remember(l, id, P);
        n++;
    }
    return MS.S.ok(n);
};

// The Studio's axis values are left / right / top / bottom ("same" for the out-axis = use the in-axis).
MS.S.axis = function (a, fallback) {
    a = String(a || "");
    if (a === "top") { return "up"; }
    if (a === "bottom") { return "down"; }
    return /^(left|right|up|down)$/.test(a) ? a : fallback;
};
MS.S.transition = function (l, key, w, P, dist, axis, id, c, ws) {
    ws = ws || [w];
    axis = MS.S.axis(axis, "left");
    if (!w.entering && P.axisOut && P.axisOut !== "same") { axis = MS.S.axis(P.axisOut, axis); }
    var op = l.transform.opacity, full = op.valueAtTime(w.entering ? w.t1 : w.t0, false), e = w.entering, cv = e ? MS.S.EASE_OUT : MS.S.EASE_IN;
    var fadeIt = function () { MS.S.tween(op, w.t0, w.t1, e ? 0 : full, e ? full : 0, cv); };
    var off = { left: [-dist, 0], right: [dist, 0], up: [0, -dist], down: [0, dist] };
    var s, fx;
    if (key === "fade") { fadeIt(); }
    else if (key === "rise") { MS.S.tweenOffset(l, w.t0, w.t1, [0, dist], e, cv); fadeIt(); }
    else if (key === "drop") { MS.S.tweenOffset(l, w.t0, w.t1, [0, -dist], e, cv); fadeIt(); }
    else if (key === "slide") { MS.S.tweenOffset(l, w.t0, w.t1, off[axis] || off.left, e, cv); fadeIt(); }
    else if (key === "zoom") {
        s = l.transform.scale.valueAtTime(e ? w.t1 : w.t0, false);
        var k = (String(e ? P.zoomMode : P.zoomOutMode || P.zoomMode) === "in") ? 0.6 : 1.4;
        MS.S.tween(l.transform.scale, w.t0, w.t1, e ? [s[0] * k, s[1] * k, s[2] || 100] : s, e ? s : [s[0] * k, s[1] * k, s[2] || 100], cv);
        fadeIt();
    } else if (key === "iris" || key === "split" || key === "unfold") {
        fx = MS.S.fx(l, key === "iris" ? "ADBE Radial Wipe" : "ADBE Linear Wipe", id);
        if (fx) {
            if (key === "split") { MS.S.setP(fx, 2, 90); }
            if (key === "unfold") { MS.S.setP(fx, 2, 0); }
            // Feather: Linear Wipe = 1 Completion, 2 Angle, 3 Feather; Radial Wipe = 1 Completion, 2 Start Angle,
            // 3 Wipe Center (a point), 4 Wipe, 5 Feather.
            if (key === "iris") { MS.S.setP(fx, 5, 20); } else { MS.S.setP(fx, 3, 40); }
            MS.S.tween(fx.property(1), w.t0, w.t1, e ? 100 : 0, e ? 0 : 100, cv);
        }
        if (key === "unfold") { s = l.transform.scale.valueAtTime(e ? w.t1 : w.t0, false); MS.S.tween(l.transform.scale, w.t0, w.t1, e ? [s[0], 0, s[2] || 100] : s, e ? s : [s[0], 0, s[2] || 100], cv); }
    } else if (key === "glitch") {
        // One expression covering every window (in and out), so "both" doesn't overwrite the "in" part.
        var on = [], wi;
        for (wi = 0; wi < ws.length; wi++) { on.push("(time >= " + ws[wi].t0 + " && time <= " + ws[wi].t1 + ")"); }
        on = on.join(" || ") || "false";
        MS.S.setExpr(l.transform.position, MS.S.marker(id) +
            "if (" + on + ") { seedRandom(Math.floor(time * 24), true); add(value, [random(-30, 30), random(-6, 6)].concat(value.length > 2 ? [0] : [])); } else { value; }");
        MS.S.setExpr(op, MS.S.marker(id) + "if (" + on + ") { seedRandom(Math.floor(time * 30), true); value * (random() < 0.5 ? 0.2 : 1); } else { value; }");
        fadeIt();
    } else if (key === "whip") {
        // A fast swipe: long travel with a hard ease, motion blur on so it streaks.
        MS.S.tweenOffset(l, w.t0, w.t1, off[axis] ? [off[axis][0] * 3, off[axis][1] * 3] : [-dist * 3, 0], e, e ? [0.05, 0.9, 0.1, 1] : [0.9, 0, 0.95, 0.1]);
        try { l.motionBlur = true; c.motionBlur = true; } catch (eMB) {}
        fadeIt();
    } else if (key === "side-center") {
        // From the comp edge to where the layer sits (or back out).
        var tt = e ? w.t1 : w.t0, pos0 = l.transform.position.valueAtTime(tt, false), hs = MS.S.halfSize(l, tt), mv;
        if (axis === "right") { mv = [c.width + hs[0] - pos0[0], 0]; }
        else if (axis === "up") { mv = [0, -(pos0[1] + hs[1])]; }
        else if (axis === "down") { mv = [0, c.height + hs[1] - pos0[1]]; }
        else { mv = [-(pos0[0] + hs[0]), 0]; }
        MS.S.tweenOffset(l, w.t0, w.t1, mv, e, cv);
    } else if (key === "spin") {
        var rot0 = l.transform.rotation.valueAtTime(e ? w.t1 : w.t0, false);
        MS.S.tween(l.transform.rotation, w.t0, w.t1, e ? rot0 - 180 : rot0, e ? rot0 : rot0 + 180, cv);
        s = l.transform.scale.valueAtTime(e ? w.t1 : w.t0, false);
        MS.S.tween(l.transform.scale, w.t0, w.t1, e ? [s[0] * 0.4, s[1] * 0.4, s[2] || 100] : s, e ? s : [s[0] * 0.4, s[1] * 0.4, s[2] || 100], cv);
        fadeIt();
    } else if (key === "blur") {
        // One blur per window (in / out), each at 0 outside its own window, like the wipes above.
        fx = MS.S.fx(l, "ADBE Gaussian Blur 2", id);
        if (fx) { try { fx.property(3).setValue(1); } catch (eR) {} MS.S.tween(fx.property(1), w.t0, w.t1, e ? MS.S.num(P.blurAmount, 40) : 0, e ? 0 : MS.S.num(P.blurAmount, 40), cv); }
        fadeIt();
    } else if (key === "orbit") {
        var r = l.transform.rotation, rv = r.valueAtTime(e ? w.t1 : w.t0, false);
        MS.S.tween(r, w.t0, w.t1, e ? rv - 90 : rv, e ? rv : rv + 90, cv);
        MS.S.tweenOffset(l, w.t0, w.t1, [dist, dist / 2], e, cv);
        fadeIt();
    } else {
        MS.S.tweenOffset(l, w.t0, w.t1, [0, dist], e, cv);
        fadeIt();
    }
};

/* --------------------------------------------------------------------- Text */

MS.S.BASED_ON = { letters: 1, characters: 1, words: 3, lines: 4 };

// New text animator "MS <preset>" with properties; returns { anim index, layer } and a fresh range selector.
MS.S.animator = function (l, id, propNames) {
    var anims = l.property("ADBE Text Properties").property("ADBE Text Animators"), n, i;
    anims.addProperty("ADBE Text Animator");
    n = l.property("ADBE Text Properties").property("ADBE Text Animators").numProperties;
    l.property("ADBE Text Properties").property("ADBE Text Animators").property(n).name = MS.S.fxName(id);
    for (i = 0; i < propNames.length; i++) {
        // 3D rotations need per-character 3D; switch it on first. Skip a property AE refuses rather than failing.
        if (/Rotation [XY]/.test(propNames[i])) { try { l.threeDPerChar = true; } catch (e3) {} }
        try { l.property("ADBE Text Properties").property("ADBE Text Animators").property(n).property("ADBE Text Animator Properties").addProperty(propNames[i]); } catch (eA) {}
    }
    return n;
};
MS.S.anim = function (l, n) { return l.property("ADBE Text Properties").property("ADBE Text Animators").property(n); };
MS.S.animProps = function (l, n) { return MS.S.anim(l, n).property("ADBE Text Animator Properties"); };
MS.S.addSelector = function (l, n, matchName) {
    MS.S.anim(l, n).property("ADBE Text Selectors").addProperty(matchName || "ADBE Text Selector");
    var sels = MS.S.anim(l, n).property("ADBE Text Selectors");
    return sels.property(sels.numProperties);
};

// Number Counter: a slider "MS Counter" animated start → end, read by a tagged Source Text expression
// (formatting from host.jsx's MS._counterExpr). Tagged like every Studio preset, so Remove / re-apply work.
// No text layer selected: one is made in the middle of the comp.
MS.S.counter = function (P, id) {
    var c = MS.S.comp(), texts = MS.S.layers(c, MS.S.isText), i, l, fx, idx, v, name = MS.S.fxName(id), dur, o;
    var start = MS.S.num(P.start, 0), end = MS.S.num(P.end, 1250);
    if (Math.abs(start) > 1e6 || Math.abs(end) > 1e6) { return MS.S.fail("Numbers above 1,000,000 don't fit — use K / M abbreviation with smaller values"); }
    // "short" is quoted: it's a reserved word in ExtendScript (ES3) and would stop the whole file loading.
    o = { mode: "counter", pre: P.prefix || "", post: P.suffix || "", start: start, end: end, dur: MS.S.num(P.duration, 2), mult: 1,
          dec: MS.S.num(P.decimals, 0), showDec: MS.S.num(P.decimals, 0) > 0, comma: P.decimalSeparator === ",",
          "short": !!P.abbreviation && P.abbreviation !== "none", thousands: !!P.thousandsSeparator && P.thousandsSeparator !== "none" };
    if (!texts.length) {
        l = MS.makeText(c, "0", Math.round(c.height / 8), "#FFFFFF");
        l.name = "Counter";
        texts = [l];
    }
    dur = Math.max(c.frameDuration, o.dur);
    var done = 0, skipped = [], st;
    for (i = 0; i < texts.length; i++) {
        l = texts[i];
        MS.S.clearPreset(l, id);
        st = l.property("ADBE Text Properties").property("ADBE Text Document");
        if (st.expression && st.expression.indexOf("// MotionSaaS ") !== 0) { skipped.push(l.name + " already has your own Source Text expression"); continue; }
        idx = l.property("ADBE Effect Parade").addProperty("ADBE Slider Control").propertyIndex;
        fx = l.property("ADBE Effect Parade").property(idx);
        fx.name = name;
        v = l.property("ADBE Effect Parade").property(idx).property(1);
        MS.S.tween(v, c.time, c.time + dur, start, end, MS.S.EASE_INOUT);
        MS.S.replaceExpr(l.property("ADBE Text Properties").property("ADBE Text Document"), MS.S.marker(id) + MS._counterExpr(o, name));
        MS.S.remember(l, id, P);
        done++;
    }
    return done ? MS.S.ok(done, { skipped: skipped }) : MS.S.fail(skipped[0] || "Nothing to apply to");
};

MS.S.apply.text = function (key, P, id) {
    var c = MS.S.comp(), layers, i, l, n = 0, t0, d, delay, sel, props, a, units, basis, dist, ax;
    if (key === "counter") { return MS.S.counter(P, id); }
    if (key === "underline" || key === "smart-box" || key === "highlight") { return MS.S.textBox(key, P, id); }
    layers = MS.S.need(MS.S.layers(c, MS.S.isText), "text layers");
    units = String(P.units || "letters");
    basis = MS.S.BASED_ON[units] || 1;
    d = Math.max(c.frameDuration * 2, MS.S.num(P.duration, 0.8));
    delay = MS.S.num(P.delay, 0.06);
    dist = MS.S.num(P.distance, 120);
    ax = MS.S.axis(P.axis, "up");
    // direction: "in" (reveal), "out" (hide at the layer's end) or "in-out" (both, on the same selector).
    var phase = String(P.direction || "in"), doIn = phase !== "out", doOut = phase === "out" || phase === "in-out";
    var reverse = String(P.order) === "reverse", tOut;
    for (i = 0; i < layers.length; i++) {
        l = layers[i];
        MS.S.clearPreset(l, id);
        t0 = Math.max(l.inPoint, c.time) + i * delay;
        tOut = Math.max(doIn ? t0 + d + c.frameDuration : l.inPoint, l.outPoint - d - c.frameDuration);
        if (!doIn) { t0 = tOut; }
        var list = ["ADBE Text Opacity"];
        if (/^(stagger|rise|blur-reveal|bounce)$/.test(key)) { list.push("ADBE Text Position 3D"); }
        if (/^(scale-pop|stagger)$/.test(key)) { list.push("ADBE Text Scale 3D"); }
        if (/^(blur-reveal|scale-pop|stagger)$/.test(key) && MS.S.num(P.blurAmount, key === "blur-reveal" ? 30 : 0) > 0) { list.push("ADBE Text Blur"); }
        if (key === "track-expand") { list = ["ADBE Text Opacity", "ADBE Text Tracking Amount"]; }
        if (key === "flip") { list.push(String(P.flipAxis) === "y" ? "ADBE Text Rotation Y" : "ADBE Text Rotation X"); }
        if (key === "helix") { list.push("ADBE Text Rotation Y"); list.push("ADBE Text Position 3D"); }
        if (key === "scramble") { list = ["ADBE Text Character Offset"]; }
        if (key === "wave") { list = ["ADBE Text Position 3D"]; }
        if (key === "typewriter") { list = ["ADBE Text Opacity"]; }
        if (key === "stagger") {
            // Stagger's Motion control: slide / fade / scale / blur, or a "+" mix of two.
            var mo = String(P.motion || "slide-fade");
            list = [];
            if (mo.indexOf("fade") !== -1) { list.push("ADBE Text Opacity"); }
            if (mo.indexOf("slide") !== -1) { list.push("ADBE Text Position 3D"); }
            if (mo.indexOf("scale") !== -1) { list.push("ADBE Text Scale 3D"); }
            if (mo.indexOf("blur") !== -1) { list.push("ADBE Text Blur"); }
            if (!list.length) { list = ["ADBE Text Opacity"]; }
        }
        a = MS.S.animator(l, id, list);
        props = MS.S.animProps(l, a);
        // Selected characters take the animator's values, so these are the "hidden" pose: opacity
        // (100 - Opacity amount; typewriter always 0), offset position, scale, blur, rotation.
        if (props.property("ADBE Text Opacity")) { MS.S.setP(props, "ADBE Text Opacity", key === "typewriter" ? 0 : 100 - MS.S.num(P.opacityAmount, 100)); }
        if (props.property("ADBE Text Position 3D")) {
            // Characters come FROM the axis side: left = start left of their place, top = start above, …
            var off = { up: [0, -dist, 0], down: [0, dist, 0], left: [-dist, 0, 0], right: [dist, 0, 0] }[ax] || [0, dist, 0];
            if (key === "rise") { off = [0, dist, 0]; }
            if (key === "bounce") { off = [0, -dist, 0]; }
            if (key === "helix") { off = [0, 0, -dist]; }
            MS.S.setP(props, "ADBE Text Position 3D", key === "wave" ? [0, MS.S.num(P.amount, 20), 0] : off);
        }
        if (props.property("ADBE Text Scale 3D")) { var sc = key === "scale-pop" ? MS.S.num(P.scaleAmount, 0) : MS.S.num(P.scaleAmount, 100); MS.S.setP(props, "ADBE Text Scale 3D", [sc, sc, 100]); }
        if (props.property("ADBE Text Blur")) { var b = MS.S.num(P.blurAmount, 30); MS.S.setP(props, "ADBE Text Blur", [b, b]); }
        if (key === "track-expand") { MS.S.setP(props, "ADBE Text Tracking Amount", MS.S.num(P.fromTracking, -60) - MS.S.num(P.toTracking, 40)); }
        if (props.property("ADBE Text Rotation X")) { MS.S.setP(props, "ADBE Text Rotation X", MS.S.num(P.rotation, 90)); }
        if (props.property("ADBE Text Rotation Y")) { MS.S.setP(props, "ADBE Text Rotation Y", MS.S.num(P.rotation, 180)); }
        if (key === "scramble") { MS.S.setP(props, "ADBE Text Character Offset", 30); }

        if (key === "wave") {
            sel = MS.S.addSelector(l, a, "ADBE Text Expressible Selector");
            var amt = MS.S.prop(sel, "ADBE Text Expressible Amount");
            if (amt) {
                amt.expression = MS.S.marker(id) + "var f = " + MS.S.num(P.frequency, 2) / 10 + ", sp = " + MS.S.num(P.speed, 30) / 10 + ";\n" +
                    "var s = Math.sin(time * sp + textIndex * f) * 100;\n[s, s, s];";
            }
        } else {
            sel = MS.S.addSelector(l, a);
            try { sel.property("ADBE Text Range Advanced").property("ADBE Text Range Type2").setValue(basis); } catch (eB) {}
            // In: hidden → shown at t0; Out: shown → hidden at tOut (keys on the same selector for In-Out).
            if (key === "typewriter") {
                // Square selection from Start to 100 %: Start 0 = all hidden, 100 = all typed. Out "backspaces".
                var st = sel.property("ADBE Text Percent Start");
                try { sel.property("ADBE Text Range Advanced").property("ADBE Text Range Shape").setValue(1); } catch (eS) {}
                if (doIn) { MS.S.tween(st, t0, t0 + d, 0, 100, [0, 0, 1, 1]); }
                if (doOut) { MS.S.tween(st, tOut, tOut + d, 100, 0, [0, 0, 1, 1]); }
            } else {
                // Ramp Up + Offset -100 → 100 reveals left to right; Ramp Down + 100 → -100 right to left.
                try { sel.property("ADBE Text Range Advanced").property("ADBE Text Range Shape").setValue(reverse ? 3 : 2); } catch (eS2) {}
                if (key === "scramble" || P.order === "random") { try { sel.property("ADBE Text Range Advanced").property("ADBE Text Randomize Order").setValue(1); } catch (eR) {} }
                var offP = sel.property("ADBE Text Percent Offset"), hidden = reverse ? 100 : -100, shown = -hidden;
                if (doIn) { MS.S.tween(offP, t0, t0 + d, hidden, shown, key === "bounce" ? [0.34, 1.56, 0.64, 1] : MS.S.EASE_OUT); }
                if (doOut) { MS.S.tween(offP, tOut, tOut + d, shown, hidden, MS.S.EASE_IN); }
            }
        }
        MS.S.remember(l, id, P);
        n++;
    }
    return MS.S.ok(n);
};

// Underline / smart box / highlight: a shape layer behind (or under) the text that follows its size.
// The box layer's anchor point always equals its position, so its layer space IS comp space (scale only
// stretches around the anchor): shape expressions use t.toComp(...) directly. No fromComp — it divides by
// the box's scale, which animates from 0.
MS.S.textBox = function (key, P, id) {
    var c = MS.S.comp(), layers = MS.S.need(MS.S.layers(c, MS.S.isText), "text layers"), i, t, box, g, rect, fill, ref, n = 0,
        px = MS.S.num(P.paddingX, MS.S.num(P.paddingAll, 18)), py = MS.S.num(P.paddingY, MS.S.num(P.paddingAll, 10)),
        color = P.color || (key === "highlight" ? "#FFE066" : "#0A84FF"), d = MS.S.num(P.duration, 0.6), sx;
    // A line (underline, or the Highlighter's underline / strike-through modes) or a box around the text.
    var mode = key === "underline" ? "underline" : (key === "highlight" ? String(P.highlightMode || "background") : "background");
    var thick = MS.S.num(P.strokeWidth, 0) > 0 ? MS.S.num(P.strokeWidth, 0) : 6;   // Studio default is 0 = "auto"
    var useFill = P.fillEnabled !== false, useStroke = !!P.strokeEnabled && MS.S.num(P.strokeWidth, 0) > 0, t0;
    for (i = 0; i < layers.length; i++) {
        t = layers[i];
        // Re-applying replaces this text's previous box instead of stacking another one.
        for (var j = c.numLayers; j >= 1; j--) { if (c.layer(j).name === t.name + " • " + MS.S.fxName(id)) { c.layer(j).remove(); } }
        box = c.layers.addShape();
        box.name = t.name + " • " + MS.S.fxName(id);
        box.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
        g = box.property("ADBE Root Vectors Group").property(1).property("ADBE Vectors Group");
        g.addProperty("ADBE Vector Shape - Rect");
        g.addProperty("ADBE Vector Graphic - Fill");
        if (useStroke) { g.addProperty("ADBE Vector Graphic - Stroke"); }
        g = box.property("ADBE Root Vectors Group").property(1).property("ADBE Vectors Group");
        rect = g.property(1);
        // The box is parented to its text with anchor = position = [0, 0], so its layer space IS the text's
        // layer space: sourceRectAtTime() numbers are used as-is, and moving / scaling / rotating / renaming /
        // reordering the text keeps the box on it.
        ref = "parent";
        if (mode === "underline" || mode === "strike") {
            var lineY = mode === "strike" ? "r.top + r.height * 0.55" : "r.top + r.height + " + MS.S.num(P.boxOffset, 8);
            rect.property("ADBE Vector Rect Size").expression = MS.S.marker(id) + "var r = " + ref + ".sourceRectAtTime(time, false);\n[r.width, " + thick + "];";
            rect.property("ADBE Vector Rect Position").expression = MS.S.marker(id) + "var r = " + ref + ".sourceRectAtTime(time, false);\n[r.left + r.width / 2, " + lineY + "];";
            rect.property("ADBE Vector Rect Roundness").setValue(thick / 2);
        } else {
            rect.property("ADBE Vector Rect Size").expression = MS.S.marker(id) + "var r = " + ref + ".sourceRectAtTime(time, false);\n[r.width + " + px * 2 + ", r.height + " + py * 2 + "];";
            rect.property("ADBE Vector Rect Position").expression = MS.S.marker(id) + "var r = " + ref + ".sourceRectAtTime(time, false);\n[r.left + r.width / 2, r.top + r.height / 2];";
            rect.property("ADBE Vector Rect Roundness").setValue(MS.S.num(P.cornerRadius, key === "highlight" ? 6 : 16));
        }
        fill = g.property(2);
        fill.property("ADBE Vector Fill Color").setValue(MS.rgba(color));
        fill.property("ADBE Vector Fill Opacity").setValue(useFill ? MS.S.num(P.fillOpacity, key === "smart-box" ? 85 : 100) : 0);
        if (useStroke) {
            var stroke = g.property(3);
            stroke.property("ADBE Vector Stroke Color").setValue(MS.rgba(P.strokeColor || "#0B1F55"));
            stroke.property("ADBE Vector Stroke Width").setValue(MS.S.num(P.strokeWidth, 2));
            stroke.property("ADBE Vector Stroke Opacity").setValue(MS.S.num(P.strokeOpacity, 100));
        }
        if (mode === "strike") { box.moveBefore(t); } else { box.moveAfter(t); }   // a strike-through sits on top
        box.setParentWithJump(t);
        box.transform.anchorPoint.setValue([0, 0]);
        box.transform.position.setValue([0, 0]);
        box.transform.scale.setValue([100, 100]);
        box.transform.rotation.setValue(0);
        box.inPoint = t.inPoint; box.outPoint = t.outPoint;
        sx = box.transform.scale;
        t0 = Math.max(t.inPoint, c.time);
        if (key === "smart-box") { MS.S.tween(box.transform.opacity, t0, t0 + d, 0, 100); }
        else {
            // Wipe in from the left: scale X from 0 around the text's left edge (anchor = position, both there).
            box.transform.anchorPoint.expression = MS.S.marker(id) + "var r = " + ref + ".sourceRectAtTime(time, false);\n[r.left - " + (mode === "background" ? px : 0) + ", r.top + r.height / 2];";
            box.transform.position.expression = MS.S.marker(id) + "transform.anchorPoint;";
            MS.S.tween(sx, t0, t0 + d, [0, 100, 100], [100, 100, 100]);
        }
        MS.S.remember(t, id, P);
        n++;
    }
    return MS.S.ok(n);
};

MS.S.cmd["highlighter-create"] = function (p, P) { return MS.S.textBox("highlight", P, p.id || "text.highlight"); };
MS.S.cmd["highlighter-remove"] = function (p) { return MS.S.removeHelpers(p.id || "text.highlight"); };

/* ------------------------------------------------------------------- Styles */

MS.S.apply.styles = function (key, P, id) {
    var c = MS.S.comp(), layers = MS.S.need(MS.S.layers(c, MS.S.isAV), "the layers to style"), i, l, fx, n = 0,
        amt = MS.S.num(P.amount, 40), soft = MS.S.num(P.softness, 30), col = P.color || P.styleColor || "#0A84FF";
    for (i = 0; i < layers.length; i++) {
        l = layers[i];
        MS.S.clearPreset(l, id);
        if (key === "shadow") {
            fx = MS.S.fx(l, "ADBE Drop Shadow", id);
            if (fx) { MS.S.setP(fx, 2, MS.S.num(P.opacity, 45) * 2.55); MS.S.setP(fx, 4, amt / 2); MS.S.setP(fx, 5, soft * 2); }
        } else if (key === "glow" || key === "display" || key === "streaks") {
            fx = MS.S.fx(l, "ADBE Glo2", id);
            if (fx) { MS.S.setP(fx, 3, soft + 10); MS.S.setP(fx, 4, 0.5 + amt / 40); }
            if (key === "display") { fx = MS.S.fx(l, "ADBE Tint", id); if (fx) { MS.S.setP(fx, 2, MS.rgb(col)); MS.S.setP(fx, 3, 35); } }
            if (key === "streaks") { fx = MS.S.fx(l, "ADBE Motion Blur", id); if (fx) { MS.S.setP(fx, 2, amt); } }
        } else if (key === "hairline") {
            fx = MS.S.fx(l, "ADBE Glo2", id);
            if (fx) { MS.S.setP(fx, 3, 2); MS.S.setP(fx, 4, 3); }
        } else if (key === "highlight" || key === "chrome") {
            fx = MS.S.fx(l, "ADBE Bevel Alpha", id);
            if (fx) { MS.S.setP(fx, 1, Math.max(1, amt / 6)); }
            if (key === "chrome") { fx = MS.S.fx(l, "ADBE Tint", id); if (fx) { MS.S.setP(fx, 1, [0.1, 0.1, 0.12]); MS.S.setP(fx, 2, [0.95, 0.95, 1]); } }
        } else if (key === "sweep") {
            fx = MS.S.fx(l, "CC Light Sweep", id) || MS.S.fx(l, "ADBE Glo2", id);
            if (fx && fx.property(1) && fx.matchName === "CC Light Sweep") {
                fx.property(1).expression = MS.S.marker(id) + "var w = thisLayer.width, sp = " + MS.S.num(P.speed, 30) / 10 + ";\n[(time * sp * w / 4) % (w * 1.6) - w * 0.3, thisLayer.height / 2];";
            }
        } else if (key === "pearl-silk") {   // soft pearly sheen: gentle bevel, pale tint, faint glow
            fx = MS.S.fx(l, "ADBE Bevel Alpha", id);
            if (fx) { MS.S.setP(fx, 1, Math.max(1, amt / 10)); }
            fx = MS.S.fx(l, "ADBE Tint", id);
            if (fx) { MS.S.setP(fx, 2, MS.rgb("#F4EEFF")); MS.S.setP(fx, 3, 25); }
            fx = MS.S.fx(l, "ADBE Glo2", id);
            if (fx) { MS.S.setP(fx, 3, soft + 20); MS.S.setP(fx, 4, 0.4); }
        } else if (key === "pixel-press") {   // chunky pixels with a reduced palette
            fx = MS.S.fx(l, "ADBE Mosaic", id);
            if (fx) { var blocks = Math.max(8, Math.round(120 - amt * 2)); MS.S.setP(fx, 1, blocks); MS.S.setP(fx, 2, Math.round(blocks * 0.6)); }
            fx = MS.S.fx(l, "ADBE Posterize", id);
            if (fx) { MS.S.setP(fx, 1, 6); }
        } else if (key === "ember-form") {   // warm ember wash: dark plum shadows, orange highlights, glow
            fx = MS.S.fx(l, "ADBE Tint", id);
            if (fx) { MS.S.setP(fx, 1, MS.rgb("#2A0F3D")); MS.S.setP(fx, 2, MS.rgb("#FFB36B")); MS.S.setP(fx, 3, 70); }
            fx = MS.S.fx(l, "ADBE Glo2", id);
            if (fx) { MS.S.setP(fx, 3, soft + 15); MS.S.setP(fx, 4, 0.8); }
        } else {   // "liquid-color" and any other colour wash: tint to the chosen colour + glow
            fx = MS.S.fx(l, "ADBE Tint", id);
            if (fx) { MS.S.setP(fx, 2, MS.rgb(col)); MS.S.setP(fx, 3, 60); }
            fx = MS.S.fx(l, "ADBE Glo2", id);
        }
        MS.S.remember(l, id, P);
        n++;
    }
    return MS.S.ok(n);
};

/* -------------------------------------------------------------------- Glass */

MS.S.apply.glass = function (key, P, id) {
    var w = MS.S.num(P.width, 900), h = MS.S.num(P.height, 520), r = MS.S.num(P.cornerRadius, 48),
        // Each glass type has its own base blur; the Studio's Pre / Post blur (default 0) add to it.
        blur = ({ "clear": 12, "liquid": 24, "soft-liquid": 32, "frosted": 60, "object": 40 }[key] || 24) +
            MS.S.num(P.glassPreBlur, 0) + MS.S.num(P.glassPostBlur, 0) + (key === "frosted" ? MS.S.num(P.amount, 20) : 0),
        tint = Math.max(4, MS.S.num(P.glassTint, 14)), c = MS.S.comp(), before = c.numLayers, res = MS.glass(w, h, r, blur, tint), i, l;
    if (res.indexOf("OK|") !== 0) { return MS.S.fail(res.replace(/^ERR\|/, "")); }
    // MS.glass adds its layers at the top: touch only those, never the user's own "Glass…" layers.
    c = MS.S.comp();
    for (i = 1; i <= c.numLayers - before; i++) {
        l = c.layer(i);
        if (l.name === "Glass • Blur" && (key === "liquid" || key === "soft-liquid") && MS.S.num(P.refraction, 40) > 0) {
            var fx = MS.S.fx(l, "ADBE Turbulent Displace", id);
            if (fx) { MS.S.setP(fx, 2, MS.S.num(P.refraction, 40) / 4); MS.S.setP(fx, 3, 180); }
        }
        if (/^Glass/.test(l.name)) { l.name = l.name.replace(/^Glass/, "MS Glass"); }
    }
    return MS.S.ok(1);
};

// Glass card = the layers MS.glass makes, all parented to a null "MS Glass Card ▸ move me", plus (optional)
// a text layer "MS Glass • Text" and image "<file> • MS Glass image" parented to the same null.
MS.S.GLASS_CTRL = /^MS Glass Card/;
MS.S.glassCtrlOf = function (c, l) {   // the card's null for a selected layer (the null itself or one of its children)
    if (!l) { return null; }
    if (MS.S.GLASS_CTRL.test(l.name)) { return l; }
    if (l.parent && MS.S.GLASS_CTRL.test(l.parent.name)) { return l.parent; }
    return null;
};
MS.S.glassChild = function (c, ctrl, re) {
    for (var i = 1; i <= c.numLayers; i++) {
        var l = c.layer(i);
        if (l.parent && l.parent.index === ctrl.index && re.test(l.name)) { return l; }
    }
    return null;
};
MS.S.selectOnly = function (c, layers) {
    var i;
    for (i = 1; i <= c.numLayers; i++) { if (c.layer(i).selected) { c.layer(i).selected = false; } }
    for (i = 0; i < layers.length; i++) { layers[i].selected = true; }
};
// Every layer of one card: its null, everything parented to it, and the blur adjustment under the matte.
MS.S.glassLayers = function (c, ctrl) {
    var out = [ctrl], i, l, matte = null;
    for (i = 1; i <= c.numLayers; i++) {
        l = c.layer(i);
        if (l.parent && l.parent.index === ctrl.index) { out.push(l); if (/^MS Glass • Matte/.test(l.name)) { matte = l; } }
    }
    if (matte && matte.index < c.numLayers && /^MS Glass • Blur/.test(c.layer(matte.index + 1).name)) { out.push(c.layer(matte.index + 1)); }
    return out;
};
// What the Studio's Glass card form shows for a selected card.
MS.S.glassInfo = function (c, ctrl) {
    var t = MS.S.glassChild(c, ctrl, /^MS Glass • Text/), td, out = { id: "glass.object", text: "", font: "", fontSize: 0 };
    if (t) {
        try {
            td = t.property("ADBE Text Properties").property("ADBE Text Document").value;
            out.text = String(td.text);
            out.fontSize = td.fontSize;
            out.font = td.fontFamily || td.font || "";
        } catch (e) {}
    }
    return out;
};
MS.S.selectedGlassCtrl = function (c) {
    var sel = MS.selectedLayers(c), i, k;
    for (i = 0; i < sel.length; i++) { k = MS.S.glassCtrlOf(c, sel[i]); if (k) { return k; } }
    return null;
};
// Font family (what the Studio's font picker lists) → the PostScript name a TextDocument wants.
MS.S.fontPS = function (family) {
    var list, i;
    if (!family) { return ""; }
    try {
        if (app.fonts && app.fonts.getFontsByFamilyNameAndStyleName) {
            list = app.fonts.getFontsByFamilyNameAndStyleName(family, "Regular");
            if (!list || !list.length) { list = app.fonts.getFontsByFamilyNameAndStyleName(family, "Medium"); }
            if (list && list.length) { return list[0].postScriptName; }
        }
    } catch (e) {}
    return String(family).replace(/\s+/g, "");   // older AE: "Inter" → "Inter", "SF Pro" → "SFPro" (best effort)
};
MS.S.styleGlassText = function (t, P) {
    var prop = t.property("ADBE Text Properties").property("ADBE Text Document"), td = prop.value, ps;
    if (P.text !== undefined && P.text !== null && String(P.text) !== "") { td.text = String(P.text); }
    if (P.fontSize && Number(P.fontSize) > 0) { td.fontSize = Number(P.fontSize); }
    if (P.color) { try { td.fillColor = MS.rgb(P.color); } catch (eC) {} }
    ps = MS.S.fontPS(P.font);
    if (ps) { try { td.font = ps; } catch (eF) {} }
    prop.setValue(td);
};
MS.S.glassText = function (c, ctrl, P) {
    var t = MS.S.glassChild(c, ctrl, /^MS Glass • Text/);
    if (!P.text && !t) { return null; }
    if (!t) {
        t = MS.makeText(c, String(P.text), Number(P.fontSize) > 0 ? Number(P.fontSize) : 64, P.color || "#FFFFFF");
        t.name = "MS Glass • Text";
        t.moveBefore(ctrl);
        t.setParentWithJump(ctrl);
        MS.S.put(t.transform.position, [0, 0], c.time);   // the null's anchor is the card centre
    }
    MS.S.styleGlassText(t, P);
    return t;
};
MS.S.cmd["glass-card-create"] = function (p, P) {
    var c = MS.S.comp(), r = MS.S.apply.glass("object", P, p.id || "glass.object"), ctrl;
    if (!r.ok) { return r; }
    c = MS.S.comp();
    ctrl = MS.S.GLASS_CTRL.test(c.layer(1).name) ? c.layer(1) : null;   // MS.glass adds the card's null last (top)
    if (ctrl) { MS.S.selectOnly(c, [ctrl]); }
    if (ctrl && !p.imageOnly && p.text) { MS.S.glassText(c, ctrl, p); }
    if (ctrl && p.imageOnly) { return MS.S.cmd["glass-card-image"](p, P); }
    return r;
};
MS.S.cmd["glass-card-update"] = function (p) {
    var c = MS.S.comp(), ctrl = MS.S.selectedGlassCtrl(c);
    if (!ctrl) { return MS.S.fail("Select a Glass card (its null or any of its layers) to update it"); }
    MS.S.glassText(c, ctrl, p);
    return MS.S.ok(1);
};
MS.S.cmd["glass-card-image"] = function () {
    var c = MS.S.comp(), ctrl = MS.S.selectedGlassCtrl(c), f = File.openDialog("Choose an image for the card"), item, l, old, surf, k;
    if (!f) { return MS.S.ok(0, { warnings: ["No image chosen"] }); }
    item = app.project.importFile(new ImportOptions(f));
    if (ctrl) {
        old = MS.S.glassChild(c, ctrl, / • MS Glass image$/);
        if (old) { old.remove(); }   // "Add image" on a card replaces its image
    }
    l = c.layers.add(item);
    l.name = decodeURI(f.name) + " • MS Glass image";
    if (ctrl) {
        surf = MS.S.glassChild(c, ctrl, /^MS Glass • Surface/);
        if (surf) { l.moveBefore(surf); } else { l.moveBefore(ctrl); }
        l.setParentWithJump(ctrl);
        MS.S.put(l.transform.position, [0, 0], c.time);
        if (l.width) { k = 0.8 * Math.min(1, 900 / l.width) * 100; MS.S.put(l.transform.scale, [k, k], c.time); }
    }
    return MS.S.ok(1);
};

/* ----------------------------------------------------------------- Carousel */

MS.S.CAROUSEL_RIG = /^MS Carousel • /;
// The layers of an existing carousel: everything parented to its null, top to bottom.
MS.S.rigChildren = function (c, rig) {
    var out = [], i, l;
    for (i = 1; i <= c.numLayers; i++) {
        l = c.layer(i);
        if (l.parent && l.parent.index === rig.index && !l.locked && MS.isVisual(l)) { out.push(l); }
    }
    return out;
};
MS.S.apply.carousel = function (key, P, id) {
    var c = MS.S.comp(), sel = MS.selectedLayers(c), rig = null, layers, n, i, l, ctrl, s, t, tk,
        size = MS.S.num(P.size, 180), radius = MS.S.num(P.radius, 350), cols = Math.max(1, Math.round(MS.S.num(P.columns, 3))),
        gap = MS.S.num(P.gap, 30), d = MS.S.num(P.duration, 0.8), delay = MS.S.num(P.delay, 0.06), t0 = c.time, k, ang, x, y, z, rot, rotY, three;
    for (i = 0; i < sel.length; i++) { if (MS.S.CAROUSEL_RIG.test(sel[i].name)) { rig = sel[i]; break; } }
    three = /^(ring|sphere|cube|coverflow|helix|perspective|path-orbit|text-wheel)$/.test(key);
    if (rig) {
        // Update: re-lay-out the carousel's own layers; take back what the previous layout added first.
        layers = MS.S.rigChildren(c, rig);
        for (i = 0; i < layers.length; i++) {
            t = MS.S.readTreat(layers[i]);
            for (tk in t) { if (t.hasOwnProperty(tk) && tk.indexOf("carousel.") === 0) { MS.S.removeOn(layers[i], tk); } }
        }
        MS.S.removeOn(rig, "");
        ctrl = rig;
        ctrl.name = "MS Carousel • " + MS.S.title(id);
        if (three && !ctrl.threeDLayer) { ctrl.threeDLayer = true; }
    } else {
        layers = MS.S.layers(c, MS.S.isAV);
    }
    n = layers.length;
    if (n < 2) { return MS.S.fail(rig ? "This carousel has fewer than two unlocked layers" : "Select two or more layers to build a carousel"); }
    if (!rig) {
        ctrl = c.layers.addNull();
        ctrl.name = "MS Carousel • " + MS.S.title(id);
        if (three) { ctrl.threeDLayer = true; }
        // Anchor at the null's origin, so children positioned at [0, 0] sit on the null's position.
        ctrl.transform.anchorPoint.setValue(three ? [0, 0, 0] : [0, 0]);
        ctrl.transform.position.setValue(three ? [c.width / 2, c.height / 2, 0] : [c.width / 2, c.height / 2]);
    }
    for (i = 0; i < n; i++) {
        l = layers[i];
        k = n > 1 ? i / (n - 1) : 0;
        ang = (i / n) * Math.PI * 2;
        x = 0; y = 0; z = 0; rot = 0; rotY = 0;
        if (key === "grid") { x = (i % cols - (cols - 1) / 2) * (size + gap); y = (Math.floor(i / cols) - (Math.ceil(n / cols) - 1) / 2) * (size + gap); }
        else if (key === "fan") { rot = (k - 0.5) * MS.S.num(P.rotation, 40); x = (k - 0.5) * radius; y = Math.abs(k - 0.5) * radius * 0.25; }
        else if (key === "arc") { ang = Math.PI * (1 + k); x = Math.cos(ang) * radius; y = Math.sin(ang) * radius * 0.5 + radius * 0.25; }
        else if (key === "ring") { x = Math.sin(ang) * radius; z = -Math.cos(ang) * radius; }
        else if (key === "helix") { x = Math.sin(ang) * radius; z = -Math.cos(ang) * radius; y = (i - (n - 1) / 2) * gap * 0.5; }
        else if (key === "coverflow") {   // a row; side items step back and turn towards the centre
            var mid = (n - 1) / 2, side2 = i < mid ? -1 : (i > mid ? 1 : 0);
            x = (i - mid) * size * 0.6 + side2 * size * 0.4; z = Math.abs(i - mid) * MS.S.num(P.depth, 220) * 0.4; rotY = -side2 * 45;
        }
        else if (key === "sphere") { var phi = Math.acos(1 - 2 * (i + 0.5) / n), th = Math.PI * (1 + Math.sqrt(5)) * i; x = Math.cos(th) * Math.sin(phi) * radius; y = Math.sin(th) * Math.sin(phi) * radius; z = Math.cos(phi) * radius; }
        else if (key === "cube") { x = ((i % 2) - 0.5) * radius; y = ((Math.floor(i / 2) % 2) - 0.5) * radius; z = ((Math.floor(i / 4) % 2) - 0.5) * radius; }
        else if (key === "stack" || key === "stacked") { x = i * 18; y = -i * 14; }
        else if (key === "vertical" || key === "text-menu") { y = (i - (n - 1) / 2) * (size * 0.6 + gap); }
        else if (key === "circle") { x = Math.sin(ang) * radius; y = -Math.cos(ang) * radius; }
        else if (key === "oval") { x = Math.sin(ang) * radius; y = -Math.cos(ang) * radius * 0.55; }
        else if (key === "square") {   // evenly around a square's outline, starting top-left, clockwise
            var sq = (i / n) * 4, side = Math.floor(sq), f = sq - side, h = radius;
            x = [-h + 2 * h * f, h, h - 2 * h * f, -h][side];
            y = [-h, -h + 2 * h * f, h, h - 2 * h * f][side];
        }
        else if (key === "perspective") { x = (i - (n - 1) / 2) * (size * 0.7); z = Math.abs(i - (n - 1) / 2) * MS.S.num(P.depth, 220) * 0.5; rot = 0; }
        else if (key === "path-orbit") {
            var shp = String(P.shape || "circle");
            x = Math.sin(ang) * radius; z = -Math.cos(ang) * radius * (shp === "oval" ? 0.55 : 1);
            if (shp === "square") { x = Math.max(-radius, Math.min(radius, x * 1.4)); z = Math.max(-radius, Math.min(radius, z * 1.4)); }
        }
        else if (key === "text-wheel") { y = Math.sin(ang) * radius; z = -Math.cos(ang) * radius; }
        else if (key === "path-ribbon") { x = (i - (n - 1) / 2) * (size + gap); y = Math.sin(i * 0.9) * size * 0.25; }
        else if (key === "cluster") { x = Math.cos(ang * 1.7) * radius * (0.4 + 0.6 * k); y = Math.sin(ang * 1.7) * radius * 0.6 * (0.4 + 0.6 * k); }
        else { x = (i - (n - 1) / 2) * (size + gap); }   // a row: "horizontal" | "ribbon" | "focus" | "stream" | "spring-chain" | "text-ticker"
        if (three) { l.threeDLayer = true; }
        if (!(l.parent && l.parent.index === ctrl.index)) { l.setParentWithJump(ctrl); }
        MS.S.put(l.transform.position, three ? [x, y, z] : [x, y], t0);
        if (rot) { MS.S.put(l.transform.rotation, rot, t0); }
        if (rotY && three) { MS.S.put(l.transform.property("ADBE Rotate Y"), rotY, t0); }
        // Size every item to `size` px on its long side. Shape / text layers report the comp size as
        // width/height, so measure the content instead.
        var rect, longSide, target;
        try { rect = l.sourceRectAtTime(t0, false); longSide = Math.max(rect.width, rect.height); } catch (eR) { longSide = Math.max(l.width, l.height); }
        target = longSide > 0 ? size / longSide * 100 : 100;
        if (key === "focus") { target *= Math.abs(k - 0.5) < 0.01 || n === 1 ? 1.3 : 0.8; }   // the middle item in front
        MS.S.tween(l.transform.scale, t0 + i * delay, t0 + i * delay + d, [0, 0, 100], [target, target, 100], [0.34, 1.56, 0.64, 1]);
        if (key === "spring-chain" || key === "stream") {
            // add/sub (not + / -): the JavaScript expression engine has no array operators.
            MS.S.setExpr(l.transform.position, MS.S.marker(id) + "var lag = " + (i * 0.08) + ", c = parent.transform.position;\nadd(value, sub(c.valueAtTime(time - lag), c.value));");
        }
        MS.S.remember(l, id, P);
    }
    // Motion of the whole carousel (speed 0 = still). Direction "out" spins the other way.
    var sp = MS.S.num(P.speed, 30) * (String(P.direction) === "out" ? -1 : 1);
    if (key === "text-wheel") {
        ctrl.transform.property("ADBE Rotate X").expression = MS.S.marker(id) + "time * " + sp + ";";
    } else if (three && !/^(coverflow|perspective)$/.test(key)) {
        ctrl.transform.property("ADBE Rotate Y").expression = MS.S.marker(id) + "time * " + sp + ";";
    } else if (key === "text-ticker" && sp) {
        // Scroll left forever, wrapping after one full row.
        ctrl.transform.position.expression = MS.S.marker(id) + "var span = " + (n * (size + gap)) + ";\nsub(value, [(time * " + Math.abs(sp) * 4 + ") % span - span / 2, 0]);";
    } else if (P.loop) {
        ctrl.transform.rotation.expression = MS.S.marker(id) + "Math.sin(time * 0.6) * 4;";
    }
    for (i = 1; i <= c.numLayers; i++) { c.layer(i).selected = false; }
    ctrl.selected = true;
    return MS.S.ok(n);
};

/* -------------------------------------------------------------- Backgrounds */

MS.S.PALETTES = {
    nocturne: ["#243a8f", "#4d6dec", "#af82d9", "#f0bcd0"],
    ember: ["#412575", "#b4489a", "#ff967d", "#ffd6a3"],
    mineral: ["#163f59", "#247da1", "#82c9b8", "#e4e0af"]
};

// The Studio's seven backgrounds (four gradient colours each, dark → light).
MS.S.BACKGROUNDS = {
    "ember-form": ["#2a0f3d", "#b4489a", "#ff967d", "#ffd6a3"],
    "ion-eclipse": ["#05060f", "#1b2a6b", "#4fd1ff", "#c8f3ff"],
    "thermal-ribbon": ["#1a0b2e", "#ff4d6d", "#ffb347", "#ffe29a"],
    "violet-halo": ["#120a2a", "#5b2bd6", "#a78bfa", "#f0e7ff"],
    "solar-horizon": ["#1c0f0a", "#ff6b35", "#ffc145", "#fff1d0"],
    "aurora-veil": ["#041c24", "#0fb39c", "#7cf0c4", "#c6b3ff"],
    "opal-flow": ["#e9f1ff", "#b8d4ff", "#f6c9e6", "#d7fff1"]
};
MS.S.BG_LAYER = /^MS Background • /;
MS.S.apply.backgrounds = function (key, P, id) {
    var c = MS.S.comp(), cols = MS.S.BACKGROUNDS[key] || MS.S.PALETTES[key] || MS.S.PALETTES.nocturne, l = null, fxp, fx, idx, i, j, pts,
        sel = MS.selectedLayers(c), seed = Math.round(MS.S.num(P.seed, 3)), drift = c.width * (0.08 + MS.S.num(P.backgroundSpeed, 50) / 500),
        loopLen = Math.max(0.5, MS.S.num(P.duration, 6));
    // Update: a selected MotionSaaS background is restyled in place instead of adding another one.
    for (i = 0; i < sel.length; i++) { if (MS.S.BG_LAYER.test(sel[i].name) && !sel[i].locked) { l = sel[i]; break; } }
    if (l) {
        MS.S.removeWhere(l, ["ADBE Effect Parade"], function () { return true; });
        l.name = "MS Background • " + MS.S.title(id);
    } else {
        l = c.layers.addSolid([0, 0, 0], "MS Background • " + MS.S.title(id), c.width, c.height, c.pixelAspect, c.duration);
        l.moveToEnd();
    }
    l.property("ADBE Effect Parade").addProperty("ADBE 4ColorGradient");
    fx = l.property("ADBE Effect Parade").property(1);
    MS._fill4Color(fx, [[c.width * 0.15, c.height * 0.15], [c.width * 0.85, c.height * 0.2], [c.width * 0.2, c.height * 0.85], [c.width * 0.85, c.height * 0.85]], cols, seed, drift);
    // Loop on: each point drifts on a path that ends where it started, every `duration` seconds.
    fx = l.property("ADBE Effect Parade").property(1);
    pts = [];
    for (j = 1; j <= fx.numProperties; j++) { if (fx.property(j).propertyValueType === PropertyValueType.TwoD_SPATIAL) { pts.push(fx.property(j)); } }
    for (j = 0; j < pts.length; j++) {
        pts[j].expression = MS.S.marker(id) + "seedRandom(" + (seed + j) + ", true);\n" +
            (P.loop === false
                ? "wiggle(" + (1.5 / loopLen) + ", " + Math.round(drift) + ");"
                : "var L = " + loopLen + ", t = time % L, f = " + (1.5 / loopLen) + ", a = " + Math.round(drift) + ";\n" +
                  "var w1 = wiggle(f, a, 1, 0.5, t), w2 = wiggle(f, a, 1, 0.5, t - L);\nlinear(t, 0, L, w1, w2);");
    }
    if (MS.S.num(P.backgroundGrain, 100) > 0) {
        fxp = l.property("ADBE Effect Parade");
        idx = fxp.addProperty("ADBE Noise").propertyIndex;
        fx = l.property("ADBE Effect Parade").property(idx);
        MS.S.setP(fx, 1, Math.min(8, MS.S.num(P.backgroundGrain, 100) / 25));
        MS.S.setP(fx, 2, 0);   // monochrome grain
    }
    MS.S.remember(l, id, P);   // so the Studio shows "Update" with these settings when it's selected
    return MS.S.ok(1);
};

/* -------------------------------------------------------------------- tools */

MS.S.cmd["center-anchor"] = function () {
    var c = MS.S.comp(), layers = MS.S.need(MS.S.layers(c, MS.S.isAV), "the layers"), i;
    for (i = 0; i < layers.length; i++) { MS._anchorTo(layers[i], 0.5, 0.5, c.time); }
    return MS.S.ok(layers.length);
};

MS.S.cmd.fonts = function () {
    var out = [], seen = {}, i, f, list;
    try {
        if (app.fonts && app.fonts.allFonts) {
            list = app.fonts.allFonts;
            for (i = 0; i < list.length && out.length < 600; i++) {
                f = list[i][0] || list[i];
                if (f && f.familyName && !seen[f.familyName]) { seen[f.familyName] = 1; out.push(f.familyName); }
            }
        }
    } catch (e) {}
    return { ok: true, fonts: out };
};

// Ease copy / paste between keyframes.
MS.S.selectedKeyed = function () {
    var c = MS.S.comp(), props = c.selectedProperties, out = [], i;
    for (i = 0; i < props.length; i++) { if (props[i].propertyType === PropertyType.PROPERTY && props[i].numKeys > 0) { out.push(props[i]); } }
    return out;
};
MS.S.cmd["ease-copy"] = function () {
    var props = MS.S.selectedKeyed(), p, keys, i, k, ie, oe, list = [];
    if (!props.length) { return MS.S.fail("Select keyframes to copy their ease"); }
    p = props[0];
    keys = p.selectedKeys.length ? p.selectedKeys : [];
    if (!keys.length) { for (i = 1; i <= p.numKeys; i++) { keys.push(i); } }
    for (i = 0; i < keys.length; i++) {
        k = keys[i]; ie = p.keyInTemporalEase(k)[0]; oe = p.keyOutTemporalEase(k)[0];
        list.push({ inSpeed: ie.speed, inInfluence: ie.influence, outSpeed: oe.speed, outInfluence: oe.influence });
    }
    return { ok: true, easeData: { keys: list } };
};
MS.S.cmd["ease-paste"] = function (p) {
    var data = p.easeData, mode = p.easeMode || "both", mirror = !!p.mirror, props = MS.S.selectedKeyed(), i, j, q, keys, src, n = 0, dims, ie, oe, a, b, k;
    if (!data || !data.keys || !data.keys.length) { return MS.S.fail("Copy an ease first"); }
    if (!props.length) { return MS.S.fail("Select keyframes to paste the ease onto"); }
    for (i = 0; i < props.length; i++) {
        q = props[i];
        keys = q.selectedKeys.length ? q.selectedKeys : [];
        if (!keys.length) { for (j = 1; j <= q.numKeys; j++) { keys.push(j); } }
        for (j = 0; j < keys.length; j++) {
            src = data.keys[mirror ? data.keys.length - 1 - (j % data.keys.length) : j % data.keys.length];
            k = keys[j]; dims = q.keyInTemporalEase(k).length;
            ie = []; oe = [];
            for (a = 0; a < dims; a++) {
                b = q.keyInTemporalEase(k)[a]; var o = q.keyOutTemporalEase(k)[a];
                var inS = mirror ? src.outSpeed : src.inSpeed, inI = mirror ? src.outInfluence : src.inInfluence;
                var outS = mirror ? src.inSpeed : src.outSpeed, outI = mirror ? src.inInfluence : src.outInfluence;
                ie.push(new KeyframeEase(mode === "influence" ? b.speed : inS, mode === "speed" ? b.influence : Math.max(0.1, Math.min(100, inI))));
                oe.push(new KeyframeEase(mode === "influence" ? o.speed : outS, mode === "speed" ? o.influence : Math.max(0.1, Math.min(100, outI))));
            }
            try { q.setInterpolationTypeAtKey(k, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER); q.setTemporalEaseAtKey(k, ie, oe); n++; } catch (e) {}
        }
    }
    return MS.S.ok(n);
};

// Text setup copy / paste: the Text presets applied to one layer, re-applied to others.
MS.S.cmd["copy-setup"] = function () {
    var c = MS.S.comp(), layers = MS.S.layers(c, MS.S.isText), t, k, tools = [];
    if (layers.length !== 1) { return MS.S.fail("Select one text layer to copy its setup"); }
    t = MS.S.readTreat(layers[0]);
    for (k in t) { if (t.hasOwnProperty(k) && k.indexOf("text.") === 0) { tools.push({ id: k, params: t[k] }); } }
    if (!tools.length) { return MS.S.fail("That layer has no MotionSaaS text animation yet"); }
    return { ok: true, recipe: { tools: tools } };
};
MS.S.cmd["paste-setup"] = function (p) {
    var tools = p.recipe && p.recipe.tools, i, r, n = 0, errs = [];
    if (!tools || !tools.length) { return MS.S.fail("Copy a text setup first"); }
    for (i = 0; i < tools.length; i++) {
        r = MS.S.apply.text(tools[i].id.split(".").pop(), tools[i].params || {}, tools[i].id, p);
        if (r.ok) { n += r.applied || 0; } else { errs = errs.concat(r.errors || []); }
    }
    return n ? MS.S.ok(n, { warnings: errs }) : { ok: false, applied: 0, errors: errs };
};

// Remove: everything MotionSaaS added for this preset (or every preset) on the selected layers.
MS.S.removeOn = function (l, id) {
    var count = 0, i, props, mark = id ? MS.S.marker(id) : "// MotionSaaS ", name = id ? MS.S.fxName(id) : null;
    var test = function (n) { return name ? n === name : MS.S.isOurs(n); };
    count += MS.S.unkey(l, id || "");
    count += MS.S.removeWhere(l, ["ADBE Effect Parade"], test);
    if (l instanceof TextLayer) { count += MS.S.removeWhere(l, ["ADBE Text Properties", "ADBE Text Animators"], test); }
    props = MS._exprProps(l, []);
    for (i = 0; i < props.length; i++) { if (props[i].expression.indexOf(mark) === 0) { props[i].expression = ""; count++; } }
    MS.S.forget(l, id);
    return count;
};
// Easing → Remove: the selected keys (or all keys of the selected properties) go back to linear, and any
// spring / bounce expression the easing preset added is taken off.
MS.S.removeEasing = function () {
    var props = MS.S.selectedKeyed(), i, k, keys, p, l, n = 0, id;
    if (!props.length) { return MS.S.fail("Select the eased keyframes (or their property) first"); }
    for (i = 0; i < props.length; i++) {
        p = props[i];
        keys = p.selectedKeys.length ? p.selectedKeys : [];
        if (!keys.length) { for (k = 1; k <= p.numKeys; k++) { keys.push(k); } }
        for (k = 0; k < keys.length; k++) {
            try { p.setInterpolationTypeAtKey(keys[k], KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR); n++; } catch (e) {}
        }
        id = MS.S.markerId(p.expression);
        if (/^easing\./.test(id)) {
            p.expression = "";
            l = p.propertyGroup(p.propertyDepth);
            MS.S.forget(l, id);
        }
    }
    return MS.S.ok(n);
};
// Carousel → Remove: with the rig (or any of its layers) selected, take the carousel apart — layers are
// unparented where they appear now, their carousel keys / expressions / settings are removed, the rig null goes.
MS.S.dismantleCarousel = function (c, layers) {
    var rigs = [], i, j, r, kids, t, k, n = 0, seen = {};
    for (i = 0; i < layers.length; i++) {
        r = MS.S.CAROUSEL_RIG.test(layers[i].name) ? layers[i] : (layers[i].parent && MS.S.CAROUSEL_RIG.test(layers[i].parent.name) ? layers[i].parent : null);
        if (r && !seen[r.index]) { seen[r.index] = true; rigs.push(r); }
    }
    // Highest index first: removing a null never shifts the rigs still to do.
    rigs.sort(function (a, b) { return b.index - a.index; });
    for (i = 0; i < rigs.length; i++) {
        kids = MS.S.rigChildren(c, rigs[i]);
        for (j = 0; j < kids.length; j++) {
            t = MS.S.readTreat(kids[j]);
            for (k in t) { if (t.hasOwnProperty(k) && k.indexOf("carousel.") === 0) { MS.S.removeOn(kids[j], k); } }
            kids[j].setParentWithJump(null);
            n++;
        }
        rigs[i].locked = false;
        rigs[i].remove();
    }
    return n;
};
MS.S.removeHelpers = function (id) {
    var c = MS.S.comp(), i, suffix = " • " + MS.S.fxName(id), n = 0, sel = MS.selectedLayers(c), names = {};
    for (i = 0; i < sel.length; i++) { names[sel[i].name + suffix] = 1; }
    for (i = c.numLayers; i >= 1; i--) { if (names[c.layer(i).name]) { c.layer(i).remove(); n++; } }
    return MS.S.ok(n);
};
MS.S.cmd.remove = function (p) {
    var c = MS.S.comp(), layers, i, n = 0, id = p.id || "";
    if (/^easing\./.test(id)) { return MS.S.removeEasing(); }   // works on selected keys, even with no layer selected
    layers = MS.S.need(MS.S.layers(c), "the layers");
    if (/^text\.(underline|smart-box|highlight)$/.test(id)) { return MS.S.removeHelpers(id); }
    if (/^glass\./.test(id) && p.deleteCreatedCard) {
        // "Remove card": the whole selected card (null, matte, surface, blur, text, image) — never other cards.
        var ctrl = MS.S.selectedGlassCtrl(c), parts;
        if (ctrl) {
            parts = MS.S.glassLayers(c, ctrl);
            for (i = 0; i < parts.length; i++) { parts[i].locked = false; }
            // Highest index first, so earlier removals don't shift the ones still to go.
            parts.sort(function (a, b) { return b.index - a.index; });
            for (i = 0; i < parts.length; i++) { parts[i].remove(); }
            return MS.S.ok(1);
        }
    }
    if (/^carousel\./.test(id)) { var undone = MS.S.dismantleCarousel(c, layers); if (undone) { return MS.S.ok(undone); } }
    if (/^backgrounds\./.test(id)) {   // a background is a layer of its own: Remove deletes the selected one(s)
        for (i = layers.length - 1; i >= 0; i--) { if (/^MS Background • /.test(layers[i].name)) { layers[i].remove(); n++; } }
        if (n) { return MS.S.ok(n); }
    }
    for (i = 0; i < layers.length; i++) { if (MS.S.removeOn(layers[i], id)) { n++; } }
    return n ? MS.S.ok(n) : { ok: true, applied: 0, warnings: ["Nothing from " + MS.S.title(id) + " on the selected layers"] };
};
MS.S.cmd["remove-all-text"] = function () {
    var c = MS.S.comp(), layers = MS.S.need(MS.S.layers(c, MS.S.isText), "text layers"), i, n = 0;
    for (i = 0; i < layers.length; i++) { if (MS.S.removeOn(layers[i], "")) { n++; } }
    return MS.S.ok(n);
};

// Diagnose / repair: MotionSaaS expressions that error.
MS.S.brokenExprs = function () {
    var c = MS.S.comp(), out = [], i, j, l, props;
    for (i = 1; i <= c.numLayers; i++) {
        l = c.layer(i);
        props = MS._exprProps(l, []);
        for (j = 0; j < props.length; j++) {
            if (props[j].expression.indexOf("// MotionSaaS ") === 0 && props[j].expressionError) { out.push({ l: l, p: props[j] }); }
        }
    }
    return out;
};
MS.S.cmd.diagnose = function () {
    var b = MS.S.brokenExprs(), issues = [], i;
    for (i = 0; i < b.length; i++) { issues.push({ layer: b[i].l.name, message: b[i].p.name + ": " + String(b[i].p.expressionError).split("\n")[0] }); }
    return { ok: true, issues: issues };
};
MS.S.cmd.repair = function () {
    var b = MS.S.brokenExprs(), i, n = 0, skipped = [];
    for (i = 0; i < b.length; i++) {
        if (b[i].l.locked) { skipped.push({ message: b[i].l.name + " is locked" }); continue; }
        b[i].p.expressionEnabled = false; n++;
    }
    return { ok: true, repaired: n, unresolved: skipped.length, skipped: skipped };
};

// Bake: turn MotionSaaS expressions on the selected layers into keyframes (AE's own converter).
MS.S.cmd["bake-v2"] = function () {
    var c = MS.S.comp(), layers = MS.S.need(MS.S.layers(c), "the layers to bake"), i, j, props, list = [], details = [], cmdId;
    for (i = 0; i < layers.length; i++) {
        props = MS._exprProps(layers[i], []);
        for (j = 0; j < props.length; j++) { if (props[j].expression.indexOf("// MotionSaaS ") === 0) { list.push({ l: layers[i], p: props[j] }); } }
    }
    if (!list.length) { return MS.S.fail("No MotionSaaS expressions on the selected layers to bake"); }
    // The menu name only matches in English After Effects; 2639 is the same command's fixed id in other languages.
    cmdId = app.findMenuCommandId("Convert Expression to Keyframes") || 2639;
    if (!cmdId) { return MS.S.fail("This After Effects version can't convert expressions to keyframes"); }
    for (i = 0; i < list.length; i++) {
        var all = c.selectedProperties;
        for (j = 0; j < all.length; j++) { try { all[j].selected = false; } catch (e) {} }
        list[i].p.selected = true;
        app.executeCommand(cmdId);
        details.push({ layer: list[i].l.name, property: list[i].p.name, samples: Math.round(c.duration / c.frameDuration), keys: list[i].p.numKeys });
    }
    return MS.S.ok(list.length, { details: details });
};

// Alive: soft squash, stretch and wobble driven by the layer's own speed.
MS.S.cmd["alive-apply"] = function (p) {
    var c = MS.S.comp(), layers = MS.S.need(MS.S.layers(c, MS.S.isAV), "the animated layer"), i, l, sc, n = 0,
        amt = MS.S.num(p.amount, 90) / 100, soft = MS.S.num(p.softness, 65) / 100, damp = MS.S.num(p.damping, 8);
    for (i = 0; i < layers.length; i++) {
        l = layers[i];
        sc = l.transform.scale;
        if (sc.expression && sc.expression.indexOf("// MotionSaaS ") !== 0) { continue; }
        sc.expression = MS.S.marker("alive") +
            "var amt = " + amt + ", freq = " + (3.5 - soft * 2.5) + ", decay = " + Math.max(1, damp) + ";\n" +
            "var v = 0;\ntry { v = length(transform.position.velocity); } catch (e) { v = 0; }\n" +
            "var stretch = Math.min(0.35, v / 4000 * amt);\n" +
            "var n = 0, wob = 0;\n" +
            "var pos = transform.position;\n" +
            "if (pos.numKeys > 0) { n = pos.nearestKey(time).index; if (pos.key(n).time > time) { n--; } }\n" +
            "if (n > 0) { var t = time - pos.key(n).time, sp = length(pos.velocityAtTime(pos.key(n).time - thisComp.frameDuration / 10)); wob = Math.sin(freq * t * 2 * Math.PI) / Math.exp(decay * t) * Math.min(0.25, sp / 3000) * amt; }\n" +
            "var sx = 1 + stretch + wob, sy = 1 - stretch / 2 - wob / 2;\n" +
            "[value[0] * sx, value[1] * sy].concat(value.length > 2 ? [value[2]] : []);";
        MS.S.remember(l, "alive", { amount: p.amount, softness: p.softness, damping: p.damping });
        n++;
    }
    return n ? MS.S.ok(n) : MS.S.fail("Those layers already have your own Scale expression");
};
MS.S.cmd["alive-remove"] = function () {
    var c = MS.S.comp(), layers = MS.S.need(MS.S.layers(c, MS.S.isAV), "the layer"), i, n = 0, sc;
    for (i = 0; i < layers.length; i++) {
        sc = layers[i].transform.scale;
        if (sc.expression.indexOf(MS.S.marker("alive")) === 0) { sc.expression = ""; MS.S.forget(layers[i], "alive"); n++; }
    }
    return MS.S.ok(n);
};

// Reverb Out (the Studio toolbar's Reverb dialog): the audio is cut at the layer's out point and a reverb
// tail rings on after it. A Stereo Mixer before the Reverb mutes the input at the cut (so the reverb stops
// being fed), the Reverb keeps sounding, and the layer is extended by the tail length.
// Reverb params (ADBE Aud Reverb): 1 Reverb Time (ms), 2 Diffusion, 3 Decay, 4 Brightness, 5 Dry Out, 6 Wet Out.
// Stereo Mixer (ADBE Aud Stereo Mixer): 1 Left Level, 2 Right Level.
MS.S.hasAudio = function (l) { try { return MS.isVisual(l) && l.hasAudio && l.audioEnabled !== false; } catch (e) { return false; } };
MS.S.cmd["reverb-out"] = function (p) {
    var c = MS.S.comp(), layers = MS.S.need(MS.S.layers(c, MS.S.hasAudio), "a layer with audio"), i, l, cut, mix, rev, n = 0, warn = [],
        tail = Math.max(0.3, Math.min(5, MS.S.num(p.length, 2))), amt = Math.max(0, Math.min(100, MS.S.num(p.amount, 40))), fd = c.frameDuration, t;
    for (i = 0; i < layers.length; i++) {
        l = layers[i];
        t = MS.S.readTreat(l);
        cut = t["reverb-out"] && t["reverb-out"].cut !== undefined ? t["reverb-out"].cut : l.outPoint;   // re-apply keeps the first cut
        MS.S.removeOn(l, "reverb-out");
        mix = MS.S.fx(l, "ADBE Aud Stereo Mixer", "reverb-out");
        if (mix) {
            MS.S.tween(mix.property(1), cut - 2 * fd, cut, 100, 0, [0, 0, 1, 1]);
            mix = MS.S.layerFx(l, "reverb-out", "ADBE Aud Stereo Mixer");
            MS.S.tween(mix.property(2), cut - 2 * fd, cut, 100, 0, [0, 0, 1, 1]);
        } else { warn.push(l.name + ": couldn't add the input cut, the tail will follow the audio"); }
        rev = MS.S.fx(l, "ADBE Aud Reverb", "reverb-out");
        if (!rev) { warn.push(l.name + ": this After Effects has no Reverb effect"); continue; }
        MS.S.setP(rev, 1, Math.min(5000, tail * 1000));
        MS.S.setP(rev, 3, 60);
        MS.S.setP(rev, 5, 100);
        MS.S.setP(rev, 6, amt);
        try { l.outPoint = cut + tail; } catch (eOut) { warn.push(l.name + ": couldn't extend the layer — the tail is cut at the layer's end"); }
        MS.S.remember(l, "reverb-out", { cut: cut, length: tail, amount: amt });
        n++;
    }
    return n ? MS.S.ok(n, { warnings: warn }) : { ok: false, applied: 0, errors: warn.length ? warn : ["Nothing to apply to"] };
};
MS.S.cmd["reverb-out-remove"] = function () {
    var c = MS.S.comp(), layers = MS.S.need(MS.S.layers(c, MS.S.hasAudio), "a layer with audio"), i, l, t, n = 0;
    for (i = 0; i < layers.length; i++) {
        l = layers[i];
        t = MS.S.readTreat(l)["reverb-out"];
        if (!t) { continue; }
        MS.S.removeOn(l, "reverb-out");
        try { if (t.cut !== undefined) { l.outPoint = t.cut; } } catch (e) {}
        n++;
    }
    return MS.S.ok(n);
};
// The effect named "MS <preset>" with this matchName on the layer (fresh reference), or null.
MS.S.layerFx = function (l, id, matchName) {
    var fxp = l.property("ADBE Effect Parade"), i, name = MS.S.fxName(id);
    for (i = 1; i <= fxp.numProperties; i++) { if (fxp.property(i).name === name && fxp.property(i).matchName === matchName) { return fxp.property(i); } }
    return null;
};

// Controls → Motion Blur: the layer switch on the selected layers (and the comp's switch, so it shows).
MS.S.cmd["motion-blur"] = function (p) {
    var c = MS.S.comp(), layers = MS.S.need(MS.S.layers(c, MS.S.isAV), "the layers"), i, on = !!p.on, n = 0;
    for (i = 0; i < layers.length; i++) { try { layers[i].motionBlur = on; n++; } catch (e) {} }
    if (on) { try { c.motionBlur = true; } catch (e2) {} }
    return MS.S.ok(n);
};

// Code: what a preset will write, for the Studio's Code panel (Easing and Expressions). Read-only.
MS.S.cmd.code = function (p, P) {
    var id = String(p.id || ""), cat = id.split(".")[0], key = id.slice(cat.length + 1), curve, lines = [], extra;
    if (cat === "expressions" && MS.S.EXPR[key]) { return { ok: true, code: MS.S.marker(id) + MS.S.EXPR[key](P), language: "expression" }; }
    if (cat === "easing") {
        curve = P.curve && P.curve.length === 4 ? P.curve : [0.33, 0, 0.67, 1];
        if (key === "linear") { curve = [0, 0, 1, 1]; }
        else if (MS.S.EASE_CURVE[key] && MS.S.sameCurve(P.curve, MS.S.STUDIO_DEFAULT_CURVE)) { curve = MS.S.EASE_CURVE[key]; }
        var r2 = function (v) { return Math.round(v * 1000) / 1000; };
        lines.push("cubic-bezier(" + r2(curve[0]) + ", " + r2(curve[1]) + ", " + r2(curve[2]) + ", " + r2(curve[3]) + ")");
        lines.push("After Effects keyframes: outgoing influence " + Math.round(Math.max(0.1, Math.min(100, curve[0] * 100))) + "%, incoming influence " + Math.round(Math.max(0.1, Math.min(100, (1 - curve[2]) * 100))) + "%");
        extra = MS.S.EASE_EXPR[key];
        if (extra) {
            var opts = {}, k;
            for (k in extra[1]) { if (extra[1].hasOwnProperty(k)) { opts[k] = extra[1][k]; } }
            if (/^spring-/.test(key)) { opts.frequency = MS.S.num(P.frequency, opts.frequency); opts.decay = MS.S.num(P.decay, opts.decay); }
            lines.push("", "Expression on the eased property:", MS.S.marker(id) + MS.S.EXPR[extra[0]](opts));
        }
        return { ok: true, code: lines.join("\n"), language: "easing" };
    }
    return { ok: true, code: "", language: "" };
};

// Layer FPS: Posterize Time on the selected layers (or reset it).
MS.S.cmd["fps-apply"] = function (p) {
    var c = MS.S.comp(), layers = MS.S.need(MS.S.layers(c, MS.S.isAV), "the layers"), i, fx, fps = Math.max(1, Math.min(60, MS.S.num(p.fps, 12)));
    for (i = 0; i < layers.length; i++) {
        MS.S.clearPreset(layers[i], "fps");
        fx = MS.S.fx(layers[i], "ADBE Posterize Time", "fps");
        if (fx) { MS.S.setP(fx, 1, fps); }
    }
    return MS.S.ok(layers.length);
};
MS.S.cmd["fps-reset"] = function () {
    var c = MS.S.comp(), layers = MS.S.need(MS.S.layers(c, MS.S.isAV), "the layers"), i, n = 0;
    for (i = 0; i < layers.length; i++) { if (MS.S.removeOn(layers[i], "fps")) { n++; } }
    return MS.S.ok(n);
};
