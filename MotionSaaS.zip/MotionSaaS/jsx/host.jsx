/*
 * MotionSaaS — After Effects host script (ExtendScript)
 *
 * IMPORTANT: ExtendScript is old JavaScript (ES3). No let/const, arrow functions,
 * Array.map/forEach, JSON, String.trim, template strings. Keep it that way so it runs on AE 2020.
 *
 * Every public function returns a string: "OK|message" or "ERR|message", and runs inside MS.run()
 * (one undo step, friendly errors). The panel calls them via MSUI.runCore("buttonName") → js/ms-core.js
 * CORE map, or MSUI.host("MS.fn", [args]) — args arrive JSON-encoded, never string-concatenated.
 * Names starting with "_" are internal helpers. Pure helpers are unit-tested by scripts/check.js.
 *
 * Contents (search for the section banner):
 *   helpers ................ MS.run, friendly errors, colours, shape/text/null/comp builders
 *   layer picker ........... selectByType, toggle (lock/hide/solo/shy)
 *   design tools ........... gradient, mesh (4-colour), glass card
 *   text animation ......... animate (fadeUp/pop/blurIn/slideIn/typewriter/cascade)
 *   colours ................ color (text/shape/solid/fill effect)
 *   templates .............. template (intro/cta/search/carousel)
 *   tool helpers ........... selection, key shifting, comp-space bounds, anchor maths
 *   layout ................. anchor, align, fit, spread
 *   easing ................. bezier → AE ease, bounce, key retiming, fitKeys
 *   layers ................. create, trueDuplicate, unprecompose, trimTo, label, fxPercent, playhead, offset, organise, purge
 *   counter & timer ........ counter (Source Text expressions)
 *   captions ............... _parseSRT, importSRT
 *   effect helpers ......... _addFx, _keyPair
 *   magic reveal ........... magicReveal
 *   icons, assets, folders . importFile, openFolder, asset* (Assetbox)
 *   subtitle pairs ......... pairStretch, selectPair
 *   ease read-back ......... readEase
 *   panel bridge extras .... gradLock, nudge, subtitleBoxes, applyPresetWithDuration, projectStats, assetFrames
 *   effect snapshots ....... _json, _parseJSON (no eval), saveFxSnapshot, applyFxPreset (.ffx/.msfx)
 *   device mockups ......... mockup (browser/iphone/macbook)
 *   self-test .............. selfTest (About → Run self-test)
 *   globals ................ purgeCache, saveSelectedEffectsPreset, applyEffectPreset (called by name from panel)
 */

// The one global MS, however this file is loaded (a plain `var MS` inside an $.evalFile called from a
// function could become a local object).
var MS = (typeof $ !== "undefined" && $.global) ? ($.global.MS = $.global.MS || {}) : (MS || {});

/* ------------------------------------------------------------------ helpers */

MS.ok = function (m) { return "OK|" + (m || "Done"); };
MS.err = function (m) { return "ERR|" + m; };

MS.comp = function () {
    var c = app.project ? app.project.activeItem : null;
    return (c && c instanceof CompItem) ? c : null;
};

MS.needComp = function () {
    var c = MS.comp();
    if (!c) { throw new Error("Open a composition first"); }
    return c;
};

// Turn AE's internal error text into something an editor can act on.
MS.friendly = function (e) {
    var m = String((e && e.message) || e || "Unknown error");
    if (/locked/i.test(m) && !/unlock/i.test(m)) { return "A selected layer is locked — unlock it (🔒) and try again"; }
    if (/hidden|not visible/i.test(m) && /property/i.test(m)) { return "That property is hidden — twirl it open or select the layer instead"; }
    if (/Unable to call|undefined is not an object|null is not an object/i.test(m)) {
        return "After Effects refused that step (" + m + (e && e.line ? ", line " + e.line : "") + ")";
    }
    return m;
};

// Wrap every action in one undo step + error handling.
MS.run = function (name, fn) {
    var result;
    if (!app.project) { return MS.err("Open or create a project first"); }
    MS._skippedLocked = 0;
    app.beginUndoGroup("MotionSaaS: " + name);
    try {
        result = fn();
    } catch (e) {
        result = MS.err(MS.friendly(e));
    }
    app.endUndoGroup();
    if (MS._skippedLocked && String(result).indexOf("OK|") === 0) {
        result += " (" + MS._skippedLocked + " locked layer" + (MS._skippedLocked === 1 ? "" : "s") + " skipped)";
    }
    MS._skippedLocked = 0;
    return result;
};

MS.rgb = function (hex) {
    hex = String(hex).replace("#", "");
    if (hex.length === 3) {
        hex = hex.charAt(0) + hex.charAt(0) + hex.charAt(1) + hex.charAt(1) + hex.charAt(2) + hex.charAt(2);
    }
    if (!/^[0-9a-fA-F]{6}$/.test(hex)) { throw new Error("“" + hex + "” isn't a colour — use a hex code like #0A84FF"); }
    return [
        parseInt(hex.substr(0, 2), 16) / 255,
        parseInt(hex.substr(2, 2), 16) / 255,
        parseInt(hex.substr(4, 2), 16) / 255
    ];
};

MS.rgba = function (hex) { var c = MS.rgb(hex); c.push(1); return c; };

// A layer with pixels (footage / solid / null / precomp, text, shape) — not a camera or light.
// Use this, never `instanceof AVLayer` alone: in ExtendScript text and shape layers are NOT instanceof
// AVLayer, so that test silently skipped every text and shape layer.
MS.isVisual = function (l) {
    return !!l && (l instanceof AVLayer || l instanceof TextLayer || l instanceof ShapeLayer);
};

MS.selectedLayers = function (c) {
    var out = [], i;
    for (i = 1; i <= c.numLayers; i++) {
        if (c.layer(i).selected) { out.push(c.layer(i)); }
    }
    return out;
};

MS.layerType = function (l) {
    if (l.guideLayer) { return "guide"; }
    if (l instanceof TextLayer) { return "text"; }
    if (l instanceof ShapeLayer) { return "shape"; }
    if (l instanceof CameraLayer) { return "camera"; }
    if (l instanceof LightLayer) { return "light"; }
    if (l.nullLayer) { return "null"; }
    if (l.adjustmentLayer) { return "adjust"; }
    if (l.source) {
        if (l.source instanceof CompItem) { return "precomp"; }
        if (l.source.mainSource instanceof SolidSource) { return "solid"; }
        if (l.source.mainSource && l.source.mainSource.isStill) { return "image"; }
        return "footage";
    }
    return "other";
};

// Number of ease entries a property expects for setTemporalEaseAtKey.
MS.easeDims = function (p) {
    var t = p.propertyValueType;
    if (t === PropertyValueType.TwoD) { return 2; }
    if (t === PropertyValueType.ThreeD) { return 3; }
    return 1;
};

// Apple-style "ease out": quick start, long soft landing.
MS.smooth = function (p) {
    var k, i, n = MS.easeDims(p), inE, outE;
    for (k = 1; k <= p.numKeys; k++) {
        inE = []; outE = [];
        for (i = 0; i < n; i++) {
            inE.push(new KeyframeEase(0, 85));
            outE.push(new KeyframeEase(0, 40));
        }
        p.setTemporalEaseAtKey(k, inE, outE);
    }
};

MS.findColorProp = function (group) {
    var i, p;
    for (i = 1; i <= group.numProperties; i++) {
        p = group.property(i);
        if (p.propertyType === PropertyType.PROPERTY && p.propertyValueType === PropertyValueType.COLOR) { return p; }
    }
    return null;
};

// Rounded-rectangle shape layer, centred in the comp.
MS.roundRect = function (c, name, w, h, radius, hex, fillOpacity, strokeWidth) {
    var l = c.layers.addShape(), g, rect, fill, stroke;
    l.name = name;
    l.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
    g = l.property("ADBE Root Vectors Group").property(1).property("ADBE Vectors Group");
    g.addProperty("ADBE Vector Shape - Rect");
    g.addProperty("ADBE Vector Graphic - Fill");
    if (strokeWidth > 0) { g.addProperty("ADBE Vector Graphic - Stroke"); }
    // Re-fetch after adding (AE invalidates older references).
    g = l.property("ADBE Root Vectors Group").property(1).property("ADBE Vectors Group");
    rect = g.property(1);
    rect.property("ADBE Vector Rect Size").setValue([w, h]);
    rect.property("ADBE Vector Rect Roundness").setValue(radius);
    fill = g.property(2);
    fill.property("ADBE Vector Fill Color").setValue(MS.rgba(hex));
    fill.property("ADBE Vector Fill Opacity").setValue(fillOpacity);
    if (strokeWidth > 0) {
        stroke = g.property(3);
        stroke.property("ADBE Vector Stroke Color").setValue([1, 1, 1, 1]);
        stroke.property("ADBE Vector Stroke Width").setValue(strokeWidth);
        stroke.property("ADBE Vector Stroke Opacity").setValue(35);
    }
    return l;
};

MS.ellipse = function (c, name, size, hex) {
    var l = c.layers.addShape(), g;
    l.name = name;
    l.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
    g = l.property("ADBE Root Vectors Group").property(1).property("ADBE Vectors Group");
    g.addProperty("ADBE Vector Shape - Ellipse");
    g.addProperty("ADBE Vector Graphic - Fill");
    g = l.property("ADBE Root Vectors Group").property(1).property("ADBE Vectors Group");
    g.property(1).property("ADBE Vector Ellipse Size").setValue([size, size]);
    g.property(2).property("ADBE Vector Fill Color").setValue(MS.rgba(hex));
    return l;
};

MS.makeText = function (c, str, size, hex) {
    var l = c.layers.addText(str), p, td, r;
    p = l.property("ADBE Text Properties").property("ADBE Text Document");
    td = p.value;
    try { td.resetCharStyle(); } catch (e) {}   // not on every AE build
    td.fontSize = size;
    td.applyFill = true;
    td.fillColor = MS.rgb(hex);
    td.applyStroke = false;
    td.tracking = -10;
    td.justification = ParagraphJustification.CENTER_JUSTIFY;
    p.setValue(td);
    r = l.sourceRectAtTime(0, false);
    l.transform.anchorPoint.setValue([r.left + r.width / 2, r.top + r.height / 2]);
    l.transform.position.setValue([c.width / 2, c.height / 2]);
    return l;
};

MS.makeNull = function (c, name) {
    var n = c.layers.addNull();
    n.name = name;
    n.transform.anchorPoint.setValue([0, 0]); // children are positioned relative to the null's centre
    n.transform.position.setValue([c.width / 2, c.height / 2]);
    return n;
};

MS.newComp = function (name, hexBg) {
    var c = app.project.items.addComp(name, 1920, 1080, 1, 8, 30), bg;
    bg = c.layers.addSolid(MS.rgb(hexBg || "#0B0B0F"), "Background", c.width, c.height, 1, c.duration);
    bg.locked = true;
    return c;
};

/* --------------------------------------------------------- layer picker */

MS.selectByType = function (type, additive) {
    return MS.run("Select " + type, function () {
        var c = MS.needComp(), i, l, t, want = {}, sel, count = 0, hasWant = false;
        if (type === "same") {
            sel = MS.selectedLayers(c);
            if (!sel.length) { throw new Error("Select a layer first, then click Same"); }
            for (i = 0; i < sel.length; i++) { want[MS.layerType(sel[i])] = true; }
        } else {
            want[type] = true;
        }
        for (i = 1; i <= c.numLayers; i++) {
            l = c.layer(i);
            t = MS.layerType(l);
            if (want[t]) { l.selected = true; count++; hasWant = true; }
            else if (!additive) { l.selected = false; }
        }
        if (!hasWant) { return MS.ok("No matching layers"); }
        return MS.ok(count + " layer" + (count === 1 ? "" : "s") + " selected");
    });
};

MS.toggle = function (what) {
    return MS.run("Toggle " + what, function () {
        var c = MS.needComp(), sel = MS.selectedLayers(c), i, l;
        if (!sel.length) { throw new Error("Select some layers first"); }
        for (i = 0; i < sel.length; i++) {
            l = sel[i];
            if (what === "lock") { l.locked = !l.locked; }
            else if (what === "hide") { l.enabled = !l.enabled; }
            else if (what === "solo") { l.solo = !l.solo; }
            else if (what === "shy") { l.shy = !l.shy; c.hideShyLayers = true; }
        }
        return MS.ok("Toggled " + what + " on " + sel.length + " layer" + (sel.length === 1 ? "" : "s"));
    });
};

/* ------------------------------------------------------- design tools */

// One-click gradient. With layers selected: applies a Gradient Ramp to each.
// With nothing selected: adds a full-frame gradient background at the bottom.
MS.gradient = function (hexA, hexB, radial) {
    return MS.run("Gradient", function () {
        var c = MS.needComp(), sel = MS._editable(MS.selectedLayers(c)), targets = [], i, l, fx, r, a, b, made = false, ca = MS.rgb(hexA), cb = MS.rgb(hexB);
        for (i = 0; i < sel.length; i++) { if (MS.isVisual(sel[i]) && sel[i].property("ADBE Effect Parade")) { targets.push(sel[i]); } }
        if (sel.length && !targets.length) { throw new Error("Gradients need footage, shape, text or solid layers"); }
        if (!sel.length) {
            l = c.layers.addSolid([0, 0, 0], "Gradient Background", c.width, c.height, c.pixelAspect, c.duration);
            l.moveToEnd();
            targets = [l];
            made = true;
        }
        for (i = 0; i < targets.length; i++) {
            l = targets[i];
            if (!l.property("ADBE Effect Parade")) { continue; }
            fx = l.property("ADBE Effect Parade").addProperty("ADBE Ramp");
            if (l instanceof TextLayer || l instanceof ShapeLayer) {
                r = l.sourceRectAtTime(c.time, false);
                a = [r.left, r.top]; b = [r.left + r.width, r.top + r.height];
            } else {
                a = [0, 0]; b = [l.width, l.height];
            }
            if (radial) {
                fx.property(1).setValue([(a[0] + b[0]) / 2, (a[1] + b[1]) / 2]);
                fx.property(3).setValue(b);
                fx.property(5).setValue(2);
            } else {
                fx.property(1).setValue(a);
                fx.property(3).setValue(b);
                fx.property(5).setValue(1);
            }
            fx.property(2).setValue(ca);
            fx.property(4).setValue(cb);
        }
        return MS.ok(made ? "Gradient background added" : "Gradient applied to " + targets.length + " layer" + (targets.length === 1 ? "" : "s"));
    });
};

// Fill a 4-Color Gradient by property type, not index (effect topics shift indexes between AE versions).
// seed < 0 = static points; otherwise each point drifts with its own wiggle.
MS._fill4Color = function (fx, pts, cols, seed, drift) {
    var i, p, points = [], colors = [], blend = null;
    for (i = 1; i <= fx.numProperties; i++) {
        p = fx.property(i);
        if (p.propertyType !== PropertyType.PROPERTY) { continue; }
        if (p.propertyValueType === PropertyValueType.TwoD_SPATIAL) { points.push(p); }
        else if (p.propertyValueType === PropertyValueType.COLOR) { colors.push(p); }
        else if (!blend && colors.length === 4 && p.propertyValueType === PropertyValueType.OneD) { blend = p; }
    }
    for (i = 0; i < 4 && i < points.length; i++) {
        points[i].setValue(pts[i]);
        if (seed >= 0) { points[i].expression = "seedRandom(" + (seed + i) + ", true);\nwiggle(0.25, " + Math.round(drift) + ");"; }
    }
    for (i = 0; i < 4 && i < colors.length; i++) { colors[i].setValue(MS.rgb(cols[i % cols.length])); }
    if (blend) { try { blend.setValue(150); } catch (e) {} }
};

// Soft 4-colour "aurora" background, optionally drifting.
MS.mesh = function (h1, h2, h3, h4, animate) {
    return MS.run("Mesh background", function () {
        var c = MS.needComp(), l, fx, cols = [h1, h2, h3, h4], pts, i;
        l = c.layers.addSolid([0, 0, 0], "Mesh Background", c.width, c.height, c.pixelAspect, c.duration);
        l.moveToEnd();
        l.property("ADBE Effect Parade").addProperty("ADBE 4ColorGradient");
        pts = [[c.width * 0.15, c.height * 0.15], [c.width * 0.85, c.height * 0.2],
               [c.width * 0.2, c.height * 0.85], [c.width * 0.85, c.height * 0.85]];
        MS._fill4Color(l.property("ADBE Effect Parade").property(l.property("ADBE Effect Parade").numProperties), pts, cols, animate ? 3 : -1, 0.18 * c.width);
        return MS.ok(animate ? "Animated mesh background added" : "Mesh background added");
    });
};

// Frosted glass card: blur adjustment (masked by a rounded matte) + translucent surface + control null.
MS.glass = function (w, h, radius, blur, opacity) {
    return MS.run("Glass card", function () {
        var c = MS.needComp(), adj, fx, matte, surface, ctrl;
        adj = c.layers.addSolid([1, 1, 1], "Glass • Blur", c.width, c.height, c.pixelAspect, c.duration);
        adj.adjustmentLayer = true;
        fx = adj.property("ADBE Effect Parade").addProperty("ADBE Gaussian Blur 2");
        fx.property(1).setValue(blur);
        try { fx.property(3).setValue(1); } catch (e1) {} // Repeat edge pixels

        matte = MS.roundRect(c, "Glass • Matte", w, h, radius, "#FFFFFF", 100, 0); // sits directly above adj
        if (typeof adj.setTrackMatte === "function") {       // AE 2023+
            adj.setTrackMatte(matte, TrackMatteType.ALPHA);
        } else {                                               // AE 2020–2022
            adj.trackMatteType = TrackMatteType.ALPHA;
        }
        matte.enabled = false;

        surface = MS.roundRect(c, "Glass • Surface", w, h, radius, "#FFFFFF", opacity, 1.5);
        try {
            fx = surface.property("ADBE Effect Parade").addProperty("ADBE Drop Shadow");
            fx.property(2).setValue(18);   // opacity
            fx.property(4).setValue(12);   // distance
            fx.property(5).setValue(40);   // softness
        } catch (e2) {}

        ctrl = MS.makeNull(c, "Glass Card ▸ move me");
        matte.parent = ctrl;
        surface.parent = ctrl;
        ctrl.selected = true;
        return MS.ok("Glass card added — move the “Glass Card” null");
    });
};

/* ------------------------------------------------------ text animation */

MS._pos = function (l) {
    var pos = l.transform.position;
    if (pos.dimensionsSeparated) {
        return { x: l.transform.property("ADBE Position_0"), y: l.transform.property("ADBE Position_1"), sep: true };
    }
    return { p: pos, sep: false };
};

MS._offsetIn = function (l, t, d, dx, dy) {
    var P = MS._pos(l), v;
    if (P.sep) {
        if (dx) { v = P.x.valueAtTime(t, false); P.x.setValueAtTime(t, v + dx); P.x.setValueAtTime(t + d, v); MS.smooth(P.x); }
        if (dy) { v = P.y.valueAtTime(t, false); P.y.setValueAtTime(t, v + dy); P.y.setValueAtTime(t + d, v); MS.smooth(P.y); }
    } else {
        v = P.p.valueAtTime(t, false);
        var s = v.slice(0); s[0] += dx; s[1] += dy;
        P.p.setValueAtTime(t, s); P.p.setValueAtTime(t + d, v); MS.smooth(P.p);
    }
};

MS._fadeIn = function (l, t, d) {
    var o = l.transform.opacity, v = o.valueAtTime(t, false);
    o.setValueAtTime(t, 0); o.setValueAtTime(t + d * 0.8, v); MS.smooth(o);
};

MS._textAnimator = function (l, t, d, kind) {
    var animators = l.property("ADBE Text Properties").property("ADBE Text Animators"), anim, props, sel, n;
    animators.addProperty("ADBE Text Animator");
    n = animators.numProperties;
    anim = animators.property(n);
    anim.name = kind === "typewriter" ? "MS Typewriter" : "MS Cascade";
    props = anim.property("ADBE Text Animator Properties");
    props.addProperty("ADBE Text Opacity");
    if (kind === "cascade") {
        // Re-fetch: AE invalidates `props` after the addProperty above.
        animators.property(n).property("ADBE Text Animator Properties").addProperty("ADBE Text Position 3D");
    }
    anim = animators.property(n);
    props = anim.property("ADBE Text Animator Properties");
    props.property("ADBE Text Opacity").setValue(0);
    if (kind === "cascade") { props.property("ADBE Text Position 3D").setValue([0, 60, 0]); }

    anim.property("ADBE Text Selectors").addProperty("ADBE Text Selector");
    anim = animators.property(n);
    sel = anim.property("ADBE Text Selectors").property(1);
    if (kind === "typewriter") {
        var st = sel.property("ADBE Text Percent Start");
        st.setValueAtTime(t, 0); st.setValueAtTime(t + d, 100);
    } else {
        try { sel.property("ADBE Text Range Advanced").property("ADBE Text Range Shape").setValue(2); } catch (e) {} // Ramp Up
        var off = sel.property("ADBE Text Percent Offset");
        off.setValueAtTime(t, -100); off.setValueAtTime(t + d, 100);
        MS.smooth(off);
    }
};

// preset: fadeUp | pop | blurIn | slideIn | typewriter | cascade
MS._animateLayer = function (c, l, preset, t, d) {
    var s, v, fx, b;
    if (!(MS.isVisual(l))) { return false; }   // cameras / lights have no opacity or effects
    if (preset === "fadeUp") { MS._fadeIn(l, t, d); MS._offsetIn(l, t, d, 0, 60); }
    else if (preset === "slideIn") { MS._fadeIn(l, t, d); MS._offsetIn(l, t, d, 160, 0); }
    else if (preset === "pop") {
        s = l.transform.scale; v = s.valueAtTime(t, false);
        var zero = [], over = [], i;
        for (i = 0; i < v.length; i++) { zero.push(0); over.push(v[i] * 1.08); }
        s.setValueAtTime(t, zero); s.setValueAtTime(t + d * 0.6, over); s.setValueAtTime(t + d, v);
        MS.smooth(s); MS._fadeIn(l, t, d * 0.5);
    }
    else if (preset === "blurIn") {
        fx = l.property("ADBE Effect Parade").addProperty("ADBE Gaussian Blur 2");
        b = fx.property(1); b.setValueAtTime(t, 60); b.setValueAtTime(t + d, 0); MS.smooth(b);
        MS._fadeIn(l, t, d);
    }
    else if (preset === "typewriter" || preset === "cascade") {
        if (!(l instanceof TextLayer)) { return false; }
        MS._textAnimator(l, t, d, preset);
    }
    return true;
};

MS.animate = function (preset, duration, stagger) {
    return MS.run("Animate " + preset, function () {
        var c = MS.needComp(), sel = MS._editable(MS.selectedLayers(c)), i, t = c.time, done = 0;
        if (!sel.length) { throw new Error("Select the layers to animate"); }
        for (i = 0; i < sel.length; i++) {
            if (MS._animateLayer(c, sel[i], preset, t + i * (stagger || 0), duration)) { done++; }
        }
        if (!done) { throw new Error(preset === "typewriter" || preset === "cascade" ? "This preset only works on text layers" : "Select footage, shape or text layers (not cameras or lights)"); }
        return MS.ok("Animated " + done + " layer" + (done === 1 ? "" : "s"));
    });
};

/* ----------------------------------------------------------- colours */

MS._fillShapes = function (group, rgba) {
    var i, p, n = 0;
    for (i = 1; i <= group.numProperties; i++) {
        p = group.property(i);
        if (p.matchName === "ADBE Vector Fill Color") { p.setValue(rgba); n++; }
        else if (p.propertyType !== PropertyType.PROPERTY) { n += MS._fillShapes(p, rgba); }
    }
    return n;
};

// Colour via a Fill effect (reuses an existing MotionSaaS fill so repeated clicks don't stack effects).
MS._fillEffect = function (l, rgb) {
    var fxp = l.property("ADBE Effect Parade"), i, fx = null, cp;
    for (i = 1; i <= fxp.numProperties; i++) {
        if (fxp.property(i).matchName === "ADBE Fill" && fxp.property(i).name === "MS Colour") { fx = fxp.property(i); break; }
    }
    if (!fx) {
        i = fxp.addProperty("ADBE Fill").propertyIndex;
        fx = l.property("ADBE Effect Parade").property(i);
        fx.name = "MS Colour";
    }
    cp = MS.findColorProp(fx);
    if (cp) { MS._set(cp, rgb, l.containingComp.time); }
};

MS.color = function (hex) {
    return MS.run("Apply colour", function () {
        var c = MS.needComp(), sel = MS._editable(MS.selectedLayers(c)), i, l, p, td, rgb = MS.rgb(hex), n = 0, src;
        if (!sel.length) { throw new Error("Select layers to colour"); }
        for (i = 0; i < sel.length; i++) {
            l = sel[i];
            if (!(MS.isVisual(l))) { continue; }
            if (l instanceof TextLayer) {
                p = l.property("ADBE Text Properties").property("ADBE Text Document");
                td = p.value; td.applyFill = true; td.fillColor = rgb;
                if (p.numKeys > 0) { p.setValueAtTime(c.time, td); } else { p.setValue(td); }
            } else if (l instanceof ShapeLayer) {
                // Shapes with only strokes / gradient fills get a Fill effect instead of silently doing nothing.
                if (!MS._fillShapes(l.property("ADBE Root Vectors Group"), MS.rgba(hex))) { MS._fillEffect(l, rgb); }
            } else if (MS.layerType(l) === "solid") {
                src = l.source;
                // Changing a shared solid would recolour every layer that uses it — only do that when it's ours alone.
                if (src.usedIn.length <= 1 && MS._solidUses(src) <= 1) { src.mainSource.color = rgb; }
                else { MS._fillEffect(l, rgb); }
            } else if (l.property("ADBE Effect Parade")) {
                MS._fillEffect(l, rgb);
            } else { continue; }
            n++;
        }
        if (!n) { throw new Error("Select text, shape, solid or footage layers to colour"); }
        return MS.ok("Coloured " + MS._plural(n, "layer"));
    });
};

// How many layers (across all comps) use this solid.
MS._solidUses = function (src) {
    var i, j, c, n = 0;
    for (i = 0; i < src.usedIn.length; i++) {
        c = src.usedIn[i];
        // Compare ids: two ExtendScript wrappers for the same item are not always ===.
        for (j = 1; j <= c.numLayers; j++) { if (c.layer(j).source && c.layer(j).source.id === src.id) { n++; } }
    }
    return n;
};

/* ---------------------------------------------------------- palettes */
// Linked palettes (js/ms-palettes.js). A palette that layers are linked to lives in the project: a null named
// after the palette in the comp "MS Palettes", with one Color Control per swatch ("Colour 1", "Colour 2", …).
// A linked layer's fill colour gets a short expression reading that control, so changing a swatch in the panel
// recolours every linked layer in every comp at once. Unlink bakes the current colour back in.
MS._PAL_COMP = "MS Palettes";
MS._PAL_MARK = "// MotionSaaS Palette";
MS._hexOf = function (c) {
    var s = "#", i, v;
    for (i = 0; i < 3; i++) {
        v = Math.round(Math.max(0, Math.min(1, c[i])) * 255).toString(16).toUpperCase();
        s += v.length < 2 ? "0" + v : v;
    }
    return s;
};
MS._palComp = function (make) {
    var i, it;
    for (i = 1; i <= app.project.numItems; i++) {
        it = app.project.item(i);
        if (it instanceof CompItem && it.name === MS._PAL_COMP) { return it; }
    }
    if (!make) { return null; }
    it = app.project.items.addComp(MS._PAL_COMP, 200, 200, 1, 10, 30);
    it.comment = "MotionSaaS: your linked colour palettes. Layers read their colours from here; edit them in the MotionSaaS panel.";
    return it;
};
MS._palLayer = function (pc, name) {
    var i;
    for (i = 1; i <= pc.numLayers; i++) { if (pc.layer(i).name === name) { return pc.layer(i); } }
    return null;
};
// Create or update the palette in the project. o: { name, colors: ["#RRGGBB", …] }
MS._palSync = function (o) {
    var pc = MS._palComp(true), name = String(o.name), l = MS._palLayer(pc, name), i, fx, nm;
    if (!l) { l = pc.layers.addNull(); l.name = name; l.comment = MS._json({ msPalette: true }); }
    for (i = 0; i < o.colors.length; i++) {
        nm = "Colour " + (i + 1);
        fx = MS._fxNamed(l, nm);
        if (!fx) {
            fx = l.property("ADBE Effect Parade").addProperty("ADBE Color Control");
            fx.name = nm;
            l = MS._palLayer(pc, name);   // addProperty invalidates references
            fx = MS._fxNamed(l, nm);
        }
        MS._set(fx.property(1), MS.rgba(o.colors[i]), 0);
    }
    return l;
};
MS._palExpr = function (name, idx) {
    return MS._PAL_MARK + " (edit the colours in the MotionSaaS panel)\ntry { comp(" + MS._json(MS._PAL_COMP) + ").layer(" + MS._json(name) +
        ").effect(" + MS._json("Colour " + idx) + ")(1); } catch (e) { value; }";
};
MS._palOurs = function (p) { return String(p.expression || "").indexOf(MS._PAL_MARK) === 0; };
// Every colour property under a group (shape fills / strokes, effect colours), depth first.
MS._palColors = function (g, out) {
    var i, p;
    for (i = 1; i <= g.numProperties; i++) {
        p = g.property(i);
        if (p.propertyType === PropertyType.PROPERTY) {
            if (p.propertyValueType === PropertyValueType.COLOR) { out.push(p); }
        } else { MS._palColors(p, out); }
    }
    return out;
};
// The colour properties a link drives on a layer: a shape layer's fills, else the "MS Colour" Fill effect
// (added when needed — it colours text, solids and footage alike).
MS._palTargets = function (l) {
    var out = [], all, i, fxp, fx = null;
    if (l instanceof ShapeLayer) {
        all = MS._palColors(l.property("ADBE Root Vectors Group"), []);
        for (i = 0; i < all.length; i++) { if (all[i].matchName === "ADBE Vector Fill Color") { out.push(all[i]); } }
        if (out.length) { return out; }
    }
    if (!l.property("ADBE Effect Parade")) { return out; }
    MS._fillEffect(l, [1, 1, 1, 1]);
    fxp = l.property("ADBE Effect Parade");
    for (i = 1; i <= fxp.numProperties; i++) { if (fxp.property(i).name === "MS Colour") { fx = fxp.property(i); } }
    if (fx && MS.findColorProp(fx)) { out.push(MS.findColorProp(fx)); }
    return out;
};

// Link the selected layers to swatch `index` (1-based) of palette o ({ name, colors }), creating / updating
// the palette in the project. Colours that carry an expression of the user's own are left alone (and counted).
MS.paletteLink = function (json, index) {
    return MS.run("Link palette colour", function () {
        var o = MS._parseJSON(json), c = MS.needComp(), sel = MS._editable(MS.selectedLayers(c)), i, j, t, n = 0, own = 0, done, idx = Math.round(Number(index)), hex;
        if (!o || !o.name || !(o.colors instanceof Array) || idx < 1 || idx > o.colors.length) { return MS.err("Pick a swatch of a palette first"); }
        if (!sel.length) { return MS.err("Select the layers to link"); }
        hex = o.colors[idx - 1];
        MS.rgb(hex);   // throws a friendly error for a bad colour, before anything changes
        MS._palSync(o);
        for (i = 0; i < sel.length; i++) {
            if (!MS.isVisual(sel[i])) { continue; }
            t = MS._palTargets(sel[i]);
            done = false;
            for (j = 0; j < t.length; j++) {
                if (t[j].expression && !MS._palOurs(t[j])) { own++; continue; }
                MS._set(t[j], MS.rgba(hex), c.time);
                t[j].expression = MS._palExpr(o.name, idx);
                done = true;
            }
            if (done) { n++; }
        }
        if (!n) { return MS.err(own ? "Those colours already have expressions of your own; nothing was changed" : "Select text, shape, solid or footage layers to link"); }
        return MS.ok("Linked " + MS._plural(n, "layer") + " to " + o.name + " · colour " + idx + (own ? " (" + own + " with your own expressions left alone)" : ""));
    });
};

// Unlink the selected layers: every palette expression is removed and the colour it showed is kept.
MS.paletteUnlink = function () {
    return MS.run("Unlink palette colours", function () {
        var c = MS.needComp(), sel = MS._editable(MS.selectedLayers(c)), i, j, ps, v, n = 0, k;
        if (!sel.length) { return MS.err("Select the linked layers to unlink"); }
        for (i = 0; i < sel.length; i++) {
            ps = MS._palColors(sel[i], []);
            k = 0;
            for (j = 0; j < ps.length; j++) {
                if (!MS._palOurs(ps[j])) { continue; }
                v = ps[j].valueAtTime(c.time, false);
                ps[j].expression = "";
                MS._set(ps[j], v, c.time);
                k++;
            }
            if (k) { n++; }
        }
        if (!n) { return MS.err("None of the selected layers is linked to a palette"); }
        return MS.ok("Unlinked " + MS._plural(n, "layer") + " (they keep their colours)");
    });
};

// Update a palette that is already in the project (its linked layers follow). Not in the project: nothing to do.
MS.paletteSync = function (json) {
    return MS.run("Update palette", function () {
        var o = MS._parseJSON(json), pc = MS._palComp(false), i;
        if (!pc || !MS._palLayer(pc, String(o.name))) { return MS.ok("0"); }
        for (i = 0; i < o.colors.length; i++) { MS.rgb(o.colors[i]); }
        MS._palSync(o);
        return MS.ok("1");
    });
};

// The palettes stored in this project → [{ name, colors }]. Read only.
MS.paletteProject = function () {
    var pc = MS._palComp(false), out = [], i, j, l, cols, fx;
    if (!pc) { return MS.ok("[]"); }
    for (i = 1; i <= pc.numLayers; i++) {
        l = pc.layer(i);
        cols = [];
        for (j = 1; ; j++) {
            fx = MS._fxNamed(l, "Colour " + j);
            if (!fx) { break; }
            cols.push(MS._hexOf(fx.property(1).valueAtTime(0, false)));
        }
        if (cols.length) { out.push({ name: l.name, colors: cols }); }
    }
    return MS.ok(MS._json(out));
};

// Rename a project palette, keeping its links: every palette expression in every comp that names it is rewritten.
MS.paletteRename = function (from, to) {
    return MS.run("Rename palette", function () {
        var pc = MS._palComp(false), l, i, j, it, ps, k, a, b, n = 0;
        from = String(from); to = String(to);
        if (!pc || !(l = MS._palLayer(pc, from))) { return MS.ok("0"); }
        if (MS._palLayer(pc, to)) { return MS.err("There's already a palette called " + to + " in this project"); }
        l.name = to;
        a = ".layer(" + MS._json(from) + ")";
        b = ".layer(" + MS._json(to) + ")";
        for (i = 1; i <= app.project.numItems; i++) {
            it = app.project.item(i);
            if (!(it instanceof CompItem) || it === pc) { continue; }
            for (j = 1; j <= it.numLayers; j++) {
                ps = MS._palColors(it.layer(j), []);
                for (k = 0; k < ps.length; k++) {
                    if (MS._palOurs(ps[k]) && String(ps[k].expression).indexOf(a) !== -1) { ps[k].expression = String(ps[k].expression).split(a).join(b); n++; }
                }
            }
        }
        return MS.ok(String(n));
    });
};

// The colours the selected layers use (or every layer's, when none is selected): shape fills and strokes,
// text fill, solid colours and effect colours. Most used first, at most 24. Read only.
MS.paletteUsed = function () {
    var c = MS.comp(), list, i, j, l, ps, seen = {}, order = [], add, td, v;
    if (!c) { return MS.err("Open a composition first"); }
    list = MS.selectedLayers(c);
    if (!list.length) { list = []; for (i = 1; i <= c.numLayers; i++) { list.push(c.layer(i)); } }
    add = function (rgb) {
        var h = MS._hexOf(rgb);
        if (!seen[h]) { seen[h] = 0; order.push(h); }
        seen[h]++;
    };
    for (i = 0; i < list.length; i++) {
        l = list[i];
        if (!MS.isVisual(l)) { continue; }
        if (l instanceof TextLayer) {
            try { td = l.property("ADBE Text Properties").property("ADBE Text Document").valueAtTime(c.time, false); if (td.applyFill !== false && td.fillColor) { add(td.fillColor); } } catch (eT) {}
        }
        if (MS.layerType(l) === "solid") { try { add(l.source.mainSource.color); } catch (eS) {} }
        ps = MS._palColors(l, []);
        for (j = 0; j < ps.length; j++) {
            try { v = ps[j].valueAtTime(c.time, false); if (v && v.length >= 3) { add(v); } } catch (eV) {}
        }
    }
    order.sort(function (a, b) { return seen[b] - seen[a]; });
    return MS.ok(MS._json(order.slice(0, 24)));
};

/* ---------------------------------------------------------- templates */

MS.template = function (name, colorsCSV) {
    return MS.run("Template " + name, function () {
        var cols = String(colorsCSV || "#0A84FF,#30D158,#FF9F0A,#FF375F,#BF5AF2").split(","), c;
        if (name === "cta") { c = MS._tplCTA(cols); }
        else if (name === "search") { c = MS._tplSearch(cols); }
        else if (name === "carousel") { c = MS._tplCarousel(cols); }
        else if (name === "intro") { c = MS._tplIntro(cols); }
        else { throw new Error("Unknown template"); }
        c.openInViewer();
        return MS.ok("Created “" + c.name + "”");
    });
};

MS._tplCTA = function (cols) {
    var c = MS.newComp("MS — CTA Button"), ctrl, pill, label, ripple, s, sc, op;
    ripple = MS.ellipse(c, "Click Ripple", 140, "#FFFFFF");
    pill = MS.roundRect(c, "Button", 560, 128, 64, cols[0], 100, 0);
    label = MS.makeText(c, "Get Started  →", 52, "#FFFFFF");
    ctrl = MS.makeNull(c, "CTA ▸ control");
    pill.parent = ctrl; label.parent = ctrl; ripple.parent = ctrl;

    s = ctrl.transform.scale;
    s.setValueAtTime(0.3, [0, 0, 100]); s.setValueAtTime(0.75, [106, 106, 100]); s.setValueAtTime(1.0, [100, 100, 100]);
    s.setValueAtTime(2.0, [100, 100, 100]); s.setValueAtTime(2.12, [93, 93, 100]); s.setValueAtTime(2.4, [100, 100, 100]);
    MS.smooth(s);

    sc = ripple.transform.scale; op = ripple.transform.opacity;
    sc.setValueAtTime(2.1, [0, 0, 100]); sc.setValueAtTime(2.8, [420, 420, 100]); MS.smooth(sc);
    op.setValueAtTime(2.1, 45); op.setValueAtTime(2.8, 0);
    return c;
};

MS._tplSearch = function (cols) {
    var c = MS.newComp("MS — Search Bar"), bar, icon, txt, ctrl, caret;
    bar = MS.roundRect(c, "Search Bar", 1180, 120, 60, "#1C1C1E", 100, 1.5);
    icon = MS.ellipse(c, "Search Dot", 34, cols[0]);
    icon.transform.position.setValue([c.width / 2 - 520, c.height / 2]);
    txt = MS.makeText(c, "Make a launch video for my SaaS", 46, "#FFFFFF");
    caret = MS.roundRect(c, "Caret", 4, 54, 2, cols[0], 100, 0);
    caret.transform.position.setValue([c.width / 2 + 400, c.height / 2]);
    caret.transform.opacity.expression = "Math.round(time * 2) % 2 == 0 ? 100 : 0;";
    ctrl = MS.makeNull(c, "Search ▸ control");
    bar.parent = ctrl; icon.parent = ctrl; txt.parent = ctrl; caret.parent = ctrl;
    MS._fadeIn(ctrl, 0.2, 0.6);
    MS._animateLayer(c, bar, "fadeUp", 0.2, 0.7);
    MS._animateLayer(c, txt, "typewriter", 0.9, 1.8);
    return c;
};

MS._tplCarousel = function (cols) {
    var c = MS.newComp("MS — Carousel"), ctrl, card, i, n = 5, gap = 640, x, k;
    ctrl = MS.makeNull(c, "Carousel ▸ control");
    for (i = 0; i < n; i++) {
        card = MS.roundRect(c, "Card " + (i + 1), 560, 360, 40, cols[i % cols.length], 100, 0);
        card.parent = ctrl;
        card.transform.position.setValue([i * gap - 0, 0]);
        card.transform.scale.expression =
            "var d = Math.abs(toComp([0,0])[0] - thisComp.width/2);\nvar s = linear(d, 0, 700, 100, 82);\n[s, s];";
        card.transform.opacity.expression =
            "var d = Math.abs(toComp([0,0])[0] - thisComp.width/2);\nlinear(d, 0, 1400, 100, 35);";
    }
    x = ctrl.transform.position;
    for (k = 0; k < n; k++) {
        x.setValueAtTime(0.5 + k * 1.4, [c.width / 2 - k * gap, c.height / 2]);
        if (k < n - 1) { x.setValueAtTime(0.5 + k * 1.4 + 0.8, [c.width / 2 - k * gap, c.height / 2]); }
    }
    MS.smooth(x);
    ctrl.moveToBeginning();
    return c;
};

MS._tplIntro = function (cols) {
    var c = MS.newComp("MS — Intro Title"), fx, title, sub, bg;
    bg = c.layers.addSolid([0, 0, 0], "Mesh Background", c.width, c.height, 1, c.duration);
    bg.moveToEnd();
    bg.property("ADBE Effect Parade").addProperty("ADBE 4ColorGradient");
    MS._fill4Color(bg.property("ADBE Effect Parade").property(1), [[300, 200], [1600, 250], [350, 900], [1650, 880]], cols, 7, 260);
    title = MS.makeText(c, "Introducing Your Product", 120, "#FFFFFF");
    title.transform.position.setValue([c.width / 2, c.height / 2 - 40]);
    sub = MS.makeText(c, "The fastest way to ship beautiful launch videos", 44, "#FFFFFF");
    sub.transform.position.setValue([c.width / 2, c.height / 2 + 80]);
    sub.transform.opacity.setValue(75);
    MS._animateLayer(c, title, "cascade", 0.3, 1.4);
    MS._animateLayer(c, sub, "fadeUp", 1.2, 0.8);
    return c;
};

/* ------------------------------------------------------- tool helpers */

MS._plural = function (n, word) { return n + " " + word + (n === 1 ? "" : "s"); };

// `list` without its locked layers, counted for MS.run's "(n locked layers skipped)" note.
MS._editable = function (list) {
    var out = [], i;
    for (i = 0; i < list.length; i++) {
        if (list[i].locked) { MS._skippedLocked = (MS._skippedLocked || 0) + 1; } else { out.push(list[i]); }
    }
    return out;
};
// The selected layers a tool may change: locked ones are left out (After Effects refuses edits to them, which
// used to stop a tool half-way). MS.run then adds "n locked layers skipped" to the tool's message. keepLocked:
// for tools that only read (Save effects).
MS._needSel = function (c, min, msg, keepLocked) {
    var all = MS.selectedLayers(c), sel = [], locked = 0, i;
    min = min || 1;
    for (i = 0; i < all.length; i++) {
        if (!keepLocked && all[i].locked) { locked++; } else { sel.push(all[i]); }
    }
    if (sel.length < min && all.length >= min && locked) {
        throw new Error(locked === all.length ? (locked === 1 ? "The selected layer is locked" : "The selected layers are locked") + " — unlock them (🔒) and try again"
            : locked + " of the selected layers " + (locked === 1 ? "is" : "are") + " locked — unlock " + (locked === 1 ? "it" : "them") + " (🔒) and try again");
    }
    if (sel.length < min) { throw new Error(msg || "Select some layers first"); }
    MS._skippedLocked = locked;
    return sel;
};

// Quote a string for use inside an expression.
MS._q = function (s) {
    return '"' + String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r?\n/g, "\\r") + '"';
};

// Set now, or at time t when the property is keyframed.
MS._set = function (p, v, t) {
    if (p.numKeys > 0) { p.setValueAtTime(t, v); } else { p.setValue(v); }
};

// Add a delta to a property's value, or to every keyframe so the animation keeps its shape.
MS._shiftProp = function (p, d) {
    var k, v;
    var add = function (val) {
        var i;
        if (val instanceof Array) {
            for (i = 0; i < d.length && i < val.length; i++) { val[i] += d[i]; }
            return val;
        }
        return val + d[0];
    };
    if (p.numKeys > 0) {
        for (k = 1; k <= p.numKeys; k++) { v = add(p.keyValue(k)); p.setValueAtKey(k, v); }
    } else {
        v = add(p.value); p.setValue(v);
    }
};

MS._shiftPosition = function (l, dx, dy) {
    if (l.transform.position.dimensionsSeparated) {
        MS._shiftProp(l.transform.property("ADBE Position_0"), [dx]);
        MS._shiftProp(l.transform.property("ADBE Position_1"), [dy]);
    } else {
        MS._shiftProp(l.transform.position, [dx, dy]);
    }
};

MS._setPositionXY = function (l, x, y, t) {
    var p = l.transform.position, v;
    if (p.dimensionsSeparated) {
        MS._set(l.transform.property("ADBE Position_0"), x, t);
        MS._set(l.transform.property("ADBE Position_1"), y, t);
    } else {
        v = p.valueAtTime(t, false); v[0] = x; v[1] = y;
        MS._set(p, v, t);
    }
};

// Layer-space content box.
MS._rect = function (l, t) {
    var r;
    if (l instanceof TextLayer || l instanceof ShapeLayer) {
        r = l.sourceRectAtTime(t, false);
        return { left: r.left, top: r.top, width: r.width, height: r.height };
    }
    return { left: 0, top: 0, width: l.width, height: l.height };
};

// Evaluate a 2D expression on the layer (via a temporary Point Control) and return the result.
// Throws if the expression fails, so callers never move a layer by a bogus [0, 0].
MS._exprPoint = function (l, expr, t) {
    var fx = l.property("ADBE Effect Parade").addProperty("ADBE Point Control"), idx = fx.propertyIndex, v, errText = "";
    fx = l.property("ADBE Effect Parade").property(idx);
    try {
        fx.property(1).expression = expr;
        v = fx.property(1).valueAtTime(t, false);
        errText = fx.property(1).expressionError || "";
        if (!errText && (!(v instanceof Array) || isNaN(v[0]) || isNaN(v[1]))) { errText = "no result"; }
    } finally {
        l.property("ADBE Effect Parade").property(idx).remove();
    }
    if (errText) { throw new Error("Couldn't measure “" + l.name + "” (" + errText + ")"); }
    return v;
};

MS._boundsExpr = function (fn) {
    return "var r = thisLayer.sourceRectAtTime(time, false);\n" +
        "var p = [toComp([r.left, r.top]), toComp([r.left + r.width, r.top]), toComp([r.left, r.top + r.height]), toComp([r.left + r.width, r.top + r.height])];\n" +
        "var x = p[0][0], y = p[0][1];\n" +
        "for (var i = 1; i < 4; i++) { x = Math." + fn + "(x, p[i][0]); y = Math." + fn + "(y, p[i][1]); }\n" +
        "[x, y];";
};

// Axis-aligned box of the layer as it appears in the comp (handles parents, scale, rotation).
MS._compBounds = function (l, t) {
    var a, b;
    if (!(MS.isVisual(l)) || !l.property("ADBE Effect Parade")) { return null; }
    a = MS._exprPoint(l, MS._boundsExpr("min"), t);
    b = MS._exprPoint(l, MS._boundsExpr("max"), t);
    return { left: a[0], top: a[1], right: b[0], bottom: b[1] };
};

// Move a layer by a comp-space offset, converting into its parent's space when parented.
MS._moveInComp = function (l, dx, dy, t) {
    var v;
    if (l.parent) {
        v = MS._exprPoint(l, "var a = parent.fromComp([" + dx + ", " + dy + "]), b = parent.fromComp([0, 0]);\n[a[0] - b[0], a[1] - b[1]];", t);
        dx = v[0]; dy = v[1];
    }
    MS._shiftPosition(l, dx, dy);
};

// Move the anchor point to a spot in the content box (0..1) without the layer jumping.
MS._anchorTo = function (l, fx, fy, t) {
    var r = MS._rect(l, t), a = l.transform.anchorPoint.valueAtTime(t, false),
        s = l.transform.scale.valueAtTime(t, false),
        rot = l.transform.rotation.valueAtTime(t, false) * Math.PI / 180,
        d = [r.left + r.width * fx - a[0], r.top + r.height * fy - a[1]],
        sx = d[0] * s[0] / 100, sy = d[1] * s[1] / 100;
    MS._shiftProp(l.transform.anchorPoint, d);
    MS._shiftPosition(l, sx * Math.cos(rot) - sy * Math.sin(rot), sx * Math.sin(rot) + sy * Math.cos(rot));
};

// Every keyframed property inside a layer or group.
MS._keyedProps = function (group, out) {
    var i, p;
    out = out || [];
    for (i = 1; i <= group.numProperties; i++) {
        try { p = group.property(i); } catch (e) { continue; }
        if (!p) { continue; }
        if (p.propertyType === PropertyType.PROPERTY) {
            if (p.numKeys > 0 && p.matchName !== "ADBE Marker") { out.push(p); }
        } else {
            MS._keyedProps(p, out);
        }
    }
    return out;
};

/* ------------------------------------------------------------ layout */

MS.anchor = function (fx, fy) {
    return MS.run("Move anchor", function () {
        var c = MS.needComp(), sel = MS._needSel(c), i, n = 0;
        for (i = 0; i < sel.length; i++) {
            if (!(MS.isVisual(sel[i]))) { continue; }
            MS._anchorTo(sel[i], fx, fy, c.time);
            n++;
        }
        return MS.ok("Anchor moved on " + MS._plural(n, "layer"));
    });
};

// where: left | hcenter | right | top | vcenter | bottom
MS.align = function (where, toSelection) {
    return MS.run("Align " + where, function () {
        var c = MS.needComp(), sel = MS._needSel(c), t = c.time, bs = [], box = null, i, b, dx, dy, n = 0;
        if (toSelection && sel.length < 2) { throw new Error("Select 2 or more layers to align to the selection"); }
        for (i = 0; i < sel.length; i++) {
            b = MS._compBounds(sel[i], t);
            bs.push(b);
            if (b && toSelection) {
                if (!box) { box = { left: b.left, top: b.top, right: b.right, bottom: b.bottom }; }
                else {
                    box.left = Math.min(box.left, b.left); box.top = Math.min(box.top, b.top);
                    box.right = Math.max(box.right, b.right); box.bottom = Math.max(box.bottom, b.bottom);
                }
            }
        }
        if (!toSelection) { box = { left: 0, top: 0, right: c.width, bottom: c.height }; }
        if (!box) { throw new Error("Nothing to align"); }
        for (i = 0; i < sel.length; i++) {
            b = bs[i];
            if (!b) { continue; }
            dx = 0; dy = 0;
            if (where === "left") { dx = box.left - b.left; }
            else if (where === "hcenter") { dx = (box.left + box.right - b.left - b.right) / 2; }
            else if (where === "right") { dx = box.right - b.right; }
            else if (where === "top") { dy = box.top - b.top; }
            else if (where === "vcenter") { dy = (box.top + box.bottom - b.top - b.bottom) / 2; }
            else if (where === "bottom") { dy = box.bottom - b.bottom; }
            if (dx || dy) { MS._moveInComp(sel[i], dx, dy, t); }
            n++;
        }
        return MS.ok("Aligned " + MS._plural(n, "layer"));
    });
};

// mode: fit | fill | width | height
MS.fit = function (mode) {
    return MS.run("Fit to comp", function () {
        var c = MS.needComp(), sel = MS._needSel(c), t = c.time, i, l, r, kx, ky, k, s, n = 0;
        for (i = 0; i < sel.length; i++) {
            l = sel[i];
            if (!(MS.isVisual(l))) { continue; }
            r = MS._rect(l, t);
            if (!r.width || !r.height) { continue; }
            MS._anchorTo(l, 0.5, 0.5, t);
            kx = c.width / r.width * 100; ky = c.height / r.height * 100;
            k = mode === "fill" ? Math.max(kx, ky) : mode === "width" ? kx : mode === "height" ? ky : Math.min(kx, ky);
            s = l.transform.scale.valueAtTime(t, false);
            s[0] = s[0] < 0 ? -k : k;
            s[1] = s[1] < 0 ? -k : k;
            MS._set(l.transform.scale, s, t);
            if (!l.parent) { MS._setPositionXY(l, c.width / 2, c.height / 2, t); }
            n++;
        }
        return MS.ok("Fitted " + MS._plural(n, "layer"));
    });
};

// Equal gaps between selected layers, along whichever axis they are spread on.
MS.spread = function () {
    return MS.run("Smart spread", function () {
        var c = MS.needComp(), sel = MS._needSel(c, 3, "Select 3 or more layers to spread"), t = c.time,
            items = [], i, b, minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9, horiz, lo, hi, size, total = 0, span, gap, cursor, it;
        for (i = 0; i < sel.length; i++) {
            b = MS._compBounds(sel[i], t);
            if (!b) { continue; }
            items.push({ l: sel[i], b: b, cx: (b.left + b.right) / 2, cy: (b.top + b.bottom) / 2 });
            minX = Math.min(minX, b.left); maxX = Math.max(maxX, b.right);
            minY = Math.min(minY, b.top); maxY = Math.max(maxY, b.bottom);
        }
        if (items.length < 3) { throw new Error("Select 3 or more visible layers"); }
        horiz = (maxX - minX) >= (maxY - minY);
        items.sort(function (a, z) { return horiz ? a.cx - z.cx : a.cy - z.cy; });
        lo = horiz ? "left" : "top"; hi = horiz ? "right" : "bottom";
        for (i = 0; i < items.length; i++) { total += items[i].b[hi] - items[i].b[lo]; }
        span = items[items.length - 1].b[hi] - items[0].b[lo];
        gap = (span - total) / (items.length - 1);
        cursor = items[0].b[hi] + gap;
        for (i = 1; i < items.length - 1; i++) {
            it = items[i];
            size = it.b[hi] - it.b[lo];
            if (horiz) { MS._moveInComp(it.l, cursor - it.b.left, 0, t); }
            else { MS._moveInComp(it.l, 0, cursor - it.b.top, t); }
            cursor += size + gap;
        }
        return MS.ok("Spread " + MS._plural(items.length, "layer") + (horiz ? " horizontally" : " vertically"));
    });
};

/* ------------------------------------------------------------ easing */

// Average speed between two keys, one entry per ease dimension AE expects.
MS._speed = function (p, a, b, dims) {
    var v1 = p.keyValue(a), v2 = p.keyValue(b), dt = p.keyTime(b) - p.keyTime(a), out = [], i, d = 0,
        vt = p.propertyValueType;
    if (dt <= 0) { dt = 0.001; }
    if (dims === 1) {
        if (vt === PropertyValueType.TwoD_SPATIAL || vt === PropertyValueType.ThreeD_SPATIAL) {
            for (i = 0; i < v1.length; i++) { d += (v2[i] - v1[i]) * (v2[i] - v1[i]); }
            return [Math.sqrt(d) / dt];
        }
        if (typeof v1 === "number") { return [(v2 - v1) / dt]; }
        return [0];
    }
    for (i = 0; i < dims; i++) { out.push((v2[i] - v1[i]) / dt); }
    return out;
};

// Slopes of cubic-bezier(x1,y1,x2,y2) at its start and end. When a handle sits on its end point
// (e.g. linear 0,0,1,1 or ease-in .42,0,1,1) the tangent comes from the other handle instead of 0/0.
MS._bezierSlopes = function (x1, y1, x2, y2) {
    var e = 0.001, s0, s1;
    if (x1 > e || Math.abs(y1) > e) { s0 = x1 > e ? y1 / x1 : (y1 > 0 ? 1000 : -1000); }
    else { s0 = x2 > e ? y2 / x2 : 1; }
    if (1 - x2 > e || Math.abs(1 - y2) > e) { s1 = 1 - x2 > e ? (1 - y2) / (1 - x2) : (1 - y2 > 0 ? 1000 : -1000); }
    else { s1 = 1 - x1 > e ? (1 - y1) / (1 - x1) : 1; }
    return [s0, s1];
};

MS._easePair = function (p, a, b, x1, y1, x2, y2) {
    var dims = p.keyOutTemporalEase(a).length, sp = MS._speed(p, a, b, dims), outE = [], inE = [], i,
        spatial = p.propertyValueType === PropertyValueType.TwoD_SPATIAL || p.propertyValueType === PropertyValueType.ThreeD_SPATIAL,
        so, si, slopes = MS._bezierSlopes(x1, y1, x2, y2);
    for (i = 0; i < dims; i++) {
        so = sp[i] * slopes[0];
        si = sp[i] * slopes[1];
        if (spatial) { so = Math.abs(so); si = Math.abs(si); }
        outE.push(new KeyframeEase(so, Math.max(0.1, Math.min(100, x1 * 100))));
        inE.push(new KeyframeEase(si, Math.max(0.1, Math.min(100, (1 - x2) * 100))));
    }
    p.setInterpolationTypeAtKey(a, p.keyInInterpolationType(a), KeyframeInterpolationType.BEZIER);
    p.setInterpolationTypeAtKey(b, KeyframeInterpolationType.BEZIER, p.keyOutInterpolationType(b));
    p.setTemporalEaseAtKey(a, p.keyInTemporalEase(a), outE);
    p.setTemporalEaseAtKey(b, inE, p.keyOutTemporalEase(b));
};

// Apply a CSS-style cubic-bezier(x1, y1, x2, y2) to the selected keyframes.
MS.ease = function (x1, y1, x2, y2) {
    return MS.run("Ease", function () {
        var c = MS.needComp(), props = c.selectedProperties, i, j, p, keys, n = 0;
        x1 = Math.min(Math.max(Number(x1) || 0, 0), 1);
        x2 = Math.min(Math.max(Number(x2) || 0, 0), 1);
        y1 = Number(y1) || 0;
        y2 = Number(y2) || 0;
        for (i = 0; i < props.length; i++) {
            p = props[i];
            if (p.propertyType !== PropertyType.PROPERTY || p.numKeys < 2) { continue; }
            keys = p.selectedKeys;
            if (keys.length === 1 && keys[0] < p.numKeys) { keys = [keys[0], keys[0] + 1]; }
            if (keys.length < 2) {
                keys = [];
                for (j = 1; j <= p.numKeys; j++) { keys.push(j); }
            }
            for (j = 0; j < keys.length - 1; j++) {
                if (keys[j + 1] !== keys[j] + 1) { continue; }
                MS._easePair(p, keys[j], keys[j + 1], x1, y1, x2, y2);
                n++;
            }
        }
        if (!n) { throw new Error("Select 2 or more keyframes to ease"); }
        return MS.ok("Eased " + MS._plural(n, "segment"));
    });
};

MS.BOUNCE_EXPR =
    "// MotionSaaS Bounce: tweak these three\n" +
    "var elasticity = 0.6, gravity = 4000, maxBounces = 6;\n" +
    "var n = 0;\n" +
    "if (numKeys > 0) { n = nearestKey(time).index; if (key(n).time > time) { n--; } }\n" +
    "var result = value;\n" +
    "if (n > 0) {\n" +
    "  var t = time - key(n).time;\n" +
    "  var v = velocityAtTime(key(n).time - thisComp.frameDuration / 10);\n" +
    "  var isArr = value instanceof Array;\n" +
    "  var speed = isArr ? length(v) : Math.abs(v);\n" +
    "  if (speed > 0) {\n" +
    "    var dir = isArr ? normalize(v) : (v < 0 ? -1 : 1);\n" +
    "    var vel = speed * elasticity, seg = 2 * vel / gravity, start = 0, count = 1;\n" +
    "    while (start + seg < t && count < maxBounces) { start += seg; vel *= elasticity; seg = 2 * vel / gravity; count++; }\n" +
    "    if (count < maxBounces) {\n" +
    "      var dt = t - start, h = dt * (vel - gravity * dt / 2);\n" +
    "      result = isArr ? sub(value, mul(dir, h)) : value - dir * h;\n" +
    "    }\n" +
    "  }\n" +
    "}\n" +
    "result;";

MS.bounce = function () {
    return MS.run("Bounce", function () {
        var c = MS.needComp(), props = [], sel, i, p, all, n = 0;
        for (i = 0; i < c.selectedProperties.length; i++) {
            p = c.selectedProperties[i];
            if (p.propertyType === PropertyType.PROPERTY && p.numKeys > 0 && p.canSetExpression) { props.push(p); }
        }
        if (!props.length) {
            sel = MS._needSel(c, 1, "Select keyframed properties (or layers) first");
            for (i = 0; i < sel.length; i++) {
                all = MS._keyedProps(sel[i].property("ADBE Transform Group"));
                props = props.concat(all);
            }
        }
        var skipped = 0;
        for (i = 0; i < props.length; i++) {
            if (!props[i].canSetExpression) { continue; }
            // Never overwrite an expression the user wrote; re-applying our own is fine.
            if (props[i].expression && props[i].expression.indexOf("MotionSaaS Bounce") === -1) { skipped++; continue; }
            props[i].expression = MS.BOUNCE_EXPR;
            n++;
        }
        if (!n) { throw new Error(skipped ? "Those properties already have expressions — remove them first" : "No keyframed properties found"); }
        return MS.ok("Bounce added to " + n + (n === 1 ? " property" : " properties") + (skipped ? " (" + skipped + " with your own expression skipped)" : ""));
    });
};

MS._readKeys = function (p) {
    var out = [], k, d;
    for (k = 1; k <= p.numKeys; k++) {
        d = { t: p.keyTime(k), v: p.keyValue(k), it: p.keyInInterpolationType(k), ot: p.keyOutInterpolationType(k),
              ie: p.keyInTemporalEase(k), oe: p.keyOutTemporalEase(k) };
        if (p.isSpatial) {
            d.ist = p.keyInSpatialTangent(k); d.ost = p.keyOutSpatialTangent(k);
            d.auto = p.keySpatialAutoBezier(k); d.cont = p.keySpatialContinuous(k);
        }
        out.push(d);
    }
    return out;
};

MS._scaleEase = function (eases, f) {
    var out = [], i;
    for (i = 0; i < eases.length; i++) { out.push(new KeyframeEase(eases[i].speed / f, eases[i].influence)); }
    return out;
};

// Rebuild every key of `p` at mapT(time). Eases of moved keys are scaled by 1/f so speeds stay right.
// If anything fails half-way, the original keys are restored so the user never loses animation.
MS._rebuildKeys = function (p, mapT, f, isMoved) {
    var keys = MS._readKeys(p);
    var write = function (list, timeFn, factorFn) {
        var j, d, idx;
        for (j = p.numKeys; j >= 1; j--) { p.removeKey(j); }
        for (j = 0; j < list.length; j++) {
            idx = p.addKey(timeFn(list[j].t));
            p.setValueAtKey(idx, list[j].v);
        }
        if (p.numKeys !== list.length) { return; }  // two keys landed on the same frame: values kept, eases dropped
        for (j = 0; j < list.length; j++) {
            d = list[j]; idx = j + 1;
            try { p.setInterpolationTypeAtKey(idx, d.it, d.ot); } catch (e1) {}
            try { p.setTemporalEaseAtKey(idx, MS._scaleEase(d.ie, factorFn(d)), MS._scaleEase(d.oe, factorFn(d))); } catch (e2) {}
            if (d.ist) {
                try {
                    p.setSpatialTangentsAtKey(idx, d.ist, d.ost);
                    p.setSpatialAutoBezierAtKey(idx, d.auto);
                    p.setSpatialContinuousAtKey(idx, d.cont);
                } catch (e3) {}
            }
        }
    };
    try {
        write(keys, mapT, function (d) { return isMoved(d.t) ? f : 1; });
    } catch (e) {
        try { write(keys, function (t) { return t; }, function () { return 1; }); } catch (e4) {}
        throw new Error("Couldn't retime “" + p.name + "” — its keys were left as they were");
    }
    return keys.length;
};

// Rebuild keys at new times: newT = t0 + (t - from) * f.
MS._retimeKeys = function (p, from, t0, f) {
    MS._rebuildKeys(p, function (t) { return t0 + (t - from) * f; }, f, function () { return true; });
};

// Stretch every keyframe on the layer to span its in/out points.
MS.fitKeys = function () {
    return MS.run("Fit keys", function () {
        var c = MS.needComp(), sel = MS._needSel(c), i, j, l, props, lo, hi, end, f, n = 0;
        for (i = 0; i < sel.length; i++) {
            l = sel[i];
            props = MS._keyedProps(l);
            lo = 1e9; hi = -1e9;
            for (j = 0; j < props.length; j++) {
                lo = Math.min(lo, props[j].keyTime(1));
                hi = Math.max(hi, props[j].keyTime(props[j].numKeys));
            }
            if (!props.length || hi <= lo) { continue; }
            end = l.outPoint - c.frameDuration;
            f = (end - l.inPoint) / (hi - lo);
            if (f <= 0) { continue; }
            for (j = 0; j < props.length; j++) { MS._retimeKeys(props[j], lo, l.inPoint, f); }
            n++;
        }
        if (!n) { throw new Error("Selected layers need 2+ keyframes at different times"); }
        return MS.ok("Fitted keys on " + MS._plural(n, "layer"));
    });
};

/* ------------------------------------------------------------ layers */

// kind: null | adjustment | camera | solidBlack | solidWhite
MS.create = function (kind) {
    return MS.run("Create " + kind, function () {
        var c = MS.needComp(), sel = MS._editable(MS.selectedLayers(c)), l, cam, i, inP = 1e9, outP = -1e9, b, box = null;
        for (i = 0; i < sel.length; i++) { inP = Math.min(inP, sel[i].inPoint); outP = Math.max(outP, sel[i].outPoint); }
        if (kind === "null") {
            l = c.layers.addNull();
            l.name = "Null";
            for (i = 0; i < sel.length; i++) {
                b = MS._compBounds(sel[i], c.time);
                if (!b) { continue; }
                if (!box) { box = b; }
                else { box = { left: Math.min(box.left, b.left), top: Math.min(box.top, b.top), right: Math.max(box.right, b.right), bottom: Math.max(box.bottom, b.bottom) }; }
            }
            if (box) { l.transform.position.setValue([(box.left + box.right) / 2, (box.top + box.bottom) / 2]); }
        } else if (kind === "adjustment") {
            l = c.layers.addSolid([1, 1, 1], "Adjustment Layer", c.width, c.height, c.pixelAspect, c.duration);
            l.adjustmentLayer = true;
        } else if (kind === "camera") {
            l = c.layers.addNull();
            l.name = "Camera Control";
            l.threeDLayer = true;
            l.transform.position.setValue([c.width / 2, c.height / 2, 0]);
            cam = c.layers.addCamera("Camera", [c.width / 2, c.height / 2]);
            cam.autoOrient = AutoOrientType.NO_AUTO_ORIENT;
            cam.parent = l;
        } else if (kind === "solidBlack" || kind === "solidWhite") {
            l = c.layers.addSolid(kind === "solidWhite" ? [1, 1, 1] : [0, 0, 0], kind === "solidWhite" ? "White Solid" : "Black Solid",
                c.width, c.height, c.pixelAspect, c.duration);
        } else {
            throw new Error("Unknown layer type");
        }
        if (sel.length && kind !== "camera") {
            l.moveBefore(sel[0]);
            l.inPoint = inP; l.outPoint = outP;
            if (kind === "null") {
                for (i = 0; i < sel.length; i++) { if (!sel[i].parent) { sel[i].parent = l; } }
            }
        }
        for (i = 0; i < sel.length; i++) { sel[i].selected = false; }
        l.selected = true;
        if (kind === "null" && sel.length) { return MS.ok("Null added and " + MS._plural(sel.length, "layer") + " parented"); }
        return MS.ok(l.name + " added");
    });
};

// Duplicate comps and every comp nested inside them, so the copy is fully independent.
MS._deepDup = function (comp, done, made) {
    var dup, i, l;
    if (done[comp.id]) { return done[comp.id]; }
    dup = comp.duplicate();
    dup.name = comp.name + " copy";
    done[comp.id] = dup;
    made.n++;
    for (i = 1; i <= dup.numLayers; i++) {
        l = dup.layer(i);
        if (l.source && l.source instanceof CompItem) { l.replaceSource(MS._deepDup(l.source, done, made), false); }
    }
    return dup;
};

MS.trueDuplicate = function () {
    return MS.run("True duplicate", function () {
        var sel = app.project.selection, comps = [], i, made = { n: 0 }, done = {}, c;
        for (i = 0; i < sel.length; i++) { if (sel[i] instanceof CompItem) { comps.push(sel[i]); } }
        if (!comps.length) { c = MS.comp(); if (c) { comps.push(c); } }
        if (!comps.length) { throw new Error("Select a comp in the Project panel, or open one"); }
        for (i = 0; i < comps.length; i++) { MS._deepDup(comps[i], done, made); }
        return MS.ok("Duplicated " + MS._plural(comps.length, "comp") + (made.n > comps.length ? " + " + (made.n - comps.length) + " nested" : ""));
    });
};

// Copy a property's value/keys/expression onto another property of the same kind.
MS._copyProp = function (from, to) {
    var keys, k, idx;
    if (from.numKeys > 0) {
        keys = MS._readKeys(from);
        for (k = 0; k < keys.length; k++) {
            idx = to.addKey(keys[k].t);
            to.setValueAtKey(idx, keys[k].v);
        }
        for (k = 0; k < keys.length && k < to.numKeys; k++) {
            to.setInterpolationTypeAtKey(k + 1, keys[k].it, keys[k].ot);
            try { to.setTemporalEaseAtKey(k + 1, keys[k].ie, keys[k].oe); } catch (e) {}
        }
    } else {
        to.setValue(from.value);
    }
    if (from.expressionEnabled && from.expression) { to.expression = from.expression; }
};

// Bring a precomp's layers back into this comp, driven by a null that carries the precomp layer's transform.
MS.unprecompose = function () {
    return MS.run("Un-precompose", function () {
        var c = MS.needComp(), sel = MS._editable(MS.selectedLayers(c)), L = null, src, ctrl, map = {}, i, nl, old, tr = ["ADBE Anchor Point", "ADBE Position", "ADBE Scale", "ADBE Rotate Z"];
        for (i = 0; i < sel.length; i++) { if (sel[i].source instanceof CompItem) { L = sel[i]; break; } }
        if (!L) { throw new Error("Select a precomp layer"); }
        src = L.source;
        if (!src.numLayers) { throw new Error("That precomp is empty"); }

        ctrl = c.layers.addNull();
        ctrl.name = "Unpacked: " + src.name;
        if (L.threeDLayer) { ctrl.threeDLayer = true; }
        if (L.transform.position.dimensionsSeparated) {
            ctrl.transform.position.dimensionsSeparated = true;
            tr = ["ADBE Anchor Point", "ADBE Position_0", "ADBE Position_1", "ADBE Scale", "ADBE Rotate Z"];
            if (L.threeDLayer) { tr.push("ADBE Position_2"); }
        }
        if (L.threeDLayer) { tr.push("ADBE Orientation", "ADBE Rotate X", "ADBE Rotate Y"); }
        for (i = 0; i < tr.length; i++) {
            try { MS._copyProp(L.transform.property(tr[i]), ctrl.transform.property(tr[i])); } catch (eT) {}
        }
        if (L.parent) { ctrl.setParentWithJump(L.parent); }
        ctrl.inPoint = L.inPoint; ctrl.outPoint = L.outPoint;
        ctrl.moveBefore(L);

        for (i = 1; i <= src.numLayers; i++) {
            src.layer(i).copyToComp(c);
            nl = c.layer(1);
            nl.moveBefore(L);
            nl.startTime += L.startTime;
            map[i] = nl;
        }
        for (i = 1; i <= src.numLayers; i++) {
            old = src.layer(i);
            if (old.parent) { map[i].setParentWithJump(map[old.parent.index]); }
            else { map[i].setParentWithJump(ctrl); }
        }
        L.enabled = false;
        L.selected = false;
        ctrl.selected = true;
        var notes = [];
        if (L.timeRemapEnabled || L.stretch !== 100) { notes.push("time remap/stretch not carried over"); }
        if (L.transform.opacity.value < 100 || L.transform.opacity.numKeys) { notes.push("precomp opacity not carried over"); }
        if (L.property("ADBE Effect Parade") && L.property("ADBE Effect Parade").numProperties) { notes.push("its effects stay on the old layer"); }
        return MS.ok("Unpacked " + MS._plural(src.numLayers, "layer") + " (original turned off" + (notes.length ? "; " + notes.join(", ") : "") + ")");
    });
};

// which: bottom = match the bottom-most selected layer; top = match the top-most.
MS.trimTo = function (which) {
    return MS.run("Trim to " + which, function () {
        var c = MS.needComp(), sel = MS._needSel(c, 2, "Select 2 or more layers"), ref = which === "top" ? sel[0] : sel[sel.length - 1], i, n = 0;
        for (i = 0; i < sel.length; i++) {
            if (sel[i] === ref) { continue; }
            try { sel[i].inPoint = ref.inPoint; sel[i].outPoint = ref.outPoint; n++; } catch (e) {}
        }
        return MS.ok("Trimmed " + MS._plural(n, "layer") + " to “" + ref.name + "”");
    });
};

MS.label = function (index) {
    return MS.run("Label", function () {
        var c = MS.comp(), sel = c ? MS.selectedLayers(c) : [], items = app.project.selection, i;
        if (sel.length) {
            for (i = 0; i < sel.length; i++) { sel[i].label = index; }
            return MS.ok("Labelled " + MS._plural(sel.length, "layer"));
        }
        if (items.length) {
            for (i = 0; i < items.length; i++) { items[i].label = index; }
            return MS.ok("Labelled " + MS._plural(items.length, "item"));
        }
        throw new Error("Select layers or project items first");
    });
};

// Turn off a share of the effects (to speed up previews). 0 turns everything back on.
// The optimizer remembers which effects *it* switched off (per comp, in AE's settings), so
// "Enable all" never turns on effects the user had disabled on purpose.
MS._fxKey = function (c) { return "fxoff_" + c.id; };
MS._fxRead = function (c) {
    try { return app.settings.haveSetting("MotionSaaS", MS._fxKey(c)) ? app.settings.getSetting("MotionSaaS", MS._fxKey(c)) : ""; }
    catch (e) { return ""; }
};
MS._fxWrite = function (c, s) { try { app.settings.saveSetting("MotionSaaS", MS._fxKey(c), s); } catch (e) {} };
MS._fxTag = function (l, fx) { return "|" + l.index + ":" + l.name + ":" + fx.propertyIndex + ":" + fx.name + "|"; };

MS.fxPercent = function (pct) {
    return MS.run("FX optimizer", function () {
        var c = MS.needComp(), sel = MS.selectedLayers(c), i, j, fxp, fx, m, keep, total = 0, off = 0, on = 0,
            record = MS._fxRead(c), tag;
        pct = Math.max(0, Math.min(100, Number(pct) || 0));
        if (!sel.length) { for (i = 1; i <= c.numLayers; i++) { sel.push(c.layer(i)); } }
        for (i = 0; i < sel.length; i++) {
            fxp = sel[i].property("ADBE Effect Parade");
            if (!fxp || sel[i].locked) { continue; }
            m = fxp.numProperties;
            keep = m - Math.round(m * pct / 100);
            for (j = 1; j <= m; j++) {
                fx = fxp.property(j);
                tag = MS._fxTag(sel[i], fx);
                total++;
                if (pct === 0 || j <= keep) {
                    // Re-enable only what we disabled (or everything when there's no record at all).
                    if (!fx.enabled && (record.indexOf(tag) !== -1 || (pct === 0 && !record))) { fx.enabled = true; on++; }
                    record = record.split(tag).join("");
                } else if (fx.enabled) {
                    fx.enabled = false; off++;
                    if (record.indexOf(tag) === -1) { record += tag; }
                }
            }
        }
        MS._fxWrite(c, record);
        if (!total) { throw new Error("No effects found"); }
        return MS.ok(pct > 0 ? "Turned off " + off + " of " + MS._plural(total, "effect") + " — Enable all brings them back"
                             : (on ? "Turned " + MS._plural(on, "effect") + " back on" : "Nothing to turn back on"));
    });
};

MS.playhead = function (frames) {
    var c = MS.comp();
    if (!c) { return MS.err("Open a composition first"); }
    c.time = Math.max(0, Math.min(c.duration - c.frameDuration, c.time + frames * c.frameDuration));
    return MS.ok("Frame " + Math.round(c.time / c.frameDuration));
};

// mode: align | forward | backward | random. Groups of `num` layers move together, `step` frames apart.
MS.offset = function (mode, num, step) {
    return MS.run("Layer offset", function () {
        var c = MS.needComp(), list = [], i, j, tmp, target;
        for (i = 0; i < c.selectedLayers.length; i++) { list.push(c.selectedLayers[i]); }
        if (!list.length) { throw new Error("Select some layers first"); }
        num = Math.max(1, Math.round(num) || 1);
        step = (step || 0) * c.frameDuration;
        if (mode === "backward") { list.reverse(); }
        if (mode === "random") {
            for (i = list.length - 1; i > 0; i--) { j = Math.floor(Math.random() * (i + 1)); tmp = list[i]; list[i] = list[j]; list[j] = tmp; }
        }
        for (i = 0; i < list.length; i++) {
            target = c.time + (mode === "align" ? 0 : Math.floor(i / num) * step);
            list[i].startTime += target - list[i].inPoint;
        }
        return MS.ok(mode === "align" ? "Moved " + MS._plural(list.length, "layer") + " to the playhead" : "Staggered " + MS._plural(list.length, "layer"));
    });
};

MS._folder = function (name) {
    var root = app.project.rootFolder, i, it;
    for (i = 1; i <= root.numItems; i++) {
        it = root.item(i);
        if (it instanceof FolderItem && it.name === name) { return it; }
    }
    return app.project.items.addFolder(name);
};

MS.organise = function () {
    return MS.run("Organise project", function () {
        var root = app.project.rootFolder, items = [], i, it, name, n = 0, src;
        for (i = 1; i <= root.numItems; i++) {
            it = root.item(i);
            if (!(it instanceof FolderItem)) { items.push(it); }
        }
        for (i = 0; i < items.length; i++) {
            it = items[i];
            name = null;
            if (it instanceof CompItem) { name = "Comps"; }
            else if (it instanceof FootageItem) {
                src = it.mainSource;
                if (src instanceof SolidSource) { name = "Solids"; }
                else if (src instanceof PlaceholderSource) { name = null; }
                else if (src.isStill) { name = "Images"; }
                else if (it.hasAudio && !it.hasVideo) { name = "Audio"; }
                else { name = "Footage"; }
            }
            if (name) { it.parentFolder = MS._folder(name); n++; }
        }
        return MS.ok(n ? "Sorted " + MS._plural(n, "item") + " into folders" : "Already tidy");
    });
};

MS.purge = function () {
    try { app.purge(PurgeTarget.ALL_CACHES); } catch (e) { return MS.err(MS.friendly(e)); }
    return MS.ok("RAM & disk cache cleared (this also clears After Effects' undo history)");
};

/* ---------------------------------------------------- counter & timer */

MS._counterExpr = function (o, slider) {
    return "// MotionSaaS Counter\n" +
        "var v = effect(" + MS._q(slider) + ")(1) * " + (Number(o.mult) || 1) + ";\n" +
        "var d = " + (o.showDec ? Math.max(0, Math.min(6, Math.round(o.dec) || 0)) : 0) + ", suffix = \"\";\n" +
        "var neg = v < 0; v = Math.abs(v);\n" +
        (o["short"] ? "if (v >= 1e9) { v /= 1e9; suffix = \"B\"; } else if (v >= 1e6) { v /= 1e6; suffix = \"M\"; } else if (v >= 1e3) { v /= 1e3; suffix = \"K\"; }\n" +
                   "if (suffix && d === 0) { d = 1; }\n" : "") +
        "var s = v.toFixed(d);\n" +
        "if (suffix) { s = s.replace(/\\.?0+$/, \"\"); }\n" +
        "var parts = s.split(\".\");\n" +
        (o.thousands ? "if (!suffix) { parts[0] = parts[0].replace(/\\B(?=(\\d{3})+(?!\\d))/g, " + (o.comma ? "\".\"" : "\",\"") + "); }\n" : "") +
        "s = parts.join(" + (o.comma ? "\",\"" : "\".\"") + ");\n" +
        MS._q(o.pre || "") + " + (neg ? \"-\" : \"\") + s + suffix + " + MS._q(o.post || "") + ";";
};

MS._timerExpr = function (o) {
    return "// MotionSaaS Timer\n" +
        "var t = " + (Number(o.tStart) || 0) + " + " + (o.countdown ? "-" : "") + "(time - inPoint) * " + (Number(o.speed) || 1) + ";\n" +
        "t = Math.max(0, Math.floor(t));\n" +
        "function pad(n) { return (n < 10 ? \"0\" : \"\") + n; }\n" +
        "var useD = " + !!o.days + ", useH = " + !!o.hours + ", useM = " + !!o.mins + ", useS = " + (o.secs !== false) + ";\n" +
        "var units = [[86400, useD], [3600, useH], [60, useM], [1, useS]], out = [], rest = t;\n" +
        "for (var i = 0; i < units.length; i++) {\n" +
        "  if (!units[i][1]) { continue; }\n" +
        "  var size = units[i][0], n = Math.floor(rest / size);\n" +
        "  rest -= n * size;\n" +
        "  out.push(out.length ? pad(n) : String(n));\n" +
        "}\n" +
        MS._q(o.pre || "") + " + out.join(\":\") + " + MS._q(o.post || "") + ";";
};

// o: { mode: "counter"|"timer", pre, post, start, end, dur, mult, dec, showDec, comma, short, thousands,
//      tStart, speed, days, hours, mins, secs, countdown }
MS.counter = function (o) {
    return MS.run(o.mode === "timer" ? "Timer" : "Counter", function () {
        var c = MS.needComp(), sel = MS._editable(MS.selectedLayers(c)), texts = [], i, l, fx, idx, v, made = false, name;
        for (i = 0; i < sel.length; i++) { if (sel[i] instanceof TextLayer) { texts.push(sel[i]); } }
        if (!texts.length) {
            l = MS.makeText(c, "0", Math.round(c.height / 8), "#FFFFFF");
            l.name = o.mode === "timer" ? "Timer" : "Counter";
            texts.push(l); made = true;
        }
        if (o.mode !== "timer" && (Math.abs(o.start) > 1e6 || Math.abs(o.end) > 1e6)) {
            throw new Error("Use Mult for numbers above 1,000,000");
        }
        var done = 0, skipped = 0, src, old, k, prev;
        for (i = 0; i < texts.length; i++) {
            l = texts[i];
            src = l.property("ADBE Text Properties").property("ADBE Text Document");
            old = String(src.expression || "");
            // Never replace a Source Text expression the user wrote; our own Counter / Timer is updated.
            if (old && !/^\/\/ MotionSaaS (Counter|Timer)/.test(old)) { skipped++; continue; }
            if (o.mode === "timer") {
                src.expression = MS._timerExpr(o);
                done++;
                continue;
            }
            // Applying again re-keys the layer's existing Counter slider instead of adding "Counter 2", "Counter 3"…
            prev = /^\/\/ MotionSaaS Counter/.test(old) ? /effect\("((?:[^"\\]|\\.)*)"\)/.exec(old) : null;
            fx = prev ? MS._fxNamed(l, MS._parseJSON("\"" + prev[1] + "\"")) : null;
            if (!fx) {
                fx = l.property("ADBE Effect Parade").addProperty("ADBE Slider Control");
                idx = fx.propertyIndex;
                fx = l.property("ADBE Effect Parade").property(idx);
                fx.name = "Counter";
            }
            name = fx.name;
            v = fx.property(1);
            for (k = v.numKeys; k >= 1; k--) { v.removeKey(k); }
            v.setValueAtTime(c.time, Number(o.start) || 0);
            v.setValueAtTime(c.time + (Number(o.dur) || 2), Number(o.end) || 0);
            MS.smooth(v);
            l.property("ADBE Text Properties").property("ADBE Text Document").expression = MS._counterExpr(o, name);
            done++;
        }
        if (!done) { throw new Error("The selected text layers already have their own Source Text expressions — remove them first"); }
        return MS.ok((made ? "Created " : "Applied to ") + MS._plural(done, "text layer") + (skipped ? " (" + skipped + " with your own expression left alone)" : ""));
    });
};

/* ---------------------------------------------------------- captions */

// Fractions are padded/truncated to milliseconds, so "1,5" (sloppy exports) means 1.5 s, not 1.005 s.
MS._srtTime = function (h, m, s, frac) { return Number(h) * 3600 + Number(m) * 60 + Number(s) + Number((String(frac) + "00").substr(0, 3)) / 1000; };

// SRT text → [{ text, a (start s), b (end s) }]. Handles BOM, CRLF, "." or "," millis, HTML/ASS tags,
// multi-line cues and missing index lines; skips empty or zero-length cues.
MS._parseSRT = function (txt) {
    var re = /(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)/, blocks, i, j, lines, m, text, a, b, out = [];
    txt = String(txt).replace(/^﻿/, "").replace(/\r\n?/g, "\n");
    blocks = txt.split(/\n[ \t]*\n/);
    for (i = 0; i < blocks.length; i++) {
        lines = blocks[i].split("\n");
        for (j = 0; j < lines.length; j++) { if (re.test(lines[j])) { break; } }
        if (j >= lines.length) { continue; }
        m = lines[j].match(re);
        text = lines.slice(j + 1).join("\r").replace(/<[^>]+>/g, "").replace(/\{\\[^}]*\}/g, "").replace(/^\s+|\s+$/g, "");
        a = MS._srtTime(m[1], m[2], m[3], m[4]);
        b = MS._srtTime(m[5], m[6], m[7], m[8]);
        if (!text || b <= a) { continue; }
        out.push({ text: text, a: a, b: b });
    }
    return out;
};

MS.importSRT = function () {
    return MS.run("Import SRT", function () {
        var c = MS.needComp(), f, txt, i, l, n = 0,
            filter = $.os.indexOf("Windows") !== -1 ? "Subtitles:*.srt" : function (x) { return x instanceof Folder || /\.srt$/i.test(x.name); };
        f = File.openDialog("Choose an .srt subtitle file", filter);
        if (!f) { return MS.ok("Cancelled"); }
        f.encoding = "UTF-8";
        if (!f.open("r")) { throw new Error("Couldn't open " + decodeURI(f.name)); }
        txt = f.read(); f.close();
        var cues = MS._parseSRT(txt), end = 0, extended = false;
        for (i = 0; i < cues.length; i++) { end = Math.max(end, cues[i].b); }
        if (!cues.length) { throw new Error("No captions found in that file"); }
        // Make room first: AE won't place layers past the end of the comp.
        if (end > c.duration) { c.duration = Math.ceil(end + 1); extended = true; }
        for (i = 0; i < cues.length; i++) {
            l = MS.makeText(c, cues[i].text, Math.round(c.height * 0.045), "#FFFFFF");
            l.name = "Caption " + (n + 1);
            l.transform.position.setValue([c.width / 2, c.height * 0.86]);
            l.outPoint = cues[i].b;
            l.inPoint = cues[i].a;
            n++;
        }
        return MS.ok("Imported " + MS._plural(n, "caption") + (extended ? " (comp lengthened to fit)" : ""));
    });
};

/* ------------------------------------------------------- effect helpers */

// Add an effect and return its index (AE invalidates older references after addProperty, so re-fetch by index).
MS._addFx = function (l, matchName, name) {
    var fx = l.property("ADBE Effect Parade").addProperty(matchName), idx = fx.propertyIndex;
    if (name) { l.property("ADBE Effect Parade").property(idx).name = name; }
    return idx;
};

MS._fxAt = function (l, idx) { return l.property("ADBE Effect Parade").property(idx); };

// Two keys from a to b, with "snap" influence leaving the first key and "settle" influence into the last.
MS._keyPair = function (p, t0, t1, a, b, snap, settle) {
    var k1, k2;
    p.setValueAtTime(t0, a);
    p.setValueAtTime(t1, b);
    k1 = p.nearestKeyIndex(t0); k2 = p.nearestKeyIndex(t1);
    p.setTemporalEaseAtKey(k1, p.keyInTemporalEase(k1), [new KeyframeEase(0, Math.max(0.1, Math.min(100, snap)))]);
    p.setTemporalEaseAtKey(k2, [new KeyframeEase(0, Math.max(0.1, Math.min(100, settle)))], p.keyOutTemporalEase(k2));
};

/* ------------------------------------------------------- magic reveal */

MS.REVEAL_ANGLES = { LR: 270, RL: 90, TB: 0, BT: 180 };

// A coloured copy of the layer that only shows a band just behind the reveal edge.
MS._revealBand = function (B, o, t0, dur, angle, band, hex, blur, feather, mode, label) {
    var idx, revName, fx, cp, op;
    B.name = label;
    idx = MS._addFx(B, "ADBE Fill");
    cp = MS.findColorProp(MS._fxAt(B, idx));
    if (cp) { cp.setValue(MS.rgb(hex)); }

    idx = MS._addFx(B, "ADBE Linear Wipe", "MS Reveal");
    fx = MS._fxAt(B, idx);
    revName = fx.name;
    fx.property(2).setValue(angle);
    fx.property(3).setValue(feather);
    MS._keyPair(MS._fxAt(B, idx).property(1), t0, t0 + dur, 100, 0, o.easeOut, o.easeIn);

    idx = MS._addFx(B, "ADBE Linear Wipe", "MS Band");
    fx = MS._fxAt(B, idx);
    fx.property(2).setValue((angle + 180) % 360);
    fx.property(3).setValue(feather);
    fx.property(1).expression = "clamp(100 - effect(" + MS._q(revName) + ")(1) - " + band + ", 0, 100);";

    if (blur > 0) {
        idx = MS._addFx(B, "ADBE Gaussian Blur 2");
        MS._fxAt(B, idx).property(1).setValue(blur);
    }
    B.blendingMode = mode;
    op = B.transform.opacity;
    while (op.numKeys) { op.removeKey(1); }
    op.expression = "";
    op.setValueAtTime(t0 + dur * 0.6, 100);
    op.setValueAtTime(t0 + dur, 0);
    if (t0 + dur + B.containingComp.frameDuration > B.inPoint) { B.outPoint = Math.min(B.outPoint, t0 + dur + B.containingComp.frameDuration); }
    if (t0 > B.inPoint && t0 < B.outPoint) { B.inPoint = t0; }
};

// o: { color, dir: LR|RL|TB|BT, frames, glow (band %), blur, feather, rim, blend: normal|add|screen, easeOut, easeIn }
MS.magicReveal = function (o) {
    return MS.run("Magic Reveal", function () {
        var c = MS.needComp(), sel = MS._needSel(c, 1, "Select the layer to reveal"), t0 = c.time,
            dur = Math.max(2, Math.round(Number(o.frames) || 20)) * c.frameDuration,
            angle = MS.REVEAL_ANGLES[o.dir] === undefined ? 270 : MS.REVEAL_ANGLES[o.dir],
            feather = Math.max(0, Number(o.feather) || 0),
            mode = o.blend === "add" ? BlendingMode.ADD : o.blend === "screen" ? BlendingMode.SCREEN : BlendingMode.NORMAL,
            i, L, rim, glow, idx, fx, n = 0;
        for (i = 0; i < sel.length; i++) {
            L = sel[i];
            if (!(MS.isVisual(L)) || !L.property("ADBE Effect Parade")) { continue; }
            // Copies first (so they don't inherit the reveal). Each duplicate lands directly above L → rim, glow, L.
            rim = Number(o.rim) > 0 ? L.duplicate() : null;
            glow = Number(o.glow) > 0 ? L.duplicate() : null;

            idx = MS._addFx(L, "ADBE Linear Wipe", "MS Reveal");
            fx = MS._fxAt(L, idx);
            fx.property(2).setValue(angle);
            fx.property(3).setValue(feather);
            MS._keyPair(MS._fxAt(L, idx).property(1), t0, t0 + dur, 100, 0, o.easeOut, o.easeIn);

            if (glow) { MS._revealBand(glow, o, t0, dur, angle, Number(o.glow) * 0.2, o.color, Number(o.blur) || 0, feather, mode, L.name + " • Glow"); }
            if (rim) { MS._revealBand(rim, o, t0, dur, angle, Math.max(0.5, Number(o.rim) * 0.25), "#FFFFFF", 2, Math.min(feather, 10), BlendingMode.ADD, L.name + " • Rim"); }
            if (glow) { glow.selected = false; }
            if (rim) { rim.selected = false; }
            n++;
        }
        if (!n) { throw new Error("Magic Reveal needs a footage, shape or text layer"); }
        return MS.ok("Magic Reveal on " + MS._plural(n, "layer"));
    });
};


/* --------------------------------------------- icons, assets, folders */

MS._findFootage = function (f) {
    var i, it;
    for (i = 1; i <= app.project.numItems; i++) {
        it = app.project.item(i);
        if (it instanceof FootageItem && it.file && it.file.fsName === f.fsName) { return it; }
    }
    return null;
};

// Import an image/icon file and drop it into the active comp at the playhead.
MS.importFile = function (path) {
    return MS.run("Import icon", function () {
        var c = MS.needComp(), f = new File(path), item, l, sel = MS.selectedLayers(c), i;
        if (!f.exists) { throw new Error("File not found: " + f.displayName); }
        item = MS._findFootage(f);
        if (!item) {
            try { item = app.project.importFile(new ImportOptions(f)); }
            catch (e) { throw new Error("After Effects " + app.version.split("x")[0] + " can't import " + decodeURI(f.name)); }
        }
        l = c.layers.add(item);
        l.startTime = c.time;
        if (sel.length) { l.moveBefore(sel[0]); }
        for (i = 0; i < sel.length; i++) { sel[i].selected = false; }
        l.selected = true;
        return MS.ok(decodeURI(f.name) + " added");
    });
};

MS.openFolder = function (path) {
    var f = new Folder(path);
    if (!f.exists) { f.create(); }
    f.execute();
    return MS.ok("Opened " + f.displayName);
};

MS._assetComp = function () {
    var sel = app.project.selection, i;
    for (i = 0; i < sel.length; i++) { if (sel[i] instanceof CompItem) { return sel[i]; } }
    return MS.needComp();
};

// Step 1 of saving an asset: thumbnail of the comp at its current time (written in the background by AE).
MS.assetThumb = function (pngPath) {
    return MS.run("Asset thumbnail", function () {
        var c = MS._assetComp();
        if (typeof c.saveFrameToPng !== "function") { return MS.ok("No thumbnail on this AE version"); }
        c.saveFrameToPng(c.time, new File(pngPath));
        return MS.ok(c.name);
    });
};

// Step 2: save the comp (and only what it uses) as its own .aep, then reopen the user's project.
// Not in an undo group (the project is closed and reopened, so undo history goes anyway). Once the project
// has been reduced, the user's own file is always reopened — even when writing the asset failed — and the
// reduced copy is closed WITHOUT saving, so it can never be saved over their project.
MS.assetSave = function (aepPath) {
    var c, orig, out = new File(aepPath), reduced = false, result;
    if (!app.project) { return MS.err("Open or create a project first"); }
    try {
        c = MS._assetComp();
        orig = app.project.file;
        if (!orig) { throw new Error("Save your project once first (File → Save), then try again"); }
        if (String(out.fsName).toLowerCase() === String(orig.fsName).toLowerCase()) { throw new Error("That name is your project's own file — pick another name"); }
        app.project.save();
        reduced = true;
        app.project.reduceProject([c]);
        app.project.save(out);
        result = MS.ok("Saved “" + decodeURI(out.name).replace(/\.aep$/i, "") + "” to Assetbox");
    } catch (e) {
        result = MS.err(MS.friendly(e));
    }
    if (reduced) {
        try { app.project.close(CloseOptions.DO_NOT_SAVE_CHANGES); } catch (eC) {}
        try { app.open(orig); } catch (eO) { result = MS.err("Your project is saved but couldn't be reopened — open it from " + orig.fsName); }
    }
    return result;
};

MS._findCompIn = function (folder, name) {
    var i, it, r, first = null;
    for (i = 1; i <= folder.numItems; i++) {
        it = folder.item(i);
        if (it instanceof CompItem) {
            if (it.name === name) { return it; }
            if (!first) { first = it; }
        }
    }
    for (i = 1; i <= folder.numItems; i++) {
        it = folder.item(i);
        if (it instanceof FolderItem) { r = MS._findCompIn(it, name); if (r) { return r; } }
    }
    return first;
};

// Import an Assetbox .aep. With a comp open, the asset comp lands in it at the playhead; otherwise it opens.
MS.assetImport = function (aepPath) {
    return MS.run("Import asset", function () {
        var f = new File(aepPath), name, active = MS.comp(), folder, comp, l;
        if (!f.exists) { throw new Error("Asset not found: " + f.displayName); }
        name = decodeURI(f.name).replace(/\.aep$/i, "");
        folder = app.project.importFile(new ImportOptions(f));
        folder.name = "Assetbox • " + name;
        comp = MS._findCompIn(folder, name);
        if (!comp) { return MS.ok("Imported “" + name + "” into the project"); }
        if (active) {
            l = active.layers.add(comp);
            l.startTime = active.time;
            return MS.ok("“" + name + "” added to " + active.name);
        }
        comp.openInViewer();
        return MS.ok("Opened “" + name + "”");
    });
};

/* ------------------------------------------------------ subtitle pairs */

// Selected layers (or every layer) in stack order, grouped two by two: [top, bottom].
MS._pairs = function (c) {
    var list = MS._editable(MS.selectedLayers(c)), out = [], i;
    if (!list.length) { for (i = 1; i <= c.numLayers; i++) { if (!c.layer(i).locked) { list.push(c.layer(i)); } } }
    list.sort(function (a, b) { return a.index - b.index; });
    for (i = 0; i < list.length; i += 2) { out.push(i + 1 < list.length ? [list[i], list[i + 1]] : [list[i]]); }
    return out;
};

MS._setInOut = function (l, a, b) {
    if (b <= a) { return; }
    if (a >= l.outPoint) { l.outPoint = b; l.inPoint = a; } else { l.inPoint = a; l.outPoint = b; }
};

// Each pair (caption + its box) gets the same in/out, then every pair stretches to the next one: no gaps, no overlaps.
MS.pairStretch = function () {
    return MS.run("Pair & stretch", function () {
        var c = MS.needComp(), pairs = MS._pairs(c), i, j, p, a, b, items = [];
        if (pairs.length < 1 || (pairs.length === 1 && pairs[0].length < 2)) { throw new Error("Select caption layers in pairs (text + box)"); }
        for (i = 0; i < pairs.length; i++) {
            p = pairs[i]; a = 1e9; b = -1e9;
            for (j = 0; j < p.length; j++) { a = Math.min(a, p[j].inPoint); b = Math.max(b, p[j].outPoint); }
            items.push({ p: p, a: a, b: b });
        }
        items.sort(function (x, y) { return x.a - y.a; });
        for (i = 0; i < items.length; i++) {
            if (i < items.length - 1 && items[i + 1].a > items[i].a) { items[i].b = items[i + 1].a; }
            for (j = 0; j < items[i].p.length; j++) { MS._setInOut(items[i].p[j], items[i].a, items[i].b); }
        }
        return MS.ok("Paired & stretched " + MS._plural(items.length, "caption"));
    });
};

// which: top | bot
MS.selectPair = function (which) {
    return MS.run("Select pair layers", function () {
        var c = MS.needComp(), pairs = MS._pairs(c), i, j, n = 0;
        for (i = 1; i <= c.numLayers; i++) { c.layer(i).selected = false; }
        for (i = 0; i < pairs.length; i++) {
            for (j = 0; j < pairs[i].length; j++) {
                if ((which === "top") === (j === 0) && pairs[i].length === 2) { pairs[i][j].selected = true; n++; }
            }
        }
        return MS.ok(MS._plural(n, which === "top" ? "top layer" : "bottom layer") + " selected");
    });
};

/* ---------------------------------------------------- ease read-back */

MS._r2 = function (v) { return Math.round(v * 100) / 100; };

// Turn the ease between two selected keys back into cubic-bezier numbers (the inverse of MS._easePair).
MS.readEase = function () {
    return MS.run("Read ease", function () {
        var c = MS.needComp(), props = c.selectedProperties, i, p = null, keys, a, b, oe, ie, sp, x1, y1, x2, y2,
            spatial;
        for (i = 0; i < props.length; i++) {
            if (props[i].propertyType === PropertyType.PROPERTY && props[i].numKeys >= 2) { p = props[i]; break; }
        }
        if (!p) { throw new Error("Select 2 keyframes to read their curve"); }
        keys = p.selectedKeys;
        a = keys.length ? keys[0] : 1;
        if (a >= p.numKeys) { a = p.numKeys - 1; }
        b = a + 1;
        oe = p.keyOutTemporalEase(a)[0];
        ie = p.keyInTemporalEase(b)[0];
        sp = MS._speed(p, a, b, p.keyOutTemporalEase(a).length)[0];
        spatial = p.propertyValueType === PropertyValueType.TwoD_SPATIAL || p.propertyValueType === PropertyValueType.ThreeD_SPATIAL;
        x1 = oe.influence / 100;
        x2 = 1 - ie.influence / 100;
        if (Math.abs(sp) < 1e-6) { y1 = 0; y2 = 1; }
        else {
            y1 = (spatial ? Math.abs(oe.speed) : oe.speed) * x1 / sp;
            y2 = 1 - (spatial ? Math.abs(ie.speed) : ie.speed) * (1 - x2) / sp;
        }
        if (p.keyOutInterpolationType(a) === KeyframeInterpolationType.LINEAR && p.keyInInterpolationType(b) === KeyframeInterpolationType.LINEAR) {
            x1 = 0; y1 = 0; x2 = 1; y2 = 1;
        }
        return MS.ok("Curve " + MS._r2(x1) + ", " + MS._r2(y1) + ", " + MS._r2(x2) + ", " + MS._r2(y2));
    });
};

/* ------------------------------------------------- panel bridge extras */

// Lock each Gradient Ramp's start/end points to the layer's content box, so the gradient follows
// text or shape size changes. Run again to unlock (bakes the current position back in).
MS.gradLock = function () {
    return MS.run("Grad lock", function () {
        var c = MS.needComp(), sel = MS._needSel(c, 1, "Select layers with a Gradient Ramp"), i, j, k, l, fxp, fx, r, p, v, fx0, fy0,
            locked = 0, unlocked = 0, skipped = 0;
        for (i = 0; i < sel.length; i++) {
            l = sel[i];
            fxp = l.property("ADBE Effect Parade");
            if (!fxp || !(MS.isVisual(l))) { continue; }
            r = MS._rect(l, c.time);
            for (j = 1; j <= fxp.numProperties; j++) {
                fx = fxp.property(j);
                if (fx.matchName !== "ADBE Ramp") { continue; }
                for (k = 1; k <= 3; k += 2) {           // 1 = Start of Ramp, 3 = End of Ramp
                    p = fx.property(k);
                    v = p.valueAtTime(c.time, false);
                    if (p.expression && p.expression.indexOf("MS Grad Lock") !== -1) {
                        p.expression = "";
                        if (p.numKeys > 0) { p.setValueAtTime(c.time, [v[0], v[1]]); } else { p.setValue([v[0], v[1]]); }
                        unlocked++;
                    } else if (p.expression) {
                        skipped++;                       // the user's own expression: never replaced
                    } else {
                        fx0 = r.width ? (v[0] - r.left) / r.width : 0;
                        fy0 = r.height ? (v[1] - r.top) / r.height : 0;
                        p.expression = "// MS Grad Lock\nvar r = thisLayer.sourceRectAtTime(time, false);\n" +
                            "[r.left + r.width * " + fx0 + ", r.top + r.height * " + fy0 + "];";
                        locked++;
                    }
                }
            }
        }
        if (!locked && !unlocked) { throw new Error(skipped ? "Those Gradient Ramp points already have your own expressions — remove them first" : "No Gradient Ramp on the selected layers"); }
        return MS.ok((locked ? "Gradient locked to layer (" + Math.ceil(locked / 2) + ")" : "Gradient unlocked (" + Math.ceil(unlocked / 2) + ")") +
            (skipped ? " — " + skipped + " point" + (skipped === 1 ? "" : "s") + " with your own expression left alone" : ""));
    });
};

// Move selected layers up (negative) or down (positive) by `dy` comp pixels.
MS.nudge = function (dy) {
    return MS.run("Nudge", function () {
        var c = MS.needComp(), sel = MS._needSel(c), i, n = 0;
        for (i = 0; i < sel.length; i++) {
            if (!(MS.isVisual(sel[i]))) { continue; }
            MS._moveInComp(sel[i], 0, Number(dy) || 0, c.time);
            n++;
        }
        return MS.ok("Nudged " + MS._plural(n, "layer") + " " + (dy < 0 ? "up" : "down") + " " + Math.abs(dy) + "px");
    });
};

// Subtitle editor: a rounded box under each caption that resizes with its text.
// The box sits directly below its caption, so Pair & Stretch / Sel Top / Sel Bot work on them.
MS.subtitleBoxes = function () {
    return MS.run("Subtitle boxes", function () {
        var c = MS.needComp(), sel = MS.selectedLayers(c), texts = [], i, t, box, g, rect, fill, n = 0, ref;
        for (i = 0; i < sel.length; i++) { if (sel[i] instanceof TextLayer) { texts.push(sel[i]); } }
        if (!texts.length) {
            for (i = 1; i <= c.numLayers; i++) { if (c.layer(i) instanceof TextLayer && /^Caption/.test(c.layer(i).name)) { texts.push(c.layer(i)); } }
        }
        if (!texts.length) { throw new Error("Select caption text layers (or import an SRT first)"); }
        for (i = 0; i < texts.length; i++) {
            t = texts[i];
            ref = "thisComp.layer(" + MS._q(t.name) + ")";
            box = c.layers.addShape();
            box.name = t.name + " • Box";
            box.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
            g = box.property("ADBE Root Vectors Group").property(1).property("ADBE Vectors Group");
            g.addProperty("ADBE Vector Shape - Rect");
            g.addProperty("ADBE Vector Graphic - Fill");
            g = box.property("ADBE Root Vectors Group").property(1).property("ADBE Vectors Group");
            rect = g.property(1);
            rect.property("ADBE Vector Rect Size").expression =
                "var t = " + ref + ", r = t.sourceRectAtTime(time, false), s = t.transform.scale.value / 100, pad = 24;\n" +
                "[r.width * s[0] + pad * 2, r.height * s[1] + pad];";
            rect.property("ADBE Vector Rect Position").expression =
                "var t = " + ref + ", r = t.sourceRectAtTime(time, false);\n" +
                "fromComp(t.toComp([r.left + r.width / 2, r.top + r.height / 2]));";
            rect.property("ADBE Vector Rect Roundness").setValue(14);
            fill = g.property(2);
            fill.property("ADBE Vector Fill Color").setValue([0, 0, 0, 1]);
            fill.property("ADBE Vector Fill Opacity").setValue(65);
            box.transform.anchorPoint.setValue([0, 0]);
            box.transform.position.setValue([0, 0]);
            box.moveAfter(t);
            box.inPoint = t.inPoint;
            box.outPoint = t.outPoint;
            box.label = 8;
            n++;
        }
        return MS.ok("Added " + n + (n === 1 ? " subtitle box" : " subtitle boxes"));
    });
};

// Rebuild keys so that every key at/after t0 is stretched by factor f around t0.
MS._retimeFrom = function (p, t0, f) {
    var moved = function (t) { return t >= t0 - 0.0001; };
    MS._rebuildKeys(p, function (t) { return moved(t) ? t0 + (t - t0) * f : t; }, f, moved);
};

// Text animator "Apply to layers": apply an .ffx at each layer's in point (+ offset) and stretch it to `duration` seconds.
MS.applyPresetWithDuration = function (path, duration, offset) {
    return MS.run("Apply text animation", function () {
        var c = MS.needComp(), sel = MS._needSel(c, 1, "Select the text layers to animate"),
            f = new File(String(path).replace(/\\+/g, "/")), t0save = c.time, i, j, k, l, t0, props, hi, kt, n = 0;
        if (!f.exists) { throw new Error("Preset not found: " + decodeURI(f.name)); }
        for (i = 0; i < sel.length; i++) { sel[i].selected = false; }
        try {
            for (i = 0; i < sel.length; i++) {
                l = sel[i];
                t0 = Math.min(c.duration - c.frameDuration, l.inPoint + (Number(offset) || 0));
                c.time = t0;
                l.selected = true;
                l.applyPreset(f);
                l.selected = false;
                if (Number(duration) > 0) {
                    props = MS._keyedProps(l);
                    hi = t0;
                    for (j = 0; j < props.length; j++) {
                        for (k = 1; k <= props[j].numKeys; k++) {
                            kt = props[j].keyTime(k);
                            if (kt >= t0 - 0.0001 && kt > hi) { hi = kt; }
                        }
                    }
                    if (hi > t0 + 0.0001) {
                        for (j = 0; j < props.length; j++) { MS._retimeFrom(props[j], t0, Number(duration) / (hi - t0)); }
                    }
                }
                n++;
            }
        } finally {
            c.time = t0save;
            for (i = 0; i < sel.length; i++) { sel[i].selected = true; }
        }
        return MS.ok(decodeURI(f.name).replace(/\.ffx$/i, "") + " → " + MS._plural(n, "layer"));
    });
};

MS.makeCounterText = function () {
    return MS.run("Counter text", function () {
        var c = MS.needComp(), l = MS.makeText(c, "0", Math.round(c.height / 8), "#FFFFFF"), i;
        l.name = "Counter";
        for (i = 1; i <= c.numLayers; i++) { c.layer(i).selected = false; }
        l.selected = true;
        return MS.ok("Text layer ready — now Apply Counter or Timer");
    });
};

MS.activeCompName = function () {
    var sel = app.project ? app.project.selection : [], i, c = MS.comp();
    for (i = 0; i < sel.length; i++) { if (sel[i] instanceof CompItem) { return MS.ok(sel[i].name); } }
    return c ? MS.ok(c.name) : MS.err("Open or select a comp first");
};

// Timer & Goal (js/ms-timer.js) asks every few seconds what the user is working on, for automatic time
// tracking: the project (its file, so two projects with the same name stay apart), the active comp, and
// `sig`, a value that changes whenever the user does something — After Effects' own edit counter
// (app.project.revision: +1 per user action) plus the comp, its current time (scrubbing, previews), layer
// count and selection. Read only: no undo step, nothing changes.
MS.timerProbe = function () {
    var p = app.project, f = null, c = null, name = "Unsaved project", path = "", comp = "", sig = "", sel, i;
    if (!p) { return MS.err("No project"); }
    try { f = p.file; } catch (eF) { f = null; }
    if (f) {
        path = String(f.fsName || "");
        try { name = decodeURI(String(f.name)); } catch (eN) { name = String(f.name); }
        name = name.replace(/\.aepx?$/i, "");
    }
    try { sig = (typeof p.revision === "number" ? p.revision : "") + "|" + p.numItems; } catch (eR) { sig = "|"; }
    try { c = p.activeItem; } catch (eA) { c = null; }
    if (c instanceof CompItem) {
        comp = c.name;
        sel = c.selectedLayers;
        sig += "|" + c.id + "|" + Math.round(c.time * 100) + "|" + c.numLayers + "|" + sel.length;
        for (i = 0; i < sel.length && i < 8; i++) { sig += "," + sel[i].index; }
        try { sig += "|" + c.selectedProperties.length; } catch (eP) {}
    } else if (c) {
        sig += "|i" + c.id;
    }
    return MS.ok(MS._json({ name: name, path: path, comp: comp, sig: sig }));
};

/* ---------------------------------------------------------------- carousel */
// The Carousel panel (js/ms-carousel.js; layout maths in js/ms-carousel-core.js). A carousel is a rig: a 3D
// null "MS Carousel N" with one effect per setting (Style, Size, Spread, Tilt, … Start / Middle / End points),
// and pictures whose position / scale / opacity / X Y Z rotation expressions read those effects. So the panel
// (or the user, in Effect Controls) changes a carousel live by setting effect values; nothing is rebuilt.
// The panel sends the expressions (with {CTRL} {IDX} {N} {LONG} {PATH} placeholders) so they always match its
// preview. The rig's comment remembers the custom path, if any.
MS._CAR_MARK = "// MotionSaaS Carousel";
MS._fxNamed = function (l, name) {
    var fx = l.property("ADBE Effect Parade"), i;
    if (!fx) { return null; }
    for (i = 1; i <= fx.numProperties; i++) { if (fx.property(i).name === name) { return fx.property(i); } }
    return null;
};
// A rig: a layer with the carousel's "Style" effect that is named "MS Carousel N" or says so in its comment
// (so it stays a rig after the user renames it).
MS._carIsRig = function (l) {
    if (!MS._fxNamed(l, "Style")) { return false; }
    return /^MS Carousel \d+$/.test(l.name) || MS._carMeta(l).rig === true;
};
// The rig name a picture's expressions refer to, or null.
MS._carRef = function (l) {
    var e, m;
    try { e = String(l.transform.position.expression || ""); } catch (eP) { return null; }
    if (e.indexOf(MS._CAR_MARK) !== 0) { return null; }
    m = /thisComp\.layer\("((?:[^"\\]|\\.)*)"\)/.exec(e);
    if (!m) { return null; }
    try { return MS._parseJSON("\"" + m[1] + "\""); } catch (eJ) { return null; }
};
// The rig a layer belongs to (the rig itself, or a picture whose expressions name it — by its current name,
// or by the name it had when built, if the user renamed it since), else null.
MS._carRigOf = function (c, l) {
    var name, r, i;
    if (MS._carIsRig(l)) { return l; }
    name = MS._carRef(l);
    if (name === null) { return null; }
    try { r = c.layer(name); } catch (eL) { r = null; }
    if (r && MS._carIsRig(r)) { return r; }
    for (i = 1; i <= c.numLayers; i++) {
        r = c.layer(i);
        if (MS._carMeta(r).name === name && MS._carIsRig(r)) { return r; }
    }
    return null;
};
MS._carItems = function (c, rig) {
    var out = [], i, l;
    for (i = 1; i <= c.numLayers; i++) {
        l = c.layer(i);
        if (l !== rig && !MS._carIsRig(l) && MS._carRigOf(c, l) === rig) { out.push(l); }
    }
    return out;
};
// The rig was renamed after it was built: point its pictures' expressions at the new name (our own
// expressions only). Returns how many pictures were reconnected.
MS._carRelink = function (c, rig) {
    var meta = MS._carMeta(rig), old = meta.name, items, i, k, props, e, n = 0, from, to;
    if (!old || old === rig.name) { return 0; }
    items = MS._carItems(c, rig);
    from = "thisComp.layer(" + MS._json(old) + ")";
    to = "thisComp.layer(" + MS._json(rig.name) + ")";
    for (i = 0; i < items.length; i++) {
        props = MS._carProps(items[i]);
        for (k in props) {
            if (!props.hasOwnProperty(k) || !props[k]) { continue; }
            e = String(props[k].expression || "");
            if (e.indexOf(MS._CAR_MARK) === 0 && e.indexOf(from) !== -1) { props[k].expression = e.split(from).join(to); }
        }
        n++;
    }
    meta.name = rig.name;
    rig.comment = MS._json(meta);
    return n;
};
MS.carouselRelink = function (rigName) {
    return MS.run("Reconnect carousel", function () {
        var c = MS.needComp(), rig = c.layer(String(rigName));
        if (!rig || !MS._carIsRig(rig)) { return MS.err("Select a carousel first"); }
        return MS.ok(String(MS._carRelink(c, rig)));
    });
};
// A path the pictures can follow: the layer's first mask, or a shape layer's first drawn path.
// → { label, expr } where expr is an expression function (u → comp point), or null.
MS._carPathOf = function (l) {
    var masks, q = MS._json(l.name), chain, found = null, root;
    try { masks = l.property("ADBE Mask Parade"); } catch (eM) { masks = null; }
    if (masks && masks.numProperties > 0) {
        return { label: l.name + " › " + masks.property(1).name,
            expr: "function (u) { var L = thisComp.layer(" + q + "); return L.toComp(L.mask(" + MS._json(masks.property(1).name) + ").maskPath.pointOnPath(u)); }" };
    }
    if (!(l instanceof ShapeLayer)) { return null; }
    function walk(g, path) {
        var i, p, inner;
        for (i = 1; i <= g.numProperties && !found; i++) {
            p = g.property(i);
            if (p.matchName === "ADBE Vector Shape - Group") { found = path + ".content(" + MS._json(p.name) + ").path"; }
            else if (p.matchName === "ADBE Vector Group") {
                inner = p.property("ADBE Vectors Group");
                if (inner) { walk(inner, path + ".content(" + MS._json(p.name) + ")"); }
            }
        }
    }
    root = l.property("ADBE Root Vectors Group");
    if (root) { walk(root, "L"); }
    if (!found) { return null; }
    chain = found;
    return { label: l.name + " › path", expr: "function (u) { var L = thisComp.layer(" + q + "); return L.toComp(" + chain + ".pointOnPath(u)); }" };
};
MS._carProps = function (l) {
    var t = l.transform;
    return { position: t.position, scale: t.scale, opacity: t.opacity, rotateX: t.property("ADBE Rotate X"), rotateY: t.property("ADBE Rotate Y"), rotateZ: t.property("ADBE Rotate Z") };
};
MS._carValues = function (rig) {
    var fx = rig.property("ADBE Effect Parade"), out = {}, i, p;
    for (i = 1; i <= fx.numProperties; i++) {
        p = fx.property(i);
        if (p.matchName === "ADBE Slider Control" || p.matchName === "ADBE Point Control") { out[p.name] = p.property(1).value; }
    }
    return out;
};
MS._carMeta = function (rig) {
    var m = null;
    try { m = MS._parseJSON(rig.comment || "{}"); } catch (e) { m = null; }
    return m && typeof m === "object" ? m : {};
};

// What the panel should show: pictures selected, the carousel being edited, a path layer in the selection,
// and whether pictures already carry expressions of the user's own (the panel asks before replacing them).
// Read only.
MS.carouselProbe = function () {
    var c = MS.comp(), sel, i, l, r, rig = null, pics = 0, path = null, own = false, props, k, e, out;
    if (!c) { return MS.ok(MS._json({ comp: false })); }
    sel = MS.selectedLayers(c);
    for (i = 0; i < sel.length; i++) {
        l = sel[i];
        r = MS._carRigOf(c, l);
        if (r) { rig = r; continue; }
        if (!path) { path = MS._carPathOf(l); if (path) { path.layer = l.name; continue; } }
        if (MS.isVisual(l) && !l.locked) {
            pics++;
            props = MS._carProps(l);
            for (k in props) {
                if (props.hasOwnProperty(k) && props[k]) {
                    e = String(props[k].expression || "");
                    if (e && props[k].expressionEnabled !== false && e.indexOf(MS._CAR_MARK) !== 0) { own = true; }
                }
            }
        }
    }
    out = { comp: true, w: c.width, h: c.height, pics: pics, path: path ? { label: path.label, layer: path.layer } : null, ownExpr: own, rig: null };
    if (rig) {
        out.rig = { name: rig.name, items: MS._carItems(c, rig).length, values: MS._carValues(rig), path: MS._carMeta(rig).pathLabel || "",
            renamed: !!MS._carMeta(rig).name && MS._carMeta(rig).name !== rig.name };
    }
    return MS.ok(MS._json(out));
};

// Build a carousel from the selected layers, or rebuild the selected one (adding newly selected layers, or
// a newly selected path). o: { fields: [[key, name, "slider"|"point", value]…], expr: { position, scale,
// opacity, rotateX, rotateY, rotateZ }, usePath, revealOn, revealDur }
MS.carouselBuild = function (json) {
    return MS.run("Carousel", function () {
        var o = MS._parseJSON(json), c = MS.needComp(), sel = MS.selectedLayers(c), rig = null, pics = [], pathL = null, pathD = null,
            i, j, l, r, items, n, fx, f, p, meta, name, num, props, k, side, rect, t0 = c.time, pathExpr = "null", rv, dur;
        for (i = 0; i < sel.length; i++) {
            l = sel[i];
            r = MS._carRigOf(c, l);
            if (r) { rig = r; continue; }
            if (o.usePath && !pathL) { pathD = MS._carPathOf(l); if (pathD) { pathL = l; continue; } }
            if (MS.isVisual(l) && !l.locked) { pics.push(l); }
        }
        items = rig ? MS._carItems(c, rig) : [];
        for (i = 0; i < pics.length; i++) {
            for (j = 0; j < items.length && items[j] !== pics[i]; j++) {}
            if (j === items.length) { items.push(pics[i]); }
        }
        items.sort(function (a, b) { return a.index - b.index; });
        n = items.length;
        if (n < 2) { return MS.err(rig ? "This carousel has fewer than two pictures left" : "Select two or more layers (your pictures) to build a carousel"); }
        meta = rig ? MS._carMeta(rig) : {};
        if (pathD) { meta.pathLabel = pathD.label; meta.pathExpr = pathD.expr; }
        if (o.usePath && !meta.pathExpr) { return MS.err("Custom path: also select the layer whose mask or shape path the pictures should follow"); }
        if (o.usePath) { pathExpr = meta.pathExpr; }

        if (!rig) {
            num = 1;
            while (c.layer("MS Carousel " + num)) { num++; }
            rig = c.layers.addNull();
            rig.name = "MS Carousel " + num;
            rig.threeDLayer = true;
            rig.transform.anchorPoint.setValue([0, 0, 0]);
            rig.transform.position.setValue([c.width / 2, c.height / 2, 0]);
            rig.moveBefore(items[0]);
        }
        meta.rig = true;           // stays a rig even if renamed
        meta.name = rig.name;      // the name its pictures' expressions use (see MS._carRelink)
        rig.comment = MS._json(meta);
        name = rig.name;
        for (i = 0; i < o.fields.length; i++) {
            f = o.fields[i];
            fx = MS._fxNamed(rig, f[1]);
            if (!fx) {
                fx = rig.property("ADBE Effect Parade").addProperty(f[2] === "point" ? "ADBE Point Control" : "ADBE Slider Control");
                fx.name = f[1];
                rig = c.layer(name);   // addProperty invalidates references
                fx = MS._fxNamed(rig, f[1]);
            }
            p = fx.property(1);
            while (p.numKeys > 0) { p.removeKey(1); }
            p.setValue(f[3]);
        }
        // Reveal: keyed 0 → 100 from the current time, easing out, unless turned off.
        rv = MS._fxNamed(rig, "Reveal").property(1);
        while (rv.numKeys > 0) { rv.removeKey(1); }
        if (o.revealOn) {
            dur = Math.max(0.2, Number(o.revealDur) || 1.2);
            rv.setValueAtTime(t0, 0);
            rv.setValueAtTime(t0 + dur, 100);
            rv.setTemporalEaseAtKey(1, [new KeyframeEase(0, 33)], [new KeyframeEase(0, 33)]);
            rv.setTemporalEaseAtKey(2, [new KeyframeEase(0, 80)], [new KeyframeEase(0, 33)]);
        } else {
            rv.setValue(100);
        }
        for (i = 0; i < n; i++) {
            l = items[i];
            l.threeDLayer = true;
            try { rect = l.sourceRectAtTime(t0, false); side = Math.max(rect.width, rect.height); } catch (eR) { side = Math.max(l.width, l.height); }
            if (!(side > 0)) { side = 100; }
            props = MS._carProps(l);
            if (props.position.dimensionsSeparated) { props.position.dimensionsSeparated = false; }
            for (k in o.expr) {
                if (o.expr.hasOwnProperty(k) && props[k]) {
                    props[k].expression = String(o.expr[k]).replace(/\{CTRL\}/g, MS._json(name)).replace(/\{IDX\}/g, String(i))
                        .replace(/\{N\}/g, String(n)).replace(/\{LONG\}/g, String(Math.round(side * 100) / 100)).replace(/\{PATH\}/g, pathExpr);
                }
            }
        }
        for (i = 1; i <= c.numLayers; i++) { c.layer(i).selected = false; }
        c.layer(name).selected = true;
        return MS.ok(MS._json({ name: name, items: n }));
    });
};

// Live edit: set effect values on the rig (by effect name). Keyframed settings get a key at the current time.
MS.carouselSet = function (rigName, json) {
    return MS.run("Carousel setting", function () {
        var c = MS.needComp(), rig = c.layer(String(rigName)), o = MS._parseJSON(json), k, fx, p, n = 0;
        if (!rig || !MS._carIsRig(rig)) { return MS.err("That carousel isn't in this comp any more"); }
        MS._carRelink(c, rig);   // renamed since it was built: reconnect its pictures first
        for (k in o) {
            if (!o.hasOwnProperty(k)) { continue; }
            fx = MS._fxNamed(rig, k);
            if (!fx) { continue; }
            p = fx.property(1);
            if (p.numKeys > 0) { p.setValueAtTime(c.time, o[k]); } else { p.setValue(o[k]); }
            n++;
        }
        return MS.ok(String(n));
    });
};

// Take a carousel apart: every picture keeps how it looks at the current time (values baked, expressions
// removed), and the rig null goes.
MS.carouselRelease = function (rigName) {
    return MS.run("Release carousel", function () {
        var c = MS.needComp(), rig = c.layer(String(rigName)), items, i, props, k, v;
        if (!rig || !MS._carIsRig(rig)) { return MS.err("Select a carousel first"); }
        items = MS._carItems(c, rig);
        for (i = 0; i < items.length; i++) {
            props = MS._carProps(items[i]);
            for (k in props) {
                if (!props.hasOwnProperty(k) || !props[k] || String(props[k].expression || "").indexOf(MS._CAR_MARK) !== 0) { continue; }
                v = props[k].value;
                props[k].expression = "";
                if (props[k].numKeys > 0) { props[k].setValueAtTime(c.time, v); } else { props[k].setValue(v); }
            }
        }
        rig.remove();
        return MS.ok(String(items.length));
    });
};

// Custom expressions (Comp Tools → Expressions): put `code` on every selected property that takes one.
// Properties that already carry another expression are left alone unless `replace` is true; then the answer
// is "ASK|n" (n of them) so the panel can ask first.
MS.applyExpression = function (code, replace) {
    return MS.run("Apply expression", function () {
        var c = MS.needComp(), props = c.selectedProperties, i, p, n = 0, busy = 0, err = "";
        code = String(code || "");
        if (!code) { return MS.err("The expression is empty"); }
        for (i = 0; i < props.length; i++) {
            p = props[i];
            if (p.propertyType !== PropertyType.PROPERTY || !p.canSetExpression) { continue; }
            if (!replace && p.expression && p.expression !== code) { busy++; }
        }
        if (busy) { return "ASK|" + busy; }
        for (i = 0; i < props.length; i++) {
            p = props[i];
            if (p.propertyType !== PropertyType.PROPERTY || !p.canSetExpression) { continue; }
            p.expression = code;
            n++;
            if (!err && p.expressionError) { err = p.expressionError; }
        }
        if (!n) { return MS.err("Select one or more properties (twirl a layer open and click a property name)"); }
        return err ? MS.err("Applied to " + n + ", but After Effects reports: " + err) : MS.ok(String(n));
    });
};

// Render `count` frames across the comp's work area as PNGs (Assetbox GIF previews). AE writes them in the background.
MS.assetFrames = function (dir, count) {
    return MS.run("Asset preview frames", function () {
        var c = MS._assetComp(), d = new Folder(dir), i, t, n = Math.max(2, Math.min(40, Math.round(count) || 16)), span;
        if (typeof c.saveFrameToPng !== "function") { return MS.err("This AE version can't render preview frames"); }
        if (!d.exists) { d.create(); }
        span = c.workAreaDuration || c.duration;
        for (i = 0; i < n; i++) {
            t = c.workAreaStart + span * i / n;
            c.saveFrameToPng(t, new File(d.fsName + "/frame_" + (i < 10 ? "0" : "") + i + ".png"));
        }
        return MS.ok(String(n));
    });
};

// Maintainer tool (About → Rebuild text previews, js/panel/05c-text-presets.js): render one Text Preset applied
// to the word "MotionSaaS" as PNG frames, across the animation plus a short hold. AE writes the frames in the
// background, so the temporary comp stays until MS.textPreviewDone removes it.
MS.textPreviewFrames = function (ffxPath, dir, count) {
    return MS.run("Text preview frames", function () {
        var f = new File(String(ffxPath).replace(/\\+/g, "/")), d = new Folder(dir), c, l, n, i, j, k, props, hi = 0, span;
        if (!f.exists) { return MS.err("Preset not found: " + decodeURI(f.name)); }
        c = app.project.items.addComp("MotionSaaS Preview Render", 960, 400, 1, 6, 24);
        if (typeof c.saveFrameToPng !== "function") { c.remove(); return MS.err("This AE version can't render preview frames"); }
        c.openInViewer();
        l = MS.makeText(c, "MotionSaaS", 110, "#FFFFFF");
        c.time = 0;
        l.selected = true;
        l.applyPreset(f);
        l = c.layer(1);   // re-fetched: applying a preset invalidates the reference
        props = MS._keyedProps(l);
        for (j = 0; j < props.length; j++) { for (k = 1; k <= props[j].numKeys; k++) { if (props[j].keyTime(k) > hi) { hi = props[j].keyTime(k); } } }
        span = Math.min(5.5, Math.max(1.2, hi + 0.6));
        n = Math.max(2, Math.min(60, Math.round(count) || 36));
        if (!d.exists) { d.create(); }
        for (i = 0; i < n; i++) { c.saveFrameToPng(span * i / n, new File(d.fsName + "/frame_" + (i < 10 ? "0" : "") + i + ".png")); }
        return MS.ok(MS._json({ frames: n, comp: c.id, fps: n / span }));
    });
};
MS.textPreviewDone = function (compId) {
    return MS.run("Text preview cleanup", function () {
        var i, it;
        for (i = app.project.numItems; i >= 1; i--) {
            it = app.project.item(i);
            if (it instanceof CompItem && it.id === compId && it.name === "MotionSaaS Preview Render") { it.remove(); return MS.ok("1"); }
        }
        return MS.ok("0");
    });
};

/* ---------------------------------------- effect snapshots (.msfx) */

MS._json = function (v) {
    var i, out, k;
    if (v === null || v === undefined) { return "null"; }
    if (typeof v === "number") { return isFinite(v) ? String(v) : "0"; }
    if (typeof v === "boolean") { return v ? "true" : "false"; }
    if (typeof v === "string") {
        // Every control character is escaped (AE text can hold e.g. \u0003); a raw one makes the panel's
        // JSON.parse fail, which looks like "After Effects isn't answering".
        return '"' + v.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n").replace(/\t/g, "\\t")
            .replace(/[\x00-\x1f]/g, function (c) { var h = c.charCodeAt(0).toString(16); return "\\u" + "0000".slice(h.length) + h; })
            .split(String.fromCharCode(0x2028)).join("\\u2028").split(String.fromCharCode(0x2029)).join("\\u2029") + '"';
    }
    out = [];
    if (v instanceof Array) {
        for (i = 0; i < v.length; i++) { out.push(MS._json(v[i])); }
        return "[" + out.join(",") + "]";
    }
    for (k in v) { if (v.hasOwnProperty(k)) { out.push(MS._json(String(k)) + ":" + MS._json(v[k])); } }
    return "{" + out.join(",") + "}";
};

// Strict JSON parser (ExtendScript has no JSON object). Data only — nothing in the text is executed.
MS._parseJSON = function (text) {
    var at = 0, s = String(text), ch = s.charAt(0);
    var fail = function (m) { throw new Error(m + " at character " + at); };
    var next = function (c) {
        if (c && c !== ch) { fail("Expected '" + c + "'"); }
        at++; ch = s.charAt(at); return ch;
    };
    var white = function () { while (ch && ch <= " ") { next(); } };
    var number = function () {
        var str = "";
        if (ch === "-") { str = "-"; next("-"); }
        while (ch >= "0" && ch <= "9") { str += ch; next(); }
        if (ch === ".") { str += "."; while (next() && ch >= "0" && ch <= "9") { str += ch; } }
        if (ch === "e" || ch === "E") {
            str += ch; next();
            if (ch === "-" || ch === "+") { str += ch; next(); }
            while (ch >= "0" && ch <= "9") { str += ch; next(); }
        }
        if (!isFinite(+str)) { fail("Bad number"); }
        return +str;
    };
    var esc = { '"': '"', "\\": "\\", "/": "/", b: "\b", f: "\f", n: "\n", r: "\r", t: "\t" };
    var string = function () {
        var out = "", hex, i, u;
        if (ch !== '"') { fail("Expected string"); }
        while (next()) {
            if (ch === '"') { next(); return out; }
            if (ch === "\\") {
                next();
                if (ch === "u") {
                    u = 0;
                    for (i = 0; i < 4; i++) { hex = parseInt(next(), 16); if (isNaN(hex)) { fail("Bad escape"); } u = u * 16 + hex; }
                    out += String.fromCharCode(u);
                } else if (esc.hasOwnProperty(ch)) { out += esc[ch]; }
                else { fail("Bad escape"); }
            } else { out += ch; }
        }
        fail("Unterminated string");
    };
    var word = function () {
        if (s.substr(at, 4) === "true") { at += 4; ch = s.charAt(at); return true; }
        if (s.substr(at, 5) === "false") { at += 5; ch = s.charAt(at); return false; }
        if (s.substr(at, 4) === "null") { at += 4; ch = s.charAt(at); return null; }
        fail("Unexpected '" + ch + "'");
    };
    var value;
    var array = function () {
        var out = [];
        next("["); white();
        if (ch === "]") { next(); return out; }
        while (ch) {
            out.push(value()); white();
            if (ch === "]") { next(); return out; }
            next(","); white();
        }
        fail("Unterminated array");
    };
    var object = function () {
        var out = {}, key;
        next("{"); white();
        if (ch === "}") { next(); return out; }
        while (ch) {
            key = string(); white(); next(":");
            if (key === "__proto__") { value(); } else { out[key] = value(); }
            white();
            if (ch === "}") { next(); return out; }
            next(","); white();
        }
        fail("Unterminated object");
    };
    value = function () {
        white();
        if (ch === "{") { return object(); }
        if (ch === "[") { return array(); }
        if (ch === '"') { return string(); }
        if (ch === "-" || (ch >= "0" && ch <= "9")) { return number(); }
        return word();
    };
    var result = value();
    white();
    if (ch) { fail("Unexpected trailing text"); }
    return result;
};

MS._snapType = function (p) {
    var t = p.propertyValueType;
    return t === PropertyValueType.OneD || t === PropertyValueType.TwoD || t === PropertyValueType.ThreeD ||
        t === PropertyValueType.TwoD_SPATIAL || t === PropertyValueType.ThreeD_SPATIAL || t === PropertyValueType.COLOR;
};

// Leaf values of one effect: [{ i: [index path], v, x (expression), k: [[time from in point, value], ...] }]
MS._fxProps = function (group, l, pathSoFar, out) {
    var i, p, entry, k, here;
    out = out || [];
    for (i = 1; i <= group.numProperties; i++) {
        p = group.property(i);
        here = pathSoFar.concat([i]);
        if (p.propertyType !== PropertyType.PROPERTY) { MS._fxProps(p, l, here, out); continue; }
        if (!MS._snapType(p)) { continue; }
        entry = { i: here };
        if (p.numKeys > 0) {
            entry.k = [];
            for (k = 1; k <= p.numKeys; k++) { entry.k.push([p.keyTime(k) - l.inPoint, p.keyValue(k)]); }
        } else {
            entry.v = p.value;
        }
        if (p.expressionEnabled && p.expression) { entry.x = p.expression; }
        out.push(entry);
    }
    return out;
};

MS.saveFxSnapshot = function (path) {
    return MS.run("Save effects", function () {
        var c = MS.needComp(), sel = MS._needSel(c, 1, "Select a layer with effects", true), props = c.selectedProperties, list = [], i, j, l = null,
            fxp, f, data = [];
        for (i = 0; i < props.length; i++) {
            if (props[i].parentProperty && props[i].parentProperty.matchName === "ADBE Effect Parade") { list.push(props[i]); }
        }
        if (list.length) {
            l = list[0].propertyGroup(list[0].propertyDepth);
        } else {
            for (i = 0; i < sel.length && !list.length; i++) {
                fxp = sel[i].property("ADBE Effect Parade");
                if (fxp && fxp.numProperties) { l = sel[i]; for (j = 1; j <= fxp.numProperties; j++) { list.push(fxp.property(j)); } }
            }
        }
        if (!list.length) { throw new Error("The selected layer has no effects"); }
        for (i = 0; i < list.length; i++) {
            data.push({ m: list[i].matchName, n: list[i].name, on: list[i].enabled, p: MS._fxProps(list[i], l, [], []) });
        }
        f = new File(path);
        if (!f.parent.exists) { f.parent.create(); }
        f.encoding = "UTF-8";
        if (!f.open("w")) { throw new Error("Can't write to " + f.parent.fsName); }
        f.write(MS._json({ motionsaas: 1, ae: app.version, effects: data }));
        f.close();
        return MS.ok("Saved " + MS._plural(data.length, "effect"));
    });
};

// Apply a saved .ffx (AE preset) or .msfx (MotionSaaS snapshot) to every selected layer.
MS.applyFxPreset = function (path) {
    return MS.run("Apply effects preset", function () {
        var c = MS.needComp(), sel = MS._needSel(c, 1, "Select the layers to apply effects to"), f = new File(String(path).replace(/\\+/g, "/")),
            i, j, k, m, l, data, e, fxp, fx, idx, p, pr, txt, missing = 0, n = 0;
        if (!f.exists) { throw new Error("Preset not found: " + decodeURI(f.name)); }
        if (/\.ffx$/i.test(f.name)) {
            for (i = 0; i < sel.length; i++) { sel[i].selected = false; }
            try {
                for (i = 0; i < sel.length; i++) { sel[i].selected = true; sel[i].applyPreset(f); sel[i].selected = false; }
            } finally {
                for (i = 0; i < sel.length; i++) { sel[i].selected = true; }
            }
            return MS.ok(decodeURI(f.name).replace(/\.ffx$/i, "") + " → " + MS._plural(sel.length, "layer"));
        }
        f.encoding = "UTF-8";
        f.open("r"); txt = f.read(); f.close();
        // Never eval() a file: presets get shared, and eval would run any code inside them.
        try { data = MS._parseJSON(txt); } catch (eJ) { throw new Error("That preset file is damaged (" + eJ.message + ")"); }
        if (!data || !(data.effects instanceof Array)) { throw new Error("Not a MotionSaaS effects file"); }
        for (i = 0; i < sel.length; i++) {
            l = sel[i];
            if (!l.property("ADBE Effect Parade")) { continue; }
            for (j = 0; j < data.effects.length; j++) {
                e = data.effects[j];
                fxp = l.property("ADBE Effect Parade");
                if (!fxp.canAddProperty(e.m)) { missing++; continue; }
                idx = fxp.addProperty(e.m).propertyIndex;
                fx = l.property("ADBE Effect Parade").property(idx);
                try { fx.name = e.n; } catch (e1) {}
                try { fx.enabled = e.on !== false; } catch (e2) {}
                for (k = 0; k < e.p.length; k++) {
                    pr = e.p[k];
                    p = fx;
                    for (m = 0; m < pr.i.length && p; m++) { try { p = p.property(pr.i[m]); } catch (e3) { p = null; } }
                    if (!p) { continue; }
                    try {
                        if (pr.k) { for (m = 0; m < pr.k.length; m++) { p.setValueAtTime(l.inPoint + pr.k[m][0], pr.k[m][1]); } }
                        else if (pr.v !== undefined && pr.v !== null) { p.setValue(pr.v); }
                        if (pr.x) { p.expression = pr.x; }
                    } catch (e4) {}
                }
            }
            n++;
        }
        if (!n) { throw new Error("Selected layers can't take effects"); }
        return MS.ok(MS._plural(data.effects.length, "effect") + " → " + MS._plural(n, "layer") + (missing ? " (" + missing + " not installed)" : ""));
    });
};

/* ------------------------------------------------------- device mockups */

// Frame geometry per device (in a 1920×1080 mockup comp). screen = the visible product area.
MS.MOCKUPS = {
    browser: { label: "Browser", body: [1600, 1000], bodyR: 22, screen: [1600, 944], screenR: 0, screenY: 28, bar: true },
    iphone:  { label: "iPhone", body: [520, 1060], bodyR: 92, screen: [484, 1024], screenR: 74, screenY: 0, island: true },
    macbook: { label: "MacBook", body: [1500, 940], bodyR: 34, screen: [1436, 878], screenR: 10, screenY: -8, base: true }
};

// Wrap the selected layer's footage/comp (or a placeholder) in a device frame, in its own comp.
// theme: "dark" | "light"
MS.mockup = function (kind, theme) {
    return MS.run("Device mockup", function () {
        var c = MS.needComp(), d = MS.MOCKUPS[kind], sel = MS.selectedLayers(c), src = null, L = null, i,
            light = theme === "light", frame = light ? "#E5E5EA" : "#1C1C1E", edge = light ? "#C7C7CC" : "#3A3A3C",
            m, cx = 960, cy, body, content, matte, s, k, ml, bar, dot, base, island, fx;
        if (!d) { throw new Error("Unknown device"); }
        for (i = 0; i < sel.length; i++) {
            if (sel[i] instanceof AVLayer && sel[i].source && sel[i].source.width > 0 && sel[i].source.height > 0 &&
                !(sel[i] instanceof TextLayer) && !(sel[i] instanceof ShapeLayer)) { L = sel[i]; src = L.source; break; }
        }
        cy = 540 + (d.base ? -30 : 0);
        m = app.project.items.addComp("MS Mockup — " + d.label + (src ? " — " + src.name : ""), 1920, 1080, 1, c.duration, c.frameRate);

        // Bottom → top. (AE adds each new layer on top, so build in stacking order.)
        body = MS.roundRect(m, d.label + " • Body", d.body[0], d.body[1], d.bodyR, frame, 100, 0);
        body.transform.position.setValue([cx, cy]);
        try {
            fx = body.property("ADBE Effect Parade").addProperty("ADBE Drop Shadow");
            fx.property(2).setValue(40); fx.property(4).setValue(30); fx.property(5).setValue(80);
        } catch (eS) {}

        if (src) {
            content = m.layers.add(src);
            k = Math.max(d.screen[0] / src.width, d.screen[1] / src.height) * 100;     // fill the screen
            content.transform.scale.setValue([k, k]);
            content.transform.position.setValue([cx, cy + d.screenY]);
            content.name = "Screen • " + src.name;
        } else {
            content = MS.roundRect(m, "Screen • replace me", d.screen[0], d.screen[1], 0, "#0A84FF", 100, 0);
            content.transform.position.setValue([cx, cy + d.screenY]);
            fx = content.property("ADBE Effect Parade").addProperty("ADBE Ramp");
            fx.property(1).setValue([-d.screen[0] / 2, -d.screen[1] / 2]); fx.property(2).setValue(MS.rgb("#0A84FF"));
            fx.property(3).setValue([d.screen[0] / 2, d.screen[1] / 2]); fx.property(4).setValue(MS.rgb("#BF5AF2"));
        }
        matte = MS.roundRect(m, "Screen • Matte", d.screen[0], d.screen[1], d.screenR, "#FFFFFF", 100, 0);   // directly above content
        matte.transform.position.setValue([cx, cy + d.screenY]);
        if (typeof content.setTrackMatte === "function") { content.setTrackMatte(matte, TrackMatteType.ALPHA); }
        else { content.trackMatteType = TrackMatteType.ALPHA; }
        matte.enabled = false;

        if (d.bar) {   // browser title bar with traffic lights and an address pill
            bar = MS.roundRect(m, "Browser • Title bar", d.body[0], 56, d.bodyR, light ? "#F2F2F7" : "#2C2C2E", 100, 0);
            bar.transform.position.setValue([cx, cy - d.body[1] / 2 + 28]);
            for (i = 0; i < 3; i++) {
                dot = MS.ellipse(m, "Browser • Light " + (i + 1), 18, ["#FF5F57", "#FEBC2E", "#28C840"][i]);
                dot.transform.position.setValue([cx - d.body[0] / 2 + 36 + i * 30, cy - d.body[1] / 2 + 28]);
            }
            s = MS.roundRect(m, "Browser • Address", 560, 32, 16, light ? "#E5E5EA" : "#3A3A3C", 100, 0);
            s.transform.position.setValue([cx, cy - d.body[1] / 2 + 28]);
        }
        if (d.island) {
            island = MS.roundRect(m, "iPhone • Island", 150, 42, 21, "#000000", 100, 0);
            island.transform.position.setValue([cx, cy - d.screen[1] / 2 + 40]);
        }
        if (d.base) {
            base = MS.roundRect(m, "MacBook • Base", 1820, 34, 17, edge, 100, 0);
            base.transform.position.setValue([cx, cy + d.body[1] / 2 + 14]);
            s = MS.roundRect(m, "MacBook • Notch", 220, 12, 6, frame, 100, 0);
            s.transform.position.setValue([cx, cy + d.body[1] / 2 + 3]);
        }

        // Drop the mockup into the user's comp, above the original layer (which is turned off, not deleted).
        ml = c.layers.add(m);
        if (L) { ml.moveBefore(L); ml.startTime = L.startTime; L.enabled = false; }
        for (i = 1; i <= c.numLayers; i++) { c.layer(i).selected = false; }
        ml.selected = true;
        return MS.ok(d.label + " mockup added" + (L ? " (original layer turned off)" : " — select a screen recording first to fill the screen"));
    });
};

/* ------------------------------------------------------------ self-test */

// A temp folder ExtendScript can write to. Folder.temp follows the TEMP variable, which is broken on
// some machines (e.g. pointing at an old Windows profile) — fall back to the user-data folder.
MS._tempDir = function () {
    var dirs = [Folder.temp, new Folder(Folder.userData.fsName + "/MotionSaaS/tmp")], i, f;
    for (i = 0; i < dirs.length; i++) {
        try {
            if (!dirs[i].exists) { dirs[i].create(); }
            f = new File(dirs[i].fsName + "/ms-probe.txt");
            if (f.open("w")) { f.write("ok"); f.close(); f.remove(); return dirs[i].fsName.replace(/\\/g, "/"); }
        } catch (e) {}
    }
    return Folder.userData.fsName.replace(/\\/g, "/");
};

// Runs (nearly) every tool against a throwaway comp, then deletes everything it created.
// Skipped on purpose: Organise (moves the user's items), Clear Cache (wipes undo), Assetbox save
// (closes the project), SRT import (needs a file dialog).
MS.selfTest = function (extPath) {
    var results = [], before = {}, i, c = null, t1, t2, sh, so, pre, idx, tmp, tmp2, pass = 0, failN = 0,
        orig = MS.comp(), ext = String(extPath || "").replace(/\\+/g, "/");
    if (!app.project) { return MS.err("Open a project first"); }
    for (i = 1; i <= app.project.numItems; i++) { before[app.project.item(i).id] = true; }
    tmp = MS._tempDir() + "/motionsaas-selftest-" + new Date().getTime();
    new Folder(tmp).create();

    var select = function (layers) {
        var j;
        for (j = 1; j <= c.numLayers; j++) { c.layer(j).selected = false; }
        for (j = 0; j < layers.length; j++) { layers[j].selected = true; }
    };
    var check = function (name, fn) {
        var out;
        try { if (c) { c.openInViewer(); } out = String(fn()); }
        catch (e) { out = "ERR|" + (e.message || e) + (e.line ? " (line " + e.line + ")" : ""); }
        if (out.indexOf("OK|") === 0) { pass++; results.push("PASS  " + name + " — " + out.slice(3)); }
        else { failN++; results.push("FAIL  " + name + " — " + out.replace(/^ERR\|/, "")); }
    };

    try {
        c = app.project.items.addComp("MotionSaaS Self-Test", 1920, 1080, 1, 10, 30);
        c.openInViewer();
        t1 = MS.makeText(c, "Self test one", 100, "#FFFFFF"); t1.name = "Caption 1";
        t2 = MS.makeText(c, "Two", 80, "#FFFFFF"); t2.name = "Text Two";
        t2.transform.position.setValue([400, 300]);
        sh = MS.roundRect(c, "Box", 300, 200, 20, "#0A84FF", 100, 0);
        sh.transform.position.setValue([1500, 800]);
        so = c.layers.addSolid([0.2, 0.2, 0.2], "Test Solid", 600, 400, 1, 10);
        c.time = 1;
        if (!MS.comp() || MS.comp().name !== c.name) { throw new Error("couldn't make the test comp active — click the comp viewer and try again"); }

        check("Anchor", function () { select([t1]); return MS.anchor(0.5, 0.5); });
        check("Align to comp", function () { select([t1, sh]); return MS.align("left", false); });
        check("Align to selection", function () { select([t1, t2, sh]); return MS.align("vcenter", true); });
        check("Fit to comp", function () { select([so]); return MS.fit("fit"); });
        check("Smart spread", function () { select([t1, t2, sh]); return MS.spread(); });
        check("Ease keyframes", function () {
            var p = t2.transform.position;
            p.setValueAtTime(0, [400, 300]); p.setValueAtTime(1, [900, 300]);
            select([t2]); p.selected = true; p.setSelectedAtKey(1, true); p.setSelectedAtKey(2, true);
            return MS.ease(0.42, 0, 0.58, 1);
        });
        check("Read ease", function () { return MS.readEase(); });
        check("Bounce", function () { return MS.bounce(); });
        check("Fit keys", function () { t2.transform.position.selected = false; select([t2]); return MS.fitKeys(); });
        check("Create null", function () { select([sh]); return MS.create("null"); });
        check("Create adjustment", function () { select([sh]); return MS.create("adjustment"); });
        check("Create camera", function () { select([]); return MS.create("camera"); });
        check("Create solid", function () { select([]); return MS.create("solidBlack"); });
        check("Trim to below", function () { select([t1, t2]); return MS.trimTo("bottom"); });
        check("Label", function () { select([t1]); return MS.label(9); });
        check("Gradient", function () { select([sh]); return MS.gradient("#0A84FF", "#BF5AF2", false); });
        check("Grad lock", function () { select([sh]); return MS.gradLock(); });
        check("Grad unlock", function () { select([sh]); return MS.gradLock(); });
        check("Colour", function () { select([t1, sh, so]); return MS.color("#FF375F"); });
        check("FX optimizer off", function () { select([]); return MS.fxPercent(50); });
        check("FX optimizer on", function () { select([]); return MS.fxPercent(0); });
        check("Playhead jump", function () { return MS.playhead(5); });
        check("Layer offset", function () { select([t1, t2]); return MS.offset("forward", 1, 2); });
        check("Nudge", function () { select([sh]); return MS.nudge(10); });
        check("Counter", function () { select([t2]); return MS.counter({ mode: "counter", start: 0, end: 10200, dur: 2, mult: 1, dec: 1, "short": true, thousands: true }); });
        check("Timer", function () { select([t1]); return MS.counter({ mode: "timer", tStart: 60, speed: 1, mins: true, secs: true, countdown: true }); });
        check("Counter text layer", function () { return MS.makeCounterText(); });
        check("Subtitle boxes", function () { select([t1]); return MS.subtitleBoxes(); });
        check("Pair & stretch", function () { select([]); t1.selected = true; c.layer(t1.index + 1).selected = true; return MS.pairStretch(); });
        check("Select pair", function () { return MS.selectPair("top"); });
        check("Magic Reveal", function () {
            select([sh]);
            return MS.magicReveal({ color: "#F5C846", dir: "LR", frames: 20, glow: 85, blur: 90, feather: 100, rim: 6, blend: "add", easeOut: 12, easeIn: 90 });
        });
        check("Save effects (.msfx)", function () { select([sh]); return MS.saveFxSnapshot(tmp + "/test.msfx"); });
        check("Apply effects (.msfx)", function () { select([so]); return MS.applyFxPreset(tmp + "/test.msfx"); });
        check("Text preset (.ffx)", function () { select([t2]); return MS.applyPresetWithDuration(ext + "/TEXT PRESET/Typewriter Classic.ffx", 1, 0); });
        check("Text preview frames (maintainer tool)", function () {
            var r = MS.textPreviewFrames(ext + "/TEXT PRESET/Typewriter Classic.ffx", tmp + "/textprev", 4), info;
            if (r.indexOf("OK|") !== 0) { return r; }
            info = MS._parseJSON(r.slice(3));
            r = MS.textPreviewDone(info.comp);
            c.openInViewer();
            return r === "OK|1" ? MS.ok(info.frames + " frames, temporary comp removed") : MS.err("temporary comp not removed: " + r);
        });
        check("Import file", function () { select([]); return MS.importFile(ext + "/previews/Floating Rise.gif"); });
        check("Time tracking probe", function () { return MS.timerProbe(); });
        check("Counter again (same slider)", function () { select([t2]); return MS.counter({ mode: "counter", start: 5, end: 50, dur: 1, mult: 1 }); });
        check("Apply expression", function () {
            select([]); t1.transform.opacity.selected = true;
            var r = MS.applyExpression("value * 0.5;", false);
            t1.transform.opacity.selected = false;
            return r;
        });
        check("Carousel build", function () {
            select([sh, so]);
            return MS.carouselBuild(MS._json({ fields: [["style", "Style", "slider", 1], ["size", "Size", "slider", 300], ["p1", "Start", "point", [0, 0]], ["reveal", "Reveal", "slider", 100]],
                expr: { position: MS._CAR_MARK + "\nvar C = thisComp.layer({CTRL});\nvalue;" }, usePath: false, revealOn: true, revealDur: 1 }));
        });
        check("Carousel live edit", function () { return MS.carouselSet("MS Carousel 1", MS._json({ Size: 420 })); });
        check("Carousel release", function () { return MS.carouselRelease("MS Carousel 1"); });
        check("Palette link", function () { select([sh, so, t1]); return MS.paletteLink(MS._json({ name: "MotionSaaS Self-Test Palette", colors: ["#FF375F", "#30D158"] }), 2); });
        check("Palette update", function () { return MS.paletteSync(MS._json({ name: "MotionSaaS Self-Test Palette", colors: ["#FF375F", "#0A84FF"] })); });
        check("Palette list", function () { return MS.paletteProject(); });
        check("Palette colours used", function () { select([sh, so]); return MS.paletteUsed(); });
        check("Palette unlink", function () { select([sh, so, t1]); return MS.paletteUnlink(); });
        try { tmp2 = MS._palComp(false); if (tmp2 && MS._palLayer(tmp2, "MotionSaaS Self-Test Palette")) { MS._palLayer(tmp2, "MotionSaaS Self-Test Palette").remove(); } } catch (ePal) {}
        check("Asset thumbnail", function () { return MS.assetThumb(tmp + "/thumb.png"); });
        var animations = ["fadeUp", "pop", "blurIn", "slideIn", "typewriter", "cascade"];
        for (i = 0; i < animations.length; i++) {
            (function (a) { check("Animate " + a, function () { select([t2]); return MS.animate(a, 0.8, 0.1); }); })(animations[i]);
        }
        check("Mesh background", function () { select([]); return MS.mesh("#0A84FF", "#30D158", "#FF9F0A", "#FF375F", true); });
        check("Glass card", function () { select([]); return MS.glass(900, 520, 48, 60, 14); });
        check("Select by type", function () { return MS.selectByType("text", false); });
        check("Toggle shy", function () { select([so]); return MS.toggle("shy"); });
        check("Mockup browser (with layer)", function () { select([so]); return MS.mockup("browser", "dark"); });
        check("Mockup iPhone (placeholder)", function () { select([]); return MS.mockup("iphone", "dark"); });
        check("Mockup MacBook (light)", function () { select([]); return MS.mockup("macbook", "light"); });
        check("True duplicate", function () { return MS.trueDuplicate(); });
        check("Un-precompose", function () {
            idx = so.index;
            pre = c.layers.precompose([idx], "MotionSaaS Self-Test Pre", true);
            select([c.layer(idx)]);
            return MS.unprecompose();
        });
        var tpl = ["intro", "cta", "search", "carousel"];
        for (i = 0; i < tpl.length; i++) {
            (function (n) { check("Template " + n, function () { return MS.template(n, "#0A84FF,#30D158,#FF9F0A,#FF375F,#BF5AF2"); }); })(tpl[i]);
        }
        MS._selfTestOS(c, check, select, results);
        MS._selfTestStudio(c, check, select, results);
    } catch (eTop) {
        failN++;
        results.push("FAIL  setup — " + (eTop.message || eTop));
    }

    // Clean up: remove every project item created during the test (newest first), and temp files.
    for (i = app.project.numItems; i >= 1; i--) {
        try { if (!before[app.project.item(i).id]) { app.project.item(i).remove(); } } catch (eR) {}
    }
    try {
        var td = new Folder(tmp), files = td.exists ? td.getFiles() : [];
        for (i = 0; i < files.length; i++) { files[i].remove(); }
        if (td.exists) { td.remove(); }
    } catch (eF) {}
    try { if (orig) { orig.openInViewer(); } } catch (eO) {}

    return MS.ok("AE " + app.version + " — " + pass + " passed, " + failN + " failed\n" + results.join("\n"));
};

// Self-test part 2: the Studio engine (jsx/studio.jsx). One or more presets per category on fresh layers,
// then Remove. After each step every MotionSaaS expression in the comp is evaluated, and any expression
// error counts as a FAIL, because a broken expression is the most likely thing to slip through.
MS._selfTestStudio = function (c, check, select, results) {
    var i, box, keys, txt, cards = [], keyed;
    if (typeof MS.studio !== "function") {
        check("Studio engine", function () { return "ERR|jsx/studio.jsx did not load (is it next to host.jsx?)"; });
        return;
    }
    var exprErrors = function () {
        var errs = [], j, k, ps, l;
        for (j = 1; j <= c.numLayers; j++) {
            l = c.layer(j);
            ps = MS._exprProps(l, []);
            for (k = 0; k < ps.length; k++) {
                if (ps[k].expression.indexOf("// MotionSaaS ") !== 0) { continue; }
                try { ps[k].valueAtTime(c.time, false); } catch (eV) {}
                if (ps[k].expressionError || ps[k].expressionEnabled === false) { errs.push(l.name + " › " + ps[k].name + ": " + (ps[k].expressionError || "disabled")); }
            }
        }
        return errs;
    };
    var st = function (name, cmd, payload, layers, before) {
        check("Studio " + name, function () {
            if (layers) { select(layers); }
            if (before) { before(); }
            var r = MS._parseJSON(MS.studio(cmd, MS._json(payload || {}))), errs;
            if (!r || !r.ok) { return "ERR|" + ((r && r.errors && r.errors[0]) || "no answer"); }
            errs = exprErrors();
            if (errs.length) { return "ERR|expression error — " + errs[0]; }
            return "OK|" + (r.applied || 0) + " applied" + (r.warnings && r.warnings.length ? " (" + r.warnings[0] + ")" : "");
        });
    };
    var preset = function (id, params) { return { id: id, category: id.split(".")[0], params: params || {} }; };

    box = MS.roundRect(c, "Studio Box", 300, 200, 20, "#30D158", 100, 0);
    box.transform.position.setValue([600, 500]);
    keys = MS.roundRect(c, "Studio Keys", 200, 200, 30, "#FF9F0A", 100, 0);
    keys.transform.position.setValueAtTime(0, [300, 300]);
    keys.transform.position.setValueAtTime(1, [900, 300]);
    txt = MS.makeText(c, "Studio text", 90, "#FFFFFF");
    txt.name = "Studio Text";
    for (i = 0; i < 3; i++) { cards.push(MS.roundRect(c, "Studio Card " + (i + 1), 240, 160, 20, "#0A84FF", 100, 0)); }
    c.time = 1;

    st("context", "context", {}, [box]);
    st("poll", "poll", {}, [box]);
    keyed = function () { var p = keys.transform.position; p.selected = true; p.setSelectedAtKey(1, true); p.setSelectedAtKey(2, true); };
    st("easing", "apply", preset("easing.standard", { curve: [0.4, 0, 0.2, 1] }), [keys], keyed);
    st("ease copy", "ease-copy", {}, [keys], keyed);

    var exprs = ["wiggle", "hover", "breathe", "sine", "random", "flicker", "squash-stretch", "loop-wiggle"];
    for (i = 0; i < exprs.length; i++) { st("expression " + exprs[i], "apply", preset("expressions." + exprs[i], {}), [box]); }
    var keyedExprs = ["loop", "ping-pong", "loop-offset", "bounce-out", "impact-bounce", "anticipation", "stop-motion", "throw", "bounce"];
    for (i = 0; i < keyedExprs.length; i++) { st("expression " + keyedExprs[i], "apply", preset("expressions." + keyedExprs[i], { exprTarget: "position" }), [keys]); }
    st("remove expressions", "remove", preset("expressions.loop", {}), [keys]);

    st("shake punch", "apply", preset("shake.punch", {}), [box]);
    st("shake handheld", "apply", preset("shake.handheld", {}), [box]);
    st("remove shake", "remove", preset("shake.punch", {}), [box]);

    var trs = ["fade", "rise", "drop", "slide", "zoom", "iris", "split", "unfold", "glitch", "orbit"];
    for (i = 0; i < trs.length; i++) { st("transition " + trs[i], "apply", preset("transitions." + trs[i], { direction: "both", duration: 0.5 }), [cards[0]]); }
    check("Studio transition Remove takes keys back", function () {
        var card = cards[2], op = card.transform.opacity, was = op.value, before, after;   // untouched card
        select([card]);
        MS._parseJSON(MS.studio("apply", MS._json(preset("transitions.rise", { direction: "in" }))));
        before = op.numKeys;
        MS._parseJSON(MS.studio("remove", MS._json(preset("transitions.rise", {}))));
        after = op.numKeys;
        if (!(before > 0 && after === 0)) { return "ERR|opacity keys " + before + " → " + after + " (expected → 0)"; }
        return op.value === was ? "OK|opacity keys " + before + " → 0, value restored" : "ERR|opacity left at " + op.value + " (was " + was + ")";
    });

    var texts = ["rise", "typewriter", "wave", "scramble", "flip", "track-expand", "scale-pop", "stagger", "blur-reveal", "helix", "bounce"];
    for (i = 0; i < texts.length; i++) { st("text " + texts[i], "apply", preset("text." + texts[i], {}), [txt]); }
    st("text underline", "apply", preset("text.underline", {}), [txt]);
    st("text smart box", "apply", preset("text.smart-box", {}), [txt]);
    st("text highlight", "apply", preset("text.highlight", {}), [txt]);
    st("remove highlight", "remove", preset("text.highlight", {}), [txt]);
    st("copy setup", "copy-setup", {}, [txt]);
    st("remove all text", "remove-all-text", {}, [txt]);

    var styles = ["shadow", "glow", "display", "streaks", "hairline", "highlight", "chrome", "sweep", "liquid-color"];
    for (i = 0; i < styles.length; i++) { st("style " + styles[i], "apply", preset("styles." + styles[i], {}), [cards[1]]); }
    st("remove styles", "remove", preset("styles.glow", {}), [cards[1]]);

    st("glass frosted", "apply", preset("glass.frosted", {}), []);
    st("glass liquid", "apply", preset("glass.liquid", { refraction: 40 }), []);
    st("background nocturne", "apply", preset("backgrounds.nocturne", {}), []);
    check("Studio remove background", function () {
        var j, bg = null;
        for (j = 1; j <= c.numLayers; j++) { if (/^MS Background • /.test(c.layer(j).name)) { bg = c.layer(j); } }
        if (!bg) { return "ERR|no background layer was made"; }
        select([bg]);
        var r = MS._parseJSON(MS.studio("remove", MS._json(preset("backgrounds.nocturne", {}))));
        return r && r.ok && r.applied === 1 ? "OK|background layer removed" : "ERR|" + ((r && r.errors && r.errors[0]) || "not removed");
    });

    st("carousel ribbon", "apply", preset("carousel.ribbon", {}), cards);
    st("carousel ring (3D)", "apply", preset("carousel.ring", {}), cards);

    st("Alive", "alive-apply", { amount: 80, softness: 60, damping: 8 }, [keys]);
    st("Alive remove", "alive-remove", {}, [keys]);
    st("Layer FPS", "fps-apply", { fps: 12 }, [box]);
    st("Layer FPS reset", "fps-reset", {}, [box]);
    st("center anchor", "center-anchor", {}, [box]);
    st("diagnose", "diagnose", {}, [box]);
    st("fonts", "fonts", {}, null);
};

/* ------------------------------------- globals the panel calls directly */

function purgeCache() { return MS.purge(); }
function saveSelectedEffectsPreset(encodedPath) {
    var r = MS.saveFxSnapshot(decodeURI(encodedPath));
    return r.indexOf("OK|") === 0 ? "SUCCESS" : r.replace(/^ERR\|/, "");
}
function applyEffectPreset(path) { return MS.applyFxPreset(path); }

/* -------------------------------------------------------------- misc */

MS.ping = function () {
    return MS.ok("AE " + app.version + (typeof MS.studio === "function" ? "" : " (Studio engine not loaded)"));
};

/* ------------------------------------------------------------ studio engine */

// jsx/studio.jsx (the engine behind the Studio panel) sits next to this file.
// The panel also loads it by its full path (js/ms-core.js → loadStudio) and shows MS.studioError, because
// $.fileName isn't always this file's path when After Effects loads host.jsx at startup.
MS.studioError = "";
MS.loadStudio = function (path) {
    var f;
    try { f = path ? new File(path) : new File(new File($.fileName).parent.fsName + "/studio.jsx"); }
    catch (e) { MS.studioError = "can't locate studio.jsx (" + e.message + ")"; return false; }
    if (!f || !f.exists) { MS.studioError = "studio.jsx not found at " + (f ? f.fsName : "?"); return false; }
    try { $.evalFile(f); }
    catch (e2) { MS.studioError = "studio.jsx line " + e2.line + ": " + e2.message; return false; }
    if (typeof MS.studio !== "function") { MS.studioError = "studio.jsx loaded but MS.studio is missing"; return false; }
    MS.studioError = "";
    return true;
};
try { MS.loadStudio(); } catch (eStudio) { MS.studioError = String(eStudio.message || eStudio); }

// jsx/os.jsx: the OS Kit panel's engine (MS.os). Same loading rules as studio.jsx.
// Self-test lines for the OS Kit tools (jsx/os.jsx), on layers of their own in the self-test comp.
MS._selfTestOS = function (c, check, select, results) {
    if (typeof MS.os !== "function") { check("OS Kit engine", function () { return MS.err(MS.osError || "jsx/os.jsx didn't load"); }); return; }
    // The OS 2.0 tools (jsx/os2/kit.jsx), each on layers of its own. Tools whose rig is an AE 2024 project
    // (cursors, backgrounds) answer "needs a newer After Effects" on 2020-2023: that counts as the expected result.
    var mk = function (label) { var l = MS.makeText(c, label, 80, "#FFFFFF"); l.name = label; return label; };
    var L = function (n) { return c.layer(n); };
    var older = function (r) { return /newer After Effects|needs After Effects 20/i.test(r) ? MS.ok("needs a newer After Effects here (expected on " + app.version + ")") : r; };
    var t1 = mk("OS Type 1"), t2 = mk("OS Type 2"), t3 = mk("OS Type 3"), t4 = mk("OS Reveal"), t5 = mk("OS Explode"), t6 = mk("OS Count");
    var osn = MS.roundRect(c, "OS Box", 400, 240, 30, "#635BFF", 100, 0).name;
    var wipe = c.layers.addSolid([0.3, 0.3, 0.8], "OS Wipe", 400, 300, 1, c.duration).name;
    var car1 = c.layers.addSolid([0.8, 0.3, 0.3], "OS Card A", 200, 120, 1, c.duration).name;
    var car2 = c.layers.addSolid([0.3, 0.8, 0.3], "OS Card B", 200, 120, 1, c.duration).name;
    check("OS Coloured Typing", function () { select([L(t1)]); return older(MS.os("typing", MS._json({ variant: "coloured" }))); });
    check("OS Typewriter", function () { select([L(t2)]); return older(MS.os("typing", MS._json({ variant: "typewriter" }))); });
    check("OS Random Letters", function () { select([L(t3)]); return older(MS.os("typing", MS._json({ variant: "random" }))); });
    check("OS Text Reveal (words)", function () { select([L(t4)]); return older(MS.os("textReveal", MS._json({ by: "words" }))); });
    check("OS Explode words", function () { select([L(t5)]); return older(MS.os("explode", MS._json({ by: "words" }))); });
    check("OS Number Counter", function () { select([L(t6)]); return older(MS.os("counter", "{}")); });
    check("OS UI Stagger", function () { select([L(car1), L(car2)]); return older(MS.os("stagger", "{}")); });
    check("OS Bounce", function () {
        var p = L(osn).transform.rotation, r;
        p.setValueAtTime(0, 0); p.setValueAtTime(1, 90);
        select([L(osn)]); p.selected = true;
        r = MS.os("bounce", "{}");
        p.selected = false;
        return older(r);
    });
    check("OS Proximity Hover", function () { select([L(car1)]); return older(MS.os("proximity", "{}")); });
    check("OS Gradient Wipe", function () { select([L(osn)]); return older(MS.os("gradientWipe", "{}")); });
    check("OS Glitch Wipe", function () { select([L(wipe)]); return older(MS.os("glitchWipe", "{}")); });
    check("OS Carousel", function () { select([L(car1), L(car2)]); return older(MS.os("carousel", "{}")); });
    check("OS Cursor 1", function () { select([L(osn)]); return older(MS.os("cursor", MS._json({ variant: "1" }))); });
    check("OS Background (Gradient 1)", function () { select([]); return older(MS.os("background", MS._json({ name: "Gradient 1" }))); });
    check("OS Attach null", function () { select([L(car2)]); return older(MS.os("attach", MS._json({ kind: "null" }))); });
    check("OS SVG import", function () {
        var f = new File(Folder.temp.fsName + "/motionsaas-selftest.svg");
        f.encoding = "UTF-8"; f.open("w");
        f.write('<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><rect x="0" y="0" width="50" height="50" fill="#ff0000"/><path d="M0 100 L100 0" stroke="#0000ff" stroke-width="4" fill="none"/></svg>');
        f.close();
        select([]);
        var r = MS.os("svgImport", MS._json({ svg: f.fsName, gradients: "" }));
        try { f.remove(); } catch (eR) {}
        return r;
    });
    var B = function () { return c.layer(osn); };
    check("OS depth source", function () {
        select([B()]);
        var r = MS.os("depthSource", "{}");
        return /^ERR\|Select a photo or video/.test(r) ? MS.ok("asks for a photo or video layer") : MS.err("unexpected: " + r);
    });
    check("OS probe", function () { select([B()]); return MS.os("osProbe", "{}"); });
    check("OS Glass", function () { select([B()]); return older(MS.os("glass", "{}")); });   // last: renames the box "… glass base"
};

MS.osError = "";
MS.loadOS = function (path) {
    var f;
    try { f = path ? new File(path) : new File(new File($.fileName).parent.fsName + "/os.jsx"); }
    catch (e) { MS.osError = "can't locate os.jsx (" + e.message + ")"; return false; }
    if (!f || !f.exists) { MS.osError = "os.jsx not found at " + (f ? f.fsName : "?"); return false; }
    try { $.evalFile(f); }
    catch (e2) { MS.osError = "os.jsx line " + e2.line + ": " + e2.message; return false; }
    if (typeof MS.os !== "function") { MS.osError = "os.jsx loaded but MS.os is missing"; return false; }
    MS.osError = "";
    return true;
};
try { MS.loadOS(); } catch (eOS) { MS.osError = String(eOS.message || eOS); }
