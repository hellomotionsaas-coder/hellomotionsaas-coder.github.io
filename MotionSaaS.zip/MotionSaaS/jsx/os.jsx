/*
 * MotionSaaS — OS Kit (the "OS Kit" tool panel, js/ms-os.js). ExtendScript ES3.
 *
 * Every tool here is the MotionSaaS OS 2.0 extension's own: its code (jsx/os2/kit.jsx, jsx/os2/svg.jsx,
 * generated from OS 2.0 with only the plumbing changed) and its presets / rigs (extension/os2/). This file
 * only routes the panel's calls to them and turns their messages into "OK|…" / "ERR|…".
 *
 * Entry: MS.os(cmd, payloadJSON).
 *   Text ........ typing (coloured | random | typewriter), textReveal (chars | words), explode (letters | words | lines)
 *   Animate ..... stagger, bounce
 *   Transitions . glitchWipe, gradientWipe, depthSource + depthImport (Depth Reveal 1-3; the depth map is made by
 *                 the panel's engine, js/ms-depth.js), depthRig (from a depth map you already have)
 *   Interaction . cursor (1 | 2 | 3), proximity
 *   Elements .... counter, carousel, glass
 *   Backgrounds . background (the 8 OS 2.0 gradients)
 *   Rigging ..... attach (null | solid | adjustment)
 *   SVG ......... svgImport (OS 2.0's SVG → shape layers engine, gradient presets made by the panel)
 *   osProbe ..... what is selected (read only)
 *
 * Versions: OS 2.0's presets were saved by After Effects 2024. On 2022-2023 its own version patch lowers the
 * preset stamp so they load; the cursor rigs and backgrounds are .aep projects that need 2024+. Older hosts get
 * OS 2.0's clear message instead of a half-applied effect.
 * Locked layers in the selection are left out (and said so) before a tool runs.
 */
// Attach to the one global MS (see the note at the top of studio.jsx).
var MS = (typeof $ !== "undefined" && $.global) ? ($.global.MS = $.global.MS || {}) : (MS || {});

MS.O = {};
// extension/ (this file is extension/jsx/os.jsx) → OS 2.0's assets in extension/os2/
MS.O.extDir = String((typeof $ !== "undefined" && $.fileName) || "").replace(/\\/g, "/").replace(/\/jsx\/[^\/]*$/, "");
MS.OS2_DIR = MS.O.extDir + "/os2";

// Load OS 2.0's tools (kit.jsx) and SVG engine (svg.jsx) from jsx/os2/. Called once by MS.os.
MS.O.loadKit = function () {
    var names = ["recipe.jsx", "kit.jsx", "svg.jsx"], i, f;
    if (MS.R && MS.R.applyPreset && MS.OS2 && MS.OS2SVG) { return ""; }
    for (i = 0; i < names.length; i++) {
        f = new File(MS.O.extDir + "/jsx/os2/" + names[i]);
        if (!f.exists) { return "os2/" + names[i] + " not found — reinstall MotionSaaS"; }
        try { $.evalFile(f); } catch (e) { return "os2/" + names[i] + " line " + e.line + ": " + e.message; }
    }
    return MS.OS2 && MS.OS2SVG ? "" : "the OS Kit tools didn't load";
};

MS.os = function (cmd, payloadJSON) {
    var fn = MS.O.cmd[String(cmd)], o = {}, why;
    if (!fn) { return MS.err("Unknown OS Kit tool: " + cmd); }
    try { if (payloadJSON) { o = MS._parseJSON(String(payloadJSON)) || {}; } } catch (e) { return MS.err("Bad request (" + e.message + ")"); }
    why = MS.O.loadKit();
    if (why) { return MS.err(why); }
    try { return fn(o); } catch (e2) { return MS.err((e2.message || String(e2)) + (e2.line ? " (line " + e2.line + ")" : "")); }
};
MS.O.cmd = {};

/* ------------------------------------------------------------------ helpers */

MS.O.sel = function (c) { return MS._editable(MS.selectedLayers(c)); };
MS.O.deselect = function (c) { var i; for (i = 1; i <= c.numLayers; i++) { c.layer(i).selected = false; } };

// Run one of OS 2.0's tools. They open their own undo group and talk through alert(), which kit.jsx collects:
// any message means the tool stopped (OS 2.0 only alerts on problems). Locked layers are deselected first.
// OS 2.0 refuses AE 2020-2021 for every tool; the ones that are pure script (no preset, no project file) work
// there too, so they run with that floor lifted.
MS.O.SCRIPT_ONLY = { caCharacters: 1, caWords: 1, explodeLetters: 1, explodeWords: 1, explodeLines: 1, addBounce: 1,
    gradientWipe: 1, proximityHover: 1, carousel: 1, createBound: 1 };
MS.O.run = function (label, fnName, args) {
    var c = MS.comp(), locked = 0, i, s, msgs, note;
    if (c) {
        s = MS.selectedLayers(c);
        for (i = 0; i < s.length; i++) { if (s[i].locked) { s[i].selected = false; locked++; } }
    }
    note = locked ? " (" + MS._plural(locked, "locked layer") + " left out)" : "";
    MS.OS2.messages();
    MS.OS2.allowOld(!!MS.O.SCRIPT_ONLY[fnName] || MS.O.recipesComplete());
    try { MS.OS2[fnName].apply(null, args || []); }
    finally { MS.OS2.allowOld(false); }
    msgs = MS.OS2.messages();
    if (msgs.length) { return MS.err(msgs[0].replace(/\s+$/, "") + note); }
    return MS.ok(label + note);
};
// Every OS 2.0 preset and rig has its recipe (extension/os2/recipes/): then the preset tools run on AE 2020-2021 too.
MS.O.recipesComplete = function () {
    var a = MS.OS2.assets, i;
    if (MS.O._complete !== undefined) { return MS.O._complete; }
    MS.O._complete = true;
    for (i = 0; i < a.ffx.length; i++) { if (!MS.R.has(a.ffx[i])) { MS.O._complete = false; } }
    for (i = 0; i < a.aep.length; i++) { if (!MS.R.has(a.aep[i])) { MS.O._complete = false; } }
    return MS.O._complete;
};
MS.O.pick = function (v, allowed, def) { var i; for (i = 0; i < allowed.length; i++) { if (v === allowed[i]) { return v; } } return def; };

/* --------------------------------------------------------------------- tools */

MS.O.cmd.typing = function (o) {
    var v = MS.O.pick(o.variant, ["coloured", "random", "typewriter"], "coloured");
    return MS.O.run({ coloured: "Coloured Typing", random: "Random Letters", typewriter: "Typewriter" }[v],
        { coloured: "typewriter1", random: "typewriter2", typewriter: "typewriter5" }[v]);
};
MS.O.cmd.textReveal = function (o) {
    return o.by === "words" ? MS.O.run("Text Reveal · words", "caWords") : MS.O.run("Text Reveal · characters", "caCharacters");
};
MS.O.cmd.explode = function (o) {
    var by = MS.O.pick(o.by, ["letters", "words", "lines"], "letters");
    return MS.O.run("Explode " + by, { letters: "explodeLetters", words: "explodeWords", lines: "explodeLines" }[by]);
};
MS.O.cmd.stagger = function () { return MS.O.run("UI Stagger", "uiStagger"); };
MS.O.cmd.bounce = function () { return MS.O.run("Bounce", "addBounce"); };
MS.O.cmd.glitchWipe = function () { return MS.O.run("Glitch Wipe", "wipeReveal1"); };
MS.O.cmd.gradientWipe = function () { return MS.O.run("Gradient Wipe", "gradientWipe"); };
MS.O.cmd.cursor = function (o) {
    var k = MS.O.pick(String(o.variant), ["1", "2", "3"], "1");
    return MS.O.run("Cursor " + k, "insertCursor", ["c" + k]);
};
MS.O.cmd.proximity = function () { return MS.O.run("Proximity Hover", "proximityHover"); };
MS.O.cmd.counter = function () { return MS.O.run("Number Counter", "numberCounter"); };
MS.O.cmd.carousel = function () { return MS.O.run("Carousel", "carousel"); };
MS.O.cmd.glass = function () { return MS.O.run("Glass", "glass"); };
MS.O.cmd.background = function (o) {
    var name = String(o.name || "");
    if (!MS.OS2.gradients[name]) { return MS.err("Unknown background: " + name); }
    return MS.O.run(name, "insertGradient", [name]);
};
MS.O.cmd.attach = function (o) {
    var kind = MS.O.pick(o.kind, ["null", "solid", "adjustment"], "null");
    return MS.O.run("Attached " + kind, "createBound", [kind]);
};

/* --------------------------------------------------------------- depth reveal */
// The depth map is made by the panel (js/ms-depth.js, in the background); After Effects is only asked which
// file to process and, when the map is ready, to import it and build OS 2.0's Depth Reveal rig on the layer.
MS.O.footageOf = function (l) {
    try { if (l.source && l.source.mainSource && l.source.mainSource.file) { return l.source.mainSource.file; } } catch (e) {}
    return null;
};
// The first selected photo / video layer: { file, video, comp, index, name }. Read only.
MS.O.cmd.depthSource = function () {
    var c = MS.needComp(), s = MS.O.sel(c), k, f;
    for (k = 0; k < s.length; k++) {
        f = MS.O.footageOf(s[k]);
        if (f) {
            return MS.ok(MS._json({ file: f.fsName, video: /\.(mp4|mov|avi|mkv|m4v|webm)$/i.test(f.name), comp: c.id, index: s[k].index, name: s[k].name }));
        }
    }
    return MS.err("Select a photo or video layer (footage from a file)");
};
MS.O.depthVariant = function (v) { return MS.O.pick(String(v), ["1", "2", "3"], "1"); };
// Import a finished depth map and build Depth Reveal 1 / 2 / 3. o: { map, sequence, comp, index, name, variant }
MS.O.cmd.depthImport = function (o) {
    var c = null, i, it, l = null, f, io, item, msgs;
    for (i = 1; i <= app.project.numItems; i++) { it = app.project.item(i); if (it && it.id === o.comp && it instanceof CompItem) { c = it; break; } }
    if (!c) { return MS.err("The composition with the picture was closed or deleted"); }
    try { if (o.index >= 1 && o.index <= c.numLayers && c.layer(o.index).name === o.name) { l = c.layer(o.index); } } catch (e0) {}
    if (!l) { try { l = c.layer(String(o.name)); } catch (e1) {} }
    if (!l) { return MS.err("The picture layer “" + o.name + "” isn't in " + c.name + " any more"); }
    if (l.locked) { return MS.err(l.name + " is locked — unlock it and try again"); }
    f = new File(String(o.map || ""));
    if (!f.exists) { return MS.err("The depth map wasn't written (" + f.fsName + ")"); }
    io = new ImportOptions(f);
    if (o.sequence) { io.sequence = true; }
    item = app.project.importFile(io);
    MS.OS2.messages();
    MS.OS2.buildDepthRig(c, l, item, MS.OS2.depthAsset[MS.O.depthVariant(o.variant)]);
    msgs = MS.OS2.messages();
    return msgs.length ? MS.err(msgs[0]) : MS.ok("Depth Reveal " + MS.O.depthVariant(o.variant) + " on " + l.name);
};
// From a depth map you already have: select the picture and its map layer (the map's name contains "depth").
MS.O.cmd.depthRig = function (o) {
    var c = MS.needComp(), s = MS.O.sel(c), main = null, map = null, k, msgs;
    for (k = 0; k < s.length; k++) {
        if (!s[k].source) { continue; }
        if (/depth/i.test(s[k].name) || /depth/i.test(String(s[k].source.name))) { map = s[k]; } else if (!main) { main = s[k]; }
    }
    if (!main || !map) { return MS.err("Select the picture and its depth map layer (its name contains “depth”)"); }
    MS.OS2.messages();
    MS.OS2.buildDepthRig(c, main, map.source, MS.OS2.depthAsset[MS.O.depthVariant(o.variant)]);
    msgs = MS.OS2.messages();
    return msgs.length ? MS.err(msgs[0]) : MS.ok("Depth Reveal " + MS.O.depthVariant(o.variant) + " on " + main.name);
};

/* ------------------------------------------------------------------------ svg */
// OS 2.0's SVG import. o: { svg: path of the .svg (the panel writes pasted code to a temp file),
// gradients: path of the panel's gradient-preset map (.json, may be "") }
MS.O.cmd.svgImport = function (o) {
    var r;
    if (!MS.comp()) { return MS.err("Open a composition first"); }
    app.beginUndoGroup("SVG import");
    try { r = String(MS.OS2SVG.runImport(String(o.svg || ""), "", String(o.gradients || ""), "", 0, 0, "", "")); }
    finally { app.endUndoGroup(); }
    return /^(OK|NODE)/.test(r) ? MS.ok(r.replace(/^OK:\s*/, "")) : MS.err(r.replace(/^ERROR:\s*/, ""));
};

/* ------------------------------------------------------------------- probe */
// What the panel shows next to the tools: selection counts, and the AE version (for the version notes). Read only.
MS.O.cmd.osProbe = function () {
    var c = MS.comp(), s, i, out = { comp: !!c, sel: 0, text: 0, shape: 0, footage: 0, props: 0, ae: String(app.version) };
    if (!c) { return MS.ok(MS._json(out)); }
    s = MS.selectedLayers(c);
    out.sel = s.length;
    for (i = 0; i < s.length; i++) {
        if (s[i] instanceof TextLayer) { out.text++; }
        else if (s[i] instanceof ShapeLayer) { out.shape++; }
        else { try { if (s[i].source && s[i].source.mainSource && s[i].source.mainSource.file) { out.footage++; } } catch (e) {} }
    }
    try { out.props = c.selectedProperties.length; } catch (e2) {}
    return MS.ok(MS._json(out));
};
