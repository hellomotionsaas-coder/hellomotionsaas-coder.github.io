/*
 * MotionSaaS — OS Kit recipes. OS 2.0's presets (.ffx) and project rigs (.aep) were saved by After Effects
 * 2024: AE 2020-2021 can't read the presets, AE 2020-2023 can't open the projects. So what each one builds is
 * recorded once in a modern After Effects (scripts/os2-port/record.jsx → extension/os2/recipes/<asset>.json)
 * and, on those older versions, rebuilt here step by step: the same effects with the same values, keyframes
 * with their eases, expressions, text animators, masks, layer styles, shape contents, comps and layers.
 * ExtendScript ES3. Published as MS.R; jsx/os2/kit.jsx calls it instead of applyPreset / importFile when needed.
 *
 * Recipe JSON
 *   preset : { kind:"ffx", asset, attrs:{…changed layer switches}, tree: node }   (what applying it changed)
 *   project: { kind:"aep", asset, items:[ comp | footage ] }                      (comps in creation order)
 *   node   : group { mn, i, n, en, ix, add, mask:{mode,inv,rb}, c:[node…] } | property { mn, i, v, k:[key…], x, xe, ds }
 *   key    : { t, v, ii, oi, ie:[[speed,influence]…], oe, tc, ta, it, ot, sc, sa, rv }
 */
var MS = (typeof $ !== "undefined" && $.global) ? ($.global.MS = $.global.MS || {}) : (MS || {});
MS.R = MS.R || {};
MS.R.force = false;   // tests: use recipes even where the original file would load (proves the replay)

/* ---------------------------------------------------------------- which way */

MS.R.hostMajor = function () { var v = NaN; try { v = parseInt(app.version, 10); } catch (e) {} return isNaN(v) || v <= 0 ? 99 : v; };
MS.R.file = function (asset) { return new File(MS.OS2_DIR + "/recipes/" + asset + ".json"); };
MS.R.has = function (asset) { try { return !!asset && MS.R.file(asset).exists; } catch (e) { return false; } };
// Presets load natively from AE 2022 (OS 2.0's version patch), projects from AE 2024.
MS.R.wants = function (kind, asset) {
    var v = MS.R.hostMajor();
    return MS.R.has(asset) && (MS.R.force || (kind === "aep" ? v < 24 : v < 22));
};
MS.R.ref = function (asset) { return { recipe: asset, fsName: asset, name: asset, exists: true }; };
MS.R.cache = {};
MS.R.load = function (asset) {
    var f, s;
    if (MS.R.cache[asset]) { return MS.R.cache[asset]; }
    f = MS.R.file(asset);
    if (!f.exists) { throw new Error("OS Kit recipe missing: " + asset + " — reinstall MotionSaaS"); }
    f.encoding = "UTF-8"; f.open("r"); s = f.read(); f.close();
    return (MS.R.cache[asset] = MS._parseJSON(s));
};

/* ----------------------------------------------------------------- values */

MS.R.TD = ["font", "fontSize", "applyFill", "fillColor", "applyStroke", "strokeColor", "strokeWidth", "strokeOverFill", "justification",
    "tracking", "autoLeading", "leading", "fauxBold", "fauxItalic", "allCaps", "smallCaps", "baselineShift", "horizontalScale", "verticalScale", "text"];
MS.R.tdOut = function (d) {
    var o = {}, i, k;
    for (i = 0; i < MS.R.TD.length; i++) { k = MS.R.TD[i]; try { if (d[k] !== undefined) { o[k] = d[k]; } } catch (e) {} }
    return o;
};
MS.R.tdIn = function (d, o) {
    var i, k;
    for (i = 0; i < MS.R.TD.length; i++) { k = MS.R.TD[i]; if (o.hasOwnProperty(k)) { try { d[k] = o[k]; } catch (e) {} } }
    return d;
};
// A property's value → JSON (undefined: not scriptable, e.g. gradient colours / curves)
MS.R.val = function (p, v) {
    var t = p.propertyValueType;
    if (t === PropertyValueType.NO_VALUE || t === PropertyValueType.CUSTOM_VALUE) { return undefined; }
    if (t === PropertyValueType.SHAPE) { return { shape: { v: v.vertices, i: v.inTangents, o: v.outTangents, c: v.closed } }; }
    if (t === PropertyValueType.TEXT_DOCUMENT) { return { td: MS.R.tdOut(v) }; }
    if (t === PropertyValueType.MARKER) { return { mk: { c: v.comment, d: v.duration } }; }
    return v;
};
// JSON → a value After Effects takes (for property p)
MS.R.mk = function (p, v) {
    var s, m;
    if (v && v.shape) { s = new Shape(); s.vertices = v.shape.v; s.inTangents = v.shape.i; s.outTangents = v.shape.o; s.closed = v.shape.c; return s; }
    if (v && v.td) { return MS.R.tdIn(p.value, v.td); }
    if (v && v.mk) { m = new MarkerValue(String(v.mk.c || "")); try { m.duration = v.mk.d || 0; } catch (e) {} return m; }
    return v;
};

/* ----------------------------------------------------------------- record */

MS.R.keys = function (p, t0) {
    var out = [], k, o, j, e;
    for (k = 1; k <= p.numKeys; k++) {
        o = { t: p.keyTime(k) - t0, v: MS.R.val(p, p.keyValue(k)) };
        try { o.ii = p.keyInInterpolationType(k); o.oi = p.keyOutInterpolationType(k); } catch (e1) {}
        try {
            e = p.keyInTemporalEase(k); o.ie = [];
            for (j = 0; j < e.length; j++) { o.ie.push([e[j].speed, e[j].influence]); }
            e = p.keyOutTemporalEase(k); o.oe = [];
            for (j = 0; j < e.length; j++) { o.oe.push([e[j].speed, e[j].influence]); }
        } catch (e2) {}
        try { o.tc = p.keyTemporalContinuous(k); o.ta = p.keyTemporalAutoBezier(k); } catch (e3) {}
        try { if (p.isSpatial) { o.it = p.keyInSpatialTangent(k); o.ot = p.keyOutSpatialTangent(k); o.sc = p.keySpatialContinuous(k); o.sa = p.keySpatialAutoBezier(k); o.rv = p.keyRoving(k); } } catch (e4) {}
        out.push(o);
    }
    return out;
};
// The whole property tree under p (groups always; properties when keyed, expressed or changed from default)
MS.R.node = function (p, t0) {
    var r = { mn: p.matchName, i: p.propertyIndex }, k, ch, rec, mod;
    if (p.propertyType === PropertyType.PROPERTY) {
        var has = false;
        try { if (p.numKeys > 0) { r.k = MS.R.keys(p, t0); has = true; } } catch (e1) {}
        try { if (p.expression) { r.x = p.expression; r.xe = p.expressionEnabled; has = true; } } catch (e2) {}
        try { if (p.dimensionsSeparated) { r.ds = 1; has = true; } } catch (e3) {}
        if (!r.k && p.matchName !== "ADBE Text Document") {
            mod = true;
            try { mod = p.isModified; } catch (e4) {}
            if (mod) { try { var vv = MS.R.val(p, p.value); if (vv !== undefined) { r.v = vv; has = true; } } catch (e5) {} }
        }
        return has ? r : null;
    }
    r.n = p.name;
    try { r.en = p.enabled; } catch (e6) {}
    r.ix = p.propertyType === PropertyType.INDEXED_GROUP ? 1 : 0;
    if (p.matchName === "ADBE Mask Atom") { try { r.mask = { mode: p.maskMode, inv: p.inverted, rb: p.rotoBezier }; } catch (e7) {} }
    r.c = [];
    for (k = 1; k <= p.numProperties; k++) {
        ch = null;
        try { ch = p.property(k); } catch (e8) {}
        if (!ch) { continue; }
        rec = null;
        try { rec = MS.R.node(ch, t0); } catch (e9) {}
        if (rec) { r.c.push(rec); }
    }
    return r;
};
MS.R.layerTree = function (l, t0) {
    var r = { mn: "layer", c: [], ix: 0 }, k, ch, rec;
    for (k = 1; k <= l.numProperties; k++) {
        ch = null;
        try { ch = l.property(k); } catch (e) {}
        if (!ch) { continue; }
        rec = null;
        try { rec = MS.R.node(ch, t0); } catch (e2) {}
        if (rec) { r.c.push(rec); }
    }
    return r;
};
MS.R.ATTRS = ["blendingMode", "adjustmentLayer", "motionBlur", "threeDLayer", "quality", "shy", "enabled", "guideLayer", "collapseTransformation",
    "preserveTransparency", "autoOrient", "label", "trackMatteType", "frameBlendingType", "samplingQuality", "effectsActive", "timeRemapEnabled"];
MS.R.attrs = function (l) {
    var o = {}, i, k;
    for (i = 0; i < MS.R.ATTRS.length; i++) { k = MS.R.ATTRS[i]; try { if (l[k] !== undefined) { o[k] = l[k]; } } catch (e) {} }
    return o;
};
// what changed between two trees: changed properties, new children of indexed groups (whole), enabled flips
MS.R.same = function (a, b) { return MS._json(a) === MS._json(b); };
MS.R.diff = function (after, before) {
    var out, i, j, a, b, d, n0;
    if (!before) { return after; }
    if (!after.c) { return MS.R.same(after, before) ? null : after; }
    out = { mn: after.mn, i: after.i, n: after.n, ix: after.ix, c: [] };
    if (after.mask) { out.mask = after.mask; }
    if (after.en !== before.en) { out.en = after.en; }
    n0 = 0;
    for (j = 0; j < before.c.length; j++) { if (before.c[j].i > n0) { n0 = before.c[j].i; } }
    for (i = 0; i < after.c.length; i++) {
        a = after.c[i];
        if (after.ix && a.i > n0) { a.add = 1; MS.R.markAdds(a); out.c.push(a); continue; }
        b = null;
        for (j = 0; j < before.c.length; j++) { if (before.c[j].i === a.i && before.c[j].mn === a.mn) { b = before.c[j]; break; } }
        d = MS.R.diff(a, b);
        if (d) { out.c.push(d); }
    }
    return out.c.length || out.en !== undefined ? out : null;
};
// inside a newly added group, every child of an indexed group (selectors, shape items, …) is added too, in order
MS.R.markAdds = function (n) {
    var i;
    if (!n.c) { return; }
    for (i = 0; i < n.c.length; i++) { if (n.ix) { n.c[i].add = 1; } MS.R.markAdds(n.c[i]); }
};
// for whole layers (projects): drop named groups that hold nothing
MS.R.prune = function (n, keep) {
    var i, c = [], r;
    if (!n.c) { return n; }
    for (i = 0; i < n.c.length; i++) { r = MS.R.prune(n.c[i], !!n.ix); if (r) { c.push(r); } }
    n.c = c;
    if (!c.length && !keep && !n.ix && !n.mask && n.en !== false) { return null; }
    if (n.ix && n.mn !== "layer") { for (i = 0; i < c.length; i++) { c[i].add = 1; } }
    return n;
};
// Apply `presetFile` to layer `l` (at time 0) and record what it changed.
MS.R.recordPreset = function (comp, l, presetFile, asset) {
    var before, after, ab, aa, k, attrs = {}, i;
    comp.time = 0;
    for (i = 1; i <= comp.numLayers; i++) { comp.layer(i).selected = false; }
    l.selected = true;
    before = MS.R.layerTree(l, 0); ab = MS.R.attrs(l);
    l.applyPreset(presetFile);
    after = MS.R.layerTree(l, 0); aa = MS.R.attrs(l);
    for (k in aa) { if (aa.hasOwnProperty(k) && aa[k] !== ab[k]) { attrs[k] = aa[k]; } }
    return { kind: "ffx", asset: asset, attrs: attrs, tree: MS.R.diff(after, before) || { mn: "layer", c: [] } };
};
// Record every comp and footage item in `items` (an imported .aep's), in an order they can be rebuilt in.
MS.R.recordProject = function (items, asset) {
    var out = [], ids = {}, i, it, done = {}, guard = 0, progressed;
    for (i = 0; i < items.length; i++) { ids[items[i].id] = items[i]; }
    function srcOf(l) { try { return l.source; } catch (e) { return null; } }
    function ready(c) {
        var k, s;
        for (k = 1; k <= c.numLayers; k++) { s = srcOf(c.layer(k)); if (s && s instanceof CompItem && ids[s.id] && !done[s.id]) { return false; } }
        return true;
    }
    for (i = 0; i < items.length; i++) {
        it = items[i];
        if (it instanceof FootageItem && !MS.R.isSolid(it)) { out.push(MS.R.footageRec(it)); done[it.id] = 1; }
    }
    do {
        progressed = false;
        for (i = 0; i < items.length; i++) {
            it = items[i];
            if (it instanceof CompItem && !done[it.id] && ready(it)) { out.push(MS.R.compRec(it)); done[it.id] = 1; progressed = true; }
        }
    } while (progressed && guard++ < 50);
    return { kind: "aep", asset: asset, items: out };
};
MS.R.isSolid = function (it) { try { return it.mainSource instanceof SolidSource; } catch (e) { return false; } };
MS.R.footageRec = function (it) {
    var r = { type: "footage", id: it.id, name: it.name, w: it.width, h: it.height };
    try { r.file = it.mainSource.file ? it.mainSource.file.name : ""; } catch (e) {}
    try { r.seq = !it.mainSource.isStill && it.duration > 0; r.dur = it.duration; r.fps = it.frameRate; } catch (e2) {}
    return r;
};
MS.R.compRec = function (c) {
    var r = { type: "comp", id: c.id, name: c.name, w: c.width, h: c.height, pa: c.pixelAspect, dur: c.duration, fps: c.frameRate, layers: [] }, k, l, L, s;
    try { r.bg = c.bgColor; r.mb = c.motionBlur; r.hs = c.hideShyLayers; r.was = c.workAreaStart; r.wad = c.workAreaDuration; r.ren = c.renderer; r.sa = c.shutterAngle; } catch (e) {}
    try { r.mk = MS.R.node(c.markerProperty, 0); } catch (e2) {}
    for (k = 1; k <= c.numLayers; k++) {
        l = c.layer(k);
        L = { nm: l.name, attrs: MS.R.attrs(l), st: l.startTime, ip: l.inPoint, op: l.outPoint, sr: l.stretch, par: 0 };
        try { if (l.parent) { L.par = l.parent.index; } } catch (e3) {}
        try { if (l.hasTrackMatte && l.trackMatteLayer) { L.tml = l.trackMatteLayer.index; } } catch (e4) {}
        s = null;
        try { s = l.source; } catch (e5) {}
        if (l instanceof TextLayer) { L.type = "text"; try { L.td = MS.R.tdOut(l.property("ADBE Text Properties").property("ADBE Text Document").value); } catch (e6) {} }
        else if (l instanceof ShapeLayer) { L.type = "shape"; }
        else if (l instanceof CameraLayer) { L.type = "camera"; }
        else if (l instanceof LightLayer) { L.type = "light"; try { L.lt = l.lightType; } catch (e7) {} }
        else if (l.nullLayer) { L.type = "null"; }
        else if (s && s instanceof CompItem) { L.type = "comp"; L.src = s.id; }
        else if (s && MS.R.isSolid(s)) { L.type = "solid"; L.color = s.mainSource.color; L.sw = s.width; L.sh = s.height; L.sname = s.name; }
        else if (s && s instanceof FootageItem) { L.type = "footage"; L.src = s.id; }
        else { L.type = "null"; }
        L.tree = MS.R.prune(MS.R.layerTree(l, 0), true) || { mn: "layer", c: [] };
        r.layers.push(L);
    }
    return r;
};

/* ----------------------------------------------------------------- replay */

MS.R.STYLE_MENU = { dropShadow: "Drop Shadow", innerShadow: "Inner Shadow", outerGlow: "Outer Glow", innerGlow: "Inner Glow",
    bevelEmboss: "Bevel and Emboss", chromeFX: "Satin", solidFill: "Color Overlay", gradientFill: "Gradient Overlay", frameFX: "Stroke" };
MS.R.ease = function (arr) {
    var out = [], i;
    for (i = 0; i < arr.length; i++) { out.push(new KeyframeEase(arr[i][0], Math.max(0.1, Math.min(100, arr[i][1])))); }
    return out;
};
MS.R.setProp = function (p, rec, t0, ctx) {
    var i, k, idx, key;
    if (rec.ds) { try { p.dimensionsSeparated = true; } catch (e0) {} }
    if (rec.k && rec.k.length) {
        try { while (p.numKeys > 0) { p.removeKey(1); } } catch (e1) {}
        for (i = 0; i < rec.k.length; i++) {
            key = rec.k[i];
            try { p.setValueAtTime(t0 + key.t, MS.R.mk(p, key.v)); } catch (e2) { ctx.miss.push(p.matchName + " key"); }
        }
        for (i = 0; i < rec.k.length; i++) {
            key = rec.k[i];
            try { idx = p.nearestKeyIndex(t0 + key.t); } catch (e3) { continue; }
            try { if (key.it && key.ot) { p.setSpatialTangentsAtKey(idx, key.it, key.ot); } } catch (e4) {}
            try { if (key.sc !== undefined) { p.setSpatialContinuousAtKey(idx, key.sc); p.setSpatialAutoBezierAtKey(idx, key.sa); } } catch (e5) {}
            try { if (key.ii) { p.setInterpolationTypeAtKey(idx, key.ii, key.oi); } } catch (e6) {}
            try { if (key.ie && key.oe) { p.setTemporalEaseAtKey(idx, MS.R.ease(key.ie), MS.R.ease(key.oe)); } } catch (e7) {}
            try { if (key.tc !== undefined) { p.setTemporalContinuousAtKey(idx, key.tc); p.setTemporalAutoBezierAtKey(idx, key.ta); } } catch (e8) {}
            try { if (key.rv) { p.setRovingAtKey(idx, true); } } catch (e9) {}
        }
    } else if (rec.v !== undefined) {
        try { p.setValue(MS.R.mk(p, rec.v)); } catch (e10) { ctx.miss.push(p.matchName); }
    }
    if (rec.x !== undefined) {
        try { p.expression = rec.x; if (rec.xe === false) { p.expressionEnabled = false; } } catch (e11) { ctx.miss.push(p.matchName + " expression"); }
    }
};
// Apply the children of `rec` into the group returned by getG() (a function: references go stale after
// addProperty, so every step looks the group up again from the layer).
MS.R.applyGroup = function (getG, rec, t0, ctx) {
    var i;
    for (i = 0; i < rec.c.length; i++) { MS.R.applyChild(getG, rec.c[i], t0, ctx); }
};
MS.R.applyChild = function (getG, ch, t0, ctx) {
    var g = getG(), target = null, idx, getC;
    if (!g) { return; }
    if (ch.add) {
        try { target = g.addProperty(ch.mn); } catch (e1) { ctx.miss.push(ch.mn + (ch.n ? " (" + ch.n + ")" : "")); return; }
        try { if (ch.n && target.name !== ch.n) { target.name = ch.n; } } catch (e2) {}
    } else {
        try { target = g.property(ch.i); } catch (e3) {}
        if (!target || target.matchName !== ch.mn) { try { target = g.property(ch.mn); } catch (e4) { target = null; } }
        if (!target) { try { if (g.canAddProperty(ch.mn)) { target = g.addProperty(ch.mn); } } catch (e5) {} }
        if (!target) { ctx.miss.push(ch.mn); return; }
    }
    idx = target.propertyIndex;
    getC = function () { var gg = getG(); return gg ? gg.property(idx) : null; };
    if (!ch.c) { MS.R.setProp(target, ch, t0, ctx); return; }
    // layer styles: a style exists on every layer but only switches on through Layer > Layer Styles
    if (ch.en === true && /\/group$/.test(ch.mn)) {
        try {
            if (!target.enabled) {
                var cmd = MS.R.STYLE_MENU[ch.mn.split("/")[0]], id = cmd ? app.findMenuCommandId(cmd) : 0;
                if (id) { MS.R.selectOnly(ctx.layer()); app.executeCommand(id); } else { ctx.miss.push("layer style " + ch.mn); }
            }
        } catch (e6) { ctx.miss.push("layer style " + ch.mn); }
    }
    if (ch.mask) {
        try { var m = getC(); m.maskMode = ch.mask.mode; m.inverted = !!ch.mask.inv; if (ch.mask.rb) { m.rotoBezier = true; } } catch (e7) {}
    }
    MS.R.applyGroup(getC, ch, t0, ctx);
    if (ch.en === false) { try { getC().enabled = false; } catch (e8) {} }
};
MS.R.selectOnly = function (l) {
    var c = l.containingComp, i;
    for (i = 1; i <= c.numLayers; i++) { c.layer(i).selected = false; }
    l.selected = true;
};
MS.R.applyTree = function (layerFn, tree, t0, ctx) {
    var i, ch;
    for (i = 0; i < tree.c.length; i++) {
        ch = tree.c[i];
        MS.R.applyChild(layerFn, ch, t0, ctx);
    }
};
MS.R.applyAttrs = function (l, attrs) {
    var k;
    for (k in attrs) { if (attrs.hasOwnProperty(k) && k !== "trackMatteType") { try { l[k] = attrs[k]; } catch (e) {} } }
};
// Instead of layer.applyPreset(<asset>): rebuild what the preset adds, at the comp's current time.
MS.R.applyPreset = function (layer, asset) {
    var r = MS.R.load(asset), c = layer.containingComp, li = layer.index, ctx;
    ctx = { miss: [], layer: function () { return c.layer(li); } };
    MS.R.applyAttrs(layer, r.attrs || {});
    MS.R.applyTree(ctx.layer, r.tree, c.time, ctx);
    MS.R.lastMissing = ctx.miss;
    return true;
};
// Instead of importing <asset>.aep: rebuild its comps (and pictures) in the project. Returns the comps made,
// the main (last) one last.
MS.R.buildProject = function (asset) {
    var r = MS.R.load(asset), made = {}, comps = [], i, it, miss = [];
    for (i = 0; i < r.items.length; i++) {
        it = r.items[i];
        if (it.type === "footage") { made[it.id] = MS.R.footage(it, miss); }
    }
    for (i = 0; i < r.items.length; i++) {
        it = r.items[i];
        if (it.type === "comp") { made[it.id] = MS.R.comp(it, made, miss); comps.push(made[it.id]); }
    }
    MS.R.lastMissing = miss;
    return comps;
};
MS.R.footage = function (it, miss) {
    var places = [Folder.userData.fsName + "/MotionSaasOS2/assets/", MS.OS2_DIR + "/"], i, f;
    for (i = 0; i < places.length; i++) {
        f = new File(places[i] + it.file);
        if (it.file && f.exists) { try { return app.project.importFile(new ImportOptions(f)); } catch (e) {} }
    }
    miss.push("picture " + it.file);
    return app.project.items.addComp(it.name || "Missing picture", Math.max(4, it.w || 100), Math.max(4, it.h || 100), 1, 1, 30);
};
MS.R.comp = function (it, made, miss) {
    var c = app.project.items.addComp(it.name, it.w, it.h, it.pa || 1, Math.max(it.dur || 1, 0.04), it.fps || 30), i, L, l, ctx, mkC;
    try { if (it.bg) { c.bgColor = it.bg; } c.motionBlur = !!it.mb; c.hideShyLayers = !!it.hs; } catch (e0) {}
    try { if (it.sa) { c.shutterAngle = it.sa; } } catch (e1) {}
    try { if (it.wad) { c.workAreaStart = it.was || 0; c.workAreaDuration = it.wad; } } catch (e2) {}
    try { if (it.ren) { c.renderer = it.ren; } } catch (e3) {}
    // bottom layer first: each new layer lands on top, so the order comes out as recorded
    for (i = it.layers.length - 1; i >= 0; i--) {
        L = it.layers[i];
        l = MS.R.newLayer(c, L, made, miss);
        try { l.name = L.nm; } catch (e4) {}
    }
    for (i = 0; i < it.layers.length; i++) {
        L = it.layers[i];
        l = c.layer(i + 1);
        try { l.startTime = L.st; if (L.sr && L.sr !== 100) { l.stretch = L.sr; } l.inPoint = L.ip; l.outPoint = L.op; } catch (e5) {}
        (function (index, rec) {
            var ctx2 = { miss: miss, layer: function () { return c.layer(index); } };
            MS.R.applyTree(ctx2.layer, rec.tree, 0, ctx2);
            MS.R.applyAttrs(c.layer(index), rec.attrs || {});
        })(i + 1, L);
    }
    for (i = 0; i < it.layers.length; i++) {
        L = it.layers[i];
        try { if (L.par) { c.layer(i + 1).parent = c.layer(L.par); } } catch (e6) {}
        try {
            if (L.attrs && L.attrs.trackMatteType && L.attrs.trackMatteType !== TrackMatteType.NO_TRACK_MATTE) {
                if (L.tml && typeof c.layer(i + 1).setTrackMatte === "function") { c.layer(i + 1).setTrackMatte(c.layer(L.tml), L.attrs.trackMatteType); }
                else { c.layer(i + 1).trackMatteType = L.attrs.trackMatteType; }
            }
        } catch (e7) { miss.push("track matte on " + L.nm); }
    }
    try { if (it.mk && it.mk.k) { MS.R.setProp(c.markerProperty, it.mk, 0, { miss: miss }); } } catch (e8) {}
    return c;
};
MS.R.newLayer = function (c, L, made, miss) {
    var l, d;
    if (L.type === "text") {
        l = c.layers.addText(L.td && L.td.text !== undefined ? String(L.td.text) : "");
        if (L.td) { try { d = l.property("ADBE Text Properties").property("ADBE Text Document"); d.setValue(MS.R.tdIn(d.value, L.td)); } catch (e) {} }
        return l;
    }
    if (L.type === "shape") { return c.layers.addShape(); }
    if (L.type === "camera") { return c.layers.addCamera(L.nm, [c.width / 2, c.height / 2]); }
    if (L.type === "light") { l = c.layers.addLight(L.nm, [c.width / 2, c.height / 2]); try { if (L.lt) { l.lightType = L.lt; } } catch (e2) {} return l; }
    if (L.type === "solid") { return c.layers.addSolid(L.color || [0, 0, 0], L.sname || L.nm, L.sw || c.width, L.sh || c.height, c.pixelAspect, c.duration); }
    if ((L.type === "comp" || L.type === "footage") && made[L.src]) { return c.layers.add(made[L.src]); }
    if (L.type !== "null") { miss.push("layer " + L.nm); }
    return c.layers.addNull(c.duration);
};
