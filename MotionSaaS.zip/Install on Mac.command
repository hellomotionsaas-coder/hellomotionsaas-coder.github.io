#!/bin/bash
# MotionSaaS installer for macOS — double-click to run (first time: right-click → Open).
cd "$(dirname "$0")" || exit 1

ID="com.motionsaas.panel"
DEST="$HOME/Library/Application Support/Adobe/CEP/extensions/$ID"

echo ""
echo "  Installing MotionSaaS for After Effects…"
echo ""

if [ ! -d "MotionSaaS" ]; then
  echo "  ✕ Can't find the MotionSaaS folder next to this installer. Unzip the whole download first."
  read -r -p "  Press Enter to close." _; exit 1
fi

# Allow unsigned extensions in every CEP version used by AE 2020 → 2026+.
for v in 9 10 11 12 13 14 15; do
  defaults write "com.adobe.CSXS.$v" PlayerDebugMode 1
done

rm -rf "$DEST"
mkdir -p "$(dirname "$DEST")"
cp -R "MotionSaaS" "$DEST"
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null

echo "  ✓ Installed to: $DEST"
echo ""
echo "  Restart After Effects, then open:  Window → Extensions → MotionSaaS"
echo ""
read -r -p "  Press Enter to close." _
