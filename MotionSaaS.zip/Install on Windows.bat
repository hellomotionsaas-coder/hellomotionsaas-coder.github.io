@echo off
REM MotionSaaS installer for Windows — double-click to run.
setlocal
set "ID=com.motionsaas.panel"
set "DEST=%APPDATA%\Adobe\CEP\extensions\%ID%"
set "SRC=%~dp0MotionSaaS"

echo.
echo   Installing MotionSaaS for After Effects...
echo.

if not exist "%SRC%\CSXS\manifest.xml" (
  echo   X Can't find the MotionSaaS folder next to this installer. Unzip the whole download first.
  pause
  exit /b 1
)

REM Allow unsigned extensions in every CEP version used by AE 2020 to 2026+.
for %%v in (9 10 11 12 13 14 15) do (
  reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
)

if exist "%DEST%" rmdir /s /q "%DEST%"
xcopy "%SRC%" "%DEST%\" /E /I /Y /Q >nul

echo   Installed to: %DEST%
echo.
echo   Restart After Effects, then open:  Window ^> Extensions ^> MotionSaaS
echo.
pause
